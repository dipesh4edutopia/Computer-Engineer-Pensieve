<map version="freeplane 1.7.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<attribute_registry SHOW_ATTRIBUTES="hide"/>
<node TEXT="Machine Learning" FOLDED="false" ID="ID_825489829" CREATED="1549259487616" MODIFIED="1563517277791" STYLE="oval">
<font NAME="Segoe Print" SIZE="18"/>
<hook NAME="MapStyle">
    <properties FIT_TO_VIEWPORT="false" SHOW_NOTE_ICONS="true" fit_to_viewport="false" show_icon_for_attributes="false" show_note_icons="true" EDGECOLORCONFIGURATION="#808080ff,#ff0000ff,#0000ffff,#00ff00ff,#ff00ffff,#00ffffff,#7c0000ff,#00007cff,#007c00ff,#7c007cff,#007c7cff,#7c7c00ff" edgeColorConfiguration="#808080ff,#808080ff,#808080ff,#808080ff,#808080ff,#808080ff,#808080ff,#808080ff,#808080ff,#808080ff,#808080ff,#808080ff"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt">
<font SIZE="24"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="default" ICON_SIZE="12.0 pt" COLOR="#000000" STYLE="fork">
<edge COLOR="#f06c27"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details"/>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes"/>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#000000" BACKGROUND_COLOR="#ffffff" TEXT_ALIGN="LEFT"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<cloud COLOR="#f0f0f0" SHAPE="ARC"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="styles.topic" COLOR="#f06c27" STYLE="fork"/>
<stylenode LOCALIZED_TEXT="styles.subtopic" COLOR="#f06c27" STYLE="fork"/>
<stylenode LOCALIZED_TEXT="styles.subsubtopic" COLOR="#f06c27"/>
<stylenode LOCALIZED_TEXT="styles.important"/>
<stylenode TEXT="mastersyl">
<edge COLOR="#f06c27" WIDTH="8"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000" STYLE="oval" SHAPE_HORIZONTAL_MARGIN="10.0 pt" SHAPE_VERTICAL_MARGIN="10.0 pt"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#0033ff"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#00b439"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" COLOR="#990000"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" COLOR="#111111"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" COLOR="#0033ff"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" COLOR="#0033ff"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" COLOR="#111111"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" COLOR="#0033ff"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" COLOR="#111111"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" COLOR="#0033ff"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11" COLOR="#111111"/>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook NAME="AutomaticEdgeColor" COUNTER="15" RULE="ON_BRANCH_CREATION"/>
<edge STYLE="sharp_bezier" WIDTH="2"/>
<node TEXT="Careers" LOCALIZED_STYLE_REF="styles.topic" POSITION="left" ID="ID_254229328" CREATED="1549348678517" MODIFIED="1562849392555" COLOR="#000e08">
<font NAME="Dialog"/>
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge WIDTH="8"/>
<node TEXT="Titles" ID="ID_361450953" CREATED="1549348685883" MODIFIED="1562235617683">
<font NAME="Dialog"/>
<edge WIDTH="2"/>
</node>
<node TEXT="LinkedIn" ID="ID_901850012" CREATED="1549366319193" MODIFIED="1562235642539">
<edge WIDTH="2"/>
<node TEXT="Groups" ID="ID_1028474751" CREATED="1549366324255" MODIFIED="1549366325936"/>
</node>
</node>
<node TEXT="Linked Maps" POSITION="left" ID="ID_1690093226" CREATED="1549349046590" MODIFIED="1562305279534">
<icon BUILTIN="mindmap"/>
<edge COLOR="#f06c27" WIDTH="8"/>
<richcontent TYPE="NOTE">

<html>
		  <head>
		  </head>
		  <body>
			<p>
			  How do you want to interact with the topic?
			</p>
			<p>
			  Accordingly, go to a particular mindmap
			</p>
		  </body>
		</html>
</richcontent>
<node TEXT="Be Motivated" ID="ID_1331859238" CREATED="1549348754107" MODIFIED="1562919497792" LINK="maps/b_1Be%20Motivated.mm">
<icon BUILTIN="mindmap"/>
<font NAME="Dialog"/>
</node>
<node TEXT="Experience" ID="ID_1622109081" CREATED="1549348758054" MODIFIED="1562919500685" LINK="maps/b_2Experience.mm">
<icon BUILTIN="mindmap"/>
<font NAME="Dialog"/>
</node>
<node TEXT="Understand" ID="ID_1713584934" CREATED="1549348762032" MODIFIED="1562919505445" LINK="maps/b_3Understand.mm">
<icon BUILTIN="mindmap"/>
<font NAME="Dialog"/>
</node>
<node TEXT="Remember" ID="ID_104961231" CREATED="1549348766178" MODIFIED="1562919503196" LINK="maps/b_4Remember.mm">
<icon BUILTIN="mindmap"/>
<font NAME="Dialog"/>
</node>
<node TEXT="Foster Creation" ID="ID_1583491843" CREATED="1549348772537" MODIFIED="1562919508811" LINK="maps/b_5Foster%20Creation.mm">
<icon BUILTIN="mindmap"/>
<font NAME="Dialog"/>
</node>
<node TEXT="Have Fun" ID="ID_1524614529" CREATED="1549348783213" MODIFIED="1562919511284" LINK="maps/b_6Have%20Fun.mm">
<icon BUILTIN="mindmap"/>
<font NAME="Dialog"/>
</node>
</node>
<node TEXT="Resources Collections" POSITION="right" ID="ID_92546246" CREATED="1549349223136" MODIFIED="1562238221141">
<attribute NAME="Type" VALUE="syllabus_point"/>
<richcontent TYPE="NOTE">

<html>
		  <head>
			
		  </head>
		  <body>
			<p>
			  These resource collections cover topics across the syllabus
			</p>
		  </body>
		</html>
</richcontent>
<edge COLOR="#f06c27" WIDTH="8"/>
<node TEXT="MOOCs" FOLDED="true" ID="ID_1189375431" CREATED="1549349235845" MODIFIED="1562238074753">
<icon BUILTIN="internet"/>
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge WIDTH="2"/>
<node TEXT="NPTL" ID="ID_1761169809" CREATED="1549353476830" MODIFIED="1549353480505">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="MOOCs MachineLearning#$D$#" FOLDED="true" ID="ID_953573754" CREATED="1557224068545" MODIFIED="1557224307481">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning | Coursera" FOLDED="true" ID="ID_323588431" CREATED="1557224068545" MODIFIED="1557224306216" LINK="https://www.coursera.org/learn/machine-learning">
<node TEXT="Machine learning is the science of getting computers to act without being explicitly programmed. In the past decade machine learning has given us self-driving cars practical speech recognition effective web search and a vastly improved understanding of the human genome." ID="ID_513701871" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Machine Learning MOOCs and Free Online Courses | MOOC List" FOLDED="true" ID="ID_642065212" CREATED="1557224068545" MODIFIED="1557224306217" LINK="https://www.mooc-list.com/tags/machine-learning">
<node TEXT="Machine learning is transforming the world around us. To become successful you&#x2019;d better know what kinds of problems can be solved with machine learning and how they can be solved. Don&#x2019;t know where to start? The answer is one button away." ID="ID_1708103533" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="What is the best MOOC to get started in Machine Learning " FOLDED="true" ID="ID_1040401711" CREATED="1557224068545" MODIFIED="1557224306217" LINK="https://www.quora.com/What-is-the-best-MOOC-to-get-started-in-Machine-Learning">
<node TEXT="So I recently wrote a blog post on this very topic which goes as follows. There are many-many MOOCs online related to Machine Learning. Be it stats or machine learning models or even core math there is a lot of content available online and for someone who is just starting with machine learning on their own it can become pretty daunting like it became for me." ID="ID_1475385740" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Learn Machine Learning | Free Online Courses | Class Central" FOLDED="true" ID="ID_1091353764" CREATED="1557224068545" MODIFIED="1557224306217" LINK="https://www.classcentral.com/subject/machine-learning">
<node TEXT="Learn Machine Learning with free online courses and MOOCs from Stanford University Goldsmiths University of London University of Washington Johns Hopkins University and other top universities around the world. Read reviews to decide if a class is right for you." ID="ID_1619892431" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Machine Learning (Coursera) | MOOC List" FOLDED="true" ID="ID_1159508903" CREATED="1557224068545" MODIFIED="1557224306217" LINK="https://www.mooc-list.com/course/machine-learning-coursera">
<node TEXT="Machine learning is the science of getting computers to act without being explicitly programmed. In the past decade machine learning has given us self-driving cars practical speech recognition effective web search and a vastly improved understanding of the human genome." ID="ID_1053646502" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="How to choose effective MOOCs for machine learning and " FOLDED="true" ID="ID_514930935" CREATED="1557224068545" MODIFIED="1557224306218" LINK="https://towardsdatascience.com/how-to-choose-effective-moocs-for-machine-learning-and-data-science-8681700ed83f">
<node TEXT="How to choose effective courses for machine learning and data science Advice for young professionals in non-CS field who wants to learn and contribute to data science/machine learning. Curated from personal experience." ID="ID_1258044307" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Top Machine Learning MOOCs and Online Lectures: A " FOLDED="true" ID="ID_1530921271" CREATED="1557224068545" MODIFIED="1557224306218" LINK="https://www.kdnuggets.com/2016/07/top-machine-learning-moocs-online-lectures.html">
<node TEXT="Everyone who gets going in Machine Learning (and Deep Learning) gets overwhelmed by the plethora of MOOCs available. Here I try to give a comprehensive survey of such courses available freely on the internet. You can take this post as an complementary to this and this previous posts. I will try to " ID="ID_1154662123" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Machine Learning | My Mooc" FOLDED="true" ID="ID_754332686" CREATED="1557224068545" MODIFIED="1557224306218" LINK="https://www.my-mooc.com/fr/mooc/machine-learning/">
<node TEXT="Machine learning is the science of getting computers to act without being explicitly programmed. In the past decade machine learning has given us self-driving cars practical speech recognition effective web search and a vastly improved understanding of the human genome." ID="ID_508944948" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Coursera | Online Courses From Top Universities. Join for Free" FOLDED="true" ID="ID_683874186" CREATED="1557224068545" MODIFIED="1557224306218" LINK="https://www.coursera.org/learn/machine-learning/home/welcome">
<node TEXT="1000+ courses from schools like Stanford and Yale - no application required. Build career skills in data science computer science business and more." ID="ID_884264465" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Which MOOCs : MachineLearning - reddit.com" FOLDED="true" ID="ID_1768582866" CREATED="1557224068545" MODIFIED="1557224306219" LINK="https://www.reddit.com/r/MachineLearning/comments/2rqv7x/which_moocs/">
<node TEXT="Which MOOCs (self.MachineLearning) submitted 4 years ago by NicolasGuacamole. It seems as though there are quite a few of Machine Learning / data science / statistics MOOCs starting soon. Im aware of Andrew Ngs course naturally and have looked briefly at others but as there are so many Im at a loss of which ones would be the most " ID="ID_628201973" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Life after Ngs and Hintons MOOCs : MachineLearning" FOLDED="true" ID="ID_968823988" CREATED="1557224068545" MODIFIED="1557224306219" LINK="https://www.reddit.com/r/MachineLearning/comments/2syv9p/life_after_ngs_and_hintons_moocs/">
<node TEXT="Hi Ive recently finished both these popular MOOCs on Coursera. Since then Ive been playing around with ML mainly using scikit-learn. Id like to learn more about the subject however and my ultimate goal is to study mostly Deep Learning Ive tried to read Murphys text but my math/stats skills are definitely too low." ID="ID_1463259164" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Free Online Course: Machine Learning from Coursera | Class " FOLDED="true" ID="ID_1281568110" CREATED="1557224068545" MODIFIED="1557224306219" LINK="https://www.classcentral.com/course/coursera-machine-learning-835">
<node TEXT="Machine learning is the science of getting computers to act without being explicitly programmed. In the past decade machine learning has given us self-driving cars practical speech recognition effective web search and a vastly improved understanding of the human genome. Machine learning is so pervasive today that you probably use it dozens of times a day without knowing it." ID="ID_1421893466" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
</node>
<node TEXT="NPTL MachineLearning#$D$#" ID="ID_1995002829" CREATED="1557224068545" MODIFIED="1557224307481">
<icon BUILTIN="stop-sign"/>
<node TEXT="NPTEL :: Computer Science and Engineering - NOC " FOLDED="true" ID="ID_1898549988" CREATED="1557224068545" MODIFIED="1557224306219" LINK="https://nptel.ac.in/courses/106106139/">
<node TEXT="We are piloting a new feature with VideoKen to provide a Table of Contents and Word-Cloud for videos. For regular video without these features you can Watch on YouTube." ID="ID_676626548" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="NPTEL :: Computer Science and Engineering - NOC " FOLDED="true" ID="ID_1610126517" CREATED="1557224068545" MODIFIED="1557224306219" LINK="https://nptel.ac.in/courses/106105152/">
<node TEXT="Concepts covered in this lecture : This lecture gives an overview of the course and its organization.This is followed by a brief discussion of the history of machine learning and its relevance in the present day world." ID="ID_216117930" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Introduction to Machine Learning - Course" FOLDED="true" ID="ID_863120677" CREATED="1557224068545" MODIFIED="1557224306219" LINK="https://onlinecourses.nptel.ac.in/noc18_cs40/preview">
<node TEXT="This course provides a concise introduction to the fundamental concepts in machine learning and popular machine learning algorithms. We will cover the standard and most popular supervised learning algorithms including linear regression logistic regression decision trees k-nearest neighbour an introduction to Bayesian learning and the na&#xef;ve Bayes algorithm support vector machines and " ID="ID_225484842" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Introduction to Machine Learning - Course - NPTEL" FOLDED="true" ID="ID_491709401" CREATED="1557224068545" MODIFIED="1557224306220" LINK="https://onlinecourses.nptel.ac.in/noc16_cs03/preview">
<node TEXT="Introduction to Machine Learning ABOUT THE COURSE With the increased availability of data from varied sources there has been increasing attention paid to the various data driven disciplines such as analytics and machine learning. In this course we intend to introduce some of the basic concepts of machine learning from a mathematically well motivated perspective." ID="ID_517505665" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Introduction - YouTube" FOLDED="true" ID="ID_1949311560" CREATED="1557224068545" MODIFIED="1557224306220" LINK="https://www.youtube.com/watch?v=T3PsRW6wZSY">
<node TEXT="47 videos Play all Introduction to machine learning NPTEL Prof. S. Sarkar IIT Kharagpur Prabu Duplex How to Learn Anything Fast - Josh Kaufman - Duration: 23:20." ID="ID_507592628" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="How is the NPTEL machine learning course? - Quora" FOLDED="true" ID="ID_675710909" CREATED="1557224068545" MODIFIED="1557224306220" LINK="https://www.quora.com/How-is-the-NPTEL-machine-learning-course">
<node TEXT="Machine learning is taking over the world- and with that there is a growing need among companies for professionals to know the ins and outs of machine learning; The machine learning market size is expected to grow from USD 1.03 Billion in 2016 to USD 8.81 Billion by 2022 at a Compound Annual Growth Rate (CAGR) of 44.1% during the forecast period" ID="ID_1601398703" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Free Online Course: Machine LearningML from NPTEL | Class " FOLDED="true" ID="ID_100978753" CREATED="1557224068545" MODIFIED="1557224306220" LINK="https://www.classcentral.com/course/nptel-machine-learning-ml-12945">
<node TEXT="The scientific discipline of Machine Learning focuses on developing algorithms to find patterns or make predictions from empirical data. It is a classical sub-discipline within Artificial Intelligence (AI)." ID="ID_1683629522" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="PG Diploma in Machine Learning and AI - UpGrad" FOLDED="true" ID="ID_1894557079" CREATED="1557224068545" MODIFIED="1557224306220" LINK="https://www.upgrad.com/machine-learning-and-artificial-intelligence/">
<node TEXT="Get most in-demand certification with the upGrad Post Graduate Diploma in Machine Learning and Artificial Intelligence in association with IIIT Bangalore. Develop skills such as Machine learning Deep learning Graphical models etc. Enrol today!" ID="ID_897501257" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Introduction - YouTube" FOLDED="true" ID="ID_1550877960" CREATED="1557224068545" MODIFIED="1557224306220" LINK="https://www.youtube.com/watch?v=BRMS3T11Cdw">
<node TEXT="70+ channels unlimited DVR storage space 6 accounts for your home all in one great price." ID="ID_1387828435" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Machine Learning in R for beginners (article) - DataCamp" FOLDED="true" ID="ID_210397869" CREATED="1557224068545" MODIFIED="1557224306221" LINK="https://www.datacamp.com/community/tutorials/machine-learning-in-r">
<node TEXT="Machine learning is a branch in computer science that studies the design of algorithms that can learn. Typical machine learning tasks are concept learning function learning or &#x201c;predictive modeling&#x201d; clustering and finding predictive patterns. These tasks are learned through available data that were observed through experiences or " ID="ID_963228590" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Machine Learning | Electrical Engineering and Computer " FOLDED="true" ID="ID_1442053169" CREATED="1557224068545" MODIFIED="1557224306221" LINK="https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-867-machine-learning-fall-2006/">
<node TEXT="6.867 is an introductory course on machine learning which gives an overview of many concepts techniques and algorithms in machine learning beginning with topics such as classification and linear regression and ending up with more recent topics such as boosting support vector machines hidden Markov models and Bayesian networks. The course will give the student the basic ideas and " ID="ID_1328332732" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
<node TEXT="Intro to Machine Learning | Udacity" FOLDED="true" ID="ID_1849718551" CREATED="1557224068545" MODIFIED="1557224306221" LINK="https://in.udacity.com/course/intro-to-machine-learning--ud120-india">
<node TEXT="Udacitys Machine Learning Foundation Nanodegree is your first step towards careers in Data Analysis Data Science Machine Learning AI and more! This Nanodegree helps you learn Python and Statistics. It consists of 4 projects and is perfect for beginners in the field of data. View Details" ID="ID_1821685024" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
</node>
<node TEXT="Open Educational Resources MachineLearning#$D$#" FOLDED="true" ID="ID_644694846" CREATED="1557224068547" MODIFIED="1557224307483">
<icon BUILTIN="stop-sign"/>
<node TEXT="Open Educational Resources&#xff0c;O.E.R &#x2013; Classroom Aid" FOLDED="true" ID="ID_746523927" CREATED="1557224068547" MODIFIED="1557224306242" LINK="https://classroom-aid.com/open-educational-resources/">
<node TEXT="Open educational resources&#xff0c;O.E.R are teaching learning and research resources that reside in the public domain or creative common area and are freely available to anyone over the Web.They are an important element of an infrastructure for learning and range from podcasts to digital libraries to textbooks and games." ID="ID_1713548307" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Big List of Resources - OER - Open Educational Resources " FOLDED="true" ID="ID_542180264" CREATED="1557224068547" MODIFIED="1557224306242" LINK="https://pitt.libguides.com/openeducation/biglist">
<node TEXT="Open Educational Resources (OER) are any type of educational material that are freely available for teachers and students to use adapt share and reuse." ID="ID_391313438" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="OER Commons" FOLDED="true" ID="ID_1480234049" CREATED="1557224068547" MODIFIED="1557224306242" LINK="https://www.oercommons.org/">
<node TEXT="OER Commons is a dynamic digital library and network. Explore open education resources and join our network of educators dedicated to curriculum improvement." ID="ID_212258813" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Open Educational Resources (OER): Resource Roundup | Edutopia" FOLDED="true" ID="ID_47723638" CREATED="1557224068547" MODIFIED="1557224306242" LINK="https://www.edutopia.org/open-educational-resources-guide">
<node TEXT="A Tour of High-Quality Open Education Resources (OER) for Writing by Todd Finley (2012) Finley leads an engaging tour of open educational resources for any teacher who wants his or her students to be better writers. Open Educational Resources for Educators by Matt Davis (2013)" ID="ID_367669959" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="List of open education resources online | Opensource.com" FOLDED="true" ID="ID_478223338" CREATED="1557224068547" MODIFIED="1557224306242" LINK="https://opensource.com/education/13/4/guide-open-source-education">
<node TEXT="Other sources for open education resources. Universities. The University of Cambridges guide on Open Educational Resources for Teacher Education (ORBIT) OpenLearn from Open University in the UK; Global. Unescos searchable open database is a portal to worldwide courses and research initiatives" ID="ID_1459004562" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Office of Virtual Education - elearningscpd.com" FOLDED="true" ID="ID_522585648" CREATED="1557224068547" MODIFIED="1557224306242" LINK="https://www.elearningscpd.com/portal/wp-content/uploads/2018/07/Open-Education-Resources-Syllabus1.pdf">
<node TEXT="Open Educational Resources for Teachers . is a course for teachers that explores free online educational resources. There are a myriad of online educational resources available to educators today. Locating and deciding how best to use them can be difficult and time-consuming to do without the proper guidance." ID="ID_1298002410" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Open Educational Resources &#x2013; The City University of New York" FOLDED="true" ID="ID_912160206" CREATED="1557224068547" MODIFIED="1557224306243" LINK="https://www2.cuny.edu/libraries/open-educational-resources/">
<node TEXT="Of particular interest are proposals that target high enrollment general education classes or &#x201c;Z&#x201d; degrees (entire OER Zero Cost Degree pathways). The Office of Academic Affairs is funding a number of grants to the colleges to implement course conversion to Open Educational Resources." ID="ID_1956456904" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Open educational resources - Wikipedia" FOLDED="true" ID="ID_297187400" CREATED="1557224068547" MODIFIED="1557224306243" LINK="https://en.wikipedia.org/wiki/Open_educational_resources">
<node TEXT="Open educational resources (OER) are freely accessible openly licensed text media and other digital assets that are useful for teaching learning and assessing as well as for research purposes. There is no universal usage of open file formats in OER.. The term OER describes publicly accessible materials and resources for any user to use re-mix improve and redistribute under some licenses." ID="ID_868434823" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Adult Education and Literacy Open Education Resources" FOLDED="true" ID="ID_771828468" CREATED="1557224068547" MODIFIED="1557224306243" LINK="https://tcall.tamu.edu/OpenEducationResources.html">
<node TEXT="Open Education Resources: A Fact Sheet for Adult Education; National OER Resources. OER Commons &#x2013; This website is a public digital library of open educational resources. Tools are available to help educators create share and collaborate on the development of instructional materials." ID="ID_1598798111" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="13 Best Open Education Resources images | Learning " FOLDED="true" ID="ID_148504155" CREATED="1557224068547" MODIFIED="1557224306243" LINK="https://www.pinterest.com/oyaxela/open-education-resources/">
<node TEXT="Open Education Resources What others are saying The e-Learning software learning management systems (LMS) and online computer based training solution of choice for Global 2000 companies in 70 countries." ID="ID_1587905843" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Open Education - Office of Educational Technology" FOLDED="true" ID="ID_1009060383" CREATED="1557224068547" MODIFIED="1557224306245" LINK="https://tech.ed.gov/open/">
<node TEXT="Openly Licensed Educational Resources. In the 2017 National Education Technology Plan the Department defines openly licensed educational resources as teaching learning and research resources that reside in the public domain or have been released under a license that permits their free use reuse modification and sharing with others." ID="ID_991854510" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="What Is OER? Answers to 5 Questions About Open Educational " FOLDED="true" ID="ID_827274302" CREATED="1557224068547" MODIFIED="1557224306246" LINK="https://www.edweek.org/ew/articles/2017/03/29/what-is-oer-5-questions-about-open-oer.html">
<node TEXT="Answers to 5 Questions About Open Educational Resources. By Sarah D. Sparks. March 28  Open educational resources are materials for teaching or learning that are either in the public domain or " ID="ID_139751206" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
</node>
</node>
<node TEXT="Coursera" ID="ID_639474338" CREATED="1549353481373" MODIFIED="1549353485342">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Machine Learning | Coursera" FOLDED="true" ID="ID_749605394" CREATED="1557224068545" MODIFIED="1557224306221" LINK="https://www.coursera.org/learn/machine-learning">
<node TEXT="Machine learning is the science of getting computers to act without being explicitly programmed. In the past decade machine learning has given us self-driving cars practical speech recognition effective web search and a vastly improved understanding of the human genome." ID="ID_299576068" CREATED="1557224068545" MODIFIED="1557224068545"/>
</node>
</node>
<node TEXT="Edx" ID="ID_81466374" CREATED="1549353488815" MODIFIED="1549353502078">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Edx MachineLearning#$D$#" FOLDED="true" ID="ID_1519396078" CREATED="1557224068546" MODIFIED="1557224307481">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning: Online Courses from Harvard MIT  - edX" FOLDED="true" ID="ID_1869632884" CREATED="1557224068546" MODIFIED="1557224306223" LINK="https://www.edx.org/learn/machine-learning">
<node TEXT="The software can make decisions and follow a path that is not specifically programmed. Machine learning is used within the field of data analytics to make predictions based on trends and insights in the data. A prime example of the application of machine learning is the autonomous vehicle." ID="ID_1450200214" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Machine Learning - edX" FOLDED="true" ID="ID_17935109" CREATED="1557224068546" MODIFIED="1557224306223" LINK="https://www.edx.org/course/machine-learning-columbiax-csmm-102x-0">
<node TEXT="Master the essentials of machine learning and algorithms to help improve learning from data without human intervention. Master the essentials of machine learning and algorithms to help improve learning from data without human intervention." ID="ID_998702152" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Machine Learning for Data Science and Analytics - edx.org" FOLDED="true" ID="ID_1550012428" CREATED="1557224068546" MODIFIED="1557224306223" LINK="https://www.edx.org/course/machine-learning-for-data-science-and-analytics">
<node TEXT="Machine Learning is a growing field that is used when searching the web placing ads credit scoring stock trading and for many other applications. This data science course is an introduction to machine learning and algorithms." ID="ID_1496386570" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Free Online Course: Machine Learning from edX | Class Central" FOLDED="true" ID="ID_1923547244" CREATED="1557224068546" MODIFIED="1557224306223" LINK="https://www.classcentral.com/course/edx-machine-learning-7231">
<node TEXT="Machine Learning is the basis for the most exciting careers in data analysis today. You&#x2019;ll learn the models and methods and apply them to real world situations ranging from identifying trending news topics to building recommendation engines ranking sports teams and plotting the path of movie zombies." ID="ID_132356098" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Machine Learning Studio | Microsoft Azure" FOLDED="true" ID="ID_555815214" CREATED="1557224068546" MODIFIED="1557224306223" LINK="https://azure.microsoft.com/en-us/services/machine-learning-studio/">
<node TEXT="Welcome to Machine Learning Studio the Azure Machine Learning solution you&#x2019;ve grown to love. Machine Learning Studio is a powerfully simple browser-based visual drag-and-drop authoring environment where no coding is necessary. Go from idea to deployment in a matter of clicks." ID="ID_1095010896" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Machine Learning | Coursera" FOLDED="true" ID="ID_1965758488" CREATED="1557224068546" MODIFIED="1557224306223" LINK="https://www.coursera.org/learn/machine-learning">
<node TEXT="Machine learning is the science of getting computers to act without being explicitly programmed. In the past decade machine learning has given us self-driving cars practical speech recognition effective web search and a vastly improved understanding of the human genome." ID="ID_822755658" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Microsoft Azure Machine Learning Studio" FOLDED="true" ID="ID_666754499" CREATED="1557224068546" MODIFIED="1557224306223" LINK="https://studio.azureml.net/">
<node TEXT="Azure Machine Learning Studio is a GUI-based integrated development environment for constructing and operationalizing Machine Learning workflow on Azure." ID="ID_1938428114" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Coursera | Online Courses From Top Universities. Join for Free" FOLDED="true" ID="ID_204756642" CREATED="1557224068546" MODIFIED="1557224306224" LINK="https://www.coursera.org/learn/machine-learning/home/welcome">
<node TEXT="1000+ courses from schools like Stanford and Yale - no application required. Build career skills in data science computer science business and more." ID="ID_1278806507" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Course | UTQML101x | edX" FOLDED="true" ID="ID_832874122" CREATED="1557224068546" MODIFIED="1557224306224" LINK="https://courses.edx.org/courses/course-v1:University_of_TorontoX+UTQML101x+1T2019/course/">
<node TEXT="Course End. This course is archived which means you can review course content but it is no longer active." ID="ID_1164561452" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Course | DSE220x | edX" FOLDED="true" ID="ID_1736443407" CREATED="1557224068546" MODIFIED="1557224306224" LINK="https://courses.edx.org/courses/course-v1:UCSanDiegoX+DS220x+1T2018/course/">
<node TEXT="Course End. This course is archived which means you can review course content but it is no longer active." ID="ID_1133289693" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Data Science: Machine Learning | Harvard University" FOLDED="true" ID="ID_348393841" CREATED="1557224068546" MODIFIED="1557224306224" LINK="https://online-learning.harvard.edu/course/data-science-machine-learning">
<node TEXT="What distinguishes machine learning from other computer guided decision processes is that it builds prediction algorithms using data. Some of the most popular products that use machine learning include the handwriting readers implemented by the postal service speech recognition movie recommendation systems and spam detectors." ID="ID_1460194219" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Machine Learning (edX) | MOOC List" FOLDED="true" ID="ID_1949541298" CREATED="1557224068546" MODIFIED="1557224306224" LINK="https://www.mooc-list.com/course/machine-learning-edx">
<node TEXT="Master the essentials of machine learning and algorithms to help improve learning from data without human intervention. Machine Learning is the basis for the most exciting careers in data analysis today. You&#x2019;ll learn the models and methods and apply them to real world situations ranging from identifying trending news topics to building recommendation engines ranking sports" ID="ID_780155772" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
</node>
</node>
<node TEXT="Interactive Tutorials" ID="ID_1787381068" CREATED="1549362426501" MODIFIED="1549495489512">
<attribute NAME="Type" VALUE="syllabus_point"/>
<richcontent TYPE="NOTE">

<html>
			  <head>
				
			  </head>
			  <body>
				<p>
				  Learn by doing. Gamified Tutorials
				</p>
			  </body>
			</html>
</richcontent>
<node TEXT="Interactive Tutorials MachineLearning#$D$#" ID="ID_1759047649" CREATED="1557224068546" MODIFIED="1557224307482">
<icon BUILTIN="stop-sign"/>
<node TEXT="A visual introduction to machine learning" FOLDED="true" ID="ID_1254734024" CREATED="1557224068546" MODIFIED="1557224306226" LINK="http://www.r2d3.us/visual-intro-to-machine-learning-part-1/">
<node TEXT="In machine learning computers apply statistical learning techniques to automatically identify patterns in data. These techniques can be used to make highly accurate predictions. Keep scrolling. Using a data set about homes we will create a machine learning model to distinguish homes in New York from homes in San Francisco." ID="ID_1081844424" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Interactive Machine Learning" FOLDED="true" ID="ID_1318320198" CREATED="1557224068546" MODIFIED="1557224306226" LINK="https://iml.media.mit.edu/">
<node TEXT="MAS.S62 Interactive Machine Learning (0-12-0) H-Level Fall 2013 Instructor: Dr. Brad Knox (principal) with Prof. Cynthia Breazeal (and early critical help from Dr. Nick Gillian) Samples of student work. Thanks to all of my fantastic students and our inspiring guest speakers this semester." ID="ID_848937972" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Learn #MachineLearning Coding Basics in a weekend &#x2013; a new " FOLDED="true" ID="ID_881357430" CREATED="1557224068546" MODIFIED="1557224306226" LINK="https://www.datasciencecentral.com/profiles/blogs/learn-machinelearning-coding-basics-in-a-weekend-a-new-approach">
<node TEXT="Learn #MachineLearning Coding Basics in a weekend &#x2013; a new approach to coding for #AI  are launching a new free online interactive book called Learn Machine Learning Coding Basics in a weekend.  We will also introduce to keep machine learning libraries in python and demonstrate code that can be used on your own problems. We will cover " ID="ID_572157101" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="A Machine Learning Tutorial with Examples | Toptal" FOLDED="true" ID="ID_904873610" CREATED="1557224068546" MODIFIED="1557224306226" LINK="https://www.toptal.com/machine-learning/machine-learning-theory-an-introductory-primer">
<node TEXT="Nicholas is a professional software engineer with a passion for quality craftsmanship. He loves architecting and writing top-notch code. Machine Learning (ML) is coming into its own with a growing recognition that ML can play a key role in a wide range of critical applications such as data mining " ID="ID_586963796" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Learn Python - Free Interactive Python Tutorial" FOLDED="true" ID="ID_82144228" CREATED="1557224068546" MODIFIED="1557224306226" LINK="https://www.learnpython.org/">
<node TEXT="This site generously supported by DataCamp.DataCamp offers online interactive Python Tutorials for Data Science. Join 575000 other learners and get started learning Python for data science today!. Welcome. Welcome to the LearnPython.org interactive Python tutorial. Whether you are an experienced programmer or not this website is intended for everyone who wishes to learn the Python " ID="ID_1721396465" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Interactive Machine Learning: Make Python &#x2018;Lively&#x2019; Again" FOLDED="true" ID="ID_1899826255" CREATED="1557224068546" MODIFIED="1557224306227" LINK="https://towardsdatascience.com/interactive-machine-learning-make-python-lively-again-a96aec7e1627">
<node TEXT="Interactive Machine Learning: Make Python &#x2018;Lively&#x2019; Again Notebooks come alive when interactive widgets are used. Users can visualize and control changes in the data and the model. Learning becomes an immersive plus fun experience." ID="ID_1792489245" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Interactive tutorial: generative adversarial networks for " FOLDED="true" ID="ID_1897146731" CREATED="1557224068546" MODIFIED="1557224306227" LINK="https://www.reddit.com/r/MachineLearning/comments/6fxbcr/interactive_tutorial_generative_adversarial/">
<node TEXT="When youve got a chance though I encourage you to come back to the interactive tutorial on a PC; were really excited about the combination of video and no-install interactivity for exploring new topics." ID="ID_800563743" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="What is Machine Learning? | Machine Learning Basics " FOLDED="true" ID="ID_1368571390" CREATED="1557224068546" MODIFIED="1557224306227" LINK="https://www.youtube.com/watch?v=Pj0neYUp9Tc">
<node TEXT="Below are the topics covered in this tutorial: 1. Evolution of Machine Learning 2. What is Machine Learning? 3. Types of Machine Learning 4. Supervised Learning 5. Unsupervised Learning 6 " ID="ID_454060978" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="[D] Official Kaggle Learn - Interactive tutorials on " FOLDED="true" ID="ID_1761424627" CREATED="1557224068546" MODIFIED="1557224306227" LINK="https://www.reddit.com/r/MachineLearning/comments/7qxjo3/d_official_kaggle_learn_interactive_tutorials_on/">
<node TEXT="The MachineLearning community on Reddit. Reddit gives you the best of the internet in one place.  Official Kaggle Learn - Interactive tutorials on Machine Learning Deep Learning R and Data Visualization. submitted 1 year ago by sksq9. comment " ID="ID_1663181672" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Practical Machine Learning Tutorial with Python Intro p.1 " FOLDED="true" ID="ID_177769445" CREATED="1557224068546" MODIFIED="1557224306227" LINK="https://www.youtube.com/watch?v=OGxgnH8y2NM">
<node TEXT="The objective of this course is to give you a holistic understanding of machine learning covering theory application and inner workings of supervised unsupervised and deep learning algorithms " ID="ID_1798097749" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="R2D3: Statistics and Data Visualization" FOLDED="true" ID="ID_1808701950" CREATED="1557224068546" MODIFIED="1557224306228" LINK="http://www.r2d3.us/">
<node TEXT="Tony visualizes with D3. Tony is a designer who loves data visualizations and information design. He is currently a Principal Designer at Noodle Analytics.Prior to Noodle Tony led user experience and product design at H2O and at Sift Science.He holds an MFA in Interaction Design at the School of Visual Arts in New York City where he tried to change congress with a fancy infographic." ID="ID_61539130" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="The Real World Interactive Learning Tutorial &#xab; Machine " FOLDED="true" ID="ID_820620390" CREATED="1557224068546" MODIFIED="1557224306228" LINK="http://hunch.net/?p=7435592">
<node TEXT="The Real World Interactive Learning Tutorial Alekh and I have been polishin the Real World Interactive Learning tutorial for ICML 2017 on Sunday. This tutorial should be of pretty wide interest. For data scientists we are crossing a threshold into easy use of interactive learning while for researchers interactive learning is plausibly the most " ID="ID_36705815" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
</node>
</node>
</node>
<node TEXT="Books" ID="ID_385808776" CREATED="1549349297473" MODIFIED="1562238083042">
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge WIDTH="2"/>
<node TEXT="Textbooks" ID="ID_1588905743" CREATED="1549349325202" MODIFIED="1549349329997"/>
<node TEXT="Reference" ID="ID_392151613" CREATED="1549349330856" MODIFIED="1549349333718"/>
</node>
<node TEXT="Podcasts" FOLDED="true" ID="ID_1585955003" CREATED="1549277416643" MODIFIED="1562677641314">
<icon BUILTIN="audio"/>
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Podcasts MachineLearning#$D$#" ID="ID_1226531116" CREATED="1557224068546" MODIFIED="1557224307482">
<icon BUILTIN="stop-sign"/>
<node TEXT="5 Top Machine Learning Podcasts" FOLDED="true" ID="ID_830439976" CREATED="1557224068546" MODIFIED="1557224306228" LINK="https://machinelearningmastery.com/machine-learning-podcasts/">
<node TEXT="Machine learning podcasts are now a thing. There are now enough of us interested in this obscure geeky topic that there are podcasts dedicated to chatting about the ins and outs of predictive modeling. There has never been a better time to get started and working in this amazing field. In this post " ID="ID_865752070" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="&#x200e;Machine Learning on Apple Podcasts" FOLDED="true" ID="ID_925854542" CREATED="1557224068546" MODIFIED="1557224306228" LINK="https://podcasts.apple.com/us/podcast/machine-learning/id384233048">
<node TEXT="&#x200e;This course provides a broad introduction to machine learning and statistical pattern recognition. The course also discusses recent applications of machine learning such as to robotic control data mining autonomous navigation bioinformatics speech recognition and text and web data processing.&#x2026;" ID="ID_450110512" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="&#x200e;Machine Learning Guide on Apple Podcasts" FOLDED="true" ID="ID_1728193007" CREATED="1557224068546" MODIFIED="1557224306228" LINK="https://podcasts.apple.com/us/podcast/machine-learning-guide/id1204521130">
<node TEXT="This podcast helped me to Index retrieve solidify and present back my understanding to my team colleagues and friends . The way it is presented makes me think link my understanding of ML from MOOC courses YouTube videos books etc. and enjoy the Machine Learning beauty." ID="ID_1637532582" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Katharine Jarmul and Ethical Machine Learning - infoq.com" FOLDED="true" ID="ID_978139051" CREATED="1557224068546" MODIFIED="1557224306228" LINK="https://www.infoq.com/podcasts/ethical-machine-learning">
<node TEXT="Today on The InfoQ Podcast Wes talks with Katharine Jarmul about privacy and fairness in machine learning algorithms. Jarmul discusses what&#x2019;s meant by Ethical Machine Learning and some things " ID="ID_1536258408" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="10 Data Science Machine Learning and AI Podcasts You Must " FOLDED="true" ID="ID_1887035147" CREATED="1557224068546" MODIFIED="1557224306228" LINK="https://www.analyticsvidhya.com/blog/2018/01/10-data-science-machine-learning-ai-podcasts-must-listen/">
<node TEXT="10 Data Science Machine Learning and AI Podcasts You Must Listen To Pranav Dar  January 21 2018 With the rapid pace at which technology is driving innovation in machine learning and artificial intelligence it has become immensely important to keep pace with the ongoing trends in data science." ID="ID_1203773144" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="5 Data Science AI and Machine Learning Podcasts to Listen " FOLDED="true" ID="ID_133629289" CREATED="1557224068546" MODIFIED="1557224306229" LINK="https://towardsdatascience.com/5-data-science-ai-and-machine-learning-podcasts-to-listen-to-now-e5078b18d184">
<node TEXT="My twitter feed is a testament to the amount of news articles I read but my favorite way to consume data science news is via podcast. In this blog I share with you some of my favorite AI and machine learning podcasts so that you too can stay up-to-date on the latest trends in the field." ID="ID_706312515" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Best Machinelearning Podcasts (2019) - player.fm" FOLDED="true" ID="ID_1973014862" CREATED="1557224068546" MODIFIED="1557224306229" LINK="https://player.fm/podcasts/machinelearning">
<node TEXT="Top Machinelearning podcasts for 2019. In this episode of the ARCHITECHT Show Dan Kohn (executive director of the Cloud Native Computing Foundation) and Sarah Novotny (head of open source strategy for Google Cloud Platform) discuss some recent Kubernetes news and CNCF survey results." ID="ID_915443512" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Top 10 Podcasts on Machine Learning  AI that you must follow" FOLDED="true" ID="ID_1387696278" CREATED="1557224068546" MODIFIED="1557224306229" LINK="https://www.analyticsindiamag.com/top-10-podcasts-machine-learning-ai-must-follow/">
<node TEXT="Podcasts have emerged as an important medium to share information through. Though not as popular as the video there are tons of very interesting podcasts that are being produced regularly. So we decided to hand-curate a list of interesting and popular podcasts around the topic of AI and machine learning. Do give a listen! Talking Machines" ID="ID_981344960" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Must Listen: Five Podcasts on Machine Learning | Georgian " FOLDED="true" ID="ID_278292822" CREATED="1557224068546" MODIFIED="1557224306229" LINK="https://georgianpartners.com/five-must-listen-podcasts-on-machine-learning/">
<node TEXT="The Future of Machine Learning. If you&#x2019;re just getting started with the wide world of machine learning this is a great jumping-off point. Inmar Givoni is director of machine learning at Kindred.ai a company that is building systems that enable robots to understand and participate in our world. In this episode of our own Impact Podcast she " ID="ID_845461411" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="[D] Best Machine Learning Podcasts? : MachineLearning" FOLDED="true" ID="ID_603233433" CREATED="1557224068546" MODIFIED="1557224306229" LINK="https://www.reddit.com/r/MachineLearning/comments/8klbbf/d_best_machine_learning_podcasts/">
<node TEXT="Podcast Addict is nice. You can subscribe to your podcasts set it to auto-update only on WiFi at certain times of day (7am for me) have it auto-delete episodes when you finish listening etc. Lots of little features like that." ID="ID_1890102173" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="This Week in Machine Learning  AI - YouTube" FOLDED="true" ID="ID_1577105952" CREATED="1557224068546" MODIFIED="1557224306229" LINK="https://www.youtube.com/channel/UC7kjWIK1H8tfmFlzZO-wHMw">
<node TEXT="This Week in #MachineLearning  #AI (podcast) brings you the week&#x2019;s most interesting and important stories from the world of #ML and artificial intelligence." ID="ID_1452752823" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Machine Learning  Podcasts  Page #1 - InfoQ.com" FOLDED="true" ID="ID_951085950" CREATED="1557224068546" MODIFIED="1557224306229" LINK="https://www.infoq.com/MachineLearning/podcasts/">
<node TEXT="Megan Cartwright on Building a Machine Learning MVP at an Early Stage Startup. In this podcast Megan Cartwright discusses why their customers need a more personal experience and how theyre using " ID="ID_1923947562" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
</node>
</node>
<node TEXT="OERs" FOLDED="true" ID="ID_946019505" CREATED="1549359102496" MODIFIED="1562238141081">
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge WIDTH="2"/>
<node TEXT="National Digital Library" ID="ID_1312359689" CREATED="1549359120158" MODIFIED="1562919713878" LINK="https://ndl.iitkgp.ac.in/">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="National Digital Library  MachineLearning#$D$#" FOLDED="true" ID="ID_1917312460" CREATED="1557224068547" MODIFIED="1557224307483">
<icon BUILTIN="stop-sign"/>
<node TEXT="National Digital Library of India" FOLDED="true" ID="ID_350249555" CREATED="1557224068547" MODIFIED="1557224306246" LINK="https://ndl.iitkgp.ac.in/">
<node TEXT="Ministry of Human Resource Development (MHRD) under its National Mission on Education through Information and Communication Technology (NMEICT) has initiated the National Digital Library of India (NDL India) pilot project to develop a framework of virtual repository of learning resources with a single-window search facility." ID="ID_1246828118" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="National Digital Library of India all set to Collab " FOLDED="true" ID="ID_1161236168" CREATED="1557224068547" MODIFIED="1557224306246" LINK="https://www.theindianwire.com/education/national-digital-library-india-set-collab-globally-digital-libraries-world-68026/">
<node TEXT="The National Digital Library of India (NDLI) is planning to go global and has collaborated with many top digital libraries of the world. The information was given as a written reply in Rajya Sabha by the Minister of State (HRD) DR Satya Pal Singh. He further stated that the NDLI has entered into a Memorandum [&#x2026;]" ID="ID_1092302895" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="National Geographic Virtual Library - gale.com" FOLDED="true" ID="ID_97267528" CREATED="1557224068547" MODIFIED="1557224306246" LINK="https://www.gale.com/primary-sources/national-geographic-virtual-library">
<node TEXT="National Geographic and Gale have partnered to bring vast resources to digital life with National Geographic Virtual Library. Now libraries can offer access to the complete archive of National Geographic magazine &#x2014; every page of every issue &#x2014; along with a cross-searchable collection of books maps images and videos." ID="ID_1235722911" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="National Digital Library of India - Home | Facebook" FOLDED="true" ID="ID_848410965" CREATED="1557224068547" MODIFIED="1557224306246" LINK="https://www.facebook.com/NDLIndia/">
<node TEXT="The NDLI-UNESCO International Symposium on Knowledge Engineering for Digital Library Design 2019 is second in the series of knowledge sharing events coordinated by National Digital Library of India. This workshop will focus on technologies and strategies for nurturing open culture in the realm of digital library." ID="ID_1902551947" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="National Digital Library of India - Wikipedia" FOLDED="true" ID="ID_535508053" CREATED="1557224068547" MODIFIED="1557224306247" LINK="https://en.wikipedia.org/wiki/National_Digital_Library_of_India">
<node TEXT="The National Digital library of India (NDLI) is a project under Ministry of Human Resource Development India.The objective is to integrate several national and international digital libraries in one single web-portal. The NDLI provides free of cost access to many books in English and the Indian languages." ID="ID_1181443141" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="National Digital Library Program - Wikipedia" FOLDED="true" ID="ID_115595735" CREATED="1557224068547" MODIFIED="1557224306247" LINK="https://en.wikipedia.org/wiki/National_Digital_Library_Program">
<node TEXT="In 1995 in conjunction with the launch of the Library of Congress National Digital Library Program the Library brought together leading history and social studies K-12 teachers and librarians to consider how archival on-line resources could best be used in the nations schools." ID="ID_717200856" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="HEC - National Digital Library - Open Access Resources" FOLDED="true" ID="ID_1563789968" CREATED="1557224068547" MODIFIED="1557224306247" LINK="http://www.digitallibrary.edu.pk/OAjournals.htm">
<node TEXT="The U.S. National Library of Medicines digital archive of life sciences journal literature claims to offer open access to over 80000 articles from over 100 journals. Access to much of the full text on PMC is free and unrestricted." ID="ID_31704386" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Its Time for a National Digital-Library System - The " FOLDED="true" ID="ID_342008944" CREATED="1557224068547" MODIFIED="1557224306247" LINK="https://www.chronicle.com/article/Its-Time-for-a-National/126489">
<node TEXT="The Chronicle Review Its Time for a National Digital-Library System. But it cant serve only elites. David Plunkert for The Chronicle Review" ID="ID_1882287508" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="How to Access Digital Editions | National Geographic" FOLDED="true" ID="ID_571714747" CREATED="1557224068547" MODIFIED="1557224306247" LINK="https://www.nationalgeographic.com/digitalaccess/">
<node TEXT="How to Access Digital Editions.  Click here to view recent issues in the online library for National Geographic Traveler. 4.Log in with your email address and the password you set up to sign in." ID="ID_1166656101" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Digital Public Library of America" FOLDED="true" ID="ID_1047967691" CREATED="1557224068547" MODIFIED="1557224306247" LINK="https://dp.la/">
<node TEXT="The Digital Public Library of America brings together the riches of America&#x2019;s libraries archives and museums and makes them freely available to the world." ID="ID_1131085066" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="About the Digital Library Federation - DLF - diglib.org" FOLDED="true" ID="ID_526683606" CREATED="1557224068547" MODIFIED="1557224306247" LINK="https://www.diglib.org/about/">
<node TEXT="Mission and Community The Digital Library Federation is a community of practitioners who advance research learning social justice and the public good through the creative design and wise application of digital library technologies. Our member institutions make the work of the DLF possible supporting community efforts in a variety of research and prototyping information sharing staff " ID="ID_1109232123" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="National Digital Library of India | SuccessCurve.in" FOLDED="true" ID="ID_1014246995" CREATED="1557224068548" MODIFIED="1557224306247" LINK="https://www.successcurve.in/national-digital-library-of-india/">
<node TEXT="Ministry of Human Resource Development under its National Mission on Education through Information and Communication Technology has initiated the National Digital Library (NDL) project to develop a framework of virtual repository of learning resources with a single-window search facility. It is being developed at IIT Kharagpur." ID="ID_1525191491" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
</node>
</node>
<node TEXT="Swayam" ID="ID_1671406895" CREATED="1549359127300" MODIFIED="1549359138987">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Swayam MachineLearning#$D$#" FOLDED="true" ID="ID_215985285" CREATED="1557224068548" MODIFIED="1557224307483">
<icon BUILTIN="stop-sign"/>
<node TEXT="Free online course on Swayam by Faculties and Universities " FOLDED="true" ID="ID_832097645" CREATED="1557224068548" MODIFIED="1557224306248" LINK="https://swayam.gov.in/">
<node TEXT="Swayam Home Page Free online course on Swayam by Faculties and Universities from : NPTEL  UGC  CEC NCERT  NIOS IGNOU IIMB  AICTE ** SWAYAM Examination May 2019 **" ID="ID_34913208" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Introduction to Machine Learning online course - SWAYAM" FOLDED="true" ID="ID_1663247151" CREATED="1557224068548" MODIFIED="1557224306248" LINK="https://swayam.gov.in/courses/4423-introduction-to-machine-learning">
<node TEXT="With the increased availability of data from varied sources there has been increasing attention paid to the various data driven disciplines such as analytics and machine learning. In this course we intend to introduce some of the basic concepts of machine learning from a mathematically well motivated perspective." ID="ID_1917562725" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Swayam: Distributed Autoscaling to Meet SLAs of Machine " FOLDED="true" ID="ID_755012090" CREATED="1557224068548" MODIFIED="1557224306248" LINK="https://www.microsoft.com/en-us/research/uploads/prod/2018/01/2017.Middleware.Swayam.TailLatencyInAzureML.pdf">
<node TEXT="Swayam: Distributed Autoscaling to Meet SLAs of Machine Learning Inference Services with Resource E&#x2d9;iciency Arpan Gujarati MPI-SWS Germany arpanbg@mpi-sws.org" ID="ID_1226491806" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Swayam - dl.acm.org" FOLDED="true" ID="ID_1880172272" CREATED="1557224068548" MODIFIED="1557224306248" LINK="https://dl.acm.org/citation.cfm?id=3135993">
<node TEXT="Developers use Machine Learning (ML) platforms to train ML models and then deploy these ML models as web services for inference (prediction). A key challenge for platform providers is to guarantee response-time Service Level Agreements (SLAs) for inference workloads while maximizing resource efficiency." ID="ID_1619589651" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Swayam: Distributed Autoscaling to Meet SLAs of Machine " FOLDED="true" ID="ID_1633946395" CREATED="1557224068548" MODIFIED="1557224306248" LINK="https://www.microsoft.com/en-us/research/publication/swayam-distributed-autoscaling-meet-slas-machine-learning-inference-services-resource-efficiency/">
<node TEXT="Developers use Machine Learning (ML) platforms to train ML models and then deploy these ML models as web services for inference (prediction). A key challenge for platform providers is to guarantee response-time Service Level Agreements (SLAs) for inference workloads while maximizing resource e ciency. Swayam is a fully distributed autoscaling framework that exploits characteristics of " ID="ID_1441616842" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="swayam mittal (@swayammittal65) | Twitter" FOLDED="true" ID="ID_162823820" CREATED="1557224068548" MODIFIED="1557224306248" LINK="https://twitter.com/swayammittal65">
<node TEXT="swayam mittal &#x200f; @swayammittal65  Remember in #datascience your main goal isn&#x2019;t knowing how to use the most fancy #machinelearning algorithms or create awesome graphs it&#x2019;s to be a problem solver. 0 replies 0 retweets 2 likes. Reply. Retweet. Retweeted. Like. 2. Liked. 2. Thanks. Twitter will use this to make your timeline better." ID="ID_1651646479" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="definition - What is machine learning? - Stack Overflow" FOLDED="true" ID="ID_499624310" CREATED="1557224068548" MODIFIED="1557224306248" LINK="https://stackoverflow.com/questions/2620343/what-is-machine-learning">
<node TEXT="Machine learning is a scientific discipline that is concerned with the design and development of algorithms that allow computers to evolve behaviors based on empirical data such as from sensor data or databases. Read more on Wikipedia. Machine learning code records facts or approximations in some sort of storage and with the algorithms calculates different probabilities." ID="ID_1780181467" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Intro to Machine Learning - YouTube" FOLDED="true" ID="ID_1316551794" CREATED="1557224068548" MODIFIED="1557224306249" LINK="https://www.youtube.com/playlist?list=PLAwxTw4SYaPkQXg8TkVdIvYv4HfLG7SiH">
<node TEXT="These videos are part of an online course Intro to Machine Learning. Check out the course here: https://www.udacity.com/course/ud120. This course was design" ID="ID_201842499" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="NPTEL :: Computer Science and Engineering - NOC " FOLDED="true" ID="ID_1617863892" CREATED="1557224068548" MODIFIED="1557224306249" LINK="https://nptel.ac.in/courses/106106139/">
<node TEXT="We are piloting a new feature with VideoKen to provide a Table of Contents and Word-Cloud for videos. For regular video without these features you can Watch on YouTube." ID="ID_1976901214" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Swayam: distributed autoscaling to meet SLAs of machine " FOLDED="true" ID="ID_1496840724" CREATED="1557224068548" MODIFIED="1557224306249" LINK="https://www.researchgate.net/publication/321415969_Swayam_distributed_autoscaling_to_meet_SLAs_of_machine_learning_inference_services_with_resource_efficiency">
<node TEXT="Request PDF on ResearchGate | Swayam: distributed autoscaling to meet SLAs of machine learning inference services with resource efficiency | Developers use Machine Learning (ML) platforms to train " ID="ID_546998934" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Swayam - people.mpi-sws.org" FOLDED="true" ID="ID_1762970590" CREATED="1557224068548" MODIFIED="1557224306249" LINK="https://people.mpi-sws.org/~bbb/papers/talks/middleware17.pdf">
<node TEXT="Swayam Distributed Autoscaling for Machine Learning as a Service 1. Machine Learning as a Service (MLaaS) Data Science  Machine Learning Amazon Machine Learning Machine Learning Google Cloud AI 2. Machine Learning as a Service (MLaaS) Data Science  Machine Learning" ID="ID_454867497" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Swayam Group | LinkedIn" FOLDED="true" ID="ID_929297488" CREATED="1557224068548" MODIFIED="1557224306249" LINK="https://www.linkedin.com/company/swayam-group">
<node TEXT="See more information about Swayam Group find and apply to jobs that match your skills and connect with people to advance your career. We are an entrepreneurial innovation focused technology firm " ID="ID_115212031" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
</node>
</node>
</node>
<node TEXT="Research Papers" ID="ID_18714266" CREATED="1549349304523" MODIFIED="1562238122009">
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge WIDTH="2"/>
<node TEXT="Important Conferences" ID="ID_842893866" CREATED="1549358959281" MODIFIED="1549358976820">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Important Conferences MachineLearning#$D$#" FOLDED="true" ID="ID_860524064" CREATED="1557224068546" MODIFIED="1557224307482">
<icon BUILTIN="stop-sign"/>
<node TEXT="What are the best conferences and journals about machine " FOLDED="true" ID="ID_1178427648" CREATED="1557224068546" MODIFIED="1557224306232" LINK="https://www.quora.com/What-are-the-best-conferences-and-journals-about-machine-learning">
<node TEXT="Recsys is a very prestigious recommendation systems and general machine learning conference. PyData is a great conference that I&#x2019;ve been to many times. This is a conference which has all of the talk tailored towards Data Science professionals who work with Python (That&#x2019;s most of them). IEEE is very well known." ID="ID_1767879025" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="Top Conferences for Machine Learning  Arti. Intelligence" FOLDED="true" ID="ID_694087382" CREATED="1557224068546" MODIFIED="1557224306232" LINK="http://www.guide2research.com/topconf/machine-learning">
<node TEXT="Top Conferences for Machine Learning  Arti. Intelligence Ranking is based on Conference H5-index=12 provided by Google Scholar Metrics" ID="ID_1774842424" CREATED="1557224068546" MODIFIED="1557224068546"/>
</node>
<node TEXT="List of Machine Learning and Deep Learning conferences in " FOLDED="true" ID="ID_736209460" CREATED="1557224068547" MODIFIED="1557224306232" LINK="https://tryolabs.com/blog/machine-learning-deep-learning-conferences/">
<node TEXT="There&#x2019;s a record amount of exciting Machine Learning (ML) and Deep Learning conferences worldwide and keeping track of them may prove to be a challenge. This list provides an overview with upcoming ML conferences and should help you decide which one to attend sponsor or submit talks to." ID="ID_224182873" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="International Conference on Machine Learning" FOLDED="true" ID="ID_735394047" CREATED="1557224068547" MODIFIED="1557224306232" LINK="https://icml.cc/">
<node TEXT="About. The International Conference on Machine Learning (ICML) is the premier gathering of professionals dedicated to the advancement of the branch of artificial intelligence known as machine learning." ID="ID_1661670640" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="ICMLT 2019" FOLDED="true" ID="ID_263823303" CREATED="1557224068547" MODIFIED="1557224306233" LINK="http://www.icmlt.org/">
<node TEXT="2019 4th International Conference on Machine Learning Technologies (ICMLT 2019) is going to take place at Jiangxi China (Nanchang University) during June 21-23 2019 which will offer an ideal platform for presentation discussion criticism exchange of innovative ideas and current challenges in the field of machine learning technologies." ID="ID_1132215449" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Important Dates &#x2013; Conference on Machine Learning for Data " FOLDED="true" ID="ID_1764886562" CREATED="1557224068547" MODIFIED="1557224306233" LINK="https://mldi2019.wordpress.com/important-dates/">
<node TEXT="Submission of paper: 15 December 2018 15 January 2019 Acceptance notification: 30 December 2018 20 January 2019 Camera ready paper submission: 10 January 2019 23 January 2019 Early bird Registration: 24 January 2019 to 27 January 2019 Registration: 28 January 2019 to 1 Feb 2019 Conference Dates : 8 -9 February 2019 Registration details &#x2026;" ID="ID_628756001" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="List of computer science conferences - Wikipedia" FOLDED="true" ID="ID_1762062906" CREATED="1557224068547" MODIFIED="1557224306233" LINK="https://en.wikipedia.org/wiki/List_of_computer_science_conferences">
<node TEXT="This is a list of academic conferences in computer science.Only conferences with separate articles are included; within each field the conferences are listed alphabetically by their short names. General. FCRC &#x2013; Federated Computing Research Conference Algorithms and theory" ID="ID_1494327242" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Machine learning AI and Big data analytics events" FOLDED="true" ID="ID_1935327147" CREATED="1557224068547" MODIFIED="1557224306233" LINK="https://computer-science.enggconferences.com/">
<node TEXT="Importance and Scope. Machine learning is the science of getting computers to act without being explicitly programmed. In the past decade machine learning has given us self-driving cars practical speech recognition effective web search and a vastly improved understanding of the human genome. Machine learning is so pervasive today that you " ID="ID_1032008664" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Machine learning - Wikipedia" FOLDED="true" ID="ID_1326374638" CREATED="1557224068547" MODIFIED="1557224306233" LINK="https://en.wikipedia.org/wiki/Machine_learning">
<node TEXT="Machine learning (ML) is the scientific study of algorithms and statistical models that computer systems use to effectively perform a specific task without using explicit instructions relying on patterns and inference instead. It is seen as a subset of artificial intelligence.Machine learning algorithms build a mathematical model based on sample data known as training data in order to " ID="ID_1996824892" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Prashanth Southekal on Applied Machine Learning - infoq.com" FOLDED="true" ID="ID_370758703" CREATED="1557224068547" MODIFIED="1557224306233" LINK="https://www.infoq.com/news/2019/04/southekal-machine-learning">
<node TEXT="Prashanth Southekal managing principal at DBP Institute hosted a workshop last month at Enterprise Data World 2019 Conference on applied machine learning techniques and when to use different ML alg" ID="ID_575849965" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Machine Learning for Healthcare" FOLDED="true" ID="ID_299563764" CREATED="1557224068547" MODIFIED="1557224306233" LINK="https://www.mlforhc.org/">
<node TEXT="Machine Learning for Healthcare. MLHC is an annual research meeting that exists to bring together two usually insular disciplines: computer scientists with artificial intelligence machine learning and big data expertise and clinicians/medical researchers." ID="ID_695907499" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="17 Top AI and Machine Learning Conferences for Developers " FOLDED="true" ID="ID_819638914" CREATED="1557224068547" MODIFIED="1557224306234" LINK="https://www.ibm.com/blogs/watson/2017/01/17-top-ai-machine-learning-conferences-developers-2017/">
<node TEXT="Conferences workshops and other meetings provide opportunities to learn where the jobs and technology is headed and a chance to learn and practice the skills necessary to keep up. Here are 17 events on AI and machine learning that developers should consider attending this year (in chronological order): 1." ID="ID_1671837792" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
</node>
</node>
<node TEXT="Important Journals" FOLDED="true" ID="ID_1581299213" CREATED="1549358977818" MODIFIED="1549358983514">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Important Journals MachineLearning#$D$#" ID="ID_892414125" CREATED="1557224068547" MODIFIED="1557224307482">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning - springer.com" FOLDED="true" ID="ID_1284398892" CREATED="1557224068547" MODIFIED="1557224306234" LINK="https://www.springer.com/computer/ai/journal/10994">
<node TEXT="Machine Learning is an international forum for research on computational approaches to learning. The journal publishes articles reporting substantive results on a wide range of learning methods applied to a variety of learning problems." ID="ID_727521231" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Machine Learning: What it is and Why it Matters - Simplilearn" FOLDED="true" ID="ID_746486056" CREATED="1557224068547" MODIFIED="1557224306234" LINK="https://www.simplilearn.com/what-is-machine-learning-and-why-it-matters-article">
<node TEXT="Find out all you need to know about machine learning and what its importance is in todays world! Find out all you need to know about machine learning and what its importance is in todays world! All Courses.  Machine Learning: What it is and Why it Matters By PriyadharshiniLast updated on Feb 14 2019 6 58762." ID="ID_605430038" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="How Machine Learning Works and Why It&#x2019;s Important " FOLDED="true" ID="ID_997994226" CREATED="1557224068547" MODIFIED="1557224306234" LINK="https://www.paymentsjournal.com/how-machine-learning-works-and-why-its-important/">
<node TEXT="Why is machine learning important for AI? As you have most likely already gathered machine learning is the branch of AI dedicated to endowing machines with the ability to learn. While there are programs that help sort your email provide you with personalized recommendations based on your online shopping behavior and make playlists based on " ID="ID_1801241370" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Top 10 Machine Learning Articles for the Past Month (v.July)" FOLDED="true" ID="ID_819000258" CREATED="1557224068547" MODIFIED="1557224306235" LINK="https://medium.mybridge.co/top-ten-machine-learning-articles-for-the-past-month-9c1202351144">
<node TEXT="That&#x2019;s it for Machine Learning monthly Top 10. If you like this curation you can read Top 10 daily articles according to your skills on iPhone  iPad.. If you don&#x2019;t have an iOS device signup on the website and receive weekly Top 10 articles for your skills.. Mybridge is a free reading app for professionals." ID="ID_1181984400" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="machine learning - Most important journals in data mining " FOLDED="true" ID="ID_606149275" CREATED="1557224068547" MODIFIED="1557224306235" LINK="https://stats.stackexchange.com/questions/81366/most-important-journals-in-data-mining-ml-nlp-and-ir">
<node TEXT="Can you please provide with me with the names of the most important journals in data mining machine learning natural language processing and information retrieval?" ID="ID_1506977334" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Top Journals for Machine Learning  Arti. Intelligence " FOLDED="true" ID="ID_1217719223" CREATED="1557224068547" MODIFIED="1557224306235" LINK="http://www.guide2research.com/journals/machine-learning">
<node TEXT="Impact Factor for Top Journals of Computer Science and Electronics 2015 How to chart a successful research career by Prof Alan Johnson Top H-Index for Scholars of Computer Science  Electronics 2014" ID="ID_915028352" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="What is Machine Learning &#x2013; and Why is it Important " FOLDED="true" ID="ID_1943176578" CREATED="1557224068547" MODIFIED="1557224306235" LINK="https://www.interactions.com/blog/technology/machine-learning-important/">
<node TEXT="The importance of machines has been highlighted in articles covering everything from Virtual Assistant solutions to self-driving cars and robots that can perform the same tasks as humans. A number of large companies are defining machine learning as &#x2018;the future&#x2019; &#x2013; but what does that really mean? What is Machine Learning?" ID="ID_978473199" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="The Importance of Machine Learning for Data Scientists " FOLDED="true" ID="ID_273984247" CREATED="1557224068547" MODIFIED="1557224306235" LINK="https://www.simplilearn.com/importance-of-machine-learning-for-data-scientists-article">
<node TEXT="Machine learning is only as good as the data it is given and the ability of algorithms to consume it. Going forward basic levels of machine learning will become a standard requirement for data scientists. This being said one of the most relevant data science skills is the ability to evaluate machine learning." ID="ID_329198343" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Machine Learning: What it is and why it matters | SAS" FOLDED="true" ID="ID_1364467947" CREATED="1557224068547" MODIFIED="1557224306235" LINK="https://www.sas.com/en_us/insights/analytics/machine-learning.html">
<node TEXT="Machine learning is a method of data analysis that automates analytical model building. It is a branch of artificial intelligence based on the idea that systems can learn from data identify patterns and make decisions with minimal human intervention. Because of new computing technologies machine " ID="ID_813646440" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Apple Machine Learning Journal" FOLDED="true" ID="ID_711495703" CREATED="1557224068547" MODIFIED="1557224306235" LINK="https://machinelearning.apple.com/">
<node TEXT="Welcome to the Apple Machine Learning Journal. Here you can read posts written by Apple engineers about their work using machine learning technologies to help build innovative products for millions of people around the world." ID="ID_1790463369" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="List of important publications in computer science - Wikipedia" FOLDED="true" ID="ID_1619906046" CREATED="1557224068547" MODIFIED="1557224306236" LINK="https://en.wikipedia.org/wiki/List_of_important_publications_in_computer_science">
<node TEXT="Machine learning An Inductive Inference Machine. Ray Solomonoff; IRE Convention Record Section on Information Theory Part 2 pp. 56&#x2013;62 1957 (A longer version of this a privately circulated report 1956 is online). Description: The first paper written on machine learning. Emphasized the importance of training sequences and the use of " ID="ID_34353800" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
</node>
<node TEXT="What are the best conferences and journals about machine " FOLDED="true" ID="ID_843808063" CREATED="1557224068547" MODIFIED="1557224306234" LINK="https://www.quora.com/What-are-the-best-conferences-and-journals-about-machine-learning">
<node TEXT="Im really surprised no one has mentioned KDD yet. Here are my categories: Top Conferences: ICML KDD NIPS In my opinion these three are the flagship machine learning conferences. They are the largest by attendance attract researchers from across" ID="ID_875437183" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Top Journals for Machine Learning  Arti. Intelligence " FOLDED="true" ID="ID_1843559258" CREATED="1557224068552" MODIFIED="1557224306293" LINK="http://www.guide2research.com/journals/machine-learning">
<node TEXT="Ranking for Top Scientists in Computer Science and Electronics 2019 5th Edition; Ranking for Top Scientists in Computer Science and Electronics 2018" ID="ID_980240415" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Journal of Machine Learning Research" FOLDED="true" ID="ID_373572455" CREATED="1557224068552" MODIFIED="1557224306293" LINK="http://jmlr.csail.mit.edu/">
<node TEXT="Journal of Machine Learning Research. The Journal of Machine Learning Research (JMLR) provides an international forum for the electronic and paper publication of high-quality scholarly articles in all areas of machine learning. All published papers are freely available online. JMLR has a commitment to rigorous yet rapid reviewing." ID="ID_1928293766" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
</node>
<node TEXT="Mtech Thesis" ID="ID_757088941" CREATED="1549367595624" MODIFIED="1549367600603">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="NDL" ID="ID_1216500325" CREATED="1549367622169" MODIFIED="1562919732869" LINK="https://ndl.iitkgp.ac.in/"><richcontent TYPE="NOTE">

<html>
		  <head>
			
		  </head>
		  <body>
			<p>
			  Mtech Thesis from IITs NITs available.
			</p>
			<p>
			  
			</p>
			<p>
			  Use appropriate filters to get there faster
			</p>
		  </body>
		</html>
</richcontent>
<node TEXT="NDL  MachineLearning#$D$#" FOLDED="true" ID="ID_42607381" CREATED="1557224068547" MODIFIED="1557224307482">
<icon BUILTIN="stop-sign"/>
<node TEXT="Natural language processing - Wikipedia" FOLDED="true" ID="ID_1291736935" CREATED="1557224068547" MODIFIED="1557224306240" LINK="https://en.wikipedia.org/wiki/Natural-language_processing">
<node TEXT="Natural language processing (NLP) is a subfield of computer science information engineering and artificial intelligence concerned with the interactions between computers and human (natural) languages in particular how to program computers to process and analyze large amounts of natural language data.. Challenges in natural language processing frequently involve speech recognition natural " ID="ID_1415648651" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="NDL &#x2013; Penn States Experts in Data Science and Business " FOLDED="true" ID="ID_1012225008" CREATED="1557224068547" MODIFIED="1557224306240" LINK="http://www.nittanydatalabs.org/">
<node TEXT="Whether you are a true analytics beginner or a seasoned professional Nittany Data Labs is the catalyst for Penn State students to begin their transformation from great professionals in their field to outstanding data-driven associates who excel in leveraging the data they collect to achieve innovation and ROI for their employers." ID="ID_1053560762" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="machine learning - Wikidata" FOLDED="true" ID="ID_1943804114" CREATED="1557224068547" MODIFIED="1557224306240" LINK="https://www.wikidata.org/wiki/Q2539">
<node TEXT="branch of statistics and computer science which studies algorithms and architectures that learn from observed facts" ID="ID_1604681135" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Category:Machine learning - Wikimedia Commons" FOLDED="true" ID="ID_692498566" CREATED="1557224068547" MODIFIED="1557224306240" LINK="https://commons.wikimedia.org/wiki/Category:Machine_learning">
<node TEXT="English: Machine learning is a branch of statistics and computer science which studies algorithms and architectures that learn from observed facts. machine learning branch of statistics and computer science which studies algorithms and architectures that learn from observed facts" ID="ID_1121637677" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="NDL India: Lecture 9: Machine-learning Approach" FOLDED="true" ID="ID_733538920" CREATED="1557224068547" MODIFIED="1557224306240" LINK="https://ndl.iitkgp.ac.in/document/xttk-4kfhvUwVlXBW-YWRJoQMnZGrg12Owg-g0YZTw2oyEdnf9E9O3yuEF6P3MK3Jm7Nc27TgB3jvmmxLNnP5Q">
<node TEXT="Age Range: above 22 year: Education Level: UG and PG: Learning Resource Type: Audio Lecture: Rights Holder: Massachusetts Institute of Technology" ID="ID_1942369356" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Microsoft releases CNTK its open source deep learning " FOLDED="true" ID="ID_1491936508" CREATED="1557224068547" MODIFIED="1557224306241" LINK="https://www.reddit.com/r/MachineLearning/comments/42ljoo/microsoft_releases_cntk_its_open_source_deep/">
<node TEXT="The MachineLearning community on Reddit. Reddit gives you the best of the internet in one place. jump to content. my subreddits.  At first look the NDL seems rather awkward.  Outside of Machine Learning stuff theyre also doing a lot of work helping develop the IoT community. " ID="ID_402566239" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Ryszard S. Michalski - Wikipedia" FOLDED="true" ID="ID_1522094595" CREATED="1557224068547" MODIFIED="1557224306241" LINK="https://en.wikipedia.org/wiki/Ryszard_S._Michalski">
<node TEXT="Ryszard S. Michalski (May 7 1937 &#x2013; September 20 2007) was a Polish-American computer scientist. Michalski was Professor at George Mason University and a pioneer in the field of machine learning." ID="ID_1396841774" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="Lecture Files &#x2013; NDL" FOLDED="true" ID="ID_1082844134" CREATED="1557224068547" MODIFIED="1557224306241" LINK="http://www.nittanydatalabs.org/lecture-files/">
<node TEXT="NDL will be directing all communications through our Slack page and heavily focus on GitHub collaborative development. Moreover we recommend using open source IDEs that support multiple languages and easy package management. We look forward to seeing you all next Sunday (9/9) for our meeting with Anthem Health Insurance." ID="ID_475216768" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="replace CriteriaNodes to CriterionNodes in NDL parser " FOLDED="true" ID="ID_169587853" CREATED="1557224068547" MODIFIED="1557224306241" LINK="https://github.com/Microsoft/CNTK/commit/d30cf439af344fcf79607fa51c6c362c8d22f24f">
<node TEXT="&#x2026;nce samples and book while keeping it compatible with old NDL and model files." ID="ID_793771543" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="National Digital Library of India" FOLDED="true" ID="ID_1264656832" CREATED="1557224068547" MODIFIED="1557224306241" LINK="https://ndl.iitkgp.ac.in/">
<node TEXT="Ministry of Human Resource Development (MHRD) under its National Mission on Education through Information and Communication Technology (NMEICT) has initiated the National Digital Library of India (NDL India) pilot project to develop a framework of virtual repository of learning resources with a single-window search facility." ID="ID_181897306" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="eBook Machine_learning - sheepshoot.com" FOLDED="true" ID="ID_993063046" CREATED="1557224068547" MODIFIED="1557224306241" LINK="http://sheepshoot.com/Machine_learning">
<node TEXT="Machine learning (ML) is the scientific study of algorithms and statistical models that computer systems use to effectively perform a specific task without using explicit instructions relying on patterns and inference instead. It is seen as a subset of artificial intelligence. Machine learning algorithms build a mathematical model of sample data known as training data in order to make " ID="ID_1853261639" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
<node TEXT="The Microsoft Cognitive Toolkit - Cognitive Toolkit - CNTK " FOLDED="true" ID="ID_846558748" CREATED="1557224068547" MODIFIED="1557224306241" LINK="https://docs.microsoft.com/en-us/cognitive-toolkit/">
<node TEXT="The Microsoft Cognitive Toolkit (CNTK) is an open-source toolkit for commercial-grade distributed deep learning. It describes neural networks as a series of computational steps via a directed graph. CNTK allows the user to easily realize and combine popular model types such as feed-forward DNNs convolutional neural networks (CNNs) and " ID="ID_1147310429" CREATED="1557224068547" MODIFIED="1557224068547"/>
</node>
</node>
</node>
</node>
<node TEXT="Community Forums" FOLDED="true" ID="ID_833563260" CREATED="1549359549189" MODIFIED="1562238171449">
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge WIDTH="2"/>
<node TEXT="Reddit" ID="ID_283895267" CREATED="1549361853140" MODIFIED="1549361855364">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Community Forums MachineLearning#$D$#" FOLDED="true" ID="ID_816840394" CREATED="1557224068549" MODIFIED="1557224307484">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning Communities" FOLDED="true" ID="ID_58667668" CREATED="1557224068549" MODIFIED="1557224306261" LINK="https://machinelearningmastery.com/machine-learning-communities/">
<node TEXT="Machine learning communities have had a big impact on my education and in this blog post I want to list all of the online machine learning communities I know about so that you too can make the most of them." ID="ID_759148911" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="What are some good machine learning forums with a decent " FOLDED="true" ID="ID_213214937" CREATED="1557224068549" MODIFIED="1557224306261" LINK="https://www.quora.com/What-are-some-good-machine-learning-forums-with-a-decent-amount-of-active-users">
<node TEXT="You can find an active Machine Learning community at Reddit. Particularly the most active sub-reddits are: * Machine Learning &#x2022; /r/MachineLearning * Data Science &#x2022; /r/datascience * Everything big data from storage to predictive analytics &#x2022; /r" ID="ID_336202309" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Msdn forums - Machine Learning" FOLDED="true" ID="ID_1613157630" CREATED="1557224068549" MODIFIED="1557224306261" LINK="https://social.msdn.microsoft.com/forums/azure/en-US/home?forum=MachineLearning">
<node TEXT="We are pleased to announce the availability of Azure Machine Learning Workspaces and Web Service Plans for all our Azure Machine Learning users through the Azure Portal. Azure Machine Learning users can now create and manage Standard workspaces through the Azure Portal. In addition users will also be able to create Web Service Pricing Plans." ID="ID_1169588449" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="machinelearning-samples/COMMUNITY-SAMPLES.md at master " FOLDED="true" ID="ID_1949851518" CREATED="1557224068549" MODIFIED="1557224306261" LINK="https://github.com/dotnet/machinelearning-samples/blob/master/docs/COMMUNITY-SAMPLES.md">
<node TEXT="Samples for ML.NET an open source and cross-platform machine learning framework for .NET. - dotnet/machinelearning-samples  Community forum;  Community Samples. This is an ever-evolving page where samples and content from the ML.NET community are highlighted so anyone in the community can also take advantage of these additional samples. " ID="ID_1252126858" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="What are good machine learning communities? - Quora" FOLDED="true" ID="ID_218647295" CREATED="1557224068549" MODIFIED="1557224306261" LINK="https://www.quora.com/What-are-good-machine-learning-communities">
<node TEXT="What are good machine learning communities? Update Cancel.  There are a variety of forums for discussing machine learning and A.I. out there. To name a few:  copycoding is a new machine learning community good for beginners and has tiny projects to get you started. Have a look at it (PS." ID="ID_447362535" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning &#x2022; r/MachineLearning - reddit" FOLDED="true" ID="ID_227109088" CREATED="1557224068549" MODIFIED="1557224306261" LINK="https://www.reddit.com/r/MachineLearning/">
<node TEXT="The MachineLearning community on Reddit. Reddit gives you the best of the internet in one place." ID="ID_1993094372" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="machine learning |Tableau Community Forums" FOLDED="true" ID="ID_503091918" CREATED="1557224068549" MODIFIED="1557224306261" LINK="https://community.tableau.com/thread/207215">
<node TEXT="Tableau also supports integrating with R and there are lots of articles detailing working with R and Machine learning algorithms. I hope that helps some. Patrick . Like Show 0 Likes; Actions ; Sign In or Create your Account. Become a Viz Whiz on the Forums! Support the Community and master Tableau. More Like This. Unable to retrieve content " ID="ID_244454808" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="MachineLearning/Anomalous.94% | Page 2 - TechSpot Forums" FOLDED="true" ID="ID_486889724" CREATED="1557224068549" MODIFIED="1557224306261" LINK="https://www.techspot.com/community/topics/machinelearning-anomalous-94.246176/page-2">
<node TEXT="Farbar Service Scanner Version: 27-01-2016 Ran by Administrator (administrator) on 16-05-2018 at 23:24:30 Running from" ID="ID_1707683597" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning Server Resources | Microsoft" FOLDED="true" ID="ID_381073478" CREATED="1557224068549" MODIFIED="1557224306262" LINK="https://www.microsoft.com/en-us/sql-server/machinelearningserver-resources">
<node TEXT="As a powerful advanced analytics platform Machine Learning Server integrates seamlessly with your existing data infrastructure to use open-source R and Microsoft innovation to create and distribute R-based analytics programs across your on-premises or cloud data stores&#x2014;delivering results into dashboards enterprise applications or web and mobile apps." ID="ID_1225881394" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning | Ulyaoth - community.ulyaoth.com" FOLDED="true" ID="ID_1267478993" CREATED="1557224068549" MODIFIED="1557224306262" LINK="https://community.ulyaoth.com/forums/aws-machinelearning/">
<node TEXT="AWS Machine Learning discussion forum https://aws.amazon.com/machine-learning/" ID="ID_1120782465" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="MachineLearning/Anomalous.94% - TechSpot Forums" FOLDED="true" ID="ID_1718335206" CREATED="1557224068549" MODIFIED="1557224306262" LINK="https://www.techspot.com/community/topics/machinelearning-anomalous-94.246176/">
<node TEXT="Machine started to act very poorly So I ran A scan and picked up a detection. I would like to make sure there is nothing else lingering in terms of" ID="ID_1358164257" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning  AI for Healthcare | HIMSS19" FOLDED="true" ID="ID_512021678" CREATED="1557224068549" MODIFIED="1557224306262" LINK="https://www.himssconference.org/education/specialty-programs/machine-learning-ai-healthcare">
<node TEXT="Machine Learning  AI for Healthcare brings healthcare IT decision makers together for insights and face-to-face dialog about how hospitals are using AI and Machine Learning to reduce costs improve care outcomes and more. Follow the conversation with #smartHIT. View the Program Guide Here" ID="ID_1355069210" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
</node>
<node TEXT="Reddit MachineLearning#$D$#" FOLDED="true" ID="ID_1600589149" CREATED="1557224068549" MODIFIED="1557224307484">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning &#x2022; r/MachineLearning - reddit" FOLDED="true" ID="ID_991169678" CREATED="1557224068549" MODIFIED="1557224306262" LINK="https://www.reddit.com/r/MachineLearning/">
<node TEXT="The MachineLearning community on Reddit. Reddit gives you the best of the internet in one place." ID="ID_1209038722" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Learn Machine Learning - reddit" FOLDED="true" ID="ID_1086889922" CREATED="1557224068549" MODIFIED="1557224306262" LINK="https://www.reddit.com/r/learnmachinelearning/">
<node TEXT="Feel free to share any educational resources of machine learning. Also we are a beginner-friendly subreddit so dont be afraid to ask questions! This can include questions that are non-technical but still highly relevant to learning machine learning such as a systematic approach to a machine learning problem." ID="ID_1291401587" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="MachineLearning - reddit.com" FOLDED="true" ID="ID_705577580" CREATED="1557224068549" MODIFIED="1557224306262" LINK="https://www.reddit.com/r/MachineLearning/comments/b3zlha/p_openais_gpt2based_reddit_bot_is_live/">
<node TEXT="Project [P] OpenAIs GPT-2-based Reddit Bot is Live! (self.MachineLearning) submitted 25 days ago * by Shevizzle. FINAL UPDATE: The bot is down until I have time to get it operational again. Will update this when it&#x2019;s back online. " ID="ID_821489827" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="[D] Im using OpenAIs GPT-2 to generate text. Give me " FOLDED="true" ID="ID_1955091483" CREATED="1557224068549" MODIFIED="1557224306262" LINK="https://www.reddit.com/r/MachineLearning/comments/b32lve/d_im_using_openais_gpt2_to_generate_text_give_me/">
<node TEXT="Thank you all for participating! Based on the popularity of this post I decided to create a full-blown reddit bot based on it. I wont be responding here anymore but check out the update for more info. UPDATE: I made a GPT-2 reddit bot Disclaimer: This is not the full model. This is the smaller and less powerful version which OpenAI released " ID="ID_117587366" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="GitHub - lovit/reddit-MachineLearning: Subreddit " FOLDED="true" ID="ID_1428119217" CREATED="1557224068549" MODIFIED="1557224306262" LINK="https://github.com/lovit/reddit-MachineLearning">
<node TEXT="Subreddit MachineLearning archive (subsample from https://pushshift.io) - lovit/reddit-MachineLearning" ID="ID_1874669581" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="[Discussion] Be careful when using pretrained  - reddit.com" FOLDED="true" ID="ID_820884250" CREATED="1557224068549" MODIFIED="1557224306262" LINK="https://www.reddit.com/r/MachineLearning/comments/bdjxf2/discussion_be_careful_when_using_pretrained_deep/">
<node TEXT="Discussion [Discussion] Be careful when using pretrained deep learning models (self.MachineLearning) submitted 7 days ago by ceceshao1 Using pre-trained deep learning models like ResNet Inception and VGG is easier than ever but there are implementation details you need to be careful with to avoid subpar performance and errors." ID="ID_1498630074" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="We are Oriol Vinyals and David Silver from DeepMind&#x2019;s " FOLDED="true" ID="ID_991836906" CREATED="1557224068549" MODIFIED="1557224306262" LINK="https://www.reddit.com/r/MachineLearning/comments/ajgzoc/we_are_oriol_vinyals_and_david_silver_from/">
<node TEXT="Hi there! We are Oriol Vinyals (/u/OriolVinyals) and David Silver (/u/David_Silver) lead researchers on DeepMind&#x2019;s AlphaStar team joined by StarCraft II pro players TLO and MaNa.This evening at DeepMind HQ we held a livestream demonstration of AlphaStar playing against TLO and MaNa - you can read more about the matches here or re-watch the stream on YouTube here." ID="ID_635561005" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Top /r/MachineLearning posts August 2018: Everybody Dance " FOLDED="true" ID="ID_1277177644" CREATED="1557224068549" MODIFIED="1557224306263" LINK="https://www.kdnuggets.com/2018/09/top-reddit-machine-learning-august.html">
<node TEXT="&#x201c;Weve designed a distributed system for sharing enormous datasets - for researchers by researchers. The result is a scalable secure and fault-tolerant repository for data with blazing fast download speeds.&#x201d; It&#x2019;s safe to say the reddit community isn&#x2019;t fully convinced &#x201c;A few months " ID="ID_1370177378" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Reddit-machinelearning on Pocket - getpocket.com" FOLDED="true" ID="ID_1728312802" CREATED="1557224068549" MODIFIED="1557224306263" LINK="https://getpocket.com/explore/reddit-machinelearning">
<node TEXT="Reddit-machinelearning on Pocket. 83 results. blogs.princeton.edu December 13 2015 On the spirit of NIPS 2015 and OpenAI. I just came back from NIPS 2015 which was a clear success in terms of numbers (note that this growth is not all because of deep learning only about 10% of the papers were on this topic which is about double of those on " ID="ID_797918955" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Top /r/MachineLearning Posts February: Oxford Deep NLP " FOLDED="true" ID="ID_327527126" CREATED="1557224068549" MODIFIED="1557224306263" LINK="https://www.kdnuggets.com/2017/03/top-reddit-machine-learning-posts-february.html">
<node TEXT="In February on /r/MachineLearning deep learning course material was hot a new library for visualizing Scikit-learn results made a splash a new machine learning crash course installment from ML @ Berkeley was a hit Google decided we need help parking and TensorFlow 1.0 got a release alongside its developer summit.. The top 5 /r/MachineLearning posts of the past month are:" ID="ID_322200446" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Top /r/MachineLearning Posts September: Implement a " FOLDED="true" ID="ID_532734214" CREATED="1557224068549" MODIFIED="1557224306263" LINK="https://www.kdnuggets.com/2015/10/top-reddit-machine-learning-september.html">
<node TEXT="By Matthew Mayo. In September on /r/MachineLearning we find a neural network tutorial video for C++ read that deep learning based Chinese character handwriting recognition beats humans grab ourselves a machine learning algorithm cheat sheet connect the dots between functional programming and deep learning and discover a neural network paper repository." ID="ID_735219241" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
</node>
</node>
<node TEXT="Stack Exchange" ID="ID_118698659" CREATED="1549361856428" MODIFIED="1549364871508">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Stack Exchange MachineLearning#$D$#" FOLDED="true" ID="ID_1907625753" CREATED="1557224068550" MODIFIED="1557224307484">
<icon BUILTIN="stop-sign"/>
<node TEXT="Newest machine-learning Questions - Stack Exchange" FOLDED="true" ID="ID_1648564798" CREATED="1557224068550" MODIFIED="1557224306265" LINK="https://stats.stackexchange.com/questions/tagged/machine-learning">
<node TEXT="QA for people interested in statistics machine learning data analysis data mining and data visualization Stack Exchange Network Stack Exchange network consists of 175 QA communities including Stack Overflow  the largest most trusted online community for developers to learn share their knowledge and build their careers." ID="ID_629440432" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Which Stack Exchange website for machine learning and " FOLDED="true" ID="ID_1693677993" CREATED="1557224068550" MODIFIED="1557224306265" LINK="https://meta.stackexchange.com/questions/130524/which-stack-exchange-website-for-machine-learning-and-computational-algorithms">
<node TEXT="Im currently working on many machine learning and computational algorithms such as Singular Value Decomposition Support Vector Machines and others. Id like to ask questions about these topics but I dont know which Stack Exchange website to use to post my questions. Should I use Computer Science? Should I use Theoretical Computer Science?" ID="ID_1075373157" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Newest machine-learning Questions - Stack Exchange" FOLDED="true" ID="ID_1368071364" CREATED="1557224068550" MODIFIED="1557224306265" LINK="https://datascience.stackexchange.com/questions/tagged/machine-learning">
<node TEXT="QA for Data science professionals Machine Learning specialists and those interested in learning more about the field Stack Exchange Network Stack Exchange network consists of 175 QA communities including Stack Overflow  the largest most trusted online community for developers to learn share their knowledge and build their careers." ID="ID_264805797" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Newest machine-learning Questions - Stack Exchange" FOLDED="true" ID="ID_1055896912" CREATED="1557224068550" MODIFIED="1557224306266" LINK="https://math.stackexchange.com/questions/tagged/machine-learning">
<node TEXT="Stack Exchange network consists of 175 QA communities including Stack Overflow the largest most trusted online community for developers to learn share their knowledge and build their careers. Visit Stack Exchange" ID="ID_1243877454" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Newest machine-learning Questions - Mathematica Stack " FOLDED="true" ID="ID_999060816" CREATED="1557224068550" MODIFIED="1557224306266" LINK="https://mathematica.stackexchange.com/questions/tagged/machine-learning">
<node TEXT="Stack Exchange network consists of 175 QA communities including Stack Overflow the largest most trusted online community for developers to learn share their knowledge and build their careers. Visit Stack Exchange" ID="ID_1574039672" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Newest machine-learning Questions - Stack Overflow" FOLDED="true" ID="ID_850261999" CREATED="1557224068550" MODIFIED="1557224306266" LINK="https://stackoverflow.com/questions/tagged/machine-learning">
<node TEXT="more stack exchange communities company blog. Tour Start here for a quick overview of the site  I have a machine learning model which is capable of doing some video analytics and then finally stores the output videos in a separate folder. I want to run the model every time I upload a new video " ID="ID_1374671" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Newest windows-machine-learning Questions - Stack Overflow" FOLDED="true" ID="ID_732358430" CREATED="1557224068550" MODIFIED="1557224306266" LINK="https://stackoverflow.com/questions/tagged/windows-machine-learning">
<node TEXT="more stack exchange communities company blog.  And finally theyve also released a machine learning API along with a code sample repo. Unfortunately windows machine-learning c++-winrt windows-machine-learning. asked Jan 18 at 14:15. hendrik. 1557 8 21. 0. votes. 0answers" ID="ID_1825726077" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Newest machine-learning Questions - Robotics Stack Exchange" FOLDED="true" ID="ID_595574261" CREATED="1557224068550" MODIFIED="1557224306266" LINK="https://robotics.stackexchange.com/questions/tagged/machine-learning">
<node TEXT="Machine learning is a branch of Artificial Intelligence concerned with the development of algorithms that adapt their behavior based on past observations. Examples of such algorithms include Artificial Neural Networks Genetic Algorithms Expectation-Maximization and Support Vector Machines." ID="ID_1053723382" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Newest machine-learning Questions - Theoretical Computer " FOLDED="true" ID="ID_403592145" CREATED="1557224068550" MODIFIED="1557224306266" LINK="https://cstheory.stackexchange.com/questions/tagged/machine-learning">
<node TEXT="Stack Exchange network consists of 175 QA communities including Stack Overflow the largest most trusted online community for developers to learn share their knowledge and build their careers. Visit Stack Exchange" ID="ID_1792063383" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Exploring and interpolating a function using machine-learning?" FOLDED="true" ID="ID_27082063" CREATED="1557224068550" MODIFIED="1557224306266" LINK="https://cs.stackexchange.com/questions/48931/exploring-and-interpolating-a-function-using-machine-learning">
<node TEXT="Stack Exchange network consists of 175 QA communities including Stack  Exploring and interpolating a function using machine-learning?  Which general machine-learning methods are there that try to learn or interpolate a smooth multivariate function and which get to actually choose the points at which the function is evaluated during " ID="ID_904675939" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Are Machine-Learning and Self-Learning really possible " FOLDED="true" ID="ID_1214313196" CREATED="1557224068550" MODIFIED="1557224306266" LINK="https://ai.stackexchange.com/questions/3580/are-machine-learning-and-self-learning-really-possible">
<node TEXT="Machine learning and self-learning are of course possible and therere many successive cases! You need to know this: machines wont think like humans. Machines form a statistical model and calibrate the model. A good model is a model that does what its supposed to do accurately." ID="ID_1608047106" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Machine Learning Predictions Repeating - Stack Exchange" FOLDED="true" ID="ID_345948580" CREATED="1557224068550" MODIFIED="1557224306266" LINK="https://salesforce.stackexchange.com/questions/105282/machine-learning-predictions-repeating">
<node TEXT="Stack Exchange network consists of 175 QA communities including Stack Overflow the largest most trusted online community for developers to learn share their knowledge and build their careers. Visit Stack Exchange" ID="ID_1371297224" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
</node>
</node>
<node TEXT="Quora" ID="ID_1252491501" CREATED="1549361862870" MODIFIED="1549361864973">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Writers" FOLDED="true" ID="ID_1201653695" CREATED="1549361885694" MODIFIED="1549361890010">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Quora Writers MachineLearning#$D$#" ID="ID_329975694" CREATED="1557224068550" MODIFIED="1557224307484">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning - Quora" FOLDED="true" ID="ID_1193352284" CREATED="1557224068550" MODIFIED="1557224306267" LINK="https://www.quora.com/topic/Machine-Learning">
<node TEXT="In my career I have seen many folks progress (or stagnate) and interviewed a lot of candidates (beginner to senior level). The good news is that the ML space has now become so big that there are m" ID="ID_117192687" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="What Is The Best Way To Learn Machine Learning Without " FOLDED="true" ID="ID_48738546" CREATED="1557224068550" MODIFIED="1557224306277" LINK="https://www.forbes.com/sites/quora/2017/03/22/what-is-the-best-way-to-learn-machine-learning-without-taking-any-online-courses/">
<node TEXT="What is the best way to start learning machine learning and deep learning without taking any online courses? This question was originally answered on Quora by Eric Jang." ID="ID_813670581" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="How to learn machine learning - Quora" FOLDED="true" ID="ID_527845527" CREATED="1557224068550" MODIFIED="1557224306277" LINK="https://www.quora.com/How-do-I-learn-machine-learning-1">
<node TEXT="Machine learning is one of the hottest trendings in tech industries today. Machine learning is very powerful to make prediction or recommendations based on huge amount of data sets. Machine learning has vast use cases for different domains either in the e-commerce business finance intelligence sci-fi movies marketing real estate etc" ID="ID_1806652851" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Top Quora Data Science Writers and Their Best Advice Updated" FOLDED="true" ID="ID_495785920" CREATED="1557224068550" MODIFIED="1557224306277" LINK="https://www.kdnuggets.com/2017/07/top-quora-data-science-writers-best-advice-updated.html">
<node TEXT="Get some insight into tips and tricks the future of the field career advice code snippets and more from the top data science writers on Quora. By Matthew Mayo  KDnuggets. This post is based on Most Viewed Writers in Data Science  the 10 writers with the most answer views in the last 30 days as retrieved on June 29 2017." ID="ID_1281810061" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Quora - A place to share knowledge and better understand " FOLDED="true" ID="ID_930330052" CREATED="1557224068550" MODIFIED="1557224306278" LINK="https://www.quora.com/">
<node TEXT="Quora is a place to gain and share knowledge. Its a platform to ask questions and connect with people who contribute unique insights and quality answers. This empowers people to learn from each other and to better understand the world." ID="ID_911008057" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Introducing Quora&#x2019;s Machine Learning Sessions Series" ID="ID_208337316" CREATED="1557224068550" MODIFIED="1557224306278" LINK="https://www.kdnuggets.com/2016/01/quora-machine-learning-sessions-series.html">
<node TEXT="The Quora Sessions will invite users to pose relevant and interesting questions to experts in various domains. Quoras VP of Engineering and noted Machine Learning expert Xavier Amatriain has subsequently announced a series of such sessions will be focused on Machine Learning." ID="ID_1430605032" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
</node>
<node TEXT="Top 10 Quora Machine Learning Writers and Their Best " FOLDED="true" ID="ID_659912897" CREATED="1557224068550" MODIFIED="1557224306277" LINK="https://www.kdnuggets.com/2017/06/top-quora-machine-learning-writers.html">
<node TEXT="Gain some insight on a variety of topics with select answers from Quoras current top machine learning writers. Advice on research interviews hot topics in the field how to best progress in your learning and more are all covered herein." ID="ID_1911488730" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Top Indian Quora Writers To Follow For Data Science" FOLDED="true" ID="ID_1183978441" CREATED="1557224068550" MODIFIED="1557224306278" LINK="https://www.analyticsindiamag.com/top-indian-quora-writers-to-follow-for-data-science/">
<node TEXT="In this article we list down 10 Indian Quora writers Data Scientist aspirants can follow to bring the latest insights and data trends to their followers. Lalit Patel. Holding a PhD in Physics Lalit Patel also holds an MBA. He is an experienced person in Machine Learning nanotechnology. Presently working as Computer Audit Analyst" ID="ID_1292672318" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Top 10 Quora Machine Learning Writers and Their Best Advice" FOLDED="true" ID="ID_1565879351" CREATED="1557224068550" MODIFIED="1557224306278" LINK="https://www.kdnuggets.com/2015/09/top-machine-learning-writers-quora.html">
<node TEXT="Tags: Machine Learning Quora Random Forests Top 10 Xavier Amatriain Yoshua Bengio. Top Quora machine learning writers give their advice on pursuing a career in the field academic research and selecting and using appropriate technologies. By Matthew Mayo." ID="ID_1408172379" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
</node>
<node TEXT="Questions" ID="ID_413890181" CREATED="1549361900339" MODIFIED="1549361902632">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Quora Questions MachineLearning#$D$#" FOLDED="true" ID="ID_295872180" CREATED="1557224068550" MODIFIED="1557224307484">
<icon BUILTIN="stop-sign"/>
<node TEXT="What are some common machine learning interview questions?" FOLDED="true" ID="ID_1715739752" CREATED="1557224068550" MODIFIED="1557224306278" LINK="https://www.quora.com/What-are-some-common-machine-learning-interview-questions">
<node TEXT="Machine learning is a broad field and there are no specific machine learning interview questions that are likely to be asked during a machine learning engineer job interview because the machine learning interview questions asked will focus on the open job position the employer is trying to fill." ID="ID_943383018" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="What Will Machine Learning Look Like In Twenty Years?" FOLDED="true" ID="ID_534583844" CREATED="1557224068550" MODIFIED="1557224306278" LINK="https://www.forbes.com/sites/quora/2019/04/04/what-will-machine-learning-look-like-in-twenty-years/">
<node TEXT="What will machine learning look like 15-20 years from now? originally appeared on Quora: the place to gain and share knowledge empowering people to learn from others and better understand the " ID="ID_1552628736" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="41 Essential Machine Learning Interview Questions " FOLDED="true" ID="ID_1204401564" CREATED="1557224068550" MODIFIED="1557224306278" LINK="https://www.springboard.com/blog/machine-learning-interview-questions/">
<node TEXT="Machine learning interview questions are an integral part of the data science interview and the path to becoming a data scientist machine learning engineer or data engineer.Springboard created a free guide to data science interviews so we know exactly how they can trip up candidates! In order to help resolve that here is a curated and created a list of key questions that you could see in a " ID="ID_707320916" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Machine Learning - Quora" FOLDED="true" ID="ID_1215183667" CREATED="1557224068550" MODIFIED="1557224306278" LINK="https://www.quora.com/topic/Machine-Learning">
<node TEXT="In my career I have seen many folks progress (or stagnate) and interviewed a lot of candidates (beginner to senior level). The good news is that the ML space has now become so big that there are m" ID="ID_1913683986" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Ask To Answer as a Machine Learning Problem - Quora" FOLDED="true" ID="ID_1975277951" CREATED="1557224068550" MODIFIED="1557224306278" LINK="https://engineering.quora.com/Ask-To-Answer-as-a-Machine-Learning-Problem">
<node TEXT="At Quora we use machine learning in many applications from home page ranking and related questions to topic inference and spam detection (see a previous blog post for more info). Some of these applications follow the approach described here and others require different techniques." ID="ID_1510170073" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Quora - A place to share knowledge and better understand " FOLDED="true" ID="ID_1865883806" CREATED="1557224068550" MODIFIED="1557224306278" LINK="https://www.quora.com/">
<node TEXT="Quora is a place to gain and share knowledge. Its a platform to ask questions and connect with people who contribute unique insights and quality answers. This empowers people to learn from each other and to better understand the world." ID="ID_359472793" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Quora: Look for Machine Learning Tools in Everyday Products" FOLDED="true" ID="ID_1602052313" CREATED="1557224068550" MODIFIED="1557224306279" LINK="https://www.newsweek.com/quora-question-whats-future-machine-learning-576424">
<node TEXT="Quora Questions are part of a partnership between Newsweek and Quora through which well be posting relevant and interesting answers from Quora contributors throughout the week. Read more about " ID="ID_1798846265" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Semantic Question Matching with Deep Learning - Quora" FOLDED="true" ID="ID_1378825094" CREATED="1557224068550" MODIFIED="1557224306279" LINK="https://engineering.quora.com/Semantic-Question-Matching-with-Deep-Learning">
<node TEXT="Authors: Quora User Shuo Chang and Nikhil Dandekar In order to build a high-quality knowledge base its important that we ensure each unique question exists on Quora only once. Writers shouldnt have to write the same answer to multiple versions of the same question and readers should be able to find a single canonical page with the question theyre looking for." ID="ID_1434337925" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Machine Learning at Quora - Engineering at Quora - Quora" FOLDED="true" ID="ID_1870550991" CREATED="1557224068550" MODIFIED="1557224306279" LINK="https://engineering.quora.com/Machine-Learning-at-Quora">
<node TEXT="At Quora we use ranking algorithms in different contexts and with different purposes. One interesting example is answer ranking. Given a question and several answers to this question we are interested in ranking them in decreasing order so to keep the &#x201c;best&#x201d; answer at the top and the worst at the bottom (see screen capture below)." ID="ID_1827061820" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="What Are The Most Promising Areas Of Machine Learning " FOLDED="true" ID="ID_1747890900" CREATED="1557224068550" MODIFIED="1557224306279" LINK="https://www.forbes.com/sites/quora/2019/04/11/what-are-the-most-promising-areas-of-machine-learning-research-right-now/">
<node TEXT="These questions originally appeared on Quora: the place to gain and share knowledge empowering people to learn from others and better understand the world. Answers by Sam Altman Y Combinator and " ID="ID_1742096377" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="machine learning - Quora Question Pairs challenge predict " FOLDED="true" ID="ID_1537246736" CREATED="1557224068550" MODIFIED="1557224306279" LINK="https://stackoverflow.com/questions/54136855/quora-question-pairs-challenge-predict-if-two-questions-ask-the-same-thing-usin">
<node TEXT="I have a csv file containing pairs of questions from the Quora Question Pairs Challenge. For each pair there is a corresponding label that specifies whether the questions are the same or not. I want to create a method so that if we have unknown pairs of questions I can answer if they ask the same thing or not." ID="ID_1729469860" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="How Does Quora Use Machine Learning In 2017? - Forbes" FOLDED="true" ID="ID_560034029" CREATED="1557224068550" MODIFIED="1557224306279" LINK="https://www.forbes.com/sites/quora/2017/04/19/how-does-quora-use-machine-learning-in-2017/">
<node TEXT="How does Quora use machine learning in 2017? originally appeared on Quora: the place to gain and share knowledge empowering people to learn from others and better understand the world. Answer by " ID="ID_1378821839" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
</node>
<node TEXT="The Best Advice From Quora on How to Learn Machine Learning" FOLDED="true" ID="ID_287469721" CREATED="1557224068550" MODIFIED="1557224306278" LINK="https://houseofbots.com/news-detail/2279-4-the-best-advice-from-quora-on-how-to-learn-machine-learning">
<node TEXT="A Quora post aptly titled How Do I Learn Machine Learning? ends up being a robust resource.The FAQ has generated a lot of attention during the course of its life with 93 answers and more than 468000 views and has contributions from a number of well-known personalities in the machine learning world." ID="ID_1484393044" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
</node>
<node TEXT="Topics" ID="ID_418711153" CREATED="1549361891209" MODIFIED="1549361895072">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Sub Topics" ID="ID_1422668863" CREATED="1549365931051" MODIFIED="1549365936959">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Quora Topics MachineLearning#$D$#" FOLDED="true" ID="ID_1720021540" CREATED="1557224068550" MODIFIED="1557224307484">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning - Quora" FOLDED="true" ID="ID_1286400295" CREATED="1557224068550" MODIFIED="1557224306279" LINK="https://www.quora.com/topic/Machine-Learning">
<node TEXT="In my career I have seen many folks progress (or stagnate) and interviewed a lot of candidates (beginner to senior level). The good news is that the ML space has now become so big that there are m" ID="ID_1656203151" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Machine Learning at Quora - Engineering at Quora - Quora" FOLDED="true" ID="ID_492589674" CREATED="1557224068550" MODIFIED="1557224306279" LINK="https://engineering.quora.com/Machine-Learning-at-Quora">
<node TEXT="The Quora use-case though is a bit more challenging than the one of ranking movies and TV shows at Netflix. As a matter of fact one could look at our use case as a combination of what Netflix Facebook and Google News need to do to optimize their personalized ranking." ID="ID_235605958" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Machine Learning Startups - Quora" FOLDED="true" ID="ID_951084248" CREATED="1557224068550" MODIFIED="1557224306279" LINK="https://www.quora.com/topic/Machine-Learning-Startups">
<node TEXT="Why are there so few machine learning and natural language processing startups? With so many applications in research literature and so much progress being made what is stopping people from starting companies based on these technologies?" ID="ID_571026855" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="As We Head Into 2018 Which Topics In AI And Machine " FOLDED="true" ID="ID_1197956582" CREATED="1557224068550" MODIFIED="1557224306280" LINK="https://www.forbes.com/sites/quora/2017/12/29/as-we-head-into-2018-which-topics-in-ai-and-machine-learning-are-still-mostly-hype/">
<node TEXT="As we enter into 2018 what are some of the topics in AI/ML that are mostly hype? originally appeared on Quora: the place to gain and share knowledge empowering people to learn from others and " ID="ID_1662381208" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Classification (machine learning) - Quora" FOLDED="true" ID="ID_374160516" CREATED="1557224068550" MODIFIED="1557224306280" LINK="https://www.quora.com/topic/Classification-machine-learning">
<node TEXT="The Inception network. If the first thing that comes to your mind on hearing the word &#x2018;inception&#x2019; is the legendary movie by Christopher Nolan and you wonder if there is there is some sort of coincide" ID="ID_1708743852" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="How Does Quora Use Machine Learning In 2017? - Forbes" FOLDED="true" ID="ID_1973185436" CREATED="1557224068550" MODIFIED="1557224306280" LINK="https://www.forbes.com/sites/quora/2017/04/19/how-does-quora-use-machine-learning-in-2017/">
<node TEXT="How does Quora use machine learning in 2017? originally appeared on Quora: the place to gain and share knowledge empowering people to learn from others and better understand the world. Answer by " ID="ID_1419096442" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Learn Machine Learning - Quora" FOLDED="true" ID="ID_1957471379" CREATED="1557224068550" MODIFIED="1557224306280" LINK="https://learn-machine-learning.quora.com/">
<node TEXT="Its a great way to refresh yourself on just a topic or two without needing to dig through a course syllabus to find what you need. Machine Learning Video Library 3023 views &#xb7; 3 upvotes &#xb7; Posted Jul 5 2012" ID="ID_161185005" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Machine Learning Intuition - Quora" FOLDED="true" ID="ID_448808313" CREATED="1557224068550" MODIFIED="1557224306280" LINK="https://schmatz-learn.quora.com/">
<node TEXT="A collection of explanations on technical topics in machine learning. The vanishing gradient problem is a problem experienced by neural networks during backpropagation when certain activation functions are used.. Neural networks are powerful because they are able to learn complex nonlinear relationships. If each layer computed a linear function of the inputs from the" ID="ID_1189723822" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="In What Ways Is Machine Learning Overrated? - Forbes" FOLDED="true" ID="ID_1454605512" CREATED="1557224068550" MODIFIED="1557224306280" LINK="https://www.forbes.com/sites/quora/2017/12/21/in-what-ways-is-machine-learning-overrated/">
<node TEXT="In what ways is machine learning overrated? originally appeared on Quora: the place to gain and share knowledge empowering people to learn from others and better understand the world. Answer by " ID="ID_923973264" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Machine Learning at Quora - LinkedIn" FOLDED="true" ID="ID_878256142" CREATED="1557224068550" MODIFIED="1557224306280" LINK="https://www.linkedin.com/pulse/machine-learning-quora-xavier-amatriain">
<node TEXT="Ever since I joined Quora almost a year ago I have been talking about all the very interesting machine learning challenges that we have here. However when I attended and spoke at MLConf last week " ID="ID_1996147678" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Public large datasets - Quora. : MachineLearning" FOLDED="true" ID="ID_1769067559" CREATED="1557224068550" MODIFIED="1557224306280" LINK="https://www.reddit.com/r/MachineLearning/comments/1kr564/public_large_datasets_quora/">
<node TEXT="The MachineLearning community on Reddit. Reddit gives you the best of the internet in one place." ID="ID_1434119393" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
<node TEXT="Machine Learning @Quora - slideshare.net" FOLDED="true" ID="ID_325256856" CREATED="1557224068550" MODIFIED="1557224306281" LINK="https://www.slideshare.net/xamat/machine-learning-to-grow-the-worlds-knowledge/9-Machine_LearningQuora">
<node TEXT="Machine Learning @Quora . Forget about surgery pills and weights they DONT work! This DOES work but you need to follow the methods contained in the guide." ID="ID_1987188542" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
</node>
</node>
</node>
<node TEXT="Spaces" ID="ID_1541337816" CREATED="1549365174076" MODIFIED="1549365263613">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Quora Spaces MachineLearning#$D$#" FOLDED="true" ID="ID_1817428549" CREATED="1557224068551" MODIFIED="1557224307485">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning - Quora" FOLDED="true" ID="ID_1261138687" CREATED="1557224068551" MODIFIED="1557224306281" LINK="https://www.quora.com/topic/Machine-Learning">
<node TEXT="In my career I have seen many folks progress (or stagnate) and interviewed a lot of candidates (beginner to senior level). The good news is that the ML space has now become so big that there are m" ID="ID_155854022" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Machine Learning Workshops at Quora - Splash" FOLDED="true" ID="ID_1571618645" CREATED="1557224068551" MODIFIED="1557224306281" LINK="https://bnbr2017.splashthat.com/">
<node TEXT="Well explain how we combine machine learning systems with human reviewers to ensure the Quora you see only consists of high quality content. Finally we will highlight some lessons learned from applying state-of-the-art machine learning techniques to consumer products at scale." ID="ID_362886554" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="What Were The Most Significant Machine Learning Advances " FOLDED="true" ID="ID_676279927" CREATED="1557224068551" MODIFIED="1557224306281" LINK="https://www.forbes.com/sites/quora/2019/01/15/what-were-the-most-significant-machine-learning-advances-of-2018/">
<node TEXT="What were the most significant machine learning/AI advances in 2018? originally appeared on Quora: the place to gain and share knowledge empowering people to learn from others and better " ID="ID_1325347339" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="How to learn machine learning - Quora" FOLDED="true" ID="ID_304316579" CREATED="1557224068551" MODIFIED="1557224306281" LINK="https://www.quora.com/How-do-I-learn-machine-learning-1">
<node TEXT="Machine learning is one of the hottest trendings in tech industries today. Machine learning is very powerful to make prediction or recommendations based on huge amount of data sets. Machine learning has vast use cases for different domains either in the e-commerce business finance intelligence sci-fi movies marketing real estate etc" ID="ID_951998911" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="What is hypothesis in machine learning? - Quora" FOLDED="true" ID="ID_1427601939" CREATED="1557224068551" MODIFIED="1557224306281" LINK="https://www.quora.com/What-is-hypothesis-in-machine-learning">
<node TEXT="What is hypothesis in machine learning? Update Cancel.  Postdoc @U of Toronto and Quora User M.S Computer Science The University of Texas at Dallas (2018) &#xb7; Author has 291 answers and 2.3m answer views.  What does the hypothesis space mean in Machine Learning?" ID="ID_37193776" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="What are the most interesting applications of machine " FOLDED="true" ID="ID_1103608808" CREATED="1557224068551" MODIFIED="1557224306281" LINK="https://www.quora.com/What-are-the-most-interesting-applications-of-machine-learning-in-unexpected-spaces">
<node TEXT="Creating a movie trailer! Last year 20th Century Fox released a trailer (watch here) claiming to be the first one created by AI/Machine Learning (IBM Watson).The movie was an AI horror thriller Morgan. In spite of headlines like Watch: IBMs Watson Created a Super Creepy Movie Trailer All By Itself Watson did not do it all by itself. All Watson did was choosing 10 scenes (totaling 6 " ID="ID_856645664" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="What is a Hypothesis in Machine Learning?" FOLDED="true" ID="ID_51831998" CREATED="1557224068551" MODIFIED="1557224306281" LINK="https://machinelearningmastery.com/what-is-a-hypothesis-in-machine-learning/">
<node TEXT="Supervised machine learning is often described as the problem of approximating a target function that maps inputs to outputs. This description is characterized as searching through and evaluating candidate hypothesis from hypothesis spaces. The discussion of hypotheses in machine learning can be " ID="ID_1997734944" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="What Is The Future Of Machine Learning? - Forbes" FOLDED="true" ID="ID_1931528677" CREATED="1557224068551" MODIFIED="1557224306282" LINK="https://www.forbes.com/sites/quora/2015/02/12/what-is-the-future-of-machine-learning/">
<node TEXT="This question originally appeared on Quora: What does David Karger think about the future of machine learning?. Answer by David Karger Computer Science Professor at MIT on Quora. I think that " ID="ID_52278750" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Examples of good PhD theses involving machine learning " FOLDED="true" ID="ID_1392897581" CREATED="1557224068551" MODIFIED="1557224306282" LINK="https://www.reddit.com/r/MachineLearning/comments/3h3k4u/examples_of_good_phd_theses_involving_machine/">
<node TEXT="Hi everyone Im just getting my feet wet in machine learning and also starting a PhD in computer science. The project that Im working on while not about machine learning directly will involve a fair bit of data analysis in particular classification." ID="ID_1465111874" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="How Does Quora Use Machine Learning In 2017? - Forbes" FOLDED="true" ID="ID_1481575684" CREATED="1557224068551" MODIFIED="1557224306282" LINK="https://www.forbes.com/sites/quora/2017/04/19/how-does-quora-use-machine-learning-in-2017/">
<node TEXT="How does Quora use machine learning in 2017? originally appeared on Quora: the place to gain and share knowledge empowering people to learn from others and better understand the world. Answer by " ID="ID_169232211" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Public large datasets - Quora. : MachineLearning" FOLDED="true" ID="ID_1597429745" CREATED="1557224068551" MODIFIED="1557224306282" LINK="https://www.reddit.com/r/MachineLearning/comments/1kr564/public_large_datasets_quora/">
<node TEXT="The MachineLearning community on Reddit. Reddit gives you the best of the internet in one place." ID="ID_819957573" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Machine Learning Workshop: Combatting Abuse Online - Quora" FOLDED="true" ID="ID_700013239" CREATED="1557224068551" MODIFIED="1557224306282" LINK="https://engineering.quora.com/Machine-Learning-Workshop-Combatting-Abuse-Online">
<node TEXT="Quora recently hosted a workshop on using machine learning to combat spam harassment and sock puppets in online communities.While human reporting and traditional moderation solutions play a key role in safeguarding shared spaces ML needs to do the heavy lifting once platforms reach a massive scale." ID="ID_67301200" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
</node>
</node>
</node>
<node TEXT="LinkedIn" ID="ID_209978364" CREATED="1549361866222" MODIFIED="1549361872653">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Organisations" ID="ID_43451991" CREATED="1549361912213" MODIFIED="1549361916326">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="LinkedIn organisations MachineLearning#$D$#" FOLDED="true" ID="ID_80164095" CREATED="1557224068551" MODIFIED="1557224307485">
<icon BUILTIN="stop-sign"/>
<node TEXT="Instantor AB | LinkedIn" FOLDED="true" ID="ID_1906595742" CREATED="1557224068551" MODIFIED="1557224306282" LINK="https://www.linkedin.com/company/instantor-ab">
<node TEXT="Learn about working at Instantor AB. Join LinkedIn today for free. See who you know at Instantor AB leverage your professional network and get hired." ID="ID_208061375" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Building The LinkedIn Knowledge Graph | LinkedIn Engineering" FOLDED="true" ID="ID_1211788358" CREATED="1557224068551" MODIFIED="1557224306282" LINK="https://engineering.linkedin.com/blog/2016/10/building-the-linkedin-knowledge-graph">
<node TEXT="Building the LinkedIn knowledge graph includes node (entity) taxonomy construction edge (entity relationship) inference and graph representation. Aggregations on top of the graph provide additional insights some of which can contribute back to further complete the graph." ID="ID_1723619884" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Data - LinkedIn" FOLDED="true" ID="ID_288240972" CREATED="1557224068551" MODIFIED="1557224306282" LINK="https://engineering.linkedin.com/teams/data">
<node TEXT="As a members-first organization LinkedIn keeps the privacy and security of our members at the forefront in all our research. LinkedIn&#x2019;s team of data scientists and researchers work with huge amounts of data solve real problems for our members around the world and publish at major conferences." ID="ID_804419475" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Sign In - LinkedIn Learning" FOLDED="true" ID="ID_1592718809" CREATED="1557224068551" MODIFIED="1557224306283" LINK="https://www.linkedin.com/learning/login">
<node TEXT="Learn business creative and technology skills to achieve your personal and professional goals. Join today to get access to thousands of courses." ID="ID_1946474475" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Learning Machine | Learning Machine" FOLDED="true" ID="ID_976172995" CREATED="1557224068551" MODIFIED="1557224306283" LINK="https://www.learningmachine.com/">
<node TEXT="Issue verifiable digital records. Learning Machine provides a complete system to issue official records using a blockchain-anchored format that is instantly verifiable anywhere in the world." ID="ID_718775895" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="LinkedIn - Online Learning  Training Platform for " FOLDED="true" ID="ID_1568594484" CREATED="1557224068551" MODIFIED="1557224306283" LINK="https://learning.linkedin.com/">
<node TEXT="Looking for online training options for your organizations workforce? LinkedIn Learning helps develop talent and keep vital business skills current with engaging online training and courses." ID="ID_1059894203" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Council Post: Using Machine Learning To Improve Customer " FOLDED="true" ID="ID_1373521890" CREATED="1557224068551" MODIFIED="1557224306283" LINK="https://www.forbes.com/sites/forbestechcouncil/2019/04/24/using-machine-learning-to-improve-customer-service/">
<node TEXT="The same fact applies when attempting to improve the customer experience by using machine learning. Forbes Technology Council is an invitation-only community for world-class CIOs CTOs and " ID="ID_319467288" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Machine-learning system used to diagnose genetic diseases " FOLDED="true" ID="ID_663636153" CREATED="1557224068551" MODIFIED="1557224306283" LINK="https://www.sciencedaily.com/releases/2019/04/190424153613.htm">
<node TEXT="Scientists have utilized a machine-learning process and clinical natural language processing (CNLP) to diagnose rare genetic diseases in record time. This new method is speeding answers to " ID="ID_392493783" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Become a Machine Learning Engineer | Udacity" FOLDED="true" ID="ID_434885744" CREATED="1557224068551" MODIFIED="1557224306283" LINK="https://www.udacity.com/course/machine-learning-engineer-nanodegree--nd009t">
<node TEXT="The Machine Learning Engineer Nanodegree program is built by engineers for programmers and learners to help prepare you for a job as a machine learning engineer. Udacity supports your career journey throughout the preparation and search process. Our goal is to move you forward in your career." ID="ID_1062161253" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="LinkedIn Learning Product Overview | LinkedIn Learning " FOLDED="true" ID="ID_1810627894" CREATED="1557224068551" MODIFIED="1557224306283" LINK="https://learning.linkedin.com/product-overview">
<node TEXT="Harness the power of the LinkedIn professional network to provide learners with individualized elearning. LinkedIn Learning features course recommendations personalized playlists expertly curated Learning Paths mobile access online or offline and robust administrative tools for measuring success." ID="ID_1204685798" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="LinkedIn 2018 Emerging Jobs Report" FOLDED="true" ID="ID_1685104213" CREATED="1557224068551" MODIFIED="1557224306283" LINK="https://economicgraph.linkedin.com/en-us/research/linkedin-2018-emerging-jobs-report">
<node TEXT="Introduction from Guy Berger Chief Economist LinkedIn The Emerging Jobs Report is our opportunity to take a look at the jobs and skills that are growing most rapidly around the country so you as U.S. professionals can make more informed decisions about your career. Using data from LinkedIn&#x2019;s Economic Graph we analyzed the roles that companies are rapidly hiring for the skills " ID="ID_321040787" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="LinkedIn Announces New Recruiter platform its first ATS " FOLDED="true" ID="ID_1933657817" CREATED="1557224068551" MODIFIED="1557224306283" LINK="https://news.linkedin.com/2018/10/linkedin-talent-connect-2018">
<node TEXT="Today at our ninth annual Talent Connect conference we announced several new products and features to help talent leaders navigate todays digital transformation against a backdrop of the growing skills shortage and fierce competition for talent and getting hired. Providing a foundation for the announcements is the evolution of our Talent Solutions portfolio to focus on helping companies " ID="ID_1814387714" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
</node>
<node TEXT="LinkedIn Industry Leaders MachineLearning#$D$#" FOLDED="true" ID="ID_684699154" CREATED="1557224068551" MODIFIED="1557224307485">
<icon BUILTIN="stop-sign"/>
<node TEXT="5000+ Machine Learning Engineer jobs in United States" FOLDED="true" ID="ID_1628118561" CREATED="1557224068551" MODIFIED="1557224306284" LINK="https://www.linkedin.com/jobs/machine-learning-engineer-jobs">
<node TEXT="Todays top 5000+ Machine Learning Engineer jobs in United States. Leverage your professional network and get hired. New Machine Learning Engineer jobs added daily." ID="ID_617890840" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="The 3 Industry Trends That Talent Leaders Are Talking About" FOLDED="true" ID="ID_1779940365" CREATED="1557224068551" MODIFIED="1557224306284" LINK="https://business.linkedin.com/talent-solutions/blog/talent-connect/2017/the-3-industry-trends-that-talent-leaders-are-talking-about">
<node TEXT="The 3 Industry Trends That Talent Leaders Are Talking About. Gregory Lewis.  LinkedIn CEO Jeff Weiner named three trends that will shape the future of talent&#x2014;and number one on his list was artificial intelligence (AI) and automation. While it reshapes the broader economy AI will also impact the way recruiters do their job too " ID="ID_670785712" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Meet the 9 most influential tech leaders on LinkedIn | CIO" FOLDED="true" ID="ID_466948922" CREATED="1557224068551" MODIFIED="1557224306284" LINK="https://www.cio.com/article/2970081/meet-the-9-most-influential-tech-leaders-on-linkedin.html">
<node TEXT="Meet the 9 most influential tech leaders on LinkedIn With more than 380 million total LinkedIn members it&#x2019;s difficult to find the most relevant people in IT to follow." ID="ID_210139995" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Data Futurology - Machine Learning From Top Industry Leaders" FOLDED="true" ID="ID_1713302394" CREATED="1557224068551" MODIFIED="1557224306284" LINK="https://www.facebook.com/datafuturology/">
<node TEXT="Data Futurology - Machine Learning From Top Industry Leaders Melbourne Victoria Australia. 93 likes. Data from a human lens. In Data Futurology we" ID="ID_1573708711" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Industry Leaders Magazine | LinkedIn" FOLDED="true" ID="ID_183022466" CREATED="1557224068551" MODIFIED="1557224306284" LINK="https://www.linkedin.com/company/industry-leaders-magazine">
<node TEXT="Learn about working at Industry Leaders Magazine. Join LinkedIn today for free. See who you know at Industry Leaders Magazine leverage your professional network and get hired." ID="ID_474325818" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Skyline G Adds Machine Learning to Their C4X Leadership " FOLDED="true" ID="ID_1917346514" CREATED="1557224068551" MODIFIED="1557224306284" LINK="https://trainingindustry.com/press-release/leadership/skyline-g-adds-machine-learning-to-their-c4x-leadership-coaching-technology/">
<node TEXT="Skyline G Adds Machine Learning to Their C4X Leadership Coaching Technology January 16 2019 1 min read San Francisco &#x2013; January 16 2019 &#x2013; As a pioneer in leadership development technology Skyline Group is proud to continue to be the innovation leader in the leadership development industry." ID="ID_1805494395" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Machine Learning in Education Market 2019 Global Trends " FOLDED="true" ID="ID_1937721601" CREATED="1557224068551" MODIFIED="1557224306284" LINK="https://www.marketwatch.com/press-release/machine-learning-in-education-market-2019-global-trends-market-share-industry-size-growth-opportunities-and-forecast-to-2024-2019-04-26">
<node TEXT="Apr 26 2019 (AB Digital via COMTEX) -- Summary WiseGuyReports.com adds &#x201c;Machine Learning in Education Market 2019 Global Analysis Growth Trends" ID="ID_992340195" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="About Us - LinkedIn" FOLDED="true" ID="ID_1841239593" CREATED="1557224068551" MODIFIED="1557224306284" LINK="https://news.linkedin.com/about-us">
<node TEXT="LinkedIn has more than 14000 full-time employees (more than 5500 in the San Francisco Bay Area) with offices in more than 30 cities around the world. LinkedIn started off 2012 with about 2100 full-time employees worldwide up from around 1000 at the beginning of 2011 and about 500 at the beginning of 2010." ID="ID_1986900273" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="The Next Wave Of Enterprise Software Powered By Machine " FOLDED="true" ID="ID_1448699199" CREATED="1557224068551" MODIFIED="1557224306285" LINK="https://techcrunch.com/2015/07/27/the-next-wave-of-enterprise-software-powered-by-machine-learning/">
<node TEXT="Emerging Leaders In Machine Learning Apps. This new wave of enterprise software powered by machine learning is already finding its way into core business disciplines:" ID="ID_1820628574" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Who are the thought leaders of machine learning? - Quora" FOLDED="true" ID="ID_1710854810" CREATED="1557224068551" MODIFIED="1557224306285" LINK="https://www.quora.com/Who-are-the-thought-leaders-of-machine-learning">
<node TEXT="I have many issues with Microsoft and I don&#x2019;t use their products much but they have a list of top researchers so called thought leaders in machine learning. The list is here: Top authors in machine learning  pattern recognition Here is another list which I agree with: 10 Famous Machine Learning Experts" ID="ID_37231429" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="LinkedIns Fastest-Growing Jobs Today Are In Data Science " FOLDED="true" ID="ID_1185442231" CREATED="1557224068551" MODIFIED="1557224306285" LINK="https://www.forbes.com/sites/louiscolumbus/2017/12/11/linkedins-fastest-growing-jobs-today-are-in-data-science-machine-learning/">
<node TEXT="There are currently 1829 open Machine Learning Engineering positions on LinkedIn. Machine learning engineer data scientist and big data engineers rank among the top emerging jobs on LinkedIn today." ID="ID_758538750" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="2019 Top Leadership Training Companies - Training Industry" FOLDED="true" ID="ID_1150864036" CREATED="1557224068551" MODIFIED="1557224306285" LINK="https://trainingindustry.com/top-training-companies/leadership/2019-top-leadership-training-companies/">
<node TEXT="As part of its commitment to continuously monitor the training marketplace for the best providers and services Training Industry has released its 2019 Top 20 Leadership Training Companies List." ID="ID_55250102" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
</node>
<node TEXT="LinkedIn Jobs  MachineLearning#$D$#" FOLDED="true" ID="ID_274562303" CREATED="1557224068551" MODIFIED="1557224307485">
<icon BUILTIN="stop-sign"/>
<node TEXT="44000+ Machine Learning jobs in United States - LinkedIn" FOLDED="true" ID="ID_592179789" CREATED="1557224068551" MODIFIED="1557224306286" LINK="https://www.linkedin.com/jobs/machine-learning-jobs">
<node TEXT="Todays top 44000+ Machine Learning jobs in United States. Leverage your professional network and get hired. New Machine Learning jobs added daily." ID="ID_130404883" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Machine Learning Intern jobs in United States - LinkedIn" FOLDED="true" ID="ID_822806795" CREATED="1557224068551" MODIFIED="1557224306287" LINK="https://www.linkedin.com/jobs/machine-learning-intern-jobs?country=in">
<node TEXT="Todays top 1000+ Machine Learning Intern jobs in United States. Leverage your professional network and get hired. New Machine Learning Intern jobs added daily." ID="ID_350362239" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Intel Corporation Machine Learning jobs in  - LinkedIn" FOLDED="true" ID="ID_873915536" CREATED="1557224068551" MODIFIED="1557224306287" LINK="https://www.linkedin.com/jobs/intel-corporation-machine-learning-jobs">
<node TEXT="Todays top 146 Intel Corporation Machine Learning jobs in United States. Leverage your professional network and get hired. New Intel Corporation Machine Learning jobs added daily." ID="ID_1034175778" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="995 Facebook Machine Learning jobs in United States - LinkedIn" FOLDED="true" ID="ID_302075406" CREATED="1557224068551" MODIFIED="1557224306287" LINK="https://www.linkedin.com/jobs/facebook-machine-learning-jobs">
<node TEXT="Todays top 995 Facebook Machine Learning jobs in United States. Leverage your professional network and get hired. New Facebook Machine Learning jobs added daily." ID="ID_994546502" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="5000+ Machine Learning Engineer jobs in United States" FOLDED="true" ID="ID_1528639762" CREATED="1557224068551" MODIFIED="1557224306287" LINK="https://www.linkedin.com/jobs/machine-learning-engineer-jobs">
<node TEXT="Todays top 5000+ Machine Learning Engineer jobs in United States. Leverage your professional network and get hired. New Machine Learning Engineer jobs added daily." ID="ID_222352497" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="483 Machine Learning jobs in South Africa - za.linkedin.com" FOLDED="true" ID="ID_1343562404" CREATED="1557224068551" MODIFIED="1557224306287" LINK="https://za.linkedin.com/jobs/machine-learning-jobs">
<node TEXT="Todays top 483 Machine Learning jobs in South Africa. Leverage your professional network and get hired. New Machine Learning jobs added daily." ID="ID_1188385166" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="LinkedIn&#x2019;s 2017 U.S. Emerging Jobs Report" FOLDED="true" ID="ID_143798559" CREATED="1557224068551" MODIFIED="1557224306287" LINK="https://economicgraph.linkedin.com/research/LinkedIns-2017-US-Emerging-Jobs-Report">
<node TEXT="The job market in the U.S. is brimming right now with fresh and exciting opportunities for professionals in a range of emerging roles. New types of jobs means new potential for workers at all levels especially for those looking to change careers. Overall job growth in the next decade is expected to outstrip growth during the previous decade creating 11.5 million jobs by 2026 according to " ID="ID_419381204" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="21 Machine Learning jobs in Pakistan - LinkedIn" FOLDED="true" ID="ID_1047000247" CREATED="1557224068551" MODIFIED="1557224306287" LINK="https://pk.linkedin.com/jobs/machine-learning-jobs">
<node TEXT="Todays top 21 Machine Learning jobs in Pakistan. Leverage your professional network and get hired. New Machine Learning jobs added daily." ID="ID_1400746379" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Become a Machine Learning Engineer | Udacity" FOLDED="true" ID="ID_839067407" CREATED="1557224068551" MODIFIED="1557224306287" LINK="https://www.udacity.com/course/machine-learning-engineer-nanodegree--nd009t">
<node TEXT="The Machine Learning Engineer Nanodegree program is built by engineers for programmers and learners to help prepare you for a job as a machine learning engineer. Udacity supports your career journey throughout the preparation and search process. Our goal is to move you forward in your career." ID="ID_846346329" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="203 Machine Learning jobs in Finland - LinkedIn" FOLDED="true" ID="ID_824886912" CREATED="1557224068551" MODIFIED="1557224306288" LINK="https://fi.linkedin.com/jobs/machine-learning-jobs">
<node TEXT="Todays top 203 Machine Learning jobs in Finland. Leverage your professional network and get hired. New Machine Learning jobs added daily." ID="ID_1482872741" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="LinkedIns Fastest-Growing Jobs Today Are In Data Science " FOLDED="true" ID="ID_726236638" CREATED="1557224068551" MODIFIED="1557224306288" LINK="https://www.forbes.com/sites/louiscolumbus/2017/12/11/linkedins-fastest-growing-jobs-today-are-in-data-science-machine-learning/">
<node TEXT="There are currently 1829 open Machine Learning Engineering positions on LinkedIn. Machine learning engineer data scientist and big data engineers rank among the top emerging jobs on LinkedIn today." ID="ID_1778435618" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Data Scientist (Machine Learning) - ph.linkedin.com" FOLDED="true" ID="ID_127657166" CREATED="1557224068551" MODIFIED="1557224306288" LINK="https://ph.linkedin.com/jobs/view/data-scientist-machine-learning-at-accenture-1211419347?position=15pageNum=0">
<node TEXT="Utilizes machine learning algorithms and models and presents them using data visualization techniques. Has strong familiarity with statistical software packages such as R Python SAS and Scala as well as different end-to-end data science and advanced analytics tools such as Microsoft Azure Machine Learning." ID="ID_360824106" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
</node>
</node>
<node TEXT="User Profiles" ID="ID_1377134515" CREATED="1549361917254" MODIFIED="1549366275622">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Groups" ID="ID_1375793908" CREATED="1549366276917" MODIFIED="1549366279692">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="LinkedIn Groups MachineLearning#$D$#" FOLDED="true" ID="ID_1927519574" CREATED="1557224068551" MODIFIED="1557224307485">
<icon BUILTIN="stop-sign"/>
<node TEXT="Top 5 LinkedIn Groups for Machine Learning Professionals" FOLDED="true" ID="ID_1989738934" CREATED="1557224068551" MODIFIED="1557224306285" LINK="https://solutionsreview.com/business-intelligence/top-5-linkedin-groups-for-machine-learning-professionals/">
<node TEXT="LinkedIn is the premier place for enterprise technology professionals to gather connect with one another share ideas and network. If you are a business person who works in the machine learning or artificial intelligence field or you&#x2019;re just looking for additional insights into what the smartest in the industry are talking about LinkedIn professional groups are a great place to start." ID="ID_195414080" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Machine Learning Society | LinkedIn" FOLDED="true" ID="ID_1524919190" CREATED="1557224068551" MODIFIED="1557224306285" LINK="https://www.linkedin.com/company/machine-learning-society">
<node TEXT="Learn about working at Machine Learning Society. Join LinkedIn today for free. See who you know at Machine Learning Society leverage your professional network and get hired." ID="ID_631854917" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Monticello Consulting Group | LinkedIn" FOLDED="true" ID="ID_1017839357" CREATED="1557224068551" MODIFIED="1557224306285" LINK="https://www.linkedin.com/company/monticello-consulting-group">
<node TEXT="Learn about working at Monticello Consulting Group. Join LinkedIn today for free. See who you know at Monticello Consulting Group leverage your professional network and get hired." ID="ID_1300851430" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Top LinkedIn Groups for Analytics Big Data Data Mining " FOLDED="true" ID="ID_233650698" CREATED="1557224068551" MODIFIED="1557224306285" LINK="https://www.kdnuggets.com/2016/10/top-linkedin-groups-analytics-big-data-mining-data-science.html">
<node TEXT="The 10 largest groups grew at a similar rate except the top Big Data  Analytics group - see Fig 1 but the next 20 groups showed a lot more variety with some groups like Data Scientists and KDnuggets growing fast but many groups showing very slow growth or declining. Fig. 1: Top 10 LinkedIn " ID="ID_932067349" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Machine Learning TO Meetup (Toronto ON) | Meetup" FOLDED="true" ID="ID_695944504" CREATED="1557224068551" MODIFIED="1557224306286" LINK="https://www.meetup.com/Machine-Learning-TO-Meetup/">
<node TEXT="Machine Learning TO is a new meetup group for ML professionals students and enthusiasts. We offer a fun casual setting where professionals can convene over a food and drink share experiences and talk current projects." ID="ID_822891113" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Machine Learning News - Google Groups" FOLDED="true" ID="ID_1833007750" CREATED="1557224068551" MODIFIED="1557224306286" LINK="https://groups.google.com/d/forum/ML-news">
<node TEXT="Machine Learning News This group serves as a forum for notices and announcements of interest to the machine learning community. This includes events calls for papers employment-related announcements etc. This group is moderated and maintained by IMLS (www.machinelearning.org). All messages are moderated and may take a few days to be posted." ID="ID_785765061" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="What are the best machine-learning research groups in " FOLDED="true" ID="ID_732378366" CREATED="1557224068551" MODIFIED="1557224306286" LINK="https://www.quora.com/What-are-the-best-machine-learning-research-groups-in-Europe">
<node TEXT="The Swiss AI Lab IDSIA situated near Lugano and headed by Dr. Juergen Schmidhuber. In the last 5 years they have had several successes in different machine learning competitions (information shamelessly taken from Deep Learning Blog):-. 22 Sept 2013: Deep neural network of the Swiss AI Lab IDSIA wins MICCAI 2013 Grand Challenge on Mitosis Detection (important for cancer prognosis etc)." ID="ID_127489416" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Nuit Blanche: Paris Machine Learning LinkedIn group and " FOLDED="true" ID="ID_1286030438" CREATED="1557224068551" MODIFIED="1557224306286" LINK="https://nuit-blanche.blogspot.com/2013/10/paris-machine-learning-linkedin-group.html">
<node TEXT="Paris Machine Learning LinkedIn group and Meetup #4 We have created a Paris Machine Learning group on LinkedIn. You might want to join us there. We also organize Meetups on the subject of Machine Learning and its applications. If you are in the area at some point in time and willing to give a talk please contact me. We currently aim for those " ID="ID_1467310853" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="David Pavlov - Machine Learning Engineer - Fadata Group " FOLDED="true" ID="ID_275550513" CREATED="1557224068551" MODIFIED="1557224306286" LINK="https://bg.linkedin.com/in/david-pavlov">
<node TEXT="Machine Learning Engineer at Fadata Group Sofia Sofia City Province Bulgaria Information Technology and Services. Fadata Group. Fadata AD. University of Groningen. 167 connections. View David Pavlov&#x2019;s full profile. Its free! Your colleagues classmates and 500 million other professionals are on LinkedIn." ID="ID_869687306" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Machine Learning Professional Networking Meetup | Meetup" FOLDED="true" ID="ID_1060853137" CREATED="1557224068551" MODIFIED="1557224306286" LINK="https://www.meetup.com/Machine-Learning-and-Data-Science-Business-Network/events/237211084/">
<node TEXT="The April meetup of the Machine Learning and Data Science Business Network is a free networking event in NYC to meet machine learning [ML] practitioners ML startup company investors and prospective clientele." ID="ID_1926311957" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Scaling Machine Learning on Graphs at LinkedIn - TWiML " FOLDED="true" ID="ID_1925256432" CREATED="1557224068551" MODIFIED="1557224306286" LINK="https://twimlai.com/twiml-talk-236-scaling-machine-learning-on-graphs-at-linkedin-with-hema-raghavan-and-scott-meyer/">
<node TEXT="Scaling Machine Learning on Graphs at LinkedIn with Hema Raghavan and Scott Meyer  Study Group - Fall 2018 Fast.ai Machine Learning Study Group - Fall 2018. Click below to receive Sams (great) newsletter as well featuring podcast industry and event updates: Please send the newsletter." ID="ID_1653704191" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
<node TEXT="Femi Ogunbode - Machine Learning Engineer - LinkedIn" FOLDED="true" ID="ID_900149189" CREATED="1557224068551" MODIFIED="1557224306286" LINK="https://ng.linkedin.com/in/femiogunbode">
<node TEXT="Machine learning represents a key evolution in the fields of computer science data analysis software engineering and artificial intelligence. This program taught me how to become a machine learning engineer and apply predictive models to massive data sets in fields like finance healthcare education and more." ID="ID_60916310" CREATED="1557224068551" MODIFIED="1557224068551"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Cheatsheets" FOLDED="true" ID="ID_721502444" CREATED="1549359403479" MODIFIED="1549359403479">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Cheatsheets MachineLearning#$D$#" FOLDED="true" ID="ID_444122585" CREATED="1557224068548" MODIFIED="1557224307483">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine learning algorithm cheat sheet - Azure Machine " FOLDED="true" ID="ID_1426654053" CREATED="1557224068548" MODIFIED="1557224306249" LINK="https://docs.microsoft.com/en-us/azure/machine-learning/studio/algorithm-cheat-sheet">
<node TEXT="Azure Machine Learning Studio has a large library of algorithms from the regression classification clustering and anomaly detection families. Each is designed to address a different type of machine learning problem. Download: Machine learning algorithm cheat sheet. Download the cheat sheet here: Machine Learning Algorithm Cheat Sheet (11x17 in.)" ID="ID_1751374501" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Top 28 Cheat Sheets for Machine Learning Data Science " FOLDED="true" ID="ID_583120004" CREATED="1557224068548" MODIFIED="1557224306249" LINK="https://www.analyticsvidhya.com/blog/2017/02/top-28-cheat-sheets-for-machine-learning-data-science-probability-sql-big-data/">
<node TEXT="After applying these filters I have collated some 28 cheat sheets on machine learning data science probability SQL and Big Data. For your convenience I have segregated the cheat sheets separately for each of the above topics. There are cheat sheets on tools  techniques various libraries  languages." ID="ID_1729175885" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Cheat Sheets for AI Neural Networks Machine Learning " FOLDED="true" ID="ID_1661671002" CREATED="1557224068548" MODIFIED="1557224306249" LINK="https://becominghuman.ai/cheat-sheets-for-ai-neural-networks-machine-learning-deep-learning-big-data-678c51b4b463">
<node TEXT="Downloadable: Cheat Sheets for AI Neural Networks Machine Learning Deep Learning  Data Science&#x2026; Downloadable PDF of Best AI Cheat Sheets in Super High Definitionbecominghuman.ai" ID="ID_1491833377" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Essential Cheat Sheets for Machine Learning and Deep " FOLDED="true" ID="ID_1136515777" CREATED="1557224068548" MODIFIED="1557224306250" LINK="https://startupsventurecapital.com/essential-cheat-sheets-for-machine-learning-and-deep-learning-researchers-efb6a8ebd2e5">
<node TEXT="Most of the machine learning libraries are difficult to understand and learning curve can be a bit frustrating. I am creating a repository on Github(cheatsheets-ai) containing cheatsheets for different machine learning frameworks gathered from different sources. Do visit the Github repository also contribute cheat sheets if you have any. Thanks." ID="ID_267742010" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="GitHub - soulmachine/machine-learning-cheat-sheet " FOLDED="true" ID="ID_975275694" CREATED="1557224068548" MODIFIED="1557224306250" LINK="https://github.com/soulmachine/machine-learning-cheat-sheet">
<node TEXT="Machine learning cheat sheet. This cheat sheet contains many classical equations and diagrams on machine learning which will help you quickly recall knowledge and ideas on machine learning. The cheat sheet will also appeal to someone who is preparing for a job interview related to machine learning. Download PDF. machine-learning-cheat-sheet.pdf" ID="ID_864803940" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning For Dummies Cheat Sheet - dummies" FOLDED="true" ID="ID_205423635" CREATED="1557224068548" MODIFIED="1557224306250" LINK="https://www.dummies.com/programming/big-data/data-science/machine-learning-dummies-cheat-sheet/">
<node TEXT="Machine learning is an incredible technology that you use more often than you think today and with the potential to do even more tomorrow. The interesting thing about machine learning is that both R and Python make the task easier than more people realize because both languages come with a lot of built-in and extended [&#x2026;]" ID="ID_896674853" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning cheat sheet | Home of Emanuel Ferm" FOLDED="true" ID="ID_440737496" CREATED="1557224068548" MODIFIED="1557224306250" LINK="https://eferm.com/machine-learning-cheat-sheet/">
<node TEXT="For a recently taken course in Machine Learning a substantial part involved learning and applying linear classifiers and clustering algorithms on smaller data sets. In order to summarise the most important material I created a cheat sheet in LaTeX. I figured someone else might appreciate it as well so why not make it available for [&#x2026;]" ID="ID_1763885944" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine learning: A cheat sheet - TechRepublic" FOLDED="true" ID="ID_87093045" CREATED="1557224068548" MODIFIED="1557224306250" LINK="https://www.techrepublic.com/article/machine-learning-the-smart-persons-guide/">
<node TEXT="Machine learning is a branch of AI. Other tools for reaching AI include rule-based engines evolutionary algorithms and Bayesian statistics. While many early AI programs like IBMs Deep Blue " ID="ID_1788834098" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Concise Cheat Sheets of Machine Learning with Python (and " FOLDED="true" ID="ID_1896983570" CREATED="1557224068548" MODIFIED="1557224306250" LINK="https://sinxloud.com/machine-learning-cheat-sheets-python-math-statistics/">
<node TEXT="Machine learning is difficult for beginners. As well as libraries for Machine Learning in python are difficult to understand. Over the past few weeks I have been collecting Machine Learning cheat sheets from different sources and to make things more interesting and give context I added excerpts for each major topic." ID="ID_1656636996" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Cheatsheets - RStudio" FOLDED="true" ID="ID_713739771" CREATED="1557224068548" MODIFIED="1557224306250" LINK="https://www.rstudio.com/resources/cheatsheets/">
<node TEXT="RStudio IDE Cheat Sheet. The RStudio IDE is the most popular integrated development environment for R. Do you want to write run and debug your own R code? Work collaboratively on R projects with version control? Build packages or create documents and apps? No matter what you do with R the RStudio IDE can help you do it faster." ID="ID_1341352964" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Illustrated Machine Learning cheatsheets covering Stanford " FOLDED="true" ID="ID_592961004" CREATED="1557224068548" MODIFIED="1557224306251" LINK="https://www.reddit.com/r/MachineLearning/comments/98wrkw/illustrated_machine_learning_cheatsheets_covering/">
<node TEXT="Illustrated Machine Learning cheatsheets covering Stanfords CS 229 class (self.MachineLearning) submitted 7 months ago by shervinea Set of illustrated Machine Learning cheatsheets covering the content of Stanfords CS 229 class:" ID="ID_1490766115" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning cheatsheets for Stanfords CS 229 - GitHub" FOLDED="true" ID="ID_1030678343" CREATED="1557224068548" MODIFIED="1557224306251" LINK="https://github.com/afshinea/stanford-cs-229-machine-learning">
<node TEXT="Machine Learning cheatsheets for Stanfords CS 229. Available in English - Espa&#xf1;ol - &#x641;&#x627;&#x631;&#x633;&#x6cc; - Fran&#xe7;ais - &#xd55c;&#xad6d;&#xc5b4; - Portugu&#xea;s - T&#xfc;rk&#xe7;e - &#x4e2d;&#x6587;. Goal. This repository aims at summing up in the same place all the important notions that are covered in Stanfords CS 229 Machine Learning course and include:" ID="ID_558953694" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
</node>
</node>
<node TEXT="Flash Cards" FOLDED="true" ID="ID_1056215552" CREATED="1549359518866" MODIFIED="1562238155721">
<edge WIDTH="2"/>
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Anki Droid" ID="ID_1309103048" CREATED="1549361992841" MODIFIED="1549361996360">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="PC" ID="ID_1317982081" CREATED="1549368517440" MODIFIED="1562919693800" LINK="https://apps.ankiweb.net/">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Flash Cards MachineLearning#$D$#" FOLDED="true" ID="ID_1495923981" CREATED="1557224068548" MODIFIED="1557224307483">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning Flashcards" FOLDED="true" ID="ID_667652720" CREATED="1557224068548" MODIFIED="1557224306251" LINK="https://machinelearningflashcards.com/">
<node TEXT="Machine learning is a broad field encompassing parts of computer science statistics scientific computing and mathematics. There are hundreds of concepts to learn. These flashcards are designed to help you memorize key concepts in machine learning rapidly and enjoyably." ID="ID_1307631573" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Flashcards - Gumroad" FOLDED="true" ID="ID_525739819" CREATED="1557224068548" MODIFIED="1557224306251" LINK="https://gumroad.com/l/machinelearningflashcards">
<node TEXT="Chris Albon A zip file containing hundreds of digital flashcards on machine learning topics in DRM-free web quality png image print quality png image PDF Anki and SVG vector file formats." ID="ID_74027257" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Flashcards - Chris Albon" FOLDED="true" ID="ID_1964703577" CREATED="1557224068548" MODIFIED="1557224306251" LINK="https://store.chrisalbon.com/machine-learning-flashcards">
<node TEXT="A zip file containing hundreds of digital flashcards on machine learning topics in DRM-free web quality png image print quality png image PDF Anki and SVG vector file formats." ID="ID_852137406" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Flashcards | Quizlet" FOLDED="true" ID="ID_894440571" CREATED="1557224068548" MODIFIED="1557224306251" LINK="https://quizlet.com/139653249/machine-learning-flash-cards/">
<node TEXT="Machine learning is the science of programming computers. Machine learning is the field of study that gives computers the ability to learn without being explicitly programmed. machine learning is the field of study that gives computers the ability to learn without being explicitly programmed." ID="ID_978699800" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Week #5: Machine Learning Flashcards | Quizlet" FOLDED="true" ID="ID_557746613" CREATED="1557224068548" MODIFIED="1557224306252" LINK="https://quizlet.com/204246879/week-5-machine-learning-flash-cards/">
<node TEXT="Start studying Week #5: Machine Learning. Learn vocabulary terms and more with flashcards games and other study tools." ID="ID_1805143898" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Learning Machine Learning&#x2026; with Flashcards - KDnuggets" FOLDED="true" ID="ID_1988344854" CREATED="1557224068548" MODIFIED="1557224306252" LINK="https://www.kdnuggets.com/2017/08/albon-machine-learning-flashcards.html">
<node TEXT="What exactly are the flashcards? Directly from Chris: Machine learning is a broad field encompassing parts of computer science statistics scientific computing and mathematics. There are hundreds of concepts to learn. These flashcards are designed to help you memorize key concepts in machine learning rapidly and enjoyably." ID="ID_990675266" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Flashcards by | Brainscape" FOLDED="true" ID="ID_1963385508" CREATED="1557224068548" MODIFIED="1557224306252" LINK="https://www.brainscape.com/flashcards/machine-learning-5303174/packs/7860266">
<node TEXT="Study Machine Learning flashcards from s class online or in Brainscapes iPhone or Android app. Learn faster with spaced repetition." ID="ID_628396476" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Flashcards - Cram.com" FOLDED="true" ID="ID_437785366" CREATED="1557224068548" MODIFIED="1557224306252" LINK="https://www.cram.com/flashcards/machine-learning-5868690">
<node TEXT="Study Flashcards On Machine Learning at Cram.com. Quickly memorize the terms phrases and much more. Cram.com makes it easy to get the grade you want!" ID="ID_1915935033" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="GitHub - jessicayung/machine-learning-flashcards: Machine " FOLDED="true" ID="ID_48402889" CREATED="1557224068548" MODIFIED="1557224306252" LINK="https://github.com/jessicayung/machine-learning-flashcards">
<node TEXT="machine-learning-flashcards. Machine learning flashcards for specific topics books and courses. Let me know if you find any errors. Thanks! Table of Contents. deep-learning-book: Flashcards based on Deep Learning by Ian Goodfellow Yoshua Bengio and Aaron Courville. programming-flashcards: flashcards on algorithms and strategies for tackling " ID="ID_1401790833" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Test - ProProfs Quiz" FOLDED="true" ID="ID_1712842426" CREATED="1557224068548" MODIFIED="1557224306252" LINK="https://www.proprofs.com/quiz-school/story.php?title=3dq-machine-learning-test">
<node TEXT="Machine learning is a field of computer science that focuses on making machines learn. Its also a revolutionary aspect of the science world and as were all part of that I wonder how much you know about it." ID="ID_1043660742" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Flashcards  Quizzes | Brainscape" FOLDED="true" ID="ID_198736229" CREATED="1557224068548" MODIFIED="1557224306252" LINK="https://www.brainscape.com/subjects/machine-learning">
<node TEXT="Top Machine Learning Flashcards Ranked by Quality. Machine Learning. Machine Learning Flashcard Maker: Kyle Ploessl. 318 Cards &#x2013; 7 Decks &#x2013;  Hands-On Machine Learning with Scikit-Learn and TensorFlow fast.ai - Practical Deep Learning for Coders Show Class Machine Learning. Machine Learning Flashcard Maker: Adam Slawny." ID="ID_984253131" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning - Term Definition Instance Space An " FOLDED="true" ID="ID_945154869" CREATED="1557224068548" MODIFIED="1557224306253" LINK="https://www.coursehero.com/file/29224749/Machine-Learning/">
<node TEXT="Term: Overfitting Definition: This is occurs when a model is found that fits the data so closely that it even models the noise. In this case bias is too low and variance too high; the result is an algorithm that does not generalize to other data set.s Term: Inductive Learning Hypothesis Definition: Any hypothesis found to approximate the target function well over a sufficiently large set of " ID="ID_846752186" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
</node>
<node TEXT="Anki Droid MachineLearning#$D$#" FOLDED="true" ID="ID_1809085407" CREATED="1557224068548" MODIFIED="1557224307483">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning Flashcards" FOLDED="true" ID="ID_1547396285" CREATED="1557224068548" MODIFIED="1557224306253" LINK="https://machinelearningflashcards.com/">
<node TEXT="Machine learning is a broad field encompassing parts of computer science statistics scientific computing and mathematics. There are hundreds of concepts to learn. These flashcards are designed to help you memorize key concepts in machine learning rapidly and enjoyably." ID="ID_706490032" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Elemental Platform | Anki" FOLDED="true" ID="ID_338622970" CREATED="1557224068548" MODIFIED="1557224306253" LINK="https://www.anki.com/en-us/company/elemental-platform">
<node TEXT="The Anki Elemental Platform is the end-to-end technical foundation to drive unparalleled capabilities in perception/AI mobility and interface at low consumer-accessible cost." ID="ID_864467207" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Anki Drive Robotic Cars Adding Android Support - Robotics " FOLDED="true" ID="ID_1343443925" CREATED="1557224068548" MODIFIED="1557224306253" LINK="https://www.roboticsbusinessreview.com/rbr/anki_drive_robotic_cars_adding_android_support/">
<node TEXT="Ever since Anki Drive &#x2014; a toy car racing system powered by artificial intelligence and machine learning &#x2014; made a big splash at Apple&#x2019;s WWDC 2013 keynote it&#x2019;s been iOS-only.That ends next month however as Anki Drive is finally coming to Android for the first time. Sean Levatino Anki&#x2019;s lead designer tells us that one of the company&#x2019;s big core commitments is accessibility and " ID="ID_437877462" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Anki - powerful intelligent flashcards" FOLDED="true" ID="ID_334670264" CREATED="1557224068548" MODIFIED="1557224306253" LINK="https://apps.ankiweb.net/">
<node TEXT="About Anki. Anki is a program which makes remembering things easy. Because its a lot more efficient than traditional study methods you can either greatly decrease your time spent studying or greatly increase the amount you learn." ID="ID_374576214" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Anki Developer" FOLDED="true" ID="ID_1824310707" CREATED="1557224068548" MODIFIED="1557224306254" LINK="https://developer.anki.com/">
<node TEXT="One of the key strengths of the Cozmo SDK platform is the versatility of the hardware and software. The pairing of a highly expressive and interactive robot with an easy-to-use programming language make it perfect for a vast spectrum of uses. Here are some ideas inspired by real-world projects to get you started." ID="ID_1385220896" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Anyone Intrested in making anki notes for fast ai new " FOLDED="true" ID="ID_1920065917" CREATED="1557224068548" MODIFIED="1557224306254" LINK="https://www.reddit.com/r/learnmachinelearning/comments/an2mof/anyone_intrested_in_making_anki_notes_for_fast_ai/">
<node TEXT="Feel free to share any educational resources of machine learning. Also we are a beginner-friendly subreddit so dont be afraid to ask questions! This can include questions that are non-technical but still highly relevant to learning machine learning such as a systematic approach to a machine learning problem." ID="ID_328120016" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Cozmo | Meet Cozmo - Anki US" FOLDED="true" ID="ID_966277768" CREATED="1557224068548" MODIFIED="1557224306254" LINK="https://www.anki.com/en-us/cozmo">
<node TEXT="Anki Cozmo is an AI toy robot with a big brain and even bigger personality. Cozmo is always ready to play and learns more as you hang out." ID="ID_1749337955" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Anki Cozmo Review: This is an Artificial Intelligence toy " FOLDED="true" ID="ID_465906064" CREATED="1557224068548" MODIFIED="1557224306254" LINK="https://readyforai.com/article/anki-cozmo-review-this-is-an-artificial-intelligence-toy-with-life/">
<node TEXT="You may be impressed with the robot Wall-E in Andrew Stanton&#x2019;s movie &#x201c;WALL-E&#x201d; because it is cute and is a robot with &#x201c;life&#x201d;. Today&#x2019;s protagonist Cozmo is an artificial intelligence toy robot from Anki I also believe that you will not be stranged with another product Anki Overdrive of this company." ID="ID_1580215939" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="[Discussion] What do you all think of companies that " FOLDED="true" ID="ID_1768822527" CREATED="1557224068548" MODIFIED="1557224306254" LINK="https://www.reddit.com/r/MachineLearning/comments/6anki8/discussion_what_do_you_all_think_of_companies/">
<node TEXT="Cleaning and labelling is the most idiosyncratic part of any data science pipeline. Everyones data is slightly different and its impossible to create a one-size-fits-all solution. Ironically it is the more involved stuff like running machine learning algorithms that is much easier to commoditise in my opinion." ID="ID_59123167" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Deep Learning PDF - Ready For AI" FOLDED="true" ID="ID_318965012" CREATED="1557224068548" MODIFIED="1557224306254" LINK="https://readyforai.com/download/deep-learning-pdf/">
<node TEXT="Deep Learning (PDF) offers mathematical and conceptual background covering relevant concepts in linear algebra probability theory and information theory numerical computation and machine learning." ID="ID_699391303" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Artificial Intelligence Toys for Kids &#x2013; Current Products " FOLDED="true" ID="ID_729181319" CREATED="1557224068548" MODIFIED="1557224306254" LINK="https://emerj.com/ai-sector-overviews/artificial-intelligence-toys-for-kids/">
<node TEXT="Anki. Anki offers a toy robot called Cozmo which it claims can be an educational tool for children and machine learning students in addition to its entertainment value. Cozmo uses machine vision to recognize and track facial movements of users other people dogs and cats." ID="ID_1940546761" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="FavouriteBlog.com - Top and Best Blog about Artificial " FOLDED="true" ID="ID_861902856" CREATED="1557224068548" MODIFIED="1557224306255" LINK="https://favouriteblog.com/">
<node TEXT="Machine Learning is a standard word in the market right now and for a substantial support we can utilize our undertakings in an increasingly [Read More..]" ID="ID_303456412" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
</node>
</node>
<node TEXT="Android" ID="ID_482079765" CREATED="1549368565933" MODIFIED="1562919702809" LINK="https://play.google.com/store/apps/details?id=com.ichi2.ankihl=en_IN">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Quizlet" ID="ID_1110467490" CREATED="1549361997524" MODIFIED="1562919685753" LINK="https://quizlet.com/subject/%23$subjecthyphenname$#/">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Quizlet  MachineLearning#$D$#" FOLDED="true" ID="ID_548107029" CREATED="1557224068548" MODIFIED="1557224307483">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning Flashcards | Quizlet" FOLDED="true" ID="ID_1527196757" CREATED="1557224068548" MODIFIED="1557224306255" LINK="https://quizlet.com/19878281/machine-learning-flash-cards/">
<node TEXT="(from Wikipedia) the ability to quantify the level at which a particular gene is expressed within a cell tissue or organism. Ideally measurement of expression is done by detecting the final gene product (for many genes this is the protein) however it is often easier to detect one of the precursors typically mRNA and infer gene expression level." ID="ID_1305538314" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning 541 Flashcards | Quizlet" FOLDED="true" ID="ID_1215673733" CREATED="1557224068548" MODIFIED="1557224306255" LINK="https://quizlet.com/78420777/machine-learning-541-flash-cards/">
<node TEXT="Supervised learning is the machine learning task of inferring a function from labeled training data. The training data consist of a set of training examples. In supervised learning each example is a pair consisting of an input object (typically a vector) and a desired output value (also called the supervisory signal)." ID="ID_1582164508" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Flashcards | Quizlet" FOLDED="true" ID="ID_73683789" CREATED="1557224068548" MODIFIED="1557224306255" LINK="https://quizlet.com/139653249/machine-learning-flash-cards/">
<node TEXT="Machine learning learns from labeled data. Machine learning is the science of programming computers. Machine learning is the field of study that gives computers the ability to learn without being explicitly programmed." ID="ID_1517954673" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Flashcards | Quizlet" FOLDED="true" ID="ID_1160269261" CREATED="1557224068548" MODIFIED="1557224306255" LINK="https://quizlet.com/177875732/machine-learning-flash-cards/">
<node TEXT="The curse of dimensionality refers to how certain learning algorithms may perform poorly in high-dimensional data. First its very easy to overfit the the training data since we can have a lot of assumptions that describe the target label (in case of supervised learning)." ID="ID_1210828409" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Flashcards | Quizlet" FOLDED="true" ID="ID_1595703790" CREATED="1557224068548" MODIFIED="1557224306255" LINK="https://quizlet.com/214973864/machine-learning-flash-cards/">
<node TEXT="Start studying Machine Learning. Learn vocabulary terms and more with flashcards games and other study tools." ID="ID_1711017184" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="machine learning Flashcards and Study Sets | Quizlet" FOLDED="true" ID="ID_346684115" CREATED="1557224068548" MODIFIED="1557224306255" LINK="https://quizlet.com/subject/machine-learning/">
<node TEXT="Learn machine learning with free interactive flashcards. Choose from 500 different sets of machine learning flashcards on Quizlet." ID="ID_477550941" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Quizlet (@quizlet) | Twitter" FOLDED="true" ID="ID_854702737" CREATED="1557224068548" MODIFIED="1557224306256" LINK="https://twitter.com/quizlet">
<node TEXT="Nathan Hall explores ways you can modify Quizlet to fit your own classroom style or needs. This was the third session of the 2018 Quizlet Unconference." ID="ID_1119329187" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Flashcards" FOLDED="true" ID="ID_1415682640" CREATED="1557224068548" MODIFIED="1557224306256" LINK="https://machinelearningflashcards.com/">
<node TEXT="Machine learning is a broad field encompassing parts of computer science statistics scientific computing and mathematics. There are hundreds of concepts to learn. These flashcards are designed to help you memorize key concepts in machine learning rapidly and enjoyably." ID="ID_1568531766" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Quizlet Learn - Machine learning-powered adaptive studying " FOLDED="true" ID="ID_339083266" CREATED="1557224068548" MODIFIED="1557224306256" LINK="https://www.producthunt.com/posts/quizlet-learn">
<node TEXT="Quizlet Learn is a simple way for students to stay ahead of the curve and master knowledge before tests or quizzes come along. Available on iOS now (and coming soon to Android and Web) it&#x2019;s powered by our new Learning Assistant Platform which uses machine learning to process data from millions of anonymized sessions and develop a curriculum " ID="ID_645057331" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Flashcards - Gumroad" FOLDED="true" ID="ID_135346352" CREATED="1557224068548" MODIFIED="1557224306256" LINK="https://gumroad.com/l/machinelearningflashcards">
<node TEXT="Chris Albon A zip file containing hundreds of digital flashcards on machine learning topics in DRM-free web quality png image print quality png image PDF Anki and SVG vector file formats." ID="ID_245269619" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Machine Learning Flashcards - Chris Albon" FOLDED="true" ID="ID_1023203864" CREATED="1557224068548" MODIFIED="1557224306256" LINK="https://store.chrisalbon.com/machine-learning-flashcards">
<node TEXT="A zip file containing hundreds of digital flashcards on machine learning topics in DRM-free web quality png image print quality png image PDF Anki and SVG vector file formats." ID="ID_983603622" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Quizlet - AI and machine learning are changing how " FOLDED="true" ID="ID_251374720" CREATED="1557224068548" MODIFIED="1557224306256" LINK="https://www.facebook.com/quizlet/posts/2010531632299761">
<node TEXT="From a rise in test-optional schools to redesigns that move away from being a test of &#x201c;how well you can learn how to take the tests&#x201d; the last few years have seen significant shifts in both the app&#x2026;" ID="ID_1216691791" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
</node>
</node>
</node>
<node TEXT="Games" FOLDED="true" ID="ID_1665202131" CREATED="1549359532970" MODIFIED="1562238164714">
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge WIDTH="2"/>
<node TEXT="Android" ID="ID_1694062144" CREATED="1549360907774" MODIFIED="1549360910374">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Android Games MachineLearning#$D$#" FOLDED="true" ID="ID_738016867" CREATED="1557224068549" MODIFIED="1557224307483">
<icon BUILTIN="stop-sign"/>
<node TEXT="How to apply machine learning in an android app - Quora" FOLDED="true" ID="ID_1224026164" CREATED="1557224068549" MODIFIED="1557224306259" LINK="https://www.quora.com/How-do-I-apply-machine-learning-in-an-android-app">
<node TEXT="There is a dozen way to apply machine learning in an Android app. Which one (or even several ones) is more suitable for you depends on tasks you want to solve with help of machine learning. For example: 1. Machine learning algorithms can analyze y" ID="ID_1301433880" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Pradyuman7/MachineLearning-Game - github.com" FOLDED="true" ID="ID_1615222081" CREATED="1557224068549" MODIFIED="1557224306259" LINK="https://github.com/Pradyuman7/MachineLearning-Game">
<node TEXT="Machine Learning Game (Android) A simple machine learning &#xfe0f; android game which becomes unbeatable &#xfffd;&#xfffd; as you play (learns from your past moves).. Finished app looks like this. Read the Hacker Noon post about building this app here." ID="ID_1636698739" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="How to make a Machine Learning Android Game from scratch" FOLDED="true" ID="ID_1620219604" CREATED="1557224068549" MODIFIED="1557224306259" LINK="https://hackernoon.com/how-to-make-a-machine-learning-android-game-from-scratch-82d9406a7635">
<node TEXT="Let&#x2019;s make an android machine learning game from scratch &#xfffd;&#xfffd;. Are you fascinated by machine learning? Do you like Java or Android? Do you want to make a cool project using android and machine learning? If yes then you&#x2019;re certainly at the right place. Here we will be making an android " ID="ID_387731870" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="How to add Machine Learning to your Android apps - Android " FOLDED="true" ID="ID_1731352706" CREATED="1557224068549" MODIFIED="1557224306259" LINK="https://www.androidauthority.com/how-to-add-machine-learning-to-android-apps-970100/">
<node TEXT="Machine learning can help you create innovative compelling and unique experiences for your mobile users - but if you want to enhance your Android apps with powerful machine learning capabilities " ID="ID_815491708" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning for Android Developers with the Mobile " FOLDED="true" ID="ID_1707669973" CREATED="1557224068549" MODIFIED="1557224306259" LINK="https://hackernoon.com/machine-learning-for-android-developers-with-the-mobile-vision-api-part-1-face-detection-e7e24a3e472f">
<node TEXT="Machine learning is a very interesting field in Computer Science that has ranked really high on my to-learn list for a long while now. With so many updates from RxJava Testing Android N Android Studio and other Android goodies I haven&#x2019;t been able to dedicate time to learn it. There&#x2019;s even a " ID="ID_376990057" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Developer uses Machine Learning to train an Android game " FOLDED="true" ID="ID_435830002" CREATED="1557224068549" MODIFIED="1557224306259" LINK="https://www.xda-developers.com/play-rock-paper-scissors-hand-gestures-against-ai-bot/">
<node TEXT="Developer uses Machine Learning to train an Android game bot to play Rock Paper Scissors. LG is trying to bring back air gestures with Air Motion on the LG G8 ThinQ but developer ramtin8731 has a " ID="ID_950948914" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Build a Game AI - Machine Learning for Hackers #3 - YouTube" FOLDED="true" ID="ID_1996820200" CREATED="1557224068549" MODIFIED="1557224306259" LINK="https://www.youtube.com/watch?v=HBAUeJkFMH0">
<node TEXT="This video will get you up and running with your first game AI in just 10 lines of Python. The AI can theoretically learn to master any game you train it on but has only been tested on 2D Atari " ID="ID_41465045" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Best Machine Learning Applications: Ideas for Mobile Apps " FOLDED="true" ID="ID_251906478" CREATED="1557224068549" MODIFIED="1557224306259" LINK="https://codetiburon.com/best-machine-learning-applications-mobile-apps/">
<node TEXT="Now that you know how popular mobile apps use machine learning to their benefit it&#x2019;s time to figure out the way to use ML to your benefit. Here are some machine learning implementation ideas. Machine learning and e-commerce. The use of machine learning in e-commerce mobile apps can provide relevant information to users while they search " ID="ID_1578666836" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Android game development" FOLDED="true" ID="ID_1395237617" CREATED="1557224068549" MODIFIED="1557224306259" LINK="https://developer.android.com/games">
<node TEXT="Android provides a suite of tools including ASan and libmemunreachable to help you diagnose memory access and allocation errors in your games native code. Identify CPU hot spots. Import your game into Android Studio to debug your app and profile it with the built-in native CPU profiler. Keep the game moving" ID="ID_1327289526" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Play Video Games with Machine Learning | Android How To" FOLDED="true" ID="ID_1516626110" CREATED="1557224068549" MODIFIED="1557224306260" LINK="http://android-how.com/play-video-games-with-machine-learning/">
<node TEXT="Ubisoft is a video game compagny developping games such as Assassin Screed The Division Far Cry Ghost Recon Watch Dogs and of course Rayman. Ubisoft always integrate innovation and new technologies in their games and this is the reason why they decided to experiment the machine learning with us." ID="ID_202090186" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="How machine learning will revolutionize the mobile experience" FOLDED="true" ID="ID_480141014" CREATED="1557224068549" MODIFIED="1557224306260" LINK="https://www.androidauthority.com/machine-learning-change-mobile-experience-627890/">
<node TEXT="Will machine learning live up to the hype and change the world? We take a look at the many ways it could impact on the mobile experience. How exactly could it change things and what can it do for us?" ID="ID_1769995936" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Ultimate Unity Games  Android Machine Learning " FOLDED="true" ID="ID_771506357" CREATED="1557224068549" MODIFIED="1557224306260" LINK="https://www.udemy.com/ultimate-unity-games-android-machine-learning-masterseries/">
<node TEXT="Do you want to build games and use machine learning? This course is for you! Join Mammoth Interactive step-by-step in building a fully featured game from scratch. You will learn to use Python Java PyCharm Android Studio and MNIST build apps and use machine learning models in hands-on projects." ID="ID_322252297" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
</node>
</node>
<node TEXT="PC" ID="ID_585705895" CREATED="1549360911231" MODIFIED="1549360912551">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="PC Games MachineLearning#$D$#" FOLDED="true" ID="ID_1578010189" CREATED="1557224068549" MODIFIED="1557224307484">
<icon BUILTIN="stop-sign"/>
<node TEXT="What are some examples of computer games which use machine " FOLDED="true" ID="ID_821554602" CREATED="1557224068549" MODIFIED="1557224306260" LINK="https://www.quora.com/What-are-some-examples-of-computer-games-which-use-machine-learning-Do-games-like-FIFA-2013-of-EA-Sports-learn-from-an-user-Does-the-computer-change-its-tactics-according-to-the-opponents-style-of-play-If-not-is-this-possible-to-implement">
<node TEXT="We used machine learning to determine if the user was making a golf swing. 100s of people were recorded in front of the Kinect to collect data points of them making a golf swing (or what they thought was a golf swing :). We then used machine learning to process these data points to feed into the game to determine when a golf swing was made." ID="ID_1863664728" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="The Past and Present of Machine Learning in Gaming | Big " FOLDED="true" ID="ID_1237581271" CREATED="1557224068549" MODIFIED="1557224306260" LINK="https://www.bigfishgames.com/blog/the-past-and-present-of-machine-learning-in-gaming/">
<node TEXT="Computer scientists have been testing the abilities of machine learning in video games for over 60 years. In 1949 Claude Shannon published a research paper titled &#x201c;Programming a Computer for Playing Chess.&#x201d;Shannon&#x2019;s paper estimated that chess has more than 10^120 possible positions." ID="ID_994290430" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning - aischool.microsoft.com" FOLDED="true" ID="ID_1749993329" CREATED="1557224068549" MODIFIED="1557224306260" LINK="https://aischool.microsoft.com/en-us/machine-learning/learning-paths">
<node TEXT="Skip to main content. Microsoft. AI" ID="ID_534714815" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Build Bots to Play Games: Machine Learning  - Kickstarter" FOLDED="true" ID="ID_146164381" CREATED="1557224068549" MODIFIED="1557224306260" LINK="https://www.kickstarter.com/projects/513736598/build-bots-to-play-games-machine-learning-ai-with">
<node TEXT="It is different from traditional machine learning (supervised or unsupervised) in that there are no training samples with expected outputs. In RL the bots are thrown into a computer game (and gaming is a field they are most extensively tested in) and then trained to learn by observing their actions and rewards." ID="ID_1150443520" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="PUBG uses machine learning to look for cheaters | PC Gamer" FOLDED="true" ID="ID_72316238" CREATED="1557224068549" MODIFIED="1557224306260" LINK="https://www.pcgamer.com/pubg-uses-machine-learning-to-look-for-cheaters/">
<node TEXT="Best PC Games; PUBG uses machine learning to look for cheaters. By Fraser Brown 2019-02-27T12:59:35Z.  the team uses machine learning to study how people play using that data to keep an eye " ID="ID_1894048619" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning in Gaming &#x2013; Building AIs to Conquer " FOLDED="true" ID="ID_622411911" CREATED="1557224068549" MODIFIED="1557224306260" LINK="https://emerj.com/ai-sector-overviews/machine-learning-in-gaming-building-ais-to-conquer-virtual-worlds/">
<node TEXT="Machine Learning in Games of Imperfect Information. With current or anticipated AI dominance in many games of perfect information research interest had shifted to games of imperfect information&#x2014;not only because such games are much harder for machines to master but also because these games more closely mimic the more challenging scenarios " ID="ID_913721825" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="AI Platform for Windows Developers - Windows Developer Blog" FOLDED="true" ID="ID_1786838200" CREATED="1557224068549" MODIFIED="1557224306260" LINK="https://blogs.windows.com/buildingapps/2018/03/07/ai-platform-windows-developers/">
<node TEXT="&#x201c;NVIDIA is delighted to be partnering with Microsoft to enhance the PC experience for users worldwide.&#x201d; The AI platform in Windows 10 enables developers to use pre-trained machine learning models in their Apps on Windows devices. This offers developers a number of benefits: Low latency real-time results." ID="ID_1844905686" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Valve announces 8 changes coming to Steam in 2019 | PC Gamer" FOLDED="true" ID="ID_782696965" CREATED="1557224068549" MODIFIED="1557224306260" LINK="https://www.pcgamer.com/valve-announces-8-changes-coming-to-steam-in-2019/">
<node TEXT="In a big blog post reflecting on the life of Steam in 2018 Valve detailed some new features planned for the go-to PC gaming client in 2019. Below all the numbers and pie charts explaining growth " ID="ID_848544805" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Microsoft: Heres how machine learning can make PC games " FOLDED="true" ID="ID_1926147189" CREATED="1557224068549" MODIFIED="1557224306261" LINK="https://www.pcworld.com/article/3263660/microsoft-winml-directml-machine-learning-games.html">
<node TEXT="Machine learning can make games prettier more adaptable to individual playstyles and easier to create Microsoft says. Let&#x2019;s start with the eye candy. WinML uses your PCs CPU and GPU" ID="ID_1959477991" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="&#xfe0f; TRAINING MY FIRST MACHINE LEARNING GAME! (2/4) - YouTube" FOLDED="true" ID="ID_550436047" CREATED="1557224068549" MODIFIED="1557224306261" LINK="https://www.youtube.com/watch?v=OpodKCR6P-M">
<node TEXT="Now that Ive written my first Machine Learning Neural Network its time to train it! Boy this is great fun :D PATREON: https://www.patreon.com/Jabrils If yo" ID="ID_1481501353" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Steam Will Use Machine Learning for Game Recommendations " FOLDED="true" ID="ID_1012788913" CREATED="1557224068549" MODIFIED="1557224306261" LINK="https://www.pcmag.com/news/365987/steam-will-use-machine-learning-for-game-recommendations">
<node TEXT="Valve this year will release a number of updates to its Steam PC games store. For a start Valve will update the design of Steam itself in order to keep it in line with the redesign of Steam Chat " ID="ID_904345877" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Using Machine Learning Agents Toolkit in a real game: a " FOLDED="true" ID="ID_880223346" CREATED="1557224068549" MODIFIED="1557224306261" LINK="https://blogs.unity3d.com/2017/12/11/using-machine-learning-agents-in-a-real-game-a-beginners-guide/">
<node TEXT="My name is Alessia Nigretti and I am a Technical Evangelist for Unity. My job is to introduce Unity&#x2019;s new features to developers. My fellow evangelist Ciro Continisio and I developed the first demo game that uses the new Unity Machine Learning Agents toolkit and showed it at DevGamm Minsk 2017." ID="ID_60009527" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
</node>
</node>
</node>
<node TEXT="Blogs" FOLDED="true" ID="ID_177375485" CREATED="1549364733339" MODIFIED="1549364735199">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Blogs MachineLearning#$D$#" FOLDED="true" ID="ID_1714916034" CREATED="1557224068552" MODIFIED="1557224307485">
<icon BUILTIN="stop-sign"/>
<node TEXT="Top 40 Machine Learning Blogs Websites  Newsletters To " FOLDED="true" ID="ID_1768671385" CREATED="1557224068552" MODIFIED="1557224306291" LINK="https://blog.feedspot.com/machine_learning_blogs/">
<node TEXT="Top 20 Machine Learning Blogs Winners. CONGRATULATIONS to every blogger that has made this Top Machine Learning blogs list! This is the most comprehensive list of best Machine Learning blogs on the internet and I&#x2019;m honoured to have you as part of this! I personally give you a high-five and want to thank you for your contribution to this world." ID="ID_1660748171" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Machine Learning Mastery Blog" FOLDED="true" ID="ID_1951538147" CREATED="1557224068552" MODIFIED="1557224306291" LINK="https://machinelearningmastery.com/blog/">
<node TEXT="Color images have height width and color channel dimensions. When represented as three-dimensional arrays the channel dimension for the image data is last by default but may be moved to be the first dimension often for performance-tuning reasons." ID="ID_1500334227" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="What are the best regularly updated machine learning " FOLDED="true" ID="ID_1181662092" CREATED="1557224068552" MODIFIED="1557224306291" LINK="https://www.quora.com/What-are-the-best-regularly-updated-machine-learning-blogs-or-resources-available">
<node TEXT="What are the best regularly updated machine learning blogs or resources available?  I Can Suggest you Best  Regularly Updated Machine Learning Online Courses. Machine Learning A-Z&#x2122;:  A great blog is the Google Cloud big data and machine learning blog they even give away scripts on how to build tools using machine learning like the " ID="ID_1129464772" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="AI | Google Blog" FOLDED="true" ID="ID_574663007" CREATED="1557224068552" MODIFIED="1557224306291" LINK="https://www.blog.google/technology/ai/">
<node TEXT="Official Blog AI. Stories and updates on the cutting-edge work Google is doing in artificial intelligence and machine learning.  How machine learning can drive change in traffic-packed L.A. View this series Top Stories. AI. How we worked to make AI for everyone in 2018. AI. A tale of a whale song. AI. 13 ways you&#x2019;re using AI in your daily " ID="ID_1955937263" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="[D] Best ML blogs? : MachineLearning - reddit.com" FOLDED="true" ID="ID_1086298900" CREATED="1557224068552" MODIFIED="1557224306291" LINK="https://www.reddit.com/r/MachineLearning/comments/7nb62j/d_best_ml_blogs/">
<node TEXT="This Blog is Very interesting to read and thank you for sharing the valuable information about Machine Learning. The information you provided was very easy to read and understand. I gathered a lot of information from your Machine Learning blog." ID="ID_1475429622" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Blog &#x2013; Machine Learning Plus" FOLDED="true" ID="ID_1910741714" CREATED="1557224068552" MODIFIED="1557224306291" LINK="https://www.machinelearningplus.com/blog/">
<node TEXT="Naive Bayes is a probabilistic machine learning algorithm based on the Bayes Theorem used in a wide variety of classification &#x2026; Read More Parallel Processing in Python &#x2013; A Practical Guide with Examples" ID="ID_1031554640" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="AI-Based Virtual Tutors &#x2013; The Future of Education " FOLDED="true" ID="ID_406640677" CREATED="1557224068552" MODIFIED="1557224306291" LINK="https://blogs.technet.microsoft.com/machinelearning/2018/09/21/ai-based-virtual-tutors-the-future-of-education/">
<node TEXT="This blog post is about the UC Berkeley Virtual Tutor project and the speech recognition technologies that were tested as part of that effort. We share best practices for machine learning and artificial intelligence techniques in selecting models and engineering training data for speech and image recognition." ID="ID_613672486" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Machine Learning c&#x1a1; b&#x1ea3;n" FOLDED="true" ID="ID_500734838" CREATED="1557224068552" MODIFIED="1557224306292" LINK="https://machinelearningcoban.com/">
<node TEXT="B&#x1ea1;n &#x111;&#x1ecd;c c&#xf3; th&#x1ec3; &#x1ee7;ng h&#x1ed9; blog qua Buy me a cofee &#x1edf; g&#xf3;c tr&#xea;n b&#xea;n tr&#xe1;i c&#x1ee7;a blog. T&#xf4;i v&#x1eeb;a ho&#xe0;n th&#xe0;nh cu&#x1ed1;n ebook Machine Learning c&#x1a1; b&#x1ea3;n b&#x1ea1;n c&#xf3; th&#x1ec3; &#x111;&#x1eb7;t s&#xe1;ch t&#x1ea1;i &#x111;&#xe2;y. C&#x1ea3;m &#x1a1;n b&#x1ea1;n." ID="ID_1084854465" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="The Logistic Regression Algorithm &#x2013; machinelearning-blog.com" FOLDED="true" ID="ID_1074566758" CREATED="1557224068552" MODIFIED="1557224306292" LINK="https://machinelearning-blog.com/2018/04/23/logistic-regression-101/">
<node TEXT="Logistic Regression is one of the most used Machine Learning algorithms for binary classification. It is a simple Algorithm that you can use as a performance baseline it is easy to implement and it will do well enough in many tasks. Therefore every Machine Learning engineer should be familiar with its concepts. The building block&#x2026;" ID="ID_1662784490" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="machinelearning-blog.com &#x2013; Tutorials and explanations " FOLDED="true" ID="ID_1216265872" CREATED="1557224068552" MODIFIED="1557224306292" LINK="https://machinelearning-blog.com/">
<node TEXT="Machine Learning Yearning is about structuring the development of machine learning projects. The book contains practical insights that are difficult to find somewhere else in a format that is easy to share with teammates and collaborators." ID="ID_1463262862" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Top Machine Learning Blogs Of 2018 - quantinsti.com" FOLDED="true" ID="ID_1758047753" CREATED="1557224068552" MODIFIED="1557224306292" LINK="https://www.quantinsti.com/blog/top-machine-learning-blogs-2018">
<node TEXT="Top Machine Learning Blogs. Machine Learning Basics; A beginner&#x2019;s guide to anyone who wishes to know the basics of machine learning. It attempts to explain what machine learning really is and what differentiates it with the most commonly confused terms like artificial intelligence and deep learning." ID="ID_930535779" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Cool deep learning / ML blogs? : MachineLearning - reddit" FOLDED="true" ID="ID_11236660" CREATED="1557224068552" MODIFIED="1557224306292" LINK="https://www.reddit.com/r/MachineLearning/comments/4juw5z/cool_deep_learning_ml_blogs/">
<node TEXT="What are some of your favorite blogs/sites from ML researchers? Dont have to be big names just people with interesting things to say. Feel free" ID="ID_1534889459" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
</node>
</node>
<node TEXT="Android Apps" FOLDED="true" ID="ID_67558226" CREATED="1549359608842" MODIFIED="1562238180586">
<edge WIDTH="2"/>
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Android Apps MachineLearning#$D$#" FOLDED="true" ID="ID_1133377176" CREATED="1557224068548" MODIFIED="1557224307483">
<icon BUILTIN="stop-sign"/>
<node TEXT="How to apply machine learning in an android app - Quora" FOLDED="true" ID="ID_236665227" CREATED="1557224068548" MODIFIED="1557224306256" LINK="https://www.quora.com/How-do-I-apply-machine-learning-in-an-android-app">
<node TEXT="There is a dozen way to apply machine learning in an Android app. Which one (or even several ones) is more suitable for you depends on tasks you want to solve with help of machine learning. For example: 1. Machine learning algorithms can analyze y" ID="ID_1947786661" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Best machine learning apps for android (Top 100) &#x2013; AppCrawlr" FOLDED="true" ID="ID_1232255560" CREATED="1557224068548" MODIFIED="1557224306256" LINK="https://appcrawlr.com/android-apps/best-apps-machine-learning">
<node TEXT="Discover the top 100 best machine learning apps for android free and paid. Top android apps for machine learning in AppCrawlr!" ID="ID_1360147832" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="How to add Machine Learning to your Android apps - Android " FOLDED="true" ID="ID_1463629786" CREATED="1557224068548" MODIFIED="1557224306257" LINK="https://www.androidauthority.com/how-to-add-machine-learning-to-android-apps-970100/">
<node TEXT="Machine learning can help you create innovative compelling and unique experiences for your mobile users - but if you want to enhance your Android apps with powerful machine learning capabilities " ID="ID_111366625" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="How to Use Machine Learning in Mobile App? - The App Solutions" FOLDED="true" ID="ID_712228417" CREATED="1557224068548" MODIFIED="1557224306257" LINK="https://theappsolutions.com/blog/development/machine-learning-in-mobile-app/">
<node TEXT="ML has started from the computer but the emerging trend shows that machine learning mobile app development is the next big thing. The modern mobile devices show the high productive capacity level that is enough to perform appropriate tasks to the same degree as traditional computers do." ID="ID_222428332" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Android TensorFlow Machine Learning Example - GitHub" FOLDED="true" ID="ID_40891260" CREATED="1557224068548" MODIFIED="1557224306257" LINK="https://github.com/MindorksOpenSource/AndroidTensorFlowMachineLearningExample">
<node TEXT="Android TensorFlow Machine Learning Example. About Android TensorFlow Machine Learning Example. This is an example project for integrating TensorFlow into Android application; How to build TensorFlow project to use with Android project. How to build TensorFlow library(.so file and jar file) to use with Android Application." ID="ID_1470135679" CREATED="1557224068548" MODIFIED="1557224068548"/>
</node>
<node TEXT="Android P with Machine learning Apps - 26+ projects in total" FOLDED="true" ID="ID_321981115" CREATED="1557224068549" MODIFIED="1557224306257" LINK="https://courses.learncodeonline.in/learn/Android-P-with-Machine-learning-Apps">
<node TEXT="Programming language used: Java Welcome to complete Android P development with machine Learning apps . A course that consists of 27 projects and counting. Although this course is big with over 120+ videos and 27 projects Still the main goal of this course is to make you a job ready Android developer." ID="ID_1515517368" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Android TensorFlow Machine Learning Example - Mindorks" FOLDED="true" ID="ID_1099853377" CREATED="1557224068549" MODIFIED="1557224306257" LINK="https://blog.mindorks.com/android-tensorflow-machine-learning-example-ff0e9b2654cc">
<node TEXT="Android TensorFlow Machine Learning Example. As we all know Google has open-sourced a library called TensorFlow that can be used in Android for implementing Machine Learning. TensorFlow is an open-source software library for Machine Intelligence provided by Google." ID="ID_837253513" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Android P with Machine Learning apps - 26+ projects in " FOLDED="true" ID="ID_599369866" CREATED="1557224068549" MODIFIED="1557224306257" LINK="https://www.udemy.com/android-p-with-machine-learning-apps/">
<node TEXT="Welcome to complete Android P development with machine Learning apps. A course that consists of 27 projects and counting. Although this course is big with over 120+ videos and 27 projects Still the main goal of this course is to make you a job ready Android developer." ID="ID_1745764303" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Best Machine Learning Applications: Ideas for Mobile Apps " FOLDED="true" ID="ID_813197631" CREATED="1557224068549" MODIFIED="1557224306257" LINK="https://codetiburon.com/best-machine-learning-applications-mobile-apps/">
<node TEXT="Time management apps can employ machine learning to find suitable times for you to complete tasks and to prioritize things on your to-do list. Sports apps. Machine learning in a sports mobile app can read the sensors a and genetic data available to tailor a deeply individual workout program." ID="ID_1728791073" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning in Mobile Applications - lynda.com" FOLDED="true" ID="ID_485597655" CREATED="1557224068549" MODIFIED="1557224306258" LINK="https://www.lynda.com/Xamarin-tutorials/Machine-Learning-Mobile-Applications/791354-2.html">
<node TEXT="- [Instructor] Machine learning is used everywhere today from self-driving cars to personal assistants like Cortana Alexa and Siri and to security technologies like facial recognition. Mobile developers are increasingly being asked to implement machine learning technologies into their apps. For many of them this is new territory." ID="ID_1306428285" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning for Android Developers with the Mobile " FOLDED="true" ID="ID_1851904328" CREATED="1557224068549" MODIFIED="1557224306258" LINK="https://hackernoon.com/machine-learning-for-android-developers-with-the-mobile-vision-api-part-1-face-detection-e7e24a3e472f">
<node TEXT="Machine learning is a very interesting field in Computer Science that has ranked really high on my to-learn list for a long while now. With so many updates from RxJava Testing Android N Android Studio and other Android goodies I haven&#x2019;t been able to dedicate time to learn it." ID="ID_1787182324" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning Libraries For Android - Stack Overflow" FOLDED="true" ID="ID_769095329" CREATED="1557224068549" MODIFIED="1557224306258" LINK="https://stackoverflow.com/questions/43649359/machine-learning-libraries-for-android">
<node TEXT="I am trying build a small text mining tool for my android app. I am checking for a machine learning library that will allow me to cluster classify etc. Are there any machine learning libraries for android? I came across tensorflow but I need a bit more access to common ML functions." ID="ID_245017983" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="How to apply machine learning in an android app - Quora" FOLDED="true" ID="ID_552008885" CREATED="1557224068549" MODIFIED="1557224306258" LINK="https://www.quora.com/How-do-I-apply-machine-learning-in-an-android-app">
<node TEXT="There is a dozen way to apply machine learning in an Android app. Which one (or even several ones) is more suitable for you depends on tasks you want to solve with help of machine learning. For example: 1. Machine learning algorithms can analyze y" ID="ID_1493764780" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Best machine learning apps for android (Top 100) &#x2013; AppCrawlr" FOLDED="true" ID="ID_1985907155" CREATED="1557224068549" MODIFIED="1557224306258" LINK="https://appcrawlr.com/android-apps/best-apps-machine-learning">
<node TEXT="Discover the top 100 best machine learning apps for android free and paid. Top android apps for machine learning in AppCrawlr!" ID="ID_1321322268" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="How to add Machine Learning to your Android apps - Android " FOLDED="true" ID="ID_560941029" CREATED="1557224068549" MODIFIED="1557224306258" LINK="https://www.androidauthority.com/how-to-add-machine-learning-to-android-apps-970100/">
<node TEXT="Machine learning can help you create innovative compelling and unique experiences for your mobile users - but if you want to enhance your Android apps with powerful machine learning capabilities " ID="ID_888337342" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="How to Use Machine Learning in Mobile App? - The App Solutions" FOLDED="true" ID="ID_319667106" CREATED="1557224068549" MODIFIED="1557224306258" LINK="https://theappsolutions.com/blog/development/machine-learning-in-mobile-app/">
<node TEXT="ML has started from the computer but the emerging trend shows that machine learning mobile app development is the next big thing. The modern mobile devices show the high productive capacity level that is enough to perform appropriate tasks to the same degree as traditional computers do." ID="ID_1715697741" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Android TensorFlow Machine Learning Example - GitHub" FOLDED="true" ID="ID_1449993541" CREATED="1557224068549" MODIFIED="1557224306258" LINK="https://github.com/MindorksOpenSource/AndroidTensorFlowMachineLearningExample">
<node TEXT="Android TensorFlow Machine Learning Example. About Android TensorFlow Machine Learning Example. This is an example project for integrating TensorFlow into Android application; How to build TensorFlow project to use with Android project. How to build TensorFlow library(.so file and jar file) to use with Android Application." ID="ID_1979666164" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Android P with Machine learning Apps - 26+ projects in total" FOLDED="true" ID="ID_38187145" CREATED="1557224068549" MODIFIED="1557224306258" LINK="https://courses.learncodeonline.in/learn/Android-P-with-Machine-learning-Apps">
<node TEXT="Programming language used: Java Welcome to complete Android P development with machine Learning apps . A course that consists of 27 projects and counting. Although this course is big with over 120+ videos and 27 projects Still the main goal of this course is to make you a job ready Android developer." ID="ID_963154258" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Android TensorFlow Machine Learning Example - Mindorks" FOLDED="true" ID="ID_455175102" CREATED="1557224068549" MODIFIED="1557224306258" LINK="https://blog.mindorks.com/android-tensorflow-machine-learning-example-ff0e9b2654cc">
<node TEXT="Android TensorFlow Machine Learning Example. As we all know Google has open-sourced a library called TensorFlow that can be used in Android for implementing Machine Learning. TensorFlow is an open-source software library for Machine Intelligence provided by Google." ID="ID_1830258064" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Android P with Machine Learning apps - 26+ projects in " FOLDED="true" ID="ID_1426242957" CREATED="1557224068549" MODIFIED="1557224306258" LINK="https://www.udemy.com/android-p-with-machine-learning-apps/">
<node TEXT="Welcome to complete Android P development with machine Learning apps. A course that consists of 27 projects and counting. Although this course is big with over 120+ videos and 27 projects Still the main goal of this course is to make you a job ready Android developer." ID="ID_1029951287" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Best Machine Learning Applications: Ideas for Mobile Apps " FOLDED="true" ID="ID_456382225" CREATED="1557224068549" MODIFIED="1557224306258" LINK="https://codetiburon.com/best-machine-learning-applications-mobile-apps/">
<node TEXT="Time management apps can employ machine learning to find suitable times for you to complete tasks and to prioritize things on your to-do list. Sports apps. Machine learning in a sports mobile app can read the sensors a and genetic data available to tailor a deeply individual workout program." ID="ID_1848887563" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning in Mobile Applications - lynda.com" FOLDED="true" ID="ID_896436995" CREATED="1557224068549" MODIFIED="1557224306259" LINK="https://www.lynda.com/Xamarin-tutorials/Machine-Learning-Mobile-Applications/791354-2.html">
<node TEXT="- [Instructor] Machine learning is used everywhere today from self-driving cars to personal assistants like Cortana Alexa and Siri and to security technologies like facial recognition. Mobile developers are increasingly being asked to implement machine learning technologies into their apps. For many of them this is new territory." ID="ID_444313363" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning for Android Developers with the Mobile " FOLDED="true" ID="ID_38803575" CREATED="1557224068549" MODIFIED="1557224306259" LINK="https://hackernoon.com/machine-learning-for-android-developers-with-the-mobile-vision-api-part-1-face-detection-e7e24a3e472f">
<node TEXT="Machine learning is a very interesting field in Computer Science that has ranked really high on my to-learn list for a long while now. With so many updates from RxJava Testing Android N Android Studio and other Android goodies I haven&#x2019;t been able to dedicate time to learn it." ID="ID_1318949131" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
<node TEXT="Machine Learning Libraries For Android - Stack Overflow" FOLDED="true" ID="ID_770816506" CREATED="1557224068549" MODIFIED="1557224306259" LINK="https://stackoverflow.com/questions/43649359/machine-learning-libraries-for-android">
<node TEXT="I am trying build a small text mining tool for my android app. I am checking for a machine learning library that will allow me to cluster classify etc. Are there any machine learning libraries for android? I came across tensorflow but I need a bit more access to common ML functions." ID="ID_1261802442" CREATED="1557224068549" MODIFIED="1557224068549"/>
</node>
</node>
</node>
<node TEXT="Magazines" FOLDED="true" ID="ID_186899293" CREATED="1549359746959" MODIFIED="1549359750155">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Magazines MachineLearning#$D$#" ID="ID_872465488" CREATED="1557224068552" MODIFIED="1557224307485">
<icon BUILTIN="stop-sign"/>
<node TEXT="machine learning | Quanta Magazine" FOLDED="true" ID="ID_1579902907" CREATED="1557224068552" MODIFIED="1557224306292" LINK="https://www.quantamagazine.org/tag/machine-learning/">
<node TEXT="Machine learning techniques are commonly based on how the visual system processes information. To beat their limitations scientists are drawing inspiration from the sense of smell. 2018 Fields Medal and Nevanlinna Prize Winners A Poet of Computation Who Uncovers Distant Truths." ID="ID_1723202768" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="What are highest rated science magazines for Machine " FOLDED="true" ID="ID_1257021287" CREATED="1557224068552" MODIFIED="1557224306292" LINK="https://www.quora.com/What-are-highest-rated-science-magazines-for-Machine-Learning-Data-Science">
<node TEXT="Some of the good magazines have been covered by the other answers here so I am going to add to the list : 1.  What are highest rated science magazines for Machine Learning / Data Science?  d b y L a m b d a L a b s. ML workstations &#x2014; fully configured. Let us save you the work. Our machine learning experts take care of the set up. We " ID="ID_975453628" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Machine Learning | Latest News Photos  Videos | WIRED" FOLDED="true" ID="ID_673007034" CREATED="1557224068552" MODIFIED="1557224306292" LINK="https://www.wired.com/tag/machine-learning/">
<node TEXT="Find the latest Machine Learning news from WIRED. See related science and technology articles photos slideshows and videos." ID="ID_1232561197" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Machine Learning digital magazine | CIOAdvisor APAC -1" FOLDED="true" ID="ID_903296930" CREATED="1557224068552" MODIFIED="1557224306293" LINK="https://www.cioadvisorapac.com/magazines/October2018/MachineLearning/">
<node TEXT="CIOAdvisor Apac digital magazine features the Most Promising Machine Learning Solution Providers offering Machine Learning solutions as per varied needs of businesses in the APAC region." ID="ID_1472024888" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="www.cioapplications.com" FOLDED="true" ID="ID_914668037" CREATED="1557224068552" MODIFIED="1557224306293" LINK="https://www.cioapplications.com/magazines/March2018/MachineLearning/">
<node TEXT="Loading Publication No javascript? read text-only version No javascript? read text-only version" ID="ID_1439607663" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Machine Learning Neural Networks and Algorithms " FOLDED="true" ID="ID_911257512" CREATED="1557224068552" MODIFIED="1557224306293" LINK="https://chatbotsmagazine.com/machine-learning-neural-networks-and-algorithms-5c0711eb8f9a">
<node TEXT="Machine Learning Algorithms. This chapter shows some of the most important machine learning algorithms more information about algorithms can be found via the following links. Decision Tree Algorithms. In this algorithm a decision tree is used to map decisions and their possible consequences including chances costs and utilities." ID="ID_1257035208" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Distill &#x2014; Latest articles about machine learning" FOLDED="true" ID="ID_956412934" CREATED="1557224068552" MODIFIED="1557224306293" LINK="https://distill.pub/">
<node TEXT="Distill is dedicated to clear explanations of machine learning About Submit Prize Archive RSS GitHub Twitter ISSN 2476-0757 " ID="ID_545894579" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Machine Learning/AI - digitalistmag.com" FOLDED="true" ID="ID_1272822736" CREATED="1557224068552" MODIFIED="1557224306293" LINK="https://www.digitalistmag.com/machine-learning-ai">
<node TEXT="Machine learning enables companies to exponentially increase the scale of their capabilities without increasing staffing &#x2013; a.k.a. &#x201c;non-linear growth.&#x201d; People will still be involved but at a higher level managing analyzing or acting upon the machine learning output." ID="ID_579918115" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
</node>
</node>
<node TEXT="Learning To Learn Machine Learning" ID="ID_389885722" CREATED="1563518619188" MODIFIED="1563518628291"/>
<node TEXT="sanjay.lakade@pccoepune.org" ID="ID_152727380" CREATED="1564037975330" MODIFIED="1564037990383"/>
<node TEXT="Monkeylearn" ID="ID_289672636" CREATED="1564039737451" MODIFIED="1564039743160"/>
</node>
<node TEXT="Liscence / Support" FOLDED="true" POSITION="left" ID="ID_699760154" CREATED="1562661513392" MODIFIED="1564049353503">
<edge COLOR="#808080"/>
<hook URI="Images/liscence.png" SIZE="0.97622514" NAME="ExternalObject"/>
<node TEXT="Last Updated" ID="ID_1474150356" CREATED="1562751156026" MODIFIED="1563175499943">
<edge COLOR="#808080"/>
<node TEXT="By" ID="ID_1897150310" CREATED="1562751167898" MODIFIED="1563175655278">
<edge COLOR="#8a8f90"/>
<node TEXT="Dipesh Walte" ID="ID_1950447681" CREATED="1562751184602" MODIFIED="1563175655279">
<edge COLOR="#8a8f90"/>
</node>
</node>
<node TEXT="On" ID="ID_575123614" CREATED="1562751173451" MODIFIED="1563175655278">
<edge COLOR="#8a8f90"/>
<node TEXT="2019-July-19" ID="ID_1533492067" CREATED="1562751221122" MODIFIED="1563175655279">
<edge COLOR="#8a8f90"/>
</node>
</node>
</node>
<node TEXT="Support the Community" ID="ID_1690919154" CREATED="1562665345531" MODIFIED="1563175551093">
<edge COLOR="#8a8f90"/>
<node TEXT="Content Creators" ID="ID_532499486" CREATED="1562661549432" MODIFIED="1563175655278">
<edge COLOR="#8a8f90"/>
</node>
<node TEXT="Edubuntu Initiative" FOLDED="true" ID="ID_1711134420" CREATED="1562665374660" MODIFIED="1563175655277">
<edge COLOR="#8a8f90"/>
<node TEXT="Support with Time/Skills" ID="ID_60800005" CREATED="1562665443611" MODIFIED="1562665584149" LINK="http://www.edubuntuinitiative.org/joinus"/>
<node TEXT="Make a micro contribution worth a wada pav/burger" ID="ID_1505701597" CREATED="1562665561131" MODIFIED="1562665696324">
<node TEXT="Paytm/Mobikwik" ID="ID_1698086308" CREATED="1562665705186" MODIFIED="1562665719469"/>
<node TEXT="UPI" ID="ID_552147867" CREATED="1562665736819" MODIFIED="1562665740124"/>
<node TEXT="Patreon" ID="ID_1138952967" CREATED="1562760717205" MODIFIED="1562760731702"/>
</node>
</node>
</node>
<node TEXT="Contact Us" ID="ID_1033167112" CREATED="1562665906850" MODIFIED="1564049353503">
<edge COLOR="#8a8f90"/>
</node>
<node TEXT="Liscence" ID="ID_1607861610" CREATED="1562661572832" MODIFIED="1563175600565">
<edge COLOR="#8a8f90"/>
<node TEXT="This work (Along with other mindmaps linked here) is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License. To view a copy of this license, click the link" ID="ID_25154297" CREATED="1562760314765" MODIFIED="1563175655278" LINK="https://creativecommons.org/licenses/by-sa/3.0/">
<edge COLOR="#8a8f90"/>
</node>
</node>
<node TEXT="Critique Links" ID="ID_457260473" CREATED="1562749849779" MODIFIED="1563175655279">
<edge COLOR="#8a8f90"/>
<node TEXT="Links to the Blogs that" ID="ID_1520030521" CREATED="1562749856683" MODIFIED="1563175655279">
<edge COLOR="#8a8f90"/>
<node TEXT="" ID="ID_933447062" CREATED="1562749915497" MODIFIED="1562749915498">
<hook NAME="FirstGroupNode"/>
</node>
<node TEXT="Critique this Edudex" ID="ID_1221342199" CREATED="1562749879363" MODIFIED="1563175655279">
<edge COLOR="#8a8f90"/>
</node>
<node TEXT="Suggest Interesting Changes to these" ID="ID_1121558722" CREATED="1562749894251" MODIFIED="1563175655279">
<edge COLOR="#8a8f90"/>
</node>
<node TEXT="" ID="ID_841067604" CREATED="1562749915485" MODIFIED="1562749915497">
<hook NAME="SummaryNode"/>
<hook NAME="AlwaysUnfoldedNode"/>
<node TEXT="Will Be Added Here" ID="ID_344380591" CREATED="1562749915499" MODIFIED="1563175655279">
<edge COLOR="#8a8f90"/>
<node TEXT="Email the Link to your Blog at Contact Us" ID="ID_179009891" CREATED="1562749953211" MODIFIED="1563175655279">
<edge COLOR="#8a8f90"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
