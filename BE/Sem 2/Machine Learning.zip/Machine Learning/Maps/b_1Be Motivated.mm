<map version="freeplane 1.7.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<attribute_registry SHOW_ATTRIBUTES="hide"/>
<node TEXT="MachineLearning" LOCALIZED_STYLE_REF="AutomaticLayout.level.root" FOLDED="false" ID="ID_191153586" CREATED="1562675315160" MODIFIED="1563517026553" ICON_SIZE="36.0 pt" LINK="../1_Machine%20Learning_MasterLookup.mm"><hook NAME="MapStyle">
    <properties fit_to_viewport="false" show_icon_for_attributes="false" show_note_icons="true" edgeColorConfiguration="#ff0000ff,#ff0000ff,#ff0000ff,#ff0000ff,#ff0000ff,#ff0000ff,#ff0000ff,#ff0000ff,#ff0000ff,#ff0000ff,#ff0000ff,#ff0000ff"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt">
<font SIZE="24"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="default" ICON_SIZE="12.0 pt" COLOR="#000000" STYLE="fork">
<font NAME="SansSerif" SIZE="10" BOLD="false" ITALIC="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details"/>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes">
<font SIZE="9"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#000000" BACKGROUND_COLOR="#ffffff" TEXT_ALIGN="LEFT"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
<cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="styles.topic" COLOR="#18898b" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subtopic" COLOR="#cc3300" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subsubtopic" COLOR="#669900">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" ICON_SIZE="14.0 pt" COLOR="#000000" STYLE="oval">
<font NAME="Segoe Print" SIZE="22"/>
<edge COLOR="#ffffff"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" ICON_SIZE="18.0 px" BORDER_WIDTH_LIKE_EDGE="true" COLOR="#000000" SHAPE_HORIZONTAL_MARGIN="0.1 pt" SHAPE_VERTICAL_MARGIN="0.1 pt">
<font SIZE="18" BOLD="false" ITALIC="true"/>
<edge STYLE="sharp_bezier" COLOR="#ff0000" WIDTH="8"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" ICON_SIZE="16.0 px" BORDER_WIDTH_LIKE_EDGE="true" COLOR="#000000">
<font SIZE="16"/>
<edge STYLE="sharp_bezier" COLOR="#ff0000" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" ICON_SIZE="14.0 px" BORDER_WIDTH_LIKE_EDGE="true" COLOR="#000000">
<font SIZE="14"/>
<edge STYLE="sharp_bezier" COLOR="#ff0000" WIDTH="3"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" ICON_SIZE="14.0 px" BORDER_WIDTH_LIKE_EDGE="true" COLOR="#000000">
<font SIZE="13"/>
<edge STYLE="sharp_bezier" COLOR="#ff0000" WIDTH="2"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" ICON_SIZE="14.0 px" BORDER_WIDTH_LIKE_EDGE="true">
<font SIZE="13"/>
<edge STYLE="sharp_bezier" COLOR="#ff0000" WIDTH="1"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" ICON_SIZE="14.0 px">
<font SIZE="13"/>
<edge STYLE="bezier"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" ICON_SIZE="14.0 px">
<font SIZE="13"/>
<edge STYLE="bezier"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" ICON_SIZE="14.0 px">
<edge STYLE="bezier"/>
<font SIZE="13"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" ICON_SIZE="14.0 px">
<font SIZE="13"/>
<edge STYLE="bezier"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" ICON_SIZE="14.0 px">
<font SIZE="13"/>
<edge STYLE="bezier"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11" ICON_SIZE="14.0 px">
<edge STYLE="bezier"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook NAME="AutomaticEdgeColor" COUNTER="27" RULE="ON_BRANCH_CREATION"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL"/>
<font SIZE="20"/>
<node TEXT="Application Domains" POSITION="right" ID="ID_1516265986" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge COLOR="#ff0000"/>
<node TEXT="Retail" ID="ID_1281529364" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="ECommerce" ID="ID_952996307" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Application MachineLearning#$D$#" FOLDED="true" ID="ID_1727330722" CREATED="1557224068552" MODIFIED="1557224288250">
<icon BUILTIN="stop-sign"/>
<node TEXT="5 Applications of Machine Learning - Robotiq" FOLDED="true" ID="ID_1992203716" CREATED="1557224068552" MODIFIED="1557224276857" LINK="https://blog.robotiq.com/5-applications-of-machine-learning">
<node TEXT="This final application isn&#x2019;t quite as groundbreaking as medical or robotic applications of machine learning but it&#x2019;s cool nonetheless. By analyzing the pixels on a screen machine learning can be used to teach a neural network how to play video games." ID="ID_1702858453" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="The Top 10 AI And Machine Learning Use Cases Everyone " FOLDED="true" ID="ID_1240351975" CREATED="1557224068552" MODIFIED="1557224276858" LINK="https://www.forbes.com/sites/bernardmarr/2016/09/30/what-are-the-top-10-use-cases-for-machine-learning-and-ai/">
<node TEXT="The implications of this are wide and varied and data scientists are coming up with new use cases for machine learning every day but these are some of the top most interesting use cases " ID="ID_685047957" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Machine learning - Wikipedia" FOLDED="true" ID="ID_951273504" CREATED="1557224068552" MODIFIED="1557224276859" LINK="https://en.wikipedia.org/wiki/Machine_learning">
<node TEXT=": 2 Machine learning algorithms are used in a wide variety of applications such as email filtering and computer vision where it is infeasible to develop an algorithm of specific instructions for performing the task. Machine learning is closely related to computational statistics which" ID="ID_1065567147" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Top 9 Machine Learning Applications in Real World - DataFlair" FOLDED="true" ID="ID_521737139" CREATED="1557224068552" MODIFIED="1557224276859" LINK="https://data-flair.training/blogs/machine-learning-applications/">
<node TEXT="2. Machine Learning Applications. As we move forward into the digital age One of the modern innovations we&#x2019;ve seen is the creation of Machine Learning.This incredible form of artificial intelligence is already being used in various industries and professions." ID="ID_1897362161" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Top 9 Machine Learning Applications in Real World - Data " FOLDED="true" ID="ID_208048708" CREATED="1557224068552" MODIFIED="1557224276860" LINK="https://www.datasciencecentral.com/profiles/blogs/top-9-machine-learning-applications-in-real-world">
<node TEXT="Machine Learning Applications. Some of the machine learning applications are: 1. Image Recognition. One of the most common uses of machine learning is image recognition. There are many situations where you can classify the object as a digital image. For digital images the measurements describe the outputs of each pixel in the image." ID="ID_1027749494" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="What are some interesting possible applications of machine " FOLDED="true" ID="ID_19955278" CREATED="1557224068552" MODIFIED="1557224276860" LINK="https://www.quora.com/What-are-some-interesting-possible-applications-of-machine-learning">
<node TEXT="Machine learning has lots of applications. So it really just depends on what you call interesting which is subjective. Since interests vary from person to person and since I have no idea what youre interested in Ill simply list some typical applications." ID="ID_838969951" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="9 Applications of Machine Learning from Day-to-Day Life" FOLDED="true" ID="ID_186182062" CREATED="1557224068552" MODIFIED="1557224276861" LINK="https://medium.com/app-affairs/9-applications-of-machine-learning-from-day-to-day-life-112a47a429d0">
<node TEXT="9 Applications of Machine Learning from Day-to-Day Life.  One of the popular applications of AI is Machine Learning (ML) in which computers software and devices perform via cognition (very " ID="ID_1498068098" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Top 10 Machine Learning Applications in Use Today - Dezyre" FOLDED="true" ID="ID_1331104368" CREATED="1557224068552" MODIFIED="1557224276861" LINK="https://www.dezyre.com/article/top-10-industrial-applications-of-machine-learning/364">
<node TEXT="Machine Learning Applications in Social Media. Machine learning offers the most efficient means of engaging billions of social media users. From personalizing news feed to rendering targeted ads machine learning is the heart of all social media platforms for their own and user benefits. Social media and chat applications have advanced to a " ID="ID_1306872729" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Six Novel Machine Learning Applications - Forbes" FOLDED="true" ID="ID_405025140" CREATED="1557224068552" MODIFIED="1557224276862" LINK="https://www.forbes.com/sites/85broads/2014/01/06/six-novel-machine-learning-applications/">
<node TEXT="Below is a list of 10 of the most interesting applications. #1: Automating Employee Access Control. Amazon one of the pioneers of machine-learning based recommendation engines and price " ID="ID_361875732" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="A Machine Learning Tutorial with Examples | Toptal" FOLDED="true" ID="ID_556413888" CREATED="1557224068552" MODIFIED="1557224276863" LINK="https://www.toptal.com/machine-learning/machine-learning-theory-an-introductory-primer">
<node TEXT="Machine Learning (ML) is coming into its own with a growing recognition that ML can play a key role in a wide range of critical applications such as data mining natural language processing image recognition and expert systems." ID="ID_513583006" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="8 Inspirational Applications of Deep Learning" FOLDED="true" ID="ID_210304725" CREATED="1557224068552" MODIFIED="1557224276863" LINK="https://machinelearningmastery.com/inspirational-applications-deep-learning/">
<node TEXT="It is hyperbole to say deep learning is achieving state-of-the-art results across a range of difficult problem domains. A fact but also hyperbole. There is a lot of excitement around artificial intelligence machine learning and deep learning at the moment. It is also an amazing opportunity to " ID="ID_1350489771" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
<node TEXT="Machine Learning Studio | Microsoft Azure" FOLDED="true" ID="ID_825588377" CREATED="1557224068552" MODIFIED="1557224276864" LINK="https://azure.microsoft.com/en-us/services/machine-learning-studio/">
<node TEXT="Welcome to Machine Learning Studio the Azure Machine Learning solution you&#x2019;ve grown to love. Machine Learning Studio is a powerfully simple browser-based visual drag-and-drop authoring environment where no coding is necessary. Go from idea to deployment in a matter of clicks." ID="ID_1417777911" CREATED="1557224068552" MODIFIED="1557224068552"/>
</node>
</node>
<node TEXT="Application Retail MachineLearning#$D$#" FOLDED="true" ID="ID_63187483" CREATED="1557224068553" MODIFIED="1557224288250">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning in Retail &#x2013; Near-Term Applications and " FOLDED="true" ID="ID_710666441" CREATED="1557224068553" MODIFIED="1557224276864" LINK="https://emerj.com/ai-sector-overviews/machine-learning-retail-applications/">
<node TEXT="Our own research into the applications of machine learning in marketing seems to bode well for retail applications. In our interviews with 51 different AI / marketing executives we found that the AI marketing vendors we spoke with were overwhelmingly optimistic about retail and eCommerce as sectors ripe for applying AI to marketing. Below is a " ID="ID_110649999" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="The Top 10 AI And Machine Learning Use Cases Everyone " FOLDED="true" ID="ID_1732744283" CREATED="1557224068553" MODIFIED="1557224276865" LINK="https://www.forbes.com/sites/bernardmarr/2016/09/30/what-are-the-top-10-use-cases-for-machine-learning-and-ai/">
<node TEXT="The implications of this are wide and varied and data scientists are coming up with new use cases for machine learning every day but these are some of the top most interesting use cases " ID="ID_683294170" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Top 10 Machine Learning Applications in Use Today - Dezyre" FOLDED="true" ID="ID_1851418156" CREATED="1557224068553" MODIFIED="1557224276866" LINK="https://www.dezyre.com/article/top-10-industrial-applications-of-machine-learning/364">
<node TEXT="Machine Learning Applications in Retail. Machine learning in retail is more than just a latest trend retailers are implementing big data technologies like Hadoop and Spark to build big data solutions and quickly realizing the fact that it&#x2019;s only the start. They need a solution which can analyse the data in real-time and provide valuable " ID="ID_1664075137" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Top 9 Machine Learning Applications in Real World - Data " FOLDED="true" ID="ID_113364872" CREATED="1557224068553" MODIFIED="1557224276866" LINK="https://www.datasciencecentral.com/profiles/blogs/top-9-machine-learning-applications-in-real-world">
<node TEXT="Machine Learning Applications. Some of the machine learning applications are: 1. Image Recognition. One of the most common uses of machine learning is image recognition. There are many situations where you can classify the object as a digital image. For digital images the measurements describe the outputs of each pixel in the image." ID="ID_507909448" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Applications of Machine Learning in Retail - cioreview.com" FOLDED="true" ID="ID_1250931017" CREATED="1557224068553" MODIFIED="1557224276867" LINK="https://www.cioreview.com/news/applications-of-machine-learning-in-retail-nid-25638-cid-38.html">
<node TEXT="The capability of machines to learn without being explicitly programmed known as machine learning (ML) has traversed technology beyond predictive analytics and algorithms. ML applications are now growing exponentially parallel to the current developments of new and existing companies. Although ML " ID="ID_236168230" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="How Machine Learning Keeps Retailers Ahead of Trends" FOLDED="true" ID="ID_1143556002" CREATED="1557224068553" MODIFIED="1557224276867" LINK="https://hortonworks.com/blog/how-machine-learning-keeps-retailers-ahead-of-trends/">
<node TEXT="Read the original article on Total Retail. Learn More. For more on this exciting topic please join Alex and Eric on September 1st 2015 for a webinar where they will exchange perspectives on what machine learning means for retail and CPG businesses and where opportunities are for its application." ID="ID_1799188993" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Machine Learning For Retail - oliverwyman.com" FOLDED="true" ID="ID_746566715" CREATED="1557224068553" MODIFIED="1557224276867" LINK="http://www.oliverwyman.com/our-expertise/insights/2017/feb/machine-learning-for-retail.html">
<node TEXT="Machine Learning For Retail. Using machine learning algorithms to predict sales on promotions. Our Expertise. Insights. Machine Learning For Retail. Share; Sales promotions are on the rise in most countries today and retailers are struggling to make better predictions to control spending and increase returns." ID="ID_1860398550" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="How machine learning is changing online retail for good " FOLDED="true" ID="ID_149678171" CREATED="1557224068553" MODIFIED="1557224276868" LINK="https://econsultancy.com/how-machine-learning-is-changing-online-retail-for-good/">
<node TEXT="There&#x2019;s a lot in store for retail in 2016 and I think machine learning algorithms are one of the most powerful tools a retailer should use to get ahead in the growing industry. Shoppers are expecting a more personalized shopping experience free of speed bumps that can run rampant in online retail." ID="ID_1814183653" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="A Machine Learning Tutorial with Examples | Toptal" FOLDED="true" ID="ID_1403254467" CREATED="1557224068553" MODIFIED="1557224276868" LINK="https://www.toptal.com/machine-learning/machine-learning-theory-an-introductory-primer">
<node TEXT="Nicholas is a professional software engineer with a passion for quality craftsmanship. He loves architecting and writing top-notch code. Machine Learning (ML) is coming into its own with a growing recognition that ML can play a key role in a wide range of critical applications such as data mining " ID="ID_875087413" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Artificial Intelligence in Retail &#x2013; 10 Present and Future " FOLDED="true" ID="ID_582128752" CREATED="1557224068553" MODIFIED="1557224276869" LINK="https://emerj.com/ai-sector-overviews/artificial-intelligence-retail/">
<node TEXT="Artificial intelligence in retail is being applied in new ways across the entire product and service cycle&#x2014;from assembly to post-sale customer service interactions but retail players need answers to important questions:. Which AI applications are playing a role in automation or augmentation of the retail process?" ID="ID_1690865210" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="What are some interesting possible applications of machine " FOLDED="true" ID="ID_462717006" CREATED="1557224068553" MODIFIED="1557224276869" LINK="https://www.quora.com/What-are-some-interesting-possible-applications-of-machine-learning">
<node TEXT="Machine learning has lots of applications. So it really just depends on what you call interesting which is subjective. Since interests vary from person to person and since I have no idea what youre interested in Ill simply list some typical applications." ID="ID_372604000" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Machine Learning Studio | Microsoft Azure" FOLDED="true" ID="ID_1550376612" CREATED="1557224068553" MODIFIED="1557224276870" LINK="https://azure.microsoft.com/en-us/services/machine-learning-studio/">
<node TEXT="Welcome to Machine Learning Studio the Azure Machine Learning solution you&#x2019;ve grown to love. Machine Learning Studio is a powerfully simple browser-based visual drag-and-drop authoring environment where no coding is necessary. Go from idea to deployment in a matter of clicks." ID="ID_1669327888" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
</node>
<node TEXT="Application ECommerce MachineLearning#$D$#" FOLDED="true" ID="ID_1958246514" CREATED="1557224068553" MODIFIED="1557224288250">
<icon BUILTIN="stop-sign"/>
<node TEXT="7 Powerful Applications of Machine Learning in E-Commerce" FOLDED="true" ID="ID_1409414207" CREATED="1557224068553" MODIFIED="1557224276870" LINK="https://www.granify.com/blog/powerful-applications-of-machine-learning-in-e-commerce">
<node TEXT="But this is woefully far from reality. Companies work with limited resources and need to prioritize what machine learning technology to adopt. It&#x2019;s safe to say that the priority would be the tech that makes the biggest impact. With this let&#x2019;s review the most powerful applications of machine learning technology in e-commerce. 1." ID="ID_51958317" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="What are the applications of machine learning in the e " FOLDED="true" ID="ID_194364897" CREATED="1557224068553" MODIFIED="1557224276870" LINK="https://www.quora.com/What-are-the-applications-of-machine-learning-in-the-e-commerce-industry-Which-ML-algorithms-and-techniques-are-used">
<node TEXT="E-commerce companies have a lot of data at their fingertips. But making use of that data was a challenge. Machine learning is able to make sense of digital data at a much faster rate than any human is capable of. Choosing the application of machine learning tends to be a decision of priorities. Hope this answer was helpful." ID="ID_1299177676" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Top 5 Machine Learning Applications for E-Commerce " FOLDED="true" ID="ID_1849285211" CREATED="1557224068553" MODIFIED="1557224276871" LINK="https://techblog.commercetools.com/top-5-machine-learning-applications-for-e-commerce-268eb1c89607">
<node TEXT="From the machine learning perspective the main challenge of this problem is to train a robust model despite having a heavily imbalanced dataset since there are far fewer cases labelled as &#x2018;anomaly&#x2019; than &#x2018;normal&#x2019;. A popular e-commerce application of this approach is fraud detection." ID="ID_140327998" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="eCommerce machine learning applications: the future of " FOLDED="true" ID="ID_1805342192" CREATED="1557224068553" MODIFIED="1557224276871" LINK="https://www.zaproo.com/ecommerce-machine-learning-applications-the-future-of-ecommerce-marketing/">
<node TEXT="Today machine learning applications are mainly employed by large companies with the resources to invest in such technologies. However it is only a matter of time until machine learning becomes more widely employed in the eCommerce industry and exploited for commercial softwares affordable by a larger number of online retailers." ID="ID_1437899561" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="How to Apply Machine Learning to Business Problems | Emerj" FOLDED="true" ID="ID_1406240856" CREATED="1557224068553" MODIFIED="1557224276872" LINK="https://emerj.com/ai-executive-guides/how-to-apply-machine-learning-to-business-problems/">
<node TEXT="It&#x2019;s easy to see the massive rise in popularity for venture investment conferences and business-related queries for &#x201c;machine learning&#x201d; since 2012 &#x2013; but most technology executives often have trouble identifying where their business might actually apply machine learning (ML) to business problems." ID="ID_1316226478" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Ecommerce Machine Learning Apps | Artificial Intelligence " FOLDED="true" ID="ID_633863932" CREATED="1557224068553" MODIFIED="1557224276872" LINK="https://mobikul.com/machine-learning/">
<node TEXT="Ecommerce Machine Learning Apps provide ML and AI integration for ecommerce platform like magento Magento 2 Opencart Prestashopwoocommerce.  The actual design and functionality will be added as per the default design and theme of the mobikul application." ID="ID_288547012" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="6 Common Machine Learning Applications for Business" FOLDED="true" ID="ID_1756170440" CREATED="1557224068553" MODIFIED="1557224276873" LINK="https://www.datascience.com/blog/common-machine-learning-business-applications">
<node TEXT="This post introduces applications of six of the most common machine learning algorithms for business. Discover how these key machine learning and data science methods can help you maximize revenue in your business." ID="ID_1736165581" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="10 Companies Using Machine Learning in Cool Ways | WordStream" FOLDED="true" ID="ID_84672003" CREATED="1557224068553" MODIFIED="1557224276873" LINK="https://www.wordstream.com/blog/ws/2017/07/28/machine-learning-applications">
<node TEXT="Machine learning is one of the most exciting technological developments in history. What are some examples of machine learning and how it works in action? Find out how these 10 companies plan to change the future with their machine learning applications." ID="ID_38105254" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="How Machine Learning can be used in B2B eCommerce - B2X " FOLDED="true" ID="ID_1369417449" CREATED="1557224068553" MODIFIED="1557224276873" LINK="https://b2xpartners.com/machine-learning-b2b-e-commerce/">
<node TEXT="CIO.com published an article on JJ Food Service and their use of Machine Learning in their E-Commerce program. JJ Food Service is an independent food delivery company in the U.K. with over 60000 business customers. About six years ago JJ Food Service built a B2B E-Commerce Portal and it now takes 60 percent of its 5000 orders online." ID="ID_365385792" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Machine Learning for Mobile Apps. How to Use?" FOLDED="true" ID="ID_42251082" CREATED="1557224068553" MODIFIED="1557224276874" LINK="https://theappsolutions.com/blog/development/machine-learning-in-mobile-app/">
<node TEXT="Further in this article we will talk about how to use this technology for predictive analytics when you need to develop a mobile app with machine learning for eCommerce. Application of machine learning in finance. In the finance sphere machine learning algorithms are widely used for predicting future trends bubbles and crashes." ID="ID_155130035" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="6 Ways Machine Learning Will Impact Ecommerce | Practical " FOLDED="true" ID="ID_1124510168" CREATED="1557224068553" MODIFIED="1557224276875" LINK="https://www.practicalecommerce.com/6-Ways-Machine-Learning-Will-Impact-Ecommerce">
<node TEXT="6 Ways Machine Learning Will Impact Ecommerce October 3 2016 &#x2022; Armando Roggio Machine learning is a discipline aimed at having computers discover patterns or trends in some set of data without being explicitly programmed to recognize the pattern or trend." ID="ID_155466306" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="How Machine Learning Will Impact Ecommerce" FOLDED="true" ID="ID_1917746293" CREATED="1557224068553" MODIFIED="1557224276875" LINK="https://multichannelmerchant.com/blog/machine-learning-will-impact-ecommerce/">
<node TEXT="Machine learning is more than the new buzzword on Buzzfeed; it has the potential to spearhead another digital upheaval transforming the way humans interact with technology and the way ecommerce does business. Any business that relies on ecommerce needs to know about digital trends &#x2014; how Google " ID="ID_552704092" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
</node>
</node>
</node>
<node TEXT="Banking" ID="ID_378196017" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Application Banking MachineLearning#$D$#" FOLDED="true" ID="ID_326804663" CREATED="1557224068553" MODIFIED="1557224288251">
<icon BUILTIN="stop-sign"/>
<node TEXT="In which areas in banking/finance is machine learning used " FOLDED="true" ID="ID_223778631" CREATED="1557224068553" MODIFIED="1557224276875" LINK="https://www.quora.com/In-which-areas-in-banking-finance-is-machine-learning-used">
<node TEXT="Machine learning is used in almost all areas of banking and financial services and it&#x2019;s application is growing many fold at each passing year due to the explosion of data digitization technology advancements competition customer centricity among other factors." ID="ID_326391430" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="5 use cases of Machine Learning in the banking industry" FOLDED="true" ID="ID_1261801450" CREATED="1557224068553" MODIFIED="1557224276876" LINK="https://techburst.io/5-use-cases-of-machine-learning-in-the-banking-industry-a4cfbedda722">
<node TEXT="5 use cases of Machine Learning in the banking industry. Vladimir Fedak Blocked Unblock Follow Following. Jan 22 2018. Machine Learning (ML) is currently the verge that has the biggest impact on the banking industry. Take a look at how 5 largest banks of the US are using ML in their workflows." ID="ID_288868516" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Application of Machine Learning in Banking - techfunnel.com" FOLDED="true" ID="ID_1920992048" CREATED="1557224068553" MODIFIED="1557224276876" LINK="https://www.techfunnel.com/fintech/application-of-machine-learning-in-banking/">
<node TEXT="The finance industry is no exception to this growing interest and adaptation and there is good reason for it. Machine learning gives banking companies the opportunity to vastly improve their business by making processes more efficient and effective. Here are a few applications of machine learning in banking. Customer Experience" ID="ID_433541151" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="15 Applications for AI and Machine Learning in Financial " FOLDED="true" ID="ID_1223250105" CREATED="1557224068553" MODIFIED="1557224276877" LINK="https://thefinancialbrand.com/71350/ai-machine-learning-analytics-marketing-banking-trends/">
<node TEXT="There is a great deal of discussion of the potential value of artificial intelligence machine learning and robotics in banking. Unfortunately much of the implementation of these technologies lags the potential by a significant margin. Nowhere is this more evident than in the application of AI for " ID="ID_1221960376" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Machine Learning in Finance &#x2013; Present and Future " FOLDED="true" ID="ID_1022814956" CREATED="1557224068553" MODIFIED="1557224276877" LINK="https://emerj.com/ai-sector-overviews/machine-learning-in-finance/">
<node TEXT="Machine learning has had fruitful applications in finance well before the advent of mobile banking apps proficient chatbots or search engines.Given the high volume accurate historical records and quantitative nature of the finance world few industries are better suited for artificial intelligence." ID="ID_1644705391" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Applications of Machine Learning in FinTech - MEDICI" FOLDED="true" ID="ID_1043724883" CREATED="1557224068553" MODIFIED="1557224276877" LINK="https://gomedici.com/applications-of-machine-learning-in-fintech/">
<node TEXT="Machine learning is a type of artificial intelligence that provides computers with the ability to learn without being explicitly programmed. The science behind machine learning is interesting and application-oriented. Many startups have disrupted the FinTech ecosystem with machine learning as their key technology.Th" ID="ID_1211945677" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Ways UK Banks Use AI And Machine Learning | Gallery " FOLDED="true" ID="ID_1330436522" CREATED="1557224068553" MODIFIED="1557224276878" LINK="https://www.computerworlduk.com/galleries/data/how-uk-banks-are-looking-embrace-ai-machine-learning-3657529/">
<node TEXT="Still applications of machine learning techniques to banks rich data sets can help fight fraud save time and money for customers and automate back-office functions. So just how are the major banks looking to use the cutting edge AI and machine learning technologies? Here are just a few examples." ID="ID_1515451809" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="5 use cases of Machine Learning in banking industry | IT " FOLDED="true" ID="ID_84966709" CREATED="1557224068553" MODIFIED="1557224276878" LINK="https://itsvit.com/blog/5-use-cases-machine-learning-banking-industry/">
<node TEXT="Final thoughts on the use cases of Machine Learning in banking. As you can see these use cases of Machine Learning in banking industry clearly indicate that 5 leading banks of the US are taking the AI and ML incredibly seriously." ID="ID_748100501" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="The Top 10 AI And Machine Learning Use Cases Everyone " FOLDED="true" ID="ID_1286634047" CREATED="1557224068553" MODIFIED="1557224276878" LINK="https://www.forbes.com/sites/bernardmarr/2016/09/30/what-are-the-top-10-use-cases-for-machine-learning-and-ai/">
<node TEXT="The implications of this are wide and varied and data scientists are coming up with new use cases for machine learning every day but these are some of the top most interesting use cases " ID="ID_1696652935" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="5 AI applications in Banking to look out for in next 5 years" FOLDED="true" ID="ID_609055142" CREATED="1557224068553" MODIFIED="1557224276879" LINK="https://www.analyticsvidhya.com/blog/2017/04/5-ai-applications-in-banking-to-look-out-for-in-next-5-years/">
<node TEXT="The following graphic shows reasons for its widespread adoption in Banking  Financial Services. Source: financialbrand.com. Artificial intelligence has several applications in the banking industry. Here are five key applications of artificial intelligence in the Banking industry that will revolutionize the industry in the next 5 years." ID="ID_554586921" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="An executive&#x2019;s guide to machine learning | McKinsey" FOLDED="true" ID="ID_1134467509" CREATED="1557224068553" MODIFIED="1557224276879" LINK="https://www.mckinsey.com/industries/high-tech/our-insights/an-executives-guide-to-machine-learning">
<node TEXT="An executive&#x2019;s guide to machine learning. Share this article on LinkedIn  and third to use (or if necessary acquire) existing expertise and knowledge in the C-suite to guide the application of that strategy. The people charged with creating the strategic vision may well be (or have been) data scientists.  an international bank " ID="ID_1365149932" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Machine Learning AI and the Future of Data Analytics in " FOLDED="true" ID="ID_531073940" CREATED="1557224068553" MODIFIED="1557224276879" LINK="https://thefinancialbrand.com/63835/artificial-intelligence-data-analytics-banking/">
<node TEXT="Machine Learning AI and the Future of Data Analytics in Banking Subscribe Now Get The Financial Brand Newsletter for FREE - Sign Up Now Banks and credit unions that dont embrace artificial intelligence and invest in the power of advanced data analytics are doomed. By Scott Hackl Global Head of Sales for Finacle at EdgeVerve" ID="ID_1105695053" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
</node>
</node>
<node TEXT="Robotics" ID="ID_1848775459" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Application Robotics MachineLearning#$D$#" FOLDED="true" ID="ID_504961625" CREATED="1557224068553" MODIFIED="1557224288251">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning in Robotics &#x2013; 5 Modern Applications | Emerj" FOLDED="true" ID="ID_1920177668" CREATED="1557224068553" MODIFIED="1557224276880" LINK="https://emerj.com/ai-sector-overviews/machine-learning-in-robotics/">
<node TEXT="The following overview of machine learning applications in robotics highlights five key areas where machine learning has had a significant impact on robotic technologies both at present and in the development stages for future uses." ID="ID_1908561157" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="5 Applications of Machine Learning - Robotiq" FOLDED="true" ID="ID_385650641" CREATED="1557224068553" MODIFIED="1557224276880" LINK="https://blog.robotiq.com/5-applications-of-machine-learning">
<node TEXT="From marketing to medicine and web security today we&#x2019;re looking at five applications of machine learning in today&#x2019;s modern world. What Is Machine Learning and How Does it Connect to Robotics? At its core machine learning is a type of artificial intelligence that gives computers the ability to learn new things without being programmed." ID="ID_1477669122" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="What are some of the applications of Machine Learning in " FOLDED="true" ID="ID_948470852" CREATED="1557224068553" MODIFIED="1557224276880" LINK="https://www.quora.com/What-are-some-of-the-applications-of-Machine-Learning-in-Robotics-Computer-Vision">
<node TEXT="Probably the most common (and necessary!) example of machine learning in robotics and computer vision has to be the Simultaneous Localization and Mapping (SLAM) algorithm. Wikipedias article has a pretty good description of the technique but at " ID="ID_753380144" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Robotics Application Machine Learning | Learn Robotics " FOLDED="true" ID="ID_1289944568" CREATED="1557224068553" MODIFIED="1557224276881" LINK="https://www.experfy.com/training/courses/robotics-application-machine-learning">
<node TEXT="Obtain the real time data exchange from the robot sensors for training AI. Learn how to select the appropriate robot for their application integrate the real time data exchange at the appropriate frequency and include the predictors that may be needed for training. Prepare the data for machine learning and deploy robustly for success." ID="ID_1965813075" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Industrial Robotics: AI and Machine Learning in Your " FOLDED="true" ID="ID_1595862734" CREATED="1557224068553" MODIFIED="1557224276881" LINK="https://www.robotics.org/blog-article.cfm/Artificial-Intelligence-and-Machine-Learning-in-Your-Industrial-Robotics-Application/83">
<node TEXT="Artificial Intelligence and Machine Learning in Your Industrial Robotics Application. By Robotics Online Marketing Team POSTED 02/13/2018. Artificial intelligence (AI) and machine learning capabilities have been quickly making their way into industrial robotics technology." ID="ID_1687982648" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Machine Learning in Your Industrial Robotics Application " FOLDED="true" ID="ID_1545721071" CREATED="1557224068553" MODIFIED="1557224276881" LINK="https://www.robotshop.com/community/blog/show/machine-learning-in-your-industrial-robotics-application">
<node TEXT="Machines that are coded with Artificial Intelligence (AI) mimic human actions and think like humans. Machine learning and AI capabilities have been quickly emerging in industrial robotics technology. In their journey to boost productivity manufacturers intend to improve the rigid skills of traditional industrial robots." ID="ID_539201019" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Machine learning applied to robotics | LASA" FOLDED="true" ID="ID_246587134" CREATED="1557224068553" MODIFIED="1557224276882" LINK="http://lasa.epfl.ch/research_new/ML/index.php">
<node TEXT="Machine learning with applications to robotics. We look at tasks that require a sequence of actions that range from single arm motions fine manipulation and coordinated behaviors. We use knowledge acquired by observing humans performing a task or by directly guiding the robot through kinesthetic demonstrations." ID="ID_1672501644" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Applying Artificial Intelligence and Machine Learning in " FOLDED="true" ID="ID_403307538" CREATED="1557224068553" MODIFIED="1557224276882" LINK="https://www.robotics.org/blog-article.cfm/Applying-Artificial-Intelligence-and-Machine-Learning-in-Robotics/103">
<node TEXT="Two Types of Industrial Robot Applications Using Artificial Intelligence and Machine Learning. Supply chain and logistics applications are seeing some of the first implementations of AI and machine learning in robotics. In one example a robotic arm is responsible for handling frozen cases of food that are covered in frost." ID="ID_240753472" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Machine Learning in Surgical Robotics &#x2013; 4 Applications " FOLDED="true" ID="ID_839904789" CREATED="1557224068553" MODIFIED="1557224276882" LINK="https://emerj.com/ai-sector-overviews/machine-learning-in-surgical-robotics-4-applications/">
<node TEXT="Machine Learning for Surgical Workflow Modeling; Below explore examples across these four sub-categories. Each provides a snapshot of how AI and robotics are converging within the surgical specialty. (Readers with a broader interest in robotics developments may want to read our complete article on machine learning in robotics applications.)" ID="ID_1786367796" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Machine learning overview definition tools applications " FOLDED="true" ID="ID_1695402158" CREATED="1557224068553" MODIFIED="1557224276883" LINK="https://www.online-sciences.com/robotics/machine-learning-overview-definition-tools-applications-cons-pros/">
<node TEXT="Machine Learning is used in many applications such as banking  financial sector healthcare retail publishing  social media robot locomotion game playing etc It is used by Google and Facebook to push relevant advertisements based on users past search behavior Source programs such as Rapidminer helps in increasing usability of algorithms for various applications." ID="ID_1750492804" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Deep Learning in Robotics: A Review of Recent Research" FOLDED="true" ID="ID_778292397" CREATED="1557224068553" MODIFIED="1557224276883" LINK="https://arxiv.org/pdf/1707.07217">
<node TEXT="Deep Learning in Robotics: A Review of Recent Research Advances in deep learning over the last decade have led to a flurry of research in the application of deep artificial neural networks to robotic systems with at least thirty papers published on the subject between 2014 and the present. This review" ID="ID_846050898" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Application Of Machine Learning and Robotics - A4academics" FOLDED="true" ID="ID_1691822712" CREATED="1557224068553" MODIFIED="1557224276883" LINK="http://a4academics.com/be-seminar-topics/19-be-mechanical-seminar-topics/305-application-of-machine-learning-robotics">
<node TEXT="If Machine Learning is applied to robots then they can learn by themselves and thus help to reduce the tedious task of monitoring programming and also will minimize the overhead charges. The paper takes into consideration the introduction of Machine Learning and its applications to robotics with a case study." ID="ID_268755748" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
</node>
</node>
<node TEXT="Agriculture" ID="ID_925056475" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Application Agriculture MachineLearning#$D$#" FOLDED="true" ID="ID_1735782716" CREATED="1557224068553" MODIFIED="1557224288251">
<icon BUILTIN="stop-sign"/>
<node TEXT="How is machine learning used in agriculture? - Quora" FOLDED="true" ID="ID_1433660086" CREATED="1557224068553" MODIFIED="1557224276914" LINK="https://www.quora.com/How-is-machine-learning-used-in-agriculture">
<node TEXT="Machine learning is a trending technology nowadays and it can be used in modern agriculture industry. The uses of ML in agriculture helps to create more healthy seeds. Machine Learning Methods In machine learning agriculture the methods are deriv" ID="ID_1127847072" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="How Machine Learning is Changing Modern Agriculture" FOLDED="true" ID="ID_410657301" CREATED="1557224068553" MODIFIED="1557224276914" LINK="https://modernag.org/innovation/machine-learning-changing-modern-agriculture/">
<node TEXT="Checkers is a game of weighing dozens of factors calculating risk and planning the next most efficient move. The same principles Arthur Samuel applied to his early machine learning experiments are used today&#x2014;especially in modern agriculture." ID="ID_765545317" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Applying Machine Learning to Agricultural Data" FOLDED="true" ID="ID_1966206908" CREATED="1557224068553" MODIFIED="1557224276915" LINK="https://www.cs.waikato.ac.nz/ml/publications/1995/McQueen95-Comp-Elec-Agri.pdf">
<node TEXT="unanticipated problems arose in the application of machine learning methods to the recorded data. Once these problems were overcome the results were encouraging and indicate that machine learning can play a useful role in large-scale agricultural problem solving. Machine learning" ID="ID_152242771" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Machine Learning in Agriculture | Iteris Inc." FOLDED="true" ID="ID_132495183" CREATED="1557224068553" MODIFIED="1557224276915" LINK="https://www.iteris.com/blog/machine-learning-agriculture">
<node TEXT="The application of machine learning to agriculture is an incredibly important advance in agriculture technologies because it allows these systems to leverage and combine historic information with real-time information such as weather information and vehicle telematics content along with the tacit information the experience that the farmer " ID="ID_372568077" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Machine Learning Applications in Agriculture and Food " FOLDED="true" ID="ID_192478017" CREATED="1557224068553" MODIFIED="1557224276915" LINK="https://lobell-lab.stanford.edu/research/machine-learning-applications-agriculture-and-food-security">
<node TEXT="Machine Learning Applications in Agriculture and Food Security Research Summary New data derived from satellites insurance records social media and other sources can help us better understand agriculture and food security." ID="ID_1094825633" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Agriculture: The Next Machine-Learning Frontier - YouTube" FOLDED="true" ID="ID_1400952430" CREATED="1557224068553" MODIFIED="1557224276916" LINK="https://www.youtube.com/watch?v=WRKh6GpjozE">
<node TEXT="In the past decade the high-tech industry has been revolutionized by machine learning algorithms applied to everything from self-driving cars to personalized recommendation systems in domains such " ID="ID_1519224889" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Applying machine learning to agricultural data - ScienceDirect" FOLDED="true" ID="ID_956174600" CREATED="1557224068553" MODIFIED="1557224276916" LINK="https://www.sciencedirect.com/science/article/pii/0168169995986019">
<node TEXT="ELSEVIER Computers and Electronics in Agriculture 12 (1995) 275-293 Computers and electronics in agriculture Applying machine learning to agricultural data Robert J. McQueen a* Stephen R. Garner b Craig G. Nevill-Manning b Ian H. Witten b Management Systems University of Waikato Hamilton New Zealand b Computer Science University of Waikato Hamilton New Zealand Accepted 30 January " ID="ID_159589207" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="AI in Agriculture &#x2013; Present Applications and Impact | Emerj" FOLDED="true" ID="ID_388862893" CREATED="1557224068553" MODIFIED="1557224276916" LINK="https://emerj.com/ai-sector-overviews/ai-agriculture-present-applications-impact/">
<node TEXT="Predictive Analytics &#x2013; Machine learning models are being developed to track and predict various environmental impacts on crop yield such as weather changes. In the full article below we&#x2019;ll explore each category of AI applications in the agricultural industry along with representative companies use-cases and videos." ID="ID_709771776" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Use of Machine Learning Techniques to Help in Predicting " FOLDED="true" ID="ID_1731057838" CREATED="1557224068553" MODIFIED="1557224276917" LINK="https://www.irjet.net/archives/V4/i5/IRJET-V4I5513.pdf">
<node TEXT="This work reflects an application of Machine learning algorithms in agriculture. Special thanks to Dr.Kavitha C Head of the Department Global academy of Technology and  October 2016 Applications of Machine Learning Techniques in Agricultural Crop Production [6] Agriculture Database ENVIS centre Punjab ." ID="ID_1269126271" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="The Top 10 AI And Machine Learning Use Cases Everyone " FOLDED="true" ID="ID_1381044768" CREATED="1557224068553" MODIFIED="1557224276917" LINK="https://www.forbes.com/sites/bernardmarr/2016/09/30/what-are-the-top-10-use-cases-for-machine-learning-and-ai/">
<node TEXT="The implications of this are wide and varied and data scientists are coming up with new use cases for machine learning every day but these are some of the top most interesting use cases " ID="ID_1594562992" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="5 Applications of Machine Learning - Robotiq" FOLDED="true" ID="ID_1347838523" CREATED="1557224068553" MODIFIED="1557224276917" LINK="https://blog.robotiq.com/5-applications-of-machine-learning">
<node TEXT="This final application isn&#x2019;t quite as groundbreaking as medical or robotic applications of machine learning but it&#x2019;s cool nonetheless. By analyzing the pixels on a screen machine learning can be used to teach a neural network how to play video games." ID="ID_95618846" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
<node TEXT="Machine-learning algorithms used to make agriculture taste " FOLDED="true" ID="ID_831086652" CREATED="1557224068553" MODIFIED="1557224276918" LINK="https://www.controleng.com/articles/machine-learning-algorithms-used-to-make-agriculture-taste-better/">
<node TEXT="It shows that we can use machine learning and well-controlled conditions to find the sweet spots that is the conditions under which the plan maximizes taste and yield&#x201d; said Barab&#xe1;si who was not involved in the study. Climate adaptation. Another important application for cyber agriculture the researchers say is adaptation to climate change." ID="ID_1571645092" CREATED="1557224068553" MODIFIED="1557224068553"/>
</node>
</node>
</node>
<node TEXT="Fashion" FOLDED="true" ID="ID_360465422" CREATED="1563179125256" MODIFIED="1564028938989">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Application Fashion MachineLearning#$D$#" ID="ID_1685454434" CREATED="1557224068554" MODIFIED="1564028938988">
<icon BUILTIN="stop-sign"/>
<node TEXT="AI in Fashion &#x2013; Present and Future Applications | Emerj" FOLDED="true" ID="ID_1533152639" CREATED="1557224068554" MODIFIED="1557224276945" LINK="https://emerj.com/ai-sector-overviews/ai-in-fashion-applications/">
<node TEXT="The global fashion industry is valued worldwide at an estimated $3 trillion and representing 2 percent of the global Gross Domestic Product.The World Bank categorizes apparel in the broader category of manufacturing which represented 15 percent of the global GDP in 2016. eCommerce has shifted the industry from strictly brick-and-mortar (and catalog) to a more mobile and social media-friendly " ID="ID_558020638" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="The Top 10 AI And Machine Learning Use Cases Everyone " FOLDED="true" ID="ID_739306810" CREATED="1557224068554" MODIFIED="1557224276945" LINK="https://www.forbes.com/sites/bernardmarr/2016/09/30/what-are-the-top-10-use-cases-for-machine-learning-and-ai/">
<node TEXT="The implications of this are wide and varied and data scientists are coming up with new use cases for machine learning every day but these are some of the top most interesting use cases " ID="ID_1989196004" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Image Recognition for Fashion with Machine Learning " FOLDED="true" ID="ID_1336469668" CREATED="1557224068554" MODIFIED="1557224276945" LINK="http://www.primaryobjects.com/2017/10/23/image-recognition-for-fashion-with-machine-learning/">
<node TEXT="From the machine learning image recognition accuracies shown above we can see that the machine learning models are certainly achieving far better results than our baseline &#x201c;guessing&#x201d; model was achieving. The best model that we&#x2019;ve trained on just 10000 images (an SVM) has scored an accuracy of 91% on the training set and 87% on the test set." ID="ID_131518119" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="The Discipline of Machine Learning" FOLDED="true" ID="ID_581543481" CREATED="1557224068554" MODIFIED="1557224276945" LINK="http://www.cs.cmu.edu/~tom/pubs/MachineLearning.pdf">
<node TEXT="Viewed this way machine learning methods play a key role in the world of computer science within an important and growing niche. While there will remain software applications where machine learning may never be useful (e.g. to write matrix multiplication programs) the niche where it will be used is growing" ID="ID_25094707" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="How Machine Learning Keeps Retailers Ahead of Trends" FOLDED="true" ID="ID_864139563" CREATED="1557224068554" MODIFIED="1557224276946" LINK="https://hortonworks.com/blog/how-machine-learning-keeps-retailers-ahead-of-trends/">
<node TEXT="In the hands of forward-thinking retailers the possibilities for advanced machine learning are limitless from sourcing buying and supply chain all the way to marketing merchandising and customer experience retailers can make significant improvements by deploying a machine learning solution." ID="ID_874961292" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Sales forecasting using extreme learning machine with " FOLDED="true" ID="ID_1887886238" CREATED="1557224068554" MODIFIED="1557224276946" LINK="https://www.sciencedirect.com/science/article/pii/S0167923608001371">
<node TEXT="In this section we present the model for the fashion sales forecasting using extreme learning machine (ELM) algorithm. For this method we first extract the sales data of one kind of fashion clothes from the raw data which include all factors affecting the sales amount. Then the most significant factors are selected to be the inputs of the ELM." ID="ID_1231999806" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="How 6 Brands are Using Machine Learning to Grow Their " FOLDED="true" ID="ID_1852903351" CREATED="1557224068554" MODIFIED="1557224276946" LINK="https://www.shopify.com/retail/how-6-brands-are-using-machine-learning-to-grow-their-business">
<node TEXT="How 6 Brands are Using Machine Learning to Grow Their Business. by Bridget Randolph; Technology  Omni-Channel Retail  and machine learning to optimize their processes anticipate their customer needs and &#x2014; in the case of one brand &#x2014; even identify the early stages of pregnancy.  Walmart&#x2019;s patent application for the machine learning " ID="ID_1709910190" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="How to deploy Machine Learning models with TensorFlow " FOLDED="true" ID="ID_1195701245" CREATED="1557224068554" MODIFIED="1557224276947" LINK="https://towardsdatascience.com/how-to-deploy-machine-learning-models-with-tensorflow-part-1-make-your-model-ready-for-serving-776a14ec3198">
<node TEXT="How to deploy Machine Learning models with TensorFlow. Part 1 &#x2014; make your model ready for serving. Vitaly Bezgachev Blocked Unblock Follow Following. Jun 24 2017. After finishing the Deep Learning Foundation course at Udacity I had a big question &#x2014; how did I deploy the trained model and make predictions for new data samples?" ID="ID_1612799957" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="8 Inspirational Applications of Deep Learning" FOLDED="true" ID="ID_1442732797" CREATED="1557224068554" MODIFIED="1557224276947" LINK="https://machinelearningmastery.com/inspirational-applications-deep-learning/">
<node TEXT="It is hyperbole to say deep learning is achieving state-of-the-art results across a range of difficult problem domains. A fact but also hyperbole. There is a lot of excitement around artificial intelligence machine learning and deep learning at the moment. It is also an amazing opportunity to " ID="ID_1763139426" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Six Novel Machine Learning Applications - Forbes" FOLDED="true" ID="ID_419308331" CREATED="1557224068554" MODIFIED="1557224276947" LINK="https://www.forbes.com/sites/85broads/2014/01/06/six-novel-machine-learning-applications/">
<node TEXT="Below is a list of 10 of the most interesting applications. #1: Automating Employee Access Control. Amazon one of the pioneers of machine-learning based recommendation engines and price " ID="ID_523121768" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning For Retail - oliverwyman.com" FOLDED="true" ID="ID_1438742459" CREATED="1557224068554" MODIFIED="1557224276947" LINK="http://www.oliverwyman.com/our-expertise/insights/2017/feb/machine-learning-for-retail.html">
<node TEXT="Machine Learning For Retail.  IT teams are now embedding machine learning algorithms in legacy systems to run automatically week after week as the promotions are churned out. Predictions to date have been done at the country level but there is interest in driving down to the store level. Beyond that the next wave of innovation will " ID="ID_501192060" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Application Of Machine Learning Techniques For The " FOLDED="true" ID="ID_231892264" CREATED="1557224068554" MODIFIED="1557224276948" LINK="https://www.researchgate.net/publication/220672760_Application_Of_Machine_Learning_Techniques_For_The_Forecasting_Of_Fashion_Trends">
<node TEXT="Request PDF on ResearchGate | On Jan 1 2010 Paola Mello and others published Application Of Machine Learning Techniques For The Forecasting Of Fashion Trends." ID="ID_797066367" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
</node>
</node>
<node TEXT="Services" ID="ID_1728427985" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Application Services MachineLearning#$D$#" FOLDED="true" ID="ID_1040757832" CREATED="1557224068554" MODIFIED="1557224288253">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning on AWS - Cloud Computing Services" FOLDED="true" ID="ID_1443742493" CREATED="1557224068554" MODIFIED="1557224277068" LINK="https://aws.amazon.com/machine-learning/">
<node TEXT="AWS has the broadest and deepest set of machine learning and AI services for your business. On behalf of our customers we are focused on solving some of the toughest challenges that hold back machine learning from being in the hands of every developer." ID="ID_1648537055" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning Studio | Microsoft Azure" FOLDED="true" ID="ID_1873828968" CREATED="1557224068554" MODIFIED="1557224277068" LINK="https://azure.microsoft.com/en-us/services/machine-learning-studio/">
<node TEXT="Welcome to Machine Learning Studio the Azure Machine Learning solution you&#x2019;ve grown to love. Machine Learning Studio is a powerfully simple browser-based visual drag-and-drop authoring environment where no coding is necessary. Go from idea to deployment in a matter of clicks." ID="ID_500980934" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Microsoft Azure Documentation | Microsoft Docs" FOLDED="true" ID="ID_173104648" CREATED="1557224068554" MODIFIED="1557224277069" LINK="https://docs.microsoft.com/en-us/azure/">
<node TEXT="Microsoft Azure Documentation. Get Started. Get started with Azure. Explore our most popular services with quickstarts samples and tutorials.  Machine Learning Services. Machine Learning Studio. Cognitive Services. Azure Notebooks. Azure Search.  Azure Active Directory for Domain Services. Application Gateway. VPN Gateway. Role-based " ID="ID_1889848606" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning Applications and Platform | SAP Leonardo" FOLDED="true" ID="ID_178835944" CREATED="1557224068554" MODIFIED="1557224277069" LINK="https://www.sap.com/products/leonardo/machine-learning.html">
<node TEXT="Connect to machine learning services.  labor-intensive invoice matching processes and free finance professionals to focus on strategy and service quality with SAP Cash Application. Use machine learning to match criteria from your history and automatically clear payments with our next-generation intelligent software." ID="ID_865409987" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="The Top 10 AI And Machine Learning Use Cases Everyone " FOLDED="true" ID="ID_768166949" CREATED="1557224068554" MODIFIED="1557224277069" LINK="https://www.forbes.com/sites/bernardmarr/2016/09/30/what-are-the-top-10-use-cases-for-machine-learning-and-ai/">
<node TEXT="The implications of this are wide and varied and data scientists are coming up with new use cases for machine learning every day but these are some of the top most interesting use cases " ID="ID_466024584" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine learning - Wikipedia" FOLDED="true" ID="ID_1011507507" CREATED="1557224068554" MODIFIED="1557224277070" LINK="https://en.wikipedia.org/wiki/Machine_learning">
<node TEXT="Machine learning (ML) is the scientific study of algorithms and statistical models that computer systems use to effectively perform a specific task without using explicit instructions relying on patterns and inference instead. It is seen as a subset of artificial intelligence.Machine learning algorithms build a mathematical model based on sample data known as training data in order to " ID="ID_1260909342" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="5 Applications of Machine Learning - Robotiq" FOLDED="true" ID="ID_1569576020" CREATED="1557224068554" MODIFIED="1557224277070" LINK="https://blog.robotiq.com/5-applications-of-machine-learning">
<node TEXT="This final application isn&#x2019;t quite as groundbreaking as medical or robotic applications of machine learning but it&#x2019;s cool nonetheless. By analyzing the pixels on a screen machine learning can be used to teach a neural network how to play video games." ID="ID_1668130203" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="What are some interesting possible applications of machine " FOLDED="true" ID="ID_1690403424" CREATED="1557224068554" MODIFIED="1557224277070" LINK="https://www.quora.com/What-are-some-interesting-possible-applications-of-machine-learning">
<node TEXT="Machine learning has lots of applications. So it really just depends on what you call interesting which is subjective. Since interests vary from person to person and since I have no idea what youre interested in Ill simply list some typical applications." ID="ID_413836110" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Azure Machine Learning Documentation &#x2013; Tutorials API " FOLDED="true" ID="ID_1031980810" CREATED="1557224068554" MODIFIED="1557224277070" LINK="https://docs.microsoft.com/en-us/azure/machine-learning/">
<node TEXT="Azure Machine Learning Service. Learn how this service empowers data scientists to develop and manage AI solutions using the Azure CLI and Python tools and libraries with a variety of Azure data and compute services." ID="ID_1911703751" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Financial Applications of Machine Learning" FOLDED="true" ID="ID_1436761427" CREATED="1557224068554" MODIFIED="1557224277071" LINK="http://www-stat.wharton.upenn.edu/~steele/Courses/9xx/Resources/MLFinancialApplications/MLFinance.html">
<node TEXT="Financial Applications of Machine Learning Headwinds. There are some good reasons why the methods of machine learning may never pay the rent in the context of money management. Low Noise Tasks: Human beings can easily pick a person out of a crowd having seen a photograph of that person. This is a resonably low noise task for a human." ID="ID_1724092007" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Azure Machine Learning Service | Microsoft Azure" FOLDED="true" ID="ID_1169919908" CREATED="1557224068554" MODIFIED="1557224277071" LINK="https://azure.microsoft.com/en-us/services/machine-learning-service/">
<node TEXT="Simplify and accelerate the building training and deployment of your machine learning models. Use automated machine learning to identify suitable algorithms and tune hyperparameters faster. Improve productivity and reduce costs with autoscaling compute and DevOps for machine learning. Seamlessly deploy to the cloud and the edge with one click." ID="ID_685210074" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning in Financial Services: 3 Potential " FOLDED="true" ID="ID_532987497" CREATED="1557224068554" MODIFIED="1557224277071" LINK="https://www.alacriti.com/machine-learning-in-financial-services-potential-applications/">
<node TEXT="The applications of machine learning in the financial services world extend well beyond these few examples. Apt implementation of machine learning technologies can help banks enhance security offer customers better digital service and increase operational efficiency. For more on financial technology and innovation visit our Resource Center." ID="ID_1963042939" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
</node>
</node>
<node TEXT="HealthCare" ID="ID_676851863" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Application HealthCare MachineLearning#$D$#" FOLDED="true" ID="ID_502959189" CREATED="1557224068554" MODIFIED="1557224288252">
<icon BUILTIN="stop-sign"/>
<node TEXT="Real-World Benefits of Machine Learning in Healthcare" FOLDED="true" ID="ID_1264294721" CREATED="1557224068554" MODIFIED="1557224277039" LINK="https://www.healthcatalyst.com/clinical-applications-of-machine-learning-in-healthcare">
<node TEXT="Let&#x2019;s Move Machine Learning from Theoretical to Clinical Reality. We already see applications of machine learning in healthcare that are advancing medicine into a new realm. It&#x2019;s exciting to think about where it can go." ID="ID_775244820" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning Healthcare Applications - emerj.com" FOLDED="true" ID="ID_97773345" CREATED="1557224068554" MODIFIED="1557224277039" LINK="https://emerj.com/ai-sector-overviews/machine-learning-healthcare-applications/">
<node TEXT="At least when it comes to machine learning it&#x2019;s likely that useful and widespread applications will develop first in narrow use-cases &#x2013; for example a machine learning healthcare application that detects the percentage growth or shrinkage of a tumor over time based on image data from dozens or hundreds of X-ray images from various angles." ID="ID_735855372" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Applications of healthcare machine learning - healthcare.ai" FOLDED="true" ID="ID_53545916" CREATED="1557224068554" MODIFIED="1557224277039" LINK="https://healthcare.ai/applications-of-healthcare-machine-learning/">
<node TEXT="Now that we have been through some of the applications of machine learning (ML) in mainstream technology we thought it would be nice to give a broader overview of some of the different types of ML and how they might be applied to improve patient care. We explored the algorithms that currently make up healthcare.ai [&#x2026;]" ID="ID_1476723500" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Top 4 Machine Learning Use Cases for Healthcare Providers" FOLDED="true" ID="ID_1015846049" CREATED="1557224068554" MODIFIED="1557224277040" LINK="https://healthitanalytics.com/news/top-4-machine-learning-use-cases-for-healthcare-providers">
<node TEXT="March 31 2017 - As healthcare providers and vendors start to show off more mature big data analytics skills machine learning and artificial intelligence have quickly rocketed to the top of the industry&#x2019;s buzzword list. The possibility of using intelligent algorithms to mine enormous stores of " ID="ID_1110523812" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Top 10 Machine Learning Applications in Use Today - Dezyre" FOLDED="true" ID="ID_1189205038" CREATED="1557224068554" MODIFIED="1557224277040" LINK="https://www.dezyre.com/article/top-10-industrial-applications-of-machine-learning/364">
<node TEXT="Machine Learning Examples in Healthcare for Personalized Treatment. A major problem that drug manufacturers often have is that a potential drug sometimes work only on a small group in clinical trial or it could be considered unsafe because a small percentage of people developed serious side effects." ID="ID_1935650588" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="[R] Machine Learning applications in the healthcare " FOLDED="true" ID="ID_1058938765" CREATED="1557224068554" MODIFIED="1557224277040" LINK="https://www.reddit.com/r/MachineLearning/comments/82817b/r_machine_learning_applications_in_the_healthcare/">
<node TEXT="I just got free college and am going to use such towards a Computer Science degree either Masters or PhD. I know I want to specialize in machine learning and data science. I have yet to figure out what field problems in the world I want to apply machine learning towards since the possibilities are endless." ID="ID_610926844" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Top 10 Applications of Machine Learning in Healthcare - FWS" FOLDED="true" ID="ID_393226783" CREATED="1557224068554" MODIFIED="1557224277041" LINK="https://www.flatworldsolutions.com/healthcare/articles/top-10-applications-of-machine-learning-in-healthcare.php">
<node TEXT="Top 10 Applications of Machine Learning in Healthcare. Healthcare is an important industry which offers value-based care to millions of people while at the same time becoming top revenue earners for many countries." ID="ID_1424263244" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Introduction to Machine Learning in Healthcare" FOLDED="true" ID="ID_742137895" CREATED="1557224068554" MODIFIED="1557224277041" LINK="http://web.orionhealth.com/rs/981-HEV-035/images/Introduction_to_Machine_Learning.pdf">
<node TEXT="application of machine learning will enable new healthcare solutions that are more precisely tailored to a person&#x2019;s unique characteristics. And our software manages over 100 million patient health records globally making us one of the few health software companies in the world capable of carrying out machine learning analysis." ID="ID_718670934" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Emerging Applications of Machine Learning in Healthcare" FOLDED="true" ID="ID_361749588" CREATED="1557224068554" MODIFIED="1557224277041" LINK="https://www.verypossible.com/blog/emerging-applications-of-machine-learning-in-healthcare">
<node TEXT="Emerging Applications of Machine Learning in Healthcare. The humans are still in charge but the impact of machine learning in healthcare is expanding. Click to look at a few of the emerging applications of machine learning in healthcare. Written by Emily Maxie on February 12 2019. Machine Learning" ID="ID_620234149" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="7 Applications of Machine Learning in Pharma and Medicine " FOLDED="true" ID="ID_332742396" CREATED="1557224068554" MODIFIED="1557224277041" LINK="https://emerj.com/ai-sector-overviews/machine-learning-in-pharma-medicine/">
<node TEXT="Image credit: Google DeepMind Health &#x2013; radiotherapy planning. DeepMind and UCLH are working on applying ML to help speed up the segmentation process (ensuring that no healthy structures are damaged) and increase accuracy in radiotherapy planning. More on this topic is covered in our industry applications piece on machine learning in radiology." ID="ID_1155703296" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine learning in healthcare applications - YouTube" FOLDED="true" ID="ID_1279942969" CREATED="1557224068554" MODIFIED="1557224277041" LINK="https://www.youtube.com/watch?v=lhLaPmUrQgk">
<node TEXT="Animated Video created using Animaker - https://www.animaker.com Machine learning in healthcare applications" ID="ID_560413261" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="The Top 10 AI And Machine Learning Use Cases Everyone " FOLDED="true" ID="ID_1818127891" CREATED="1557224068554" MODIFIED="1557224277042" LINK="https://www.forbes.com/sites/bernardmarr/2016/09/30/what-are-the-top-10-use-cases-for-machine-learning-and-ai/">
<node TEXT="The implications of this are wide and varied and data scientists are coming up with new use cases for machine learning every day but these are some of the top most interesting use cases " ID="ID_1027025270" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
</node>
</node>
<node TEXT="Entertainment" ID="ID_1725712200" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Application Entertainment MachineLearning#$D$#" FOLDED="true" ID="ID_535718974" CREATED="1557224068554" MODIFIED="1557224288252">
<icon BUILTIN="stop-sign"/>
<node TEXT="What are applications of data science and machine learning " FOLDED="true" ID="ID_710159547" CREATED="1557224068554" MODIFIED="1557224276976" LINK="https://www.quora.com/What-are-applications-of-data-science-and-machine-learning-in-the-media-entertainment-industry">
<node TEXT="Nowadays what we deal with is the high amount of information created shared and widely commented in diverse media. As it is still growing it may create problems and risks like the necessity of coping with a hate speech.. Machine learning seems to be a proper solution in those cases." ID="ID_1156249968" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning Already Changing the Entertainment Industry" FOLDED="true" ID="ID_796272463" CREATED="1557224068554" MODIFIED="1557224276976" LINK="https://futurumresearch.com/machine-learning-already-changing-entertainment-industry/">
<node TEXT="Machine Learning is also helping entertainment providers recommend personalized content based on the user&#x2019;s previous viewing activity and behavior. Take Netflix for example. They run a large number of machine learning workflows every day to be able to predict what we want to watch." ID="ID_527480279" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Applying AI and Machine Learning to Media and Entertainment" FOLDED="true" ID="ID_1646444344" CREATED="1557224068554" MODIFIED="1557224276976" LINK="https://towardsdatascience.com/applying-ai-and-machine-learning-to-media-and-entertainment-8d3ebc4b68f7">
<node TEXT="Applying AI and Machine Learning to Media and Entertainment  Next up was a panel of data science professionals in a fireside chat on Data Science Applications in Media and Entertainment.  Smart Script virtualizes production across time and space and is collaborative and democratic. Entertainment AI is generating new levels of " ID="ID_1690831650" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="AI in Movies Entertainment and Visual Media &#x2013; 5 Current " FOLDED="true" ID="ID_711898968" CREATED="1557224068554" MODIFIED="1557224276976" LINK="https://emerj.com/ai-sector-overviews/ai-in-movies-entertainment-visual-media/">
<node TEXT="Entertainment and Media AI Applications Overview. Based on our assessment of the applications in this sector the majority of entertainment and media use-cases appear to fall into three major categories: Marketing and Advertising: Companies are training machine learning algorithms to help develop film trailers and design advertisements." ID="ID_1802470718" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="In the form of case studies how do financial companies " FOLDED="true" ID="ID_1022029719" CREATED="1557224068554" MODIFIED="1557224276977" LINK="https://www.quora.com/In-the-form-of-case-studies-how-do-financial-companies-use-machine-learning">
<node TEXT="In the form of case studies how do financial companies use machine learning? Update Cancel. a d b y L a m b d a L a b s. ML workstations &#x2014; fully configured. Let us save you the work. Our machine learning experts take care of the set up.  Information Extraction has been a major application of machine learning. It involves extraction from " ID="ID_1163035288" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning - aischool.microsoft.com" FOLDED="true" ID="ID_978381501" CREATED="1557224068554" MODIFIED="1557224276977" LINK="https://aischool.microsoft.com/en-us/machine-learning/learning-paths">
<node TEXT="Skip to main content. Microsoft. AI" ID="ID_455977353" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Top AI and Machine Learning Trends in Media and Entertainment" FOLDED="true" ID="ID_96551753" CREATED="1557224068554" MODIFIED="1557224276977" LINK="https://towardsdatascience.com/top-ai-and-machine-learning-trends-in-media-and-entertainment-823f7efea928">
<node TEXT="What trends are you seeing in machine learning and AI in media and entertainment? In Media and Entertainment there are already many applications of Machine Learning and AI hiding in plain sight. But this is a recent development says Ryan McCabe Senior Data Scientist at Spotify." ID="ID_1098580028" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning - The New York Times" FOLDED="true" ID="ID_1858074029" CREATED="1557224068554" MODIFIED="1557224276977" LINK="https://www.nytimes.com/column/machine-learning">
<node TEXT="Experts say it&#x2019;s not enough for a smartphone or other gadget to have all the software bells and whistles it must also look and feel good. With its vast share of the industry&#x2019;s profits Apple " ID="ID_691637431" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="The Top 10 AI And Machine Learning Use Cases Everyone " FOLDED="true" ID="ID_1789026354" CREATED="1557224068554" MODIFIED="1557224276978" LINK="https://www.forbes.com/sites/bernardmarr/2016/09/30/what-are-the-top-10-use-cases-for-machine-learning-and-ai/">
<node TEXT="The implications of this are wide and varied and data scientists are coming up with new use cases for machine learning every day but these are some of the top most interesting use cases " ID="ID_721484229" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Six Novel Machine Learning Applications - Forbes" FOLDED="true" ID="ID_379850507" CREATED="1557224068554" MODIFIED="1557224276978" LINK="https://www.forbes.com/sites/85broads/2014/01/06/six-novel-machine-learning-applications/">
<node TEXT="Below is a list of 10 of the most interesting applications. #1: Automating Employee Access Control. Amazon one of the pioneers of machine-learning based recommendation engines and price " ID="ID_771176089" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Amazons free training: Internal machine-learning courses " FOLDED="true" ID="ID_657825356" CREATED="1557224068554" MODIFIED="1557224276978" LINK="https://www.zdnet.com/article/amazons-free-training-internal-machine-learning-courses-are-now-open-to-all/">
<node TEXT="Amazons free training: Internal machine-learning courses are now open to all. New free AWS machine-learning training offers everyone the same curriculum that its employees use." ID="ID_849620606" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="An executive&#x2019;s guide to machine learning | McKinsey" FOLDED="true" ID="ID_1174726911" CREATED="1557224068554" MODIFIED="1557224276979" LINK="https://www.mckinsey.com/industries/high-tech/our-insights/an-executives-guide-to-machine-learning">
<node TEXT="Machine learning is based on algorithms that can learn from data without relying on rules-based programming. It came into its own as a scientific discipline in the late 1990s as steady advances in digitization and cheap computing power enabled data scientists to stop building finished models and " ID="ID_1638689221" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
</node>
</node>
<node TEXT="Education" ID="ID_635378567" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Application Education MachineLearning#$D$#" FOLDED="true" ID="ID_1839487370" CREATED="1557224068554" MODIFIED="1557224288252">
<icon BUILTIN="stop-sign"/>
<node TEXT="8 Ways Machine Learning Will Improve Education" FOLDED="true" ID="ID_1107410965" CREATED="1557224068554" MODIFIED="1557224277005" LINK="https://www.gettingsmart.com/2015/11/8-ways-machine-learning-will-improve-education/">
<node TEXT="Improve learning retention and application. Lots of back office stuff: EDULOG does school bus scheduling ; Evolution DietMaster. Learning will remain highly relational for most of us but those relationships will increasingly be informed by data as a result of machine learning in education." ID="ID_106961305" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine learning - Wikipedia" FOLDED="true" ID="ID_1141300308" CREATED="1557224068554" MODIFIED="1557224277005" LINK="https://en.wikipedia.org/wiki/Machine_learning">
<node TEXT=": 2 Machine learning algorithms are used in a wide variety of applications such as email filtering and computer vision where it is infeasible to develop an algorithm of specific instructions for performing the task. Machine learning is closely related to computational statistics which" ID="ID_721821100" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning Applications in Education" FOLDED="true" ID="ID_283241658" CREATED="1557224068554" MODIFIED="1557224277005" LINK="https://www.icmla-conference.org/icmla13/S03v03.pdf">
<node TEXT="Special Session on Machine Learning Applications in Education at the 12th IEEE International Conference on Machine Learning and Applications: ICMLA 2013 December 04- 07 Miami Florida USA" ID="ID_965750253" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Top 9 Machine Learning Applications in Real World - DataFlair" FOLDED="true" ID="ID_1109230967" CREATED="1557224068554" MODIFIED="1557224277006" LINK="https://data-flair.training/blogs/machine-learning-applications/">
<node TEXT="2. Machine Learning Applications. As we move forward into the digital age One of the modern innovations we&#x2019;ve seen is the creation of Machine Learning.This incredible form of artificial intelligence is already being used in various industries and professions." ID="ID_576608297" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning with Business Applications | Indian " FOLDED="true" ID="ID_847505755" CREATED="1557224068554" MODIFIED="1557224277006" LINK="https://exed.economist.com/indian-institute-management-bangalore/machine-learning-business-applications-2020-02-24">
<node TEXT="Machine learning algorithms are part of artificial intelligence (AI) that imitates the human learning process. Machines are more powerful than the human brain at analysing data and gain insights about the business. Machine Learning (ML) algorithms have applications across various industries and different functional areas." ID="ID_1791513006" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="What are some interesting possible applications of machine " FOLDED="true" ID="ID_709683037" CREATED="1557224068554" MODIFIED="1557224277007" LINK="https://www.quora.com/What-are-some-interesting-possible-applications-of-machine-learning">
<node TEXT="Machine learning has lots of applications. So it really just depends on what you call interesting which is subjective. Since interests vary from person to person and since I have no idea what youre interested in Ill simply list some typical applications." ID="ID_98470710" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="16 Top Schools for Machine Learning [2019 Update " FOLDED="true" ID="ID_1688498104" CREATED="1557224068554" MODIFIED="1557224277007" LINK="https://admissiontable.com/ms-in-machine-learning/">
<node TEXT="The Machine Learning Track is intended for students who wish to develop their knowledge of machine learning techniques and applications. Machine learning is a rapidly expanding field with many applications in diverse areas such as bioinformatics fraud detection intelligent systems perception finance information retrieval and other areas." ID="ID_1938690257" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning And The Future Of Education - Forbes" FOLDED="true" ID="ID_833123460" CREATED="1557224068554" MODIFIED="1557224277007" LINK="https://www.forbes.com/sites/adigaskell/2016/11/04/machine-learning-and-the-future-of-education/">
<node TEXT="A look at how machine learning and big data is improving the education processes at McGraw-Hill.  Machine Learning And The Future Of Education. Adi Gaskell  &#xa9;2019 Forbes Media LLC. All " ID="ID_1764834660" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="The Top 10 AI And Machine Learning Use Cases Everyone " FOLDED="true" ID="ID_224152749" CREATED="1557224068554" MODIFIED="1557224277007" LINK="https://www.forbes.com/sites/bernardmarr/2016/09/30/what-are-the-top-10-use-cases-for-machine-learning-and-ai/">
<node TEXT="The implications of this are wide and varied and data scientists are coming up with new use cases for machine learning every day but these are some of the top most interesting use cases " ID="ID_899368991" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning in Education Market 2019 Global Trends " FOLDED="true" ID="ID_900218771" CREATED="1557224068554" MODIFIED="1557224277007" LINK="https://www.marketwatch.com/press-release/machine-learning-in-education-market-2019-global-trends-market-share-industry-size-growth-opportunities-and-forecast-to-2024-2019-04-26">
<node TEXT="Apr 26 2019 (AB Digital via COMTEX) -- Summary WiseGuyReports.com adds &#x201c;Machine Learning in Education Market 2019 Global Analysis Growth Trends" ID="ID_311289895" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Machine Learning: Strategic Applications | Sauder School " FOLDED="true" ID="ID_7847030" CREATED="1557224068554" MODIFIED="1557224277008" LINK="https://execed.economist.com/sauder-school-business/machine-learning-strategic-applications-2019-10-04">
<node TEXT="Machine Learning&#x2014;it&#x2019;s not just a buzzword any more. A subset of artificial intelligence Machine Learning (ML) is the science of getting computers to uncover key connections and make decisions without being explicitly programmed. It has given us many striking new applications like self-driving cars and speech recognition." ID="ID_216555786" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="7 Applications of Deep Learning for Natural Language " FOLDED="true" ID="ID_947326004" CREATED="1557224068554" MODIFIED="1557224277008" LINK="https://machinelearningmastery.com/applications-of-deep-learning-for-natural-language-processing/">
<node TEXT="The field of natural language processing is shifting from statistical methods to neural network methods. There are still many challenging problems to solve in natural language. Nevertheless deep learning methods are achieving state-of-the-art results on some specific language problems. It is not " ID="ID_592020720" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
</node>
</node>
</node>
<node TEXT="Resources" FOLDED="true" POSITION="right" ID="ID_905208821" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge COLOR="#ff0000"/>
<node TEXT="Ted Talks" ID="ID_919533068" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Ted Talks MachineLearning#$D$#" FOLDED="true" ID="ID_477540440" CREATED="1557224068556" MODIFIED="1557224288254">
<icon BUILTIN="stop-sign"/>
<node TEXT="Ideas about Machine learning - TED" FOLDED="true" ID="ID_452066246" CREATED="1557224068556" MODIFIED="1557224277311" LINK="https://www.ted.com/topics/machine+learning">
<node TEXT="A collection of TED Talks (and more) on the topic of Machine learning. Menu. Ideas worth spreading. Watch. TED Talks. Browse the library of TED talks and speakers. TED Recommends. Get TED Talks picked just for you. Playlists. 100+ collections of TED Talks for curious minds " ID="ID_1081153552" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="10 TED Talks on AI and machine learning | The Enterprisers " FOLDED="true" ID="ID_77934535" CREATED="1557224068556" MODIFIED="1557224277311" LINK="https://enterprisersproject.com/article/2019/2/ai-and-machine-learning-10-ted-talks">
<node TEXT="We&#x2019;ve collected 10 recent TED Talks that explore these and similar issues in thought-provoking fashion. (OK it&#x2019;s really 9 serious TED Talks plus a fun imagining of one future AI scenario.) This isn&#x2019;t the stuff of movies and Netflix shows but the real AI issues of our present and future. 1." ID="ID_1674729834" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="The wonderful and terrifying implications of computers " FOLDED="true" ID="ID_1531699323" CREATED="1557224068556" MODIFIED="1557224277311" LINK="https://www.youtube.com/watch?v=t4kyRyKyOpo">
<node TEXT="The wonderful and terrifying implications of computers that can learn | Jeremy Howard  TEDTalks is a daily video podcast of the best talks and performances from the TED Conference where the " ID="ID_1047955046" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Top TED Talks on AI And Machine Learning: 2019 Edition" FOLDED="true" ID="ID_334390287" CREATED="1557224068556" MODIFIED="1557224277311" LINK="https://www.analyticsindiamag.com/top-ted-talks-on-ai-and-machine-learning-2019-edition/">
<node TEXT="Top TED Talks on AI And Machine Learning: 2019 Edition. Akshaya Asokan. Feb 20 2019. Image source: Ted.com. Since its conceptualisation in 1983 TED Talks have been the go-to platform for people from all walks of life to share ideas and thoughts. Over the last three decades the platform has witnessed some of the finest speakers capture the " ID="ID_1554872396" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="What are the best TED Talks about big data and machine " FOLDED="true" ID="ID_1728691370" CREATED="1557224068556" MODIFIED="1557224277311" LINK="https://www.quora.com/What-are-the-best-TED-Talks-about-big-data-and-machine-learning">
<node TEXT="What are the best TED Talks about big data and machine learning? Update Cancel. a d b y Z o h o. Automate your business with Zoho One. Run your entire business with 40+ integrated apps. No multi-year contracts and no multiple versions. S i g n U p a t z o h o. c " ID="ID_1992466312" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="machine learning | Search Results | TED" FOLDED="true" ID="ID_1235562269" CREATED="1557224068556" MODIFIED="1557224277312" LINK="https://www.ted.com/search?q=machine+learning">
<node TEXT="Machine learning isnt just for simple tasks like assessing credit risk and sorting mail anymore -- today its capable of far more complex applications like grading essays and diagnosing diseases. With these advances comes an uneasy question: Will a robot do your job in the future?" ID="ID_510676933" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Top 10 TED Talks for Data Scientists and Machine Learning " FOLDED="true" ID="ID_1696991767" CREATED="1557224068556" MODIFIED="1557224277312" LINK="https://www.kdnuggets.com/2018/01/top-10-ted-talks-data-scientists-machine-learning.html">
<node TEXT="Top 10 TED Talks for Data Scientists and Machine Learning Engineers. Previous post. Next post Tags: AGI AI Anthony Goldbloom Machine Learning Nick Bostrom TED Zeynep Tufekci. A comprehensive and diverse compilation of TED talks to understand the big picture of AI and Machine Learning. By Ilan Reinstein KDnuggets." ID="ID_806389904" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Ted Talks | Iran Machine Learning" FOLDED="true" ID="ID_1744685427" CREATED="1557224068556" MODIFIED="1557224277312" LINK="http://iran-machinelearning.ir/ted-talks/">
<node TEXT="&#x648;&#x6cc;&#x62f;&#x6cc;&#x648; &#x647;&#x627;&#x6cc; Ted Talks &#x628;&#x627; &#x645;&#x648;&#x636;&#x648;&#x639; &#x647;&#x648;&#x634; &#x645;&#x635;&#x646;&#x648;&#x639;&#x6cc;. Ted Talks. &#x647;&#x648;&#x634; &#x645;&#x635;&#x646;&#x648;&#x639;&#x6cc; &#x686;&#x6af;&#x648;&#x646;&#x647; &#x645;&#x6cc; &#x62a;&#x648;&#x627;&#x646;&#x62f; &#x628;&#x634;&#x631;&#x6cc;&#x62a; &#x631;&#x627; &#x646;&#x62c;&#x627;&#x62a; &#x62f;&#x647;&#x62f;. &#x645;&#x646;&#x62a;&#x634;&#x631; &#x634;&#x62f;&#x647; &#x62a;&#x648;&#x633;&#x637; Iran Machine Learning-&#x6f1;&#x6f3;&#x6f9;&#x6f7;-&#x6f0;&#x6f7;- " ID="ID_1870696960" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Top 5 must watch TED Talks on AI and machine learning" FOLDED="true" ID="ID_89878635" CREATED="1557224068556" MODIFIED="1557224277312" LINK="https://becominghuman.ai/top-5-must-watch-ted-talks-on-ai-and-machine-learning-3dac3dad0d54">
<node TEXT="If you want to understand more about the power and potential of AI and machine learning TED Talks are a great start. Presented by thought leaders in the field of artificial intelligence TED Talks give anyone the opportunity to gain insider knowledge from an expert&#x2019;s perspective." ID="ID_1815588633" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="The Rise of Artificial Intelligence through Deep Learning " FOLDED="true" ID="ID_444570718" CREATED="1557224068556" MODIFIED="1557224277312" LINK="https://www.youtube.com/watch?v=uawLjkSI7Mo">
<node TEXT="A revolution in AI is occurring thanks to progress in deep learning. How far are we towards the goal of achieving human-level AI? What are some of the main challenges ahead? Yoshua Bengio believes " ID="ID_745495500" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="5 TED Talks on AI to watch | The Enterprisers Project" FOLDED="true" ID="ID_287029755" CREATED="1557224068556" MODIFIED="1557224277312" LINK="https://enterprisersproject.com/article/2017/10/5-ted-talks-ai-watch">
<node TEXT="If you want to understand more about the power and potential of AI and machine learning a great place to start is with TED Talks. Many TED speakers have explored the question of AI and its potential to change our lives in thought-provoking and entertaining ways. These talks will get you thinking about AI in a whole new way: 1." ID="ID_456196537" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="10 TED Talks on AI and machine learning - Advanced HPC" FOLDED="true" ID="ID_1863055953" CREATED="1557224068556" MODIFIED="1557224277312" LINK="https://www.advancedhpc.com/news-insights/insights/10-ted-talks-on-ai-and-machine-learning/">
<node TEXT="Recent TED talks explore some fascinating AI questions. Artificial intelligence as a topic has long been a mix of both fascination and fantasy the realm of both computer science and Hollywood movies. As AI and related sub-disciplines such as machine learning become a reality in our everyday lives that fascination grows." ID="ID_1696538115" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
</node>
<node TEXT="Best Ted Talks on MachineLearning#$D$#" FOLDED="true" ID="ID_911930377" CREATED="1557224068557" MODIFIED="1557224288255">
<icon BUILTIN="stop-sign"/>
<node TEXT="Ideas about Machine learning - TED: Ideas worth spreading" FOLDED="true" ID="ID_1981703335" CREATED="1557224068557" MODIFIED="1557224277313" LINK="https://www.ted.com/topics/machine+learning">
<node TEXT="A collection of TED Talks (and more) on the topic of Machine learning. Menu. Ideas worth spreading. Watch. TED Talks. Browse the library of TED talks and speakers. TED Recommends. Get TED Talks picked just for you. Playlists. 100+ collections of TED Talks for curious minds " ID="ID_200428899" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="What are the best TED Talks about big data and machine " FOLDED="true" ID="ID_733465428" CREATED="1557224068557" MODIFIED="1557224277313" LINK="https://www.quora.com/What-are-the-best-TED-Talks-about-big-data-and-machine-learning">
<node TEXT="What are the best TED Talks about big data and machine learning? Update Cancel. a d b y Z o h o. Automate your business with Zoho One. Run your entire business with 40+ integrated apps.  Apart from TED Talks probably one of the best ever live Data Talk is around the corner (29th September @ 5 PM (IST) ) " ID="ID_1216449376" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="10 TED Talks on AI and machine learning | The Enterprisers " FOLDED="true" ID="ID_1276895078" CREATED="1557224068557" MODIFIED="1557224277313" LINK="https://enterprisersproject.com/article/2019/2/ai-and-machine-learning-10-ted-talks">
<node TEXT="(OK it&#x2019;s really 9 serious TED Talks plus a fun imagining of one future AI scenario.) This isn&#x2019;t the stuff of movies and Netflix shows but the real AI issues of our present and future. 1. How machine learning can teach us to build more effective teams" ID="ID_1061746549" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Top 10 TED Talks for Data Scientists and Machine Learning " FOLDED="true" ID="ID_1077599664" CREATED="1557224068557" MODIFIED="1557224277313" LINK="https://www.kdnuggets.com/2018/01/top-10-ted-talks-data-scientists-machine-learning.html">
<node TEXT="In this post instead of discussing what language to use or what algorithm works best for a problem we have gathered a set of videos from the highly popular nonprofit organization TED. In this series of videos you will find interesting discussions and conferences about AI and Machine Learning from a big picture perspective." ID="ID_427203740" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="10 Mind-Blowing TED Talks on Artificial Intelligence Every " FOLDED="true" ID="ID_889390852" CREATED="1557224068557" MODIFIED="1557224277313" LINK="https://www.analyticsvidhya.com/blog/2018/09/best-ted-talks-artificial-intelligence-must-watch/">
<node TEXT="TED talks are simply fascinating. They provide tightly knit stories in short doses with mind-blowing information and experiences. It is amazing how much knowledge has been shared in this world using this simple and powerful medium. With Artificial Intelligence and Machine Learning getting so much " ID="ID_330073673" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="The wonderful and terrifying implications of computers " FOLDED="true" ID="ID_813015330" CREATED="1557224068557" MODIFIED="1557224277314" LINK="https://www.youtube.com/watch?v=t4kyRyKyOpo">
<node TEXT="The wonderful and terrifying implications of computers that can learn | Jeremy Howard  TEDTalks is a daily video podcast of the best talks and performances from the TED Conference where the " ID="ID_1179666787" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Top TED Talks on AI And Machine Learning: 2019 Edition" FOLDED="true" ID="ID_617210150" CREATED="1557224068557" MODIFIED="1557224277314" LINK="https://www.analyticsindiamag.com/top-ted-talks-on-ai-and-machine-learning-2019-edition/">
<node TEXT="Since its conceptualisation in 1983 TED Talks have been the go-to platform for people from all walks of life to share ideas and thoughts. Over the last three decades the platform has witnessed some of the finest speakers capture the imagination of their audience with absolute exuberance. In this " ID="ID_336007273" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Top 10 TED Talks for the Data Scientists - KDnuggets" FOLDED="true" ID="ID_688514701" CREATED="1557224068557" MODIFIED="1557224277314" LINK="https://www.kdnuggets.com/2016/02/top-10-tedtalks-data-scientists.html">
<node TEXT="TED is a nonprofitable organization devoted to Ideas Worth Spreading &#x2013; through TED.com they also schedule annual conferences and local TEDx events. TEDTalks shares the best ideas from the TED Conference with the world for free: trusted voices and convention-breaking mavericks icons and " ID="ID_1020407766" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="BestOfTedTalks - YouTube" FOLDED="true" ID="ID_328407923" CREATED="1557224068557" MODIFIED="1557224277314" LINK="https://www.youtube.com/user/BestOfTedTalks">
<node TEXT="This YouTube Channel brings you the best of the TED talks in easy to navigate through categories. Whether youre a TED talk newbie or a season TED talk liste" ID="ID_1253003503" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="5 TED Talks on AI to watch | The Enterprisers Project" FOLDED="true" ID="ID_535846689" CREATED="1557224068557" MODIFIED="1557224277314" LINK="https://enterprisersproject.com/article/2017/10/5-ted-talks-ai-watch">
<node TEXT="If you want to understand more about the power and potential of AI and machine learning a great place to start is with TED Talks. Many TED speakers have explored the question of AI and its potential to change our lives in thought-provoking and entertaining ways. These talks will get you thinking about AI in a whole new way: 1." ID="ID_330231683" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Top 5 must watch TED Talks on AI and machine learning" FOLDED="true" ID="ID_1599102910" CREATED="1557224068557" MODIFIED="1557224277314" LINK="https://becominghuman.ai/top-5-must-watch-ted-talks-on-ai-and-machine-learning-3dac3dad0d54">
<node TEXT="Top 5 must watch TED Talks on AI and machine learning. Rei Morikawa Blocked Unblock Follow Following. Jan 22. If you want to understand more about the power and potential of AI and machine learning TED Talks are a great start. Presented by thought leaders in the field of artificial intelligence TED Talks give anyone the opportunity to gain " ID="ID_569124949" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Top 10 Must-Watch TED Talks on AI and Machine Learning " FOLDED="true" ID="ID_1171433827" CREATED="1557224068557" MODIFIED="1557224277314" LINK="https://gengo.ai/articles/top-10-must-watch-ted-talks-on-ai-and-machine-learning/">
<node TEXT="Top 10 Must-Watch TED Talks on AI and Machine Learning. Top 10 Must-Watch TED Talks on AI and Machine Learning. Article by Meiryum Ali | January 11 2019. Share this post:  We at Gengo have put together a collection of the best AI TED Talks. Check them out for yourself! 1." ID="ID_1127391645" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
</node>
<node TEXT="Ted Talks Topic Page  MachineLearning#$D$#" FOLDED="true" ID="ID_1849972466" CREATED="1557224068557" MODIFIED="1557224288255">
<icon BUILTIN="stop-sign"/>
<node TEXT="Ideas about Machine learning - TED: Ideas worth spreading" FOLDED="true" ID="ID_211960345" CREATED="1557224068557" MODIFIED="1557224277315" LINK="https://www.ted.com/topics/machine+learning">
<node TEXT="A collection of TED Talks (and more) on the topic of Machine learning. Menu. Ideas worth spreading. Watch. TED Talks . Browse the library of TED talks and speakers. TED Recommends. Get TED Talks picked just for you  A collection of TED Talks (and more) on the topic of Machine learning. Video playlists about Machine learning. What are we " ID="ID_814108249" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Top 10 TED Talks for Data Scientists and Machine Learning " FOLDED="true" ID="ID_845201330" CREATED="1557224068557" MODIFIED="1557224277315" LINK="https://www.kdnuggets.com/2018/01/top-10-ted-talks-data-scientists-machine-learning.html">
<node TEXT="Top 10 TED Talks for Data Scientists and Machine Learning Engineers. Previous post. Next post Tags: AGI AI Anthony Goldbloom Machine Learning Nick Bostrom TED Zeynep Tufekci. A comprehensive and diverse compilation of TED talks to understand the big picture of AI and Machine Learning. By Ilan Reinstein KDnuggets." ID="ID_1329158352" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="TED-RNN &#x2014; Machine generated TED-Talks &#x2013; samim &#x2013; Medium" FOLDED="true" ID="ID_664811338" CREATED="1557224068557" MODIFIED="1557224277315" LINK="https://medium.com/@samim/ted-rnn-machine-generated-ted-talks-3dd682b894c0">
<node TEXT="TED-RNN &#x2014; Machine generated TED-Talks  aiming to identify the best A.I. TED Talk.  Working at the intersection of HCI Machine Learning  Creativity. Building tools for Enlightenment." ID="ID_144574127" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="TED: Ideas worth spreading" FOLDED="true" ID="ID_863163720" CREATED="1557224068557" MODIFIED="1557224277315" LINK="https://www.ted.com/topics">
<node TEXT="TED.com home of TED Talks is a global initiative about ideas worth spreading via TEDx the TED Prize TED Books TED Conferences TED-Ed and more." ID="ID_1441360360" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="machine learning | TED Blog" FOLDED="true" ID="ID_628126568" CREATED="1557224068557" MODIFIED="1557224277315" LINK="https://blog.ted.com/tag/machine-learning/">
<node TEXT="A cat. A house. A plane. Most 3-year-old children can point at these and identify them by sight. Fei-Fei Li the director of Stanford&#x2019;s Artificial Intelligence Lab and Vision Lab has spent the past 15 years teaching machines how to see." ID="ID_119015388" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="10 Mind-Blowing TED Talks on Artificial Intelligence Every " FOLDED="true" ID="ID_729798916" CREATED="1557224068557" MODIFIED="1557224277315" LINK="https://www.analyticsvidhya.com/blog/2018/09/best-ted-talks-artificial-intelligence-must-watch/">
<node TEXT="TED talks are simply fascinating. They provide tightly knit stories in short doses with mind-blowing information and experiences. It is amazing how much knowledge has been shared in this world using this simple and powerful medium. With Artificial Intelligence and Machine Learning getting so much " ID="ID_1973357763" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="The wonderful and terrifying implications of computers " FOLDED="true" ID="ID_306641467" CREATED="1557224068557" MODIFIED="1557224277316" LINK="https://www.youtube.com/watch?v=t4kyRyKyOpo">
<node TEXT="The wonderful and terrifying implications of computers that can learn | Jeremy Howard  TEDTalks is a daily video podcast of the best talks and performances from the TED Conference where the " ID="ID_207303383" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="The Quest for the Master Algorithm | Pedro Domingos " FOLDED="true" ID="ID_578401587" CREATED="1557224068557" MODIFIED="1557224277316" LINK="https://www.youtube.com/watch?v=qIZ5PXLVZfo">
<node TEXT="Pedro Domingos speaks on the future of the Information Age. Machine learning not only affects computers but it will also change our lives.  This talk was given at a TEDx event using the TED " ID="ID_1247322562" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Which topic should I choose for a TED talk presentation " FOLDED="true" ID="ID_1760600247" CREATED="1557224068557" MODIFIED="1557224277316" LINK="https://www.quora.com/Which-topic-should-I-choose-for-a-TED-talk-presentation">
<node TEXT="Which topic should I choose for a TED talk presentation? Update Cancel. Answer Wiki. 5 Answers. Dan Meyer  Watch and study as many TED talks as you can read books on TED talks and attend as many TEDx events as you can to fine-tune your talk.  If you have the privilege of speaking at a TED Talk what topic would you choose?" ID="ID_1267744985" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Top TED Talks on AI And Machine Learning: 2019 Edition" FOLDED="true" ID="ID_1599589717" CREATED="1557224068557" MODIFIED="1557224277316" LINK="https://www.analyticsindiamag.com/top-ted-talks-on-ai-and-machine-learning-2019-edition/">
<node TEXT="Top TED Talks on AI And Machine Learning: 2019 Edition. Akshaya Asokan. Feb 20 2019.  Bryn Freedman discuss the much-debated topic of securing jobs in a more AI-relevant future. &#x201c;When we spoke to people there were two themes that came out loud and clear and that is people are less looking for more money or get out of the fear of robots " ID="ID_665685417" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="TED 2019: Twitter boss offers to demote likes and follows " FOLDED="true" ID="ID_983173365" CREATED="1557224068557" MODIFIED="1557224277316" LINK="https://www.bbc.co.uk/news/technology-47955820">
<node TEXT="The TED audience were invited to contribute to the conversation via the hashtag #askJackatTED which received more than 1000 questions within 10 minutes of the talk starting." ID="ID_756205233" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="10 TED Talks on AI and machine learning | AITopics" FOLDED="true" ID="ID_303977923" CREATED="1557224068557" MODIFIED="1557224277316" LINK="https://aitopics.org/doc/news:03F30E76/">
<node TEXT="10 TED Talks on AI and machine learning. Feb-7-2019 08:40:09 GMT &#x2013;#artificialintelligence . Artificial intelligence as a topic has long been a mix of both fascination and fantasy the realm of both computer science and Hollywood movies. As AI and related sub-disciplines such as machine learning become a reality in our everyday lives that " ID="ID_522402790" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
</node>
</node>
<node TEXT="Documentries" ID="ID_836143262" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Documentries MachineLearning#$D$#" ID="ID_1249910453" CREATED="1557224068557" MODIFIED="1557224288255">
<icon BUILTIN="stop-sign"/>
<node TEXT="7 Must Watch Documentaries on Statistics and Machine Learning" FOLDED="true" ID="ID_406648785" CREATED="1557224068557" MODIFIED="1557224277317" LINK="https://www.analyticsvidhya.com/blog/2015/11/7-watch-documentaries-statistics-machine-learning/">
<node TEXT="Here is a list of must watch documentaries on statistics and machine learning which shows the rising importance of data and robotic devices. Here is a list of must watch documentaries on statistics and machine learning which shows the rising importance of data and robotic devices  Artificial Intelligence Big data data data mining data " ID="ID_857399159" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Algorithmic Trading and Machine Learning - YouTube" FOLDED="true" ID="ID_39116288" CREATED="1557224068557" MODIFIED="1557224277317" LINK="https://www.youtube.com/watch?v=XNZ7o3621FY">
<node TEXT="Household sharing included. No complicated set-up. Unlimited DVR storage space. Cancel anytime." ID="ID_1899043897" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Machine Learning &#x2022; r/MachineLearning - reddit" FOLDED="true" ID="ID_842128469" CREATED="1557224068557" MODIFIED="1557224277317" LINK="https://www.reddit.com/r/MachineLearning/">
<node TEXT="The MachineLearning community on Reddit. Reddit gives you the best of the internet in one place." ID="ID_958007789" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="10 Must-Watch Education Documentaries On The Future of " FOLDED="true" ID="ID_1524633175" CREATED="1557224068557" MODIFIED="1557224277317" LINK="https://www.diygenius.com/documentaries-on-the-future-of-education/">
<node TEXT="10 Must-Watch Education Documentaries On The Future of Learning.  Each of these fascinating education documentaries provide a glimpse into the future of education learning and creativity.  and how artificial intelligence and machine learning will transform all kinds of industries and occupations. 9. Everything Is A Remix" ID="ID_618054454" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="[D] Machine Learning meets Functional Programming: Nubank " FOLDED="true" ID="ID_512518772" CREATED="1557224068557" MODIFIED="1557224277317" LINK="https://www.reddit.com/r/MachineLearning/comments/bhp17f/d_machine_learning_meets_functional_programming/">
<node TEXT="Machine Learning is frequently done by using object-oriented python code and that&#x2019;s the way we used to do it at Nubank as well. Back then the process of building machine learning models and putting them into production was tiresome and often full of bugs." ID="ID_463870550" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Machine Learning | CosmoLearning Computer Science" FOLDED="true" ID="ID_368584755" CREATED="1557224068557" MODIFIED="1557224277317" LINK="https://cosmolearning.org/courses/machine-learning/">
<node TEXT="Topics include supervised learning unsupervised learning learning theory reinforcement learning and adaptive control. Recent applications of machine learning such as to robotic control data mining autonomous navigation bioinformatics speech recognition and text and web data processing are also discussed." ID="ID_1647802279" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Top 10 Documentaries On Artificial Intelligence That You " FOLDED="true" ID="ID_619032886" CREATED="1557224068557" MODIFIED="1557224277318" LINK="https://www.analyticsindiamag.com/top-10-documentaries-on-artificial-intelligence-that-you-must-watch/">
<node TEXT="Here is our list of 10 best artificial intelligence documentaries that you must watch. Lo And Behold: Reveries Of The Connected World; Duration: 1 hour 38 minutes. This award-winning 2016 documentary is an American documentary film directed by Werner Herzog. In it Herzog ponders the existential impact of the Internet robotics AI the " ID="ID_155752851" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="Introduction to Machine Learning | CosmoLearning Computer " FOLDED="true" ID="ID_826068059" CREATED="1557224068557" MODIFIED="1557224277318" LINK="https://cosmolearning.org/courses/introduction-machine-learning/">
<node TEXT="This is an introductory course by Caltech Professor Yaser Abu-Mostafa on machine learning that covers the basic theory algorithms and applications. Machine learning (ML) enables computational systems to adaptively improve their performance with experience accumulated from the observed data." ID="ID_128485168" CREATED="1557224068557" MODIFIED="1557224068557"/>
</node>
<node TEXT="7 Steps to Mastering Machine Learning With Python" FOLDED="true" ID="ID_1063988640" CREATED="1557224068557" MODIFIED="1557224277318" LINK="https://www.kdnuggets.com/2015/11/seven-steps-machine-learning-python.html">
<node TEXT="Step 2: Foundational Machine Learning Skills KDnuggets own Zachary Lipton has pointed out that there is a lot of variation in what people consider a data scientist. This actually is a reflection of the field of machine learning since much of what data scientists do involves using machine learning algorithms to varying degrees." ID="ID_1890589307" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="10 Must Watch Movies on Data Science and Machine Learning" FOLDED="true" ID="ID_1956095807" CREATED="1557224068558" MODIFIED="1557224277318" LINK="https://www.analyticsvidhya.com/blog/2015/11/10-watch-movies-data-science-machine-learning/">
<node TEXT="List of must watch movies on data science machine learning and artificial intelligence which clearly shows the future of humans with robots. List of must watch movies on data science machine learning and artificial intelligence which clearly shows the future of humans with robots." ID="ID_820683158" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="A Short History of Machine Learning -- Every Manager " FOLDED="true" ID="ID_1542266906" CREATED="1557224068558" MODIFIED="1557224277318" LINK="https://www.forbes.com/sites/bernardmarr/2016/02/19/a-short-history-of-machine-learning-every-manager-should-read/">
<node TEXT="Machine Learning is a sub-set of artificial intelligence where computer algorithms are used to autonomously learn from data and information. In machine learning computers don&#x2019;t have to be " ID="ID_1054496935" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
</node>
</node>
<node TEXT="Magazines" ID="ID_1815643863" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Youtube Channels" ID="ID_895441728" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Motivating Youtube Channels for MachineLearning#$D$#" ID="ID_120931923" CREATED="1557224068559" MODIFIED="1557224288256">
<icon BUILTIN="stop-sign"/>
<node TEXT="Absolute Motivation - YouTube" FOLDED="true" ID="ID_1685775098" CREATED="1557224068559" MODIFIED="1557224277325" LINK="https://www.youtube.com/channel/UCpmZQGTZXn9xd4nN59pbIWQ">
<node TEXT="If you enjoyed this video and it has helped you please share and like it. It really helps to the video be seen by others. I cant tell you how grateful I am for the support." ID="ID_1630280901" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Machine Learning - YouTube" FOLDED="true" ID="ID_890132928" CREATED="1557224068559" MODIFIED="1557224277325" LINK="https://www.youtube.com/playlist?list=PLD0F06AA0D2E8FFBA">
<node TEXT="Sign in now to see your channels and recommendations! Sign in. Watch Queue Queue" ID="ID_915454171" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Top 60 Motivational Youtube Channels For Motivational " FOLDED="true" ID="ID_1721115214" CREATED="1557224068559" MODIFIED="1557224277325" LINK="https://blog.feedspot.com/motivational_youtube_channels/">
<node TEXT="Top 60 Motivational Youtube Channels Winners. CONGRATULATIONS to every youtuber that has made this Top Motivational Youtube Channels list! This is the most comprehensive list of best Motivational Youtube Channels on the internet and I&#x2019;m honoured to have you as part of this!" ID="ID_1419962359" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="The 15 Best Motivational YouTube Channels of All Time" FOLDED="true" ID="ID_1022251721" CREATED="1557224068559" MODIFIED="1557224277325" LINK="https://www.fearlessmotivation.com/2017/02/08/15-best-motivational-youtube-channels-time/">
<node TEXT="The 15 Best Motivational YouTube Channels of All Time 1. Mateusz M. With over 880000 subscribers Mateusz M is the best motivational YouTube channel in our list. It&#x2019;s videos ignite emotions using words from the greatest legends ever such as Steve Jobs Will Smith and Les Brown." ID="ID_1416066815" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="25 most inspiring YouTube channels to follow for motivation" FOLDED="true" ID="ID_403620047" CREATED="1557224068559" MODIFIED="1557224277325" LINK="http://www.motivationjet.com/2017/12/motivational-youtube-channels-for-self-improvement.html">
<node TEXT="Awesome list of 25 best motivational channels on YouTube. In this list you can find the most inspiring videos for motivating yourself in lifes tough time. Best self help YouTube channels to help and motivate you in the long run of success." ID="ID_1532860071" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="10 Inspirational and Motivational YouTube Channels You " FOLDED="true" ID="ID_104945878" CREATED="1557224068559" MODIFIED="1557224277325" LINK="https://www.entrepreneur.com/article/320677">
<node TEXT="With 10 million subscribers Neistats channel is one of the most popular on YouTube. Ive followed this channel since Neistat started to vlog daily and what he has accomplished on YouTube is " ID="ID_1618020290" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Inspiring YouTube Channels &#x2013; EVERY DAY SHOULD BE FUN" FOLDED="true" ID="ID_78318374" CREATED="1557224068559" MODIFIED="1557224277326" LINK="http://everydayshouldbefun.com/youtube/">
<node TEXT="HES19 Motivation. My Channel will make you inspired and motivated to grow up in your life you will forget the negativity!! 88. Project Life Mastery. This YouTube channel is designed to help you make continual progress in each area of your life so that you can have lasting growth and fulfillment. 89. Inside Quest" ID="ID_1701503878" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Top 10 Machine Learning Youtube Channels To Follow" FOLDED="true" ID="ID_1985463860" CREATED="1557224068559" MODIFIED="1557224277326" LINK="https://blog.feedspot.com/machine_learning_youtube_channels/">
<node TEXT="Machine Learning Youtube Channels List The best Machine Learning Youtube Channels selected from thousands of Machine Learning channels on youtube and ranked based on its subscribers and popularity. Data will be refreshed once a week." ID="ID_850514326" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Top 10 Machine Learning Videos on YouTube - KDnuggets" FOLDED="true" ID="ID_752526110" CREATED="1557224068559" MODIFIED="1557224277326" LINK="https://www.kdnuggets.com/2015/06/top-10-machine-learning-videos-youtube.html">
<node TEXT="YouTube contains a great many videos on the topic of Machine Learning but it can be hard to figure out whats worth watching with your limited time. Here the top videos by views were sorted through to provide some of the greatest video content on the subject. If you want an easy way to get all of " ID="ID_1308324586" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Fitness motivation videos on YouTube kind of suck but " FOLDED="true" ID="ID_1414641577" CREATED="1557224068559" MODIFIED="1557224277326" LINK="https://www.washingtonpost.com/arts-entertainment/2019/04/26/fitness-motivation-videos-youtube-kind-suck-these-personalities-might-shift-your-perspective-gym/">
<node TEXT="Fitness motivation videos on YouTube kind of suck but these personalities might shift your perspective on the gym.  His self-titled channel features the basics of lifting documents his life " ID="ID_1172426177" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Most Subscribed Self-Help  Motivational YouTube Channels " FOLDED="true" ID="ID_422224702" CREATED="1557224068559" MODIFIED="1557224277326" LINK="https://channelpages.com/most-subscribed-youtube-channels/self-help-motivational">
<node TEXT="See and contact the most subscribed YouTube channels about Self-Help  Motivational. View Self-Help  Motivational channel stats demographics and more." ID="ID_1749096441" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Top 10 Inspiring YouTube Channels - Self Thrive" FOLDED="true" ID="ID_1041309625" CREATED="1557224068559" MODIFIED="1557224277326" LINK="http://www.selfthrive.com/top-10-inspiring-youtube-channels/">
<node TEXT="Inspiration is sometimes difficult to find. As the variety of online content expands though so do the different mediums of inspiration that are out there. If a self help book or pep talk from a trusted friend just isn&#x2019;t enough you can now turn to online video to help inspire you to keep going even when the going gets tough. Here are the top ten inspirational YouTube channels so you can " ID="ID_599830699" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
</node>
</node>
<node TEXT="Yourstory" ID="ID_506375269" CREATED="1563179125256" MODIFIED="1563179125256">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Tag " ID="ID_775342836" CREATED="1563179125256" MODIFIED="1563179391080" LINK="https://yourstory.com/tag/Machine-Learning">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Best Documentries on   MachineLearning#$D$#" ID="ID_126228410" CREATED="1557224068558" MODIFIED="1557224288255">
<icon BUILTIN="stop-sign"/>
<node TEXT="7 Must Watch Documentaries on Statistics and Machine Learning" FOLDED="true" ID="ID_122322836" CREATED="1557224068558" MODIFIED="1557224277318" LINK="https://www.analyticsvidhya.com/blog/2015/11/7-watch-documentaries-statistics-machine-learning/">
<node TEXT="Here is a list of must watch documentaries on statistics and machine learning which shows the rising importance of data and robotic devices. Here is a list of must watch documentaries on statistics and machine learning which shows the rising importance of data and robotic devices  I am listing down some of the best documentaries on Data " ID="ID_976760544" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="10 Must-Watch Education Documentaries On The Future of " FOLDED="true" ID="ID_1183609333" CREATED="1557224068558" MODIFIED="1557224277319" LINK="https://www.diygenius.com/documentaries-on-the-future-of-education/">
<node TEXT="10 Must-Watch Education Documentaries On The Future of Learning.  Each of these fascinating education documentaries provide a glimpse into the future of education learning and creativity.  The technology is a best choice to choose. but my problem no have resources That is a one issue. And the another is on the student. The teacher must " ID="ID_1078813005" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Science Documentary 2016 | Big Data - YouTube" FOLDED="true" ID="ID_693258724" CREATED="1557224068558" MODIFIED="1557224277319" LINK="https://www.youtube.com/watch?v=m9D-v6r3NJQ">
<node TEXT="With the rapid emergence of digital devices an unstoppable invisible force is changing human lives in incredible ways. Every two days the human race is now generating as much data as was " ID="ID_1598891598" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Top 10 Documentaries On Artificial Intelligence That You " FOLDED="true" ID="ID_656743721" CREATED="1557224068558" MODIFIED="1557224277319" LINK="https://www.analyticsindiamag.com/top-10-documentaries-on-artificial-intelligence-that-you-must-watch/">
<node TEXT="Here is our list of 10 best artificial intelligence documentaries that you must watch. Lo And Behold: Reveries Of The Connected World; Duration: 1 hour 38 minutes. This award-winning 2016 documentary is an American documentary film directed by Werner Herzog. In it Herzog ponders the existential impact of the Internet robotics AI the " ID="ID_933249882" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Machine Learning Documentary - YouTube" FOLDED="true" ID="ID_1148947918" CREATED="1557224068558" MODIFIED="1557224277319" LINK="https://www.youtube.com/watch?v=sBoZ6Yb4HkU">
<node TEXT="Please order ebook/audiobook of this video to support our channel https://www.smashwords.com/books/view/804834 https://www.amazon.co.uk/Machine-Learning-Int" ID="ID_476285377" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="The Best Documentaries  Short Films On Artificial " FOLDED="true" ID="ID_1147026786" CREATED="1557224068558" MODIFIED="1557224277319" LINK="https://creativefuture.co/top-ai-creativity-documentaries-films-videos-machine-learning/">
<node TEXT="Below is an overview of the most interesting documentaries and short films on creativity artificial intelligence and machine learning. D ocumentary films on artificial intelligence can sometimes be illuminating scary and exciting. The list below covers all of those while painting a picture of what artificial intelligence is how it works what it is doing and what is is capable of doing in " ID="ID_1739112779" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Best Of Machine Learning Architecture #mk81 " FOLDED="true" ID="ID_318237320" CREATED="1557224068558" MODIFIED="1557224277319" LINK="https://www.documentariesforchange.org/machine-learning-architecture.php4">
<node TEXT="Machine Learning Architecture layouts let you recycle the same construction and styles in numerous documents. The fact is that Machine Learning Architecture will be misunderstood and also underused since successfully using them takes a bit of tech knowledge." ID="ID_668689963" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Machine Learning &#x2022; r/MachineLearning - reddit" FOLDED="true" ID="ID_129239625" CREATED="1557224068558" MODIFIED="1557224277319" LINK="https://www.reddit.com/r/MachineLearning/">
<node TEXT="The MachineLearning community on Reddit. Reddit gives you the best of the internet in one place." ID="ID_377964689" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="10 Must Watch Movies on Data Science and Machine Learning" FOLDED="true" ID="ID_795266652" CREATED="1557224068558" MODIFIED="1557224277319" LINK="https://www.analyticsvidhya.com/blog/2015/11/10-watch-movies-data-science-machine-learning/">
<node TEXT="Some members of our team (including me) live by just 2 passions in life &#x2013; Data Science  Movies! For us slicing and dicing movies over Monday morning coffee is part of warming up ritual. So we decided to do a poll among ourselves on the best movies related to data science and machine learning " ID="ID_977695675" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="[D] Best open source Text to Speech networks " FOLDED="true" ID="ID_799600503" CREATED="1557224068558" MODIFIED="1557224277319" LINK="https://www.reddit.com/r/MachineLearning/comments/8utx7o/d_best_open_source_text_to_speech_networks/">
<node TEXT="Also note from the samples that the owner tried generating audio features (mel spectrogram) with another open source repository (tacotron) to generate speeches that are not in the training set. The pronunciation isnt the best but the audio quality is great." ID="ID_1094085839" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Top 15 Machine Learning Films | Big Cloud Recruitment" FOLDED="true" ID="ID_818174330" CREATED="1557224068558" MODIFIED="1557224277319" LINK="http://www.bigcloud.io/big-clouds-top-15-machine-learning-films/">
<node TEXT="However Machine Learning in particular has been part of popular culture since the 1920s! We&#x2019;ve compiled a list of the Top 15 Machine Learning movies; taking in big-budget Hollywood efforts independent films and much more besides! Let us know what you think! 15. I Robot (2004) &#x2018;You know somehow &#x201c;I told you so&#x201d; doesn&#x2019;t quite cut " ID="ID_1858801131" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="What are the best documentaries on artificial intelligence " FOLDED="true" ID="ID_1070394419" CREATED="1557224068558" MODIFIED="1557224277319" LINK="https://www.quora.com/What-are-the-best-documentaries-on-artificial-intelligence">
<node TEXT="AlphaGo documentary on Netflix follows the historic 2017 win of AI software playing against Lee Sedol the Go world champion. Up until this moment top human players were unbeatable by software. The movie doesnt tell you much about AI or deep learning but it is a good human drama." ID="ID_197565888" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
</node>
<node TEXT="Yourstory MachineLearning#$D$#" FOLDED="true" ID="ID_1895135632" CREATED="1557224068558" MODIFIED="1557224288255">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning Made For .NET - yourstory.com" FOLDED="true" ID="ID_1133278530" CREATED="1557224068558" MODIFIED="1557224277322" LINK="https://yourstory.com/mystory/machine-learning-made-for-net-yjrgcaccsa">
<node TEXT="Machine Learning made for .NET is usually considered to be an open source as well as cross-platform machine learning framework. This Microsoft&#x2019;s ML.NET is again well supported on macOS Linux " ID="ID_1830633532" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="These 5 startups are monitoring India&#x2019;s health with AI " FOLDED="true" ID="ID_1832745294" CREATED="1557224068558" MODIFIED="1557224277322" LINK="https://yourstory.com/2019/04/startups-monitoring-india-health-machine-learning">
<node TEXT="These 5 startups are monitoring India&#x2019;s health with AI machine learning and smart apps  We are targeting these consumers in the 25-45 age group through digital channels&#x201d; Aadil told " ID="ID_782019631" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Amazon AI Conclave 2018 - events.yourstory.com" FOLDED="true" ID="ID_1258330290" CREATED="1557224068558" MODIFIED="1557224277322" LINK="https://events.yourstory.com/amazon-ai-conclave-2018">
<node TEXT="Alexa is fuelled by Natural Language Understanding and Automated Speech Recognition deep learning; as is our drone initiative Prime Air and the computer vision technology in our new retail experience Amazon Go. We have thousands of engineers at Amazon committed to machine learning and deep learning and it&#x2019;s a big part of our heritage." ID="ID_1162900436" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="AWS Innovate Online Conference - events.yourstory.com" FOLDED="true" ID="ID_1088994285" CREATED="1557224068558" MODIFIED="1557224277322" LINK="https://events.yourstory.com/aws-innovate-online-conference">
<node TEXT="Join AWS Innovate Online Conference Special Edition &#x2013; Machine Learning On Demand led by AWS subject matter experts. This on demand conference focus on Artificial Intelligence Machine Learning and Deep Learning services to drive innovation deliver seamless customer experience and business outcomes for your organization." ID="ID_1967971791" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="TalentSprint - #YourStory #ArtificialIntelligence " FOLDED="true" ID="ID_47147446" CREATED="1557224068558" MODIFIED="1557224277322" LINK="https://www.facebook.com/talentsprint/posts/2193500590666785">
<node TEXT="#YourStory #ArtificialIntelligence #MachineLearning #TalentSprint #IIITHyderabad. See more of TalentSprint on Facebook. Log In" ID="ID_1340316330" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="EVC Ventures | Media" FOLDED="true" ID="ID_1723412257" CREATED="1557224068558" MODIFIED="1557224277322" LINK="http://www.evc.ventures/media.html">
<node TEXT="Media. Economic Times Dec - 2018 EVC Ventures investee company Milkbasket gets $7m YourStory Dec - 2018 EVC Ventures investee company Milkbasket raises $7m. Bizztor Dec - 2018  YourStory Nov - 2017 Machine Learning &#x2013; The New Catalyst In Higher Education FUNDING SAGE Nov - 2017" ID="ID_786662995" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Shailu Tipparaju - CTO - Examity | LinkedIn" FOLDED="true" ID="ID_1848563722" CREATED="1557224068558" MODIFIED="1557224277322" LINK="https://www.linkedin.com/in/shailu">
<node TEXT="#datascience #precisionmedicine #machinelearning #NLP  Shailu Tipparaju liked this. We just got YourStoryed. The Hacker Street . Launched in June 2018 The Hacker Street is a tech-driven " ID="ID_1852211523" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="20 Best AI and Machine Learning Companies for Startups " FOLDED="true" ID="ID_1383310834" CREATED="1557224068558" MODIFIED="1557224277322" LINK="https://yourstory.com/mystory/20-best-ai-and-machine-learning-companies-for-star-1loryd1ekg">
<node TEXT="For the last few months many top artificial intelligence companies have come out and made their own place in the Indian market. India is reputed to be the market full of efficient machine " ID="ID_628886937" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="What are the best machine learning libraries? - Quora" FOLDED="true" ID="ID_90784426" CREATED="1557224068558" MODIFIED="1557224277322" LINK="https://www.quora.com/What-are-the-best-machine-learning-libraries">
<node TEXT="All the above best machine learning libraries based on python that data scientists and engineers are comprehensively using in the current day scenario. You can also get the advantage of machine learning solutions by approaching the best software development company. It is essential to gain knowledge and get familiarized with these libraries for " ID="ID_524533098" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Machine Learning on AWS - Amazon Web Services (AWS)" FOLDED="true" ID="ID_1182383349" CREATED="1557224068558" MODIFIED="1557224277323" LINK="https://aws.amazon.com/machine-learning/">
<node TEXT="The AWS Machine Learning Research Awards program funds university departments faculty PhD students and post-docs that are conducting novel research in machine learning. Our goal is to accelerate the development of innovative algorithms publications and source code across a wide variety of ML applications and focus areas." ID="ID_7910910" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Animashree Anandkumar - California Institute of Technology" FOLDED="true" ID="ID_14674660" CREATED="1557224068558" MODIFIED="1557224277323" LINK="http://tensorlab.cms.caltech.edu/users/anima/">
<node TEXT="Animashree (Anima) Anandkumar is a Bren professor at Caltech CMS department and a director of machine learning research at NVIDIA. Her research spans both theoretical and practical aspects of machine learning." ID="ID_557695775" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="TiE Distinguished Speaker Series | YourStory Events" FOLDED="true" ID="ID_1445884286" CREATED="1557224068558" MODIFIED="1557224277323" LINK="https://events.yourstory.com/partners/tie-distinguished-speaker-series">
<node TEXT="TiE Amaravati is launching TiE Distinguished Speaker Series. The first speaker in the series shall be Mr.Ravi Garikipati. Ravi shall talk about his journey opportunities in Fintech space and interact with the entrepreneurs." ID="ID_671603525" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="People Stories" POSITION="right" ID="ID_1058549610" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge COLOR="#ff0000"/>
<node TEXT="Personal Success Stories" ID="ID_670687777" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Linkedin Resume" ID="ID_643586381" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="People Stories MachineLearning#$D$#" FOLDED="true" ID="ID_1234955084" CREATED="1557224068558" MODIFIED="1557224288255">
<icon BUILTIN="stop-sign"/>
<node TEXT="MachineLearning - Home | Facebook" FOLDED="true" ID="ID_284595639" CREATED="1557224068558" MODIFIED="1557224277320" LINK="https://www.facebook.com/AIMachineLearning">
<node TEXT="Hey all one of our followers have created a free real-time machine learning tool made for data scientists and in constant evolution! The main feature is the dynamic restitution of real-time evolutions in the algorithm (iterations of a Markov chain) and you can already test it on your own data or on existing datasets!" ID="ID_1909852677" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="What are some good machine learning jokes? - Quora" FOLDED="true" ID="ID_307983793" CREATED="1557224068558" MODIFIED="1557224277320" LINK="https://www.quora.com/What-are-some-good-machine-learning-jokes">
<node TEXT="What are some good machine learning jokes? Update Cancel. a d b y L a m b d a L a b s. Be a smart engineer. Choose the workstations built by ML experts.  Surprisingly it predicted the answer to be deep neural networks! People accused it was biased. NN coders assumed it was probably due to the large initial bias." ID="ID_520475203" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="McDonalds Acquires Machine-Learning Startup Dynamic Yield " FOLDED="true" ID="ID_201829864" CREATED="1557224068558" MODIFIED="1557224277320" LINK="https://www.wired.com/story/mcdonalds-big-data-dynamic-yield-acquisition/">
<node TEXT="Mention McDonald&#x2019;s to someone today and theyre more likely to think about Big Mac than Big Data. But that could soon change: The fast-food giant has embraced machine learning in a fittingly " ID="ID_1379933159" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Stories &#x2013; Google AI" FOLDED="true" ID="ID_942715873" CREATED="1557224068558" MODIFIED="1557224277320" LINK="https://ai.google/stories/">
<node TEXT="AI is helping people everywhere solve problems in exciting new ways. Read stories about Google AI and the people who use machine learning to do incredible things." ID="ID_1629797668" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Machine Learning - Facebook Research" FOLDED="true" ID="ID_943519871" CREATED="1557224068558" MODIFIED="1557224277320" LINK="https://research.fb.com/category/machine-learning/">
<node TEXT="It helps people discover new content and connect with the stories they care the most about. Our machine learning and applied machine learning researchers and engineers develop machine learning algorithms that rank feeds ads and search results and create new text understanding algorithms that keep spam and misleading content at bay." ID="ID_1062893993" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Machine Learning Studio | Microsoft Azure" FOLDED="true" ID="ID_22132753" CREATED="1557224068558" MODIFIED="1557224277320" LINK="https://azure.microsoft.com/en-us/services/machine-learning-studio/">
<node TEXT="Welcome to Machine Learning Studio the Azure Machine Learning solution you&#x2019;ve grown to love. Machine Learning Studio is a powerfully simple browser-based visual drag-and-drop authoring environment where no coding is necessary. Go from idea to deployment in a matter of clicks." ID="ID_1189198150" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Machine Learning (@machine_ml) | Twitter" FOLDED="true" ID="ID_29948008" CREATED="1557224068558" MODIFIED="1557224277320" LINK="https://twitter.com/machine_ml">
<node TEXT="Hive taps a workforce of 700000 people to label data and train AI models #datascience #machinelearning https:  #arXiv #machinelearning [cs.LG] Human-like machine learning: limitations and suggestions.  Catch up instantly on the best stories happening as they unfold." ID="ID_1531537073" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="What Will Machine Learning Look Like In Twenty Years?" FOLDED="true" ID="ID_940749648" CREATED="1557224068558" MODIFIED="1557224277320" LINK="https://www.forbes.com/sites/quora/2019/04/04/what-will-machine-learning-look-like-in-twenty-years/">
<node TEXT="What will machine learning look like 15-20 years from now? originally appeared on Quora: the place to gain and share knowledge empowering people to learn from others and better understand the " ID="ID_120701514" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Researchers use machine-learning system to diagnose " FOLDED="true" ID="ID_650235377" CREATED="1557224068558" MODIFIED="1557224277320" LINK="https://medicalxpress.com/news/2019-04-machine-learning-genetic-diseases.html">
<node TEXT="Researchers at Rady Childrens Institute for Genomic Medicine (RCIGM) have utilized a machine-learning process and clinical natural language processing (CNLP) to diagnose rare genetic diseases in " ID="ID_1459494715" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="tag: machine-learning - Flexso for People" FOLDED="true" ID="ID_1801416838" CREATED="1557224068558" MODIFIED="1557224277320" LINK="https://www.flexsoforpeople.com/en/stories/tag/machine-learning">
<node TEXT="Every story needs a hero. In our case that&#x2019;s you. Your goal is our top priority. Whether we&#x2019;re consultants planning a project or" ID="ID_138395701" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Machine Learning - Quora" FOLDED="true" ID="ID_693483046" CREATED="1557224068558" MODIFIED="1557224277320" LINK="https://www.quora.com/topic/Machine-Learning">
<node TEXT="Most business datasets are either too dirty or too sparse to make machine learning useful.  Why do so many people I know seem so eager to learn about neural networks yet when I mention the prerequisites or a good book for learning it they look at me like I have the plague and escape as quickly as they can?" ID="ID_1469788232" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Machine Learning for March Madness Is a Competition In " FOLDED="true" ID="ID_645205214" CREATED="1557224068558" MODIFIED="1557224277320" LINK="https://www.wired.com/story/machine-learning-march-madness/">
<node TEXT="Machine Learning Madness was launched in 2014 by Jeff Sonas the owner of a database consulting firm who also designed a chess ranking method and Mark Glickman a statistician at Harvard." ID="ID_1560083864" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
</node>
<node TEXT="Career Success Stories MachineLearning#$D$#" FOLDED="true" ID="ID_1550649713" CREATED="1557224068558" MODIFIED="1557224288255">
<icon BUILTIN="stop-sign"/>
<node TEXT="Great Learning: Top-Ranked Professional Courses for Career " FOLDED="true" ID="ID_1230211339" CREATED="1557224068558" MODIFIED="1557224277321" LINK="https://www.greatlearning.in/">
<node TEXT="No.1 Ranked online and classroom courses on Artificial Intelligence Machine Learning Business analyst Deep Leaning Data Science Engineering Cloud Computing DevOps Engineering Get certified by Top Ranked Universities. Visit us to explore more." ID="ID_167043806" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Career Success Stories | Ocean County College NJ" FOLDED="true" ID="ID_255925477" CREATED="1557224068558" MODIFIED="1557224277321" LINK="https://www.ocean.edu/about-us/human-resources/career-success-stories/">
<node TEXT="The College offers genuine career paths to adjunct faculty who distinguish themselves as exceptional prospects for future academic instruction and administration positions. Listed below are just a few of the many career success stories that began with an adjunct faculty opportunity." ID="ID_1257261316" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="IT Success Stories - The Cisco Learning Network" FOLDED="true" ID="ID_320148452" CREATED="1557224068558" MODIFIED="1557224277321" LINK="https://learningnetwork.cisco.com/community/it_careers/it_success_stories">
<node TEXT="All Cisco certified professionals have a unique story to tell regarding how they decided to pursue a career in IT and how Cisco certifications helped achieve their goals. Read these real world IT success stories and IT career profiles now and envision the possibilities your future IT Career path can hold!" ID="ID_1101076020" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Applied AI Course - The Machine Learning  - Applied Course" FOLDED="true" ID="ID_1307051490" CREATED="1557224068558" MODIFIED="1557224277321" LINK="https://www.appliedaicourse.com/">
<node TEXT="What is Applied AI Course? No Pre-requisites  Data Analysis Machine Learning and Deep Learning. 70+ hours of live sessions covering topics based on student feedback and industry requirements to prepare students better for real-world problem-solving.  Success Stories Our students come from wide spectrum of backgrounds ranging from " ID="ID_1491444808" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="GW Career Success Stories | Center for Career Services " FOLDED="true" ID="ID_927409956" CREATED="1557224068558" MODIFIED="1557224277321" LINK="https://careerservices.gwu.edu/career-success-stories">
<node TEXT="GW students and alumni share their experiences learning what career success means including articles from GW Today featuring students and alumni in their How I Got the Job series and blog posts from the #GWCareerSuccess blog and from students participating in GW Career Quest and Knowledge in Action Career Internship Fund (KACIF) programs." ID="ID_1202797809" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Springboard: Online Courses to Future Proof Your Career" FOLDED="true" ID="ID_1596941992" CREATED="1557224068558" MODIFIED="1557224277321" LINK="https://in.springboard.com/">
<node TEXT="Designed for workplace success We design our curriculum with hiring managers and industry experts not academics so you learn the real-life skills you need for career success. Our curriculum focuses on hands-on projects and practical advice for job interviews and networking." ID="ID_865336357" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="9 Career Change Success Stories That Will Seriously " FOLDED="true" ID="ID_645412920" CREATED="1557224068558" MODIFIED="1557224277321" LINK="https://www.themuse.com/advice/9-career-change-success-stories-that-will-seriously-inspire-you">
<node TEXT="9. A Sweet Career: From Day Job to Desserts in Jars. Food blogger Shaina Olmanson shares how she turned a just OK job into a successful food blog and now a delectable dessert book. For anyone whos wanted to be a writer&#x2014;or change careers&#x2014;see what lessons shes learned along the way. Have you heard a great career change success story?" ID="ID_275258739" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Machine Learning Framework for Predicting Vaccine " FOLDED="true" ID="ID_1729795040" CREATED="1557224068558" MODIFIED="1557224277321" LINK="https://www.informs.org/Impact/O.R.-Analytics-Success-Stories/Machine-Learning-Framework-for-Predicting-Vaccine-Immunogenicity">
<node TEXT="It also identifies individuals unlikely to benefit from the vaccine. A team of researchers from the CDC Georgia Tech and Emory University created a general-purpose machine learning framework called DAMIP for discovering gene signatures that can predict vaccine immunity and efficacy." ID="ID_1500122055" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Career Success Stories | Pacific University" FOLDED="true" ID="ID_289822712" CREATED="1557224068558" MODIFIED="1557224277321" LINK="https://www.pacificu.edu/academics/academic-support/career-development-center/career-success-stories">
<node TEXT="Career success stories are why we&#x2019;re in this business. They inspire us and validate our mission and sense of purpose filling us up inside. They&#x2019;re also full of useful lessons for other students and alumni in the midst of their own career journeys." ID="ID_97875571" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Student Success Stories | Springboard" FOLDED="true" ID="ID_249627038" CREATED="1557224068558" MODIFIED="1557224277321" LINK="https://www.springboard.com/students/">
<node TEXT="Springboards students say that enrolling was the best career decision they made. Read their stories.  Job guarantee. AI/Machine Learning Career Track Job guarantee. Introduction to Data Science Intermediate Data Science: Python Marketing. Digital Marketing Career Track  Success stories." ID="ID_1576996816" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="10 machine learning success stories: An inside look - cio.com" FOLDED="true" ID="ID_1844255759" CREATED="1557224068558" MODIFIED="1557224277321" LINK="https://www.cio.com/article/3225445/machine-learning-success-stories.html">
<node TEXT="10 machine learning success stories: An inside look IT leaders share how they are using artificial intelligence and machine learning to generate business insights and new services." ID="ID_28458992" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Tesco Bengaluru &#x2013; Career Success Stories" FOLDED="true" ID="ID_517336265" CREATED="1557224068558" MODIFIED="1557224277321" LINK="http://www.tescobengaluru.com/careers/our-colleague-stories/career-success-stories">
<node TEXT="Career Success Stories Career Success Story - Abirudh Anilkumar. Career Success Story - Abirudh Anilkumar. Lead Read full profile My Key Motivators One of the biggest motivators is the fact that I work for the retail sector which is constantly evolving and is experiencing a massive boom.  Machine learning Deep Learning Data Mining/ Data " ID="ID_721020797" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
</node>
<node TEXT="Best Linkedin Resumes MachineLearning#$D$#" FOLDED="true" ID="ID_1815405470" CREATED="1557224068558" MODIFIED="1557224288256">
<icon BUILTIN="stop-sign"/>
<node TEXT="5000+ Machine Learning Engineer jobs in United States" FOLDED="true" ID="ID_1024724929" CREATED="1557224068558" MODIFIED="1557224277323" LINK="https://www.linkedin.com/jobs/machine-learning-engineer-jobs">
<node TEXT="Todays top 5000+ Machine Learning Engineer jobs in United States. Leverage your professional network and get hired. New Machine Learning Engineer jobs added daily." ID="ID_200476002" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="How to Build a Killer LinkedIn Profile | Udacity" FOLDED="true" ID="ID_1495021921" CREATED="1557224068558" MODIFIED="1557224277323" LINK="https://blog.udacity.com/2015/02/3-goals-for-your-linkedin-profile-to-achieve.html">
<node TEXT="LinkedIn is the world&#x2019;s largest online professional network with over 300 million users worldwide. Most importantly &#x2013; it&#x2019;s is more than a traditional resume! LinkedIn allows you to market your accomplishments online while strengthening your professional network. Recruiters use LinkedIn increasingly to connect with candidates." ID="ID_1422101927" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="3 Stunningly Good LinkedIn Profile SUMMARIES " FOLDED="true" ID="ID_204941872" CREATED="1557224068558" MODIFIED="1557224277323" LINK="https://www.linkedinsights.com/3-stunningly-good-linkedin-profile-summaries/">
<node TEXT="Resume Skills Examples &#x2013; Get Cover Letter - [&#x2026;] 3 Stunningly Good LinkedIn Profile SUMMARIES [&#x2026;] Tips For A Good Resume &#x2013; Tips and Trick - [&#x2026;] 3 Stunningly Good LinkedIn Profile SUMMARIES [&#x2026;] Best 3 LinkedIn Profile Creating Tactics - EspritAssociatesOnline - [&#x2026;] 3 Stunningly Good LinkedIn Profile Summaries [&#x2026;]" ID="ID_1647082098" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="What things should be there in machine learning resume " FOLDED="true" ID="ID_1113183721" CREATED="1557224068558" MODIFIED="1557224277323" LINK="https://www.quora.com/What-things-should-be-there-in-machine-learning-resume">
<node TEXT="What things should be there in machine learning resume? Update Cancel. a d b y P a r a b o l a. i o. What is the best data validation tool for spreadsheet data like DataCleaner Talend Google Refine? I&#x2019;d recommend using Parabola with your data. It is a canvas based drag and drop tool that provides a codeless way to interact with your data " ID="ID_668948009" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Best LinkedIn Profiles Examples | LinkedIn" FOLDED="true" ID="ID_1892275702" CREATED="1557224068558" MODIFIED="1557224277324" LINK="https://www.linkedin.com/showcase/best-linkedin-profiles-examples">
<node TEXT="Keep up with Best LinkedIn Profiles Examples. See more information about Best LinkedIn Profiles Examples find and apply to jobs that match your skills and connect with people to advance your career." ID="ID_1283505318" CREATED="1557224068558" MODIFIED="1557224068558"/>
</node>
<node TEXT="Machine Learning Engineer Resume Example - livecareer.com" FOLDED="true" ID="ID_975348664" CREATED="1557224068559" MODIFIED="1557224277324" LINK="https://www.livecareer.com/resume-search/r/machine-learning-engineer-d282aa9ca3c94cbaa70594772952db9b">
<node TEXT="This is an actual resume example of a Machine Learning Engineer who works in the Securities and Financial Services Industry. LiveCareer has 20462 Securities and Financial Services resumes in its database. LiveCareer&#x2019;s Resume Directory contains real resumes created by subscribers using LiveCareer&#x2019;s Resume Builder." ID="ID_1804019211" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Tips for Writing a Great LinkedIn Summary With Examples" FOLDED="true" ID="ID_1953213651" CREATED="1557224068559" MODIFIED="1557224277324" LINK="https://www.thebalancecareers.com/good-linkedin-summary-with-examples-4126809">
<node TEXT="Learn how to write a good LinkedIn summary what to include in your profile summary what hiring managers look for and examples of great LinkedIn summaries.  Many summaries on LinkedIn read like the summary on a resume. But the summary section on your resume is actually a very different creature.  Our Best Money Tips Delivered . Email " ID="ID_147586023" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Data Scientist Resume Projects &#x2013; Stats and Bots" FOLDED="true" ID="ID_1897095231" CREATED="1557224068559" MODIFIED="1557224277324" LINK="https://blog.statsbot.co/data-scientist-resume-projects-806a74388ae6">
<node TEXT="Data Scientist Resume Projects Machine learning problems set to build a data scientist CV without work experience. Denis Semenenko Blocked Unblock Follow Following.  A machine learning engine defines spam based on the probability of meeting such words as &#x201c;sale&#x201d; and &#x201c;buy&#x201d; in spam messages. As a result you can get a working prototype " ID="ID_626605411" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="190325 Ananda Resume - University of Michigan" FOLDED="true" ID="ID_146711953" CREATED="1557224068559" MODIFIED="1557224277324" LINK="http://www-personal.umich.edu/~anandan/Ananda_Resume.pdf">
<node TEXT="o Formulated the given Machine Learning problem as 5 di&#xfb00;erent optimization problems LSTM RNNs were best Machine Learning Scientist Amazon.com Seattle (Summer 14) &#x2022; Improving Fraud Detection using Digital Links at Amazon Seattle o Scaled up Machine Learning pipelines: 4600 processors 35000 GB memory achieving 5-minute execution" ID="ID_355727344" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="The Best LinkedIn Profile Tips for Job Seekers - The Muse" FOLDED="true" ID="ID_679730696" CREATED="1557224068559" MODIFIED="1557224277325" LINK="https://www.themuse.com/advice/the-31-best-linkedin-profile-tips-for-job-seekers">
<node TEXT="Your resume isn&#x2019;t just a list of job duties (or at least it shouldn&#x2019;t be)&#x2014;it&#x2019;s a place to highlight your best accomplishments. Same goes for your LinkedIn profile: Make sure your experience section is fleshed out with bullet points that describe what you did how well you did it and who it impacted." ID="ID_1977126023" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Ranking Resumes using Machine Learning | Vinayak Joglekar" FOLDED="true" ID="ID_547490507" CREATED="1557224068559" MODIFIED="1557224277325" LINK="https://vinayakjoglekar.wordpress.com/2014/06/24/ranking-resumes-using-machine-learning/">
<node TEXT="In a recent article we saw how ranking resumes can help us keep the WIP within limit to improve efficiency. We also saw an interesting way of achieving this is by playing a mobile game. In this article we will see how machine learning can be applied to rank resumes. Disclaimer This article covers a &#x201c;Quick&#x2026;" ID="ID_1814635674" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="6 Important LinkedIn Profile and Resume-Writing Tips " FOLDED="true" ID="ID_1644151489" CREATED="1557224068559" MODIFIED="1557224277325" LINK="https://www.topresume.com/career-advice/these-6-things-are-killing-your-resume-and-linkedin-profiles">
<node TEXT="The best method by far is eliminating mistakes from your resume and LinkedIn profile. There are few mistakes that are sure to lose a job faster than spelling grammar and punctuation errors. One typo and all your claims of being detailed-oriented fly straight out the window." ID="ID_449349557" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
</node>
</node>
</node>
<node TEXT="Company Success Stories" ID="ID_1512748129" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Yourstory" ID="ID_1317378" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
</node>
<node TEXT="Finance" POSITION="right" ID="ID_829522454" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge COLOR="#ff0000"/>
<node TEXT="Salary Reports" ID="ID_582608085" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Company Specific Salaries " ID="ID_1844078658" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Top Salaries MachineLearning#$D$#" FOLDED="true" ID="ID_1039984377" CREATED="1557224068559" MODIFIED="1557224809332">
<icon BUILTIN="stop-sign"/>
<node TEXT="Average Machine Learning Engineer Salaries in the United " FOLDED="true" ID="ID_1864345599" CREATED="1557224068559" MODIFIED="1557224277328" LINK="https://www.indeed.com/salaries/Machine-Learning-Engineer-Salaries">
<node TEXT="The average salary for a Machine Learning Engineer is $142911 per year in the United States. Salary estimates are based on 3113 salaries submitted anonymously to Indeed by Machine Learning Engineer employees users and collected from past and present job advertisements on Indeed in the past 36 months." ID="ID_204850307" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Machine Learning Salary | PayScale" FOLDED="true" ID="ID_1879893656" CREATED="1557224068559" MODIFIED="1557224277328" LINK="https://www.payscale.com/research/US/Skill=Machine_Learning/Salary">
<node TEXT="Machine Learning - Salary - Get a free salary comparison based on job title skills experience and education. Accurate reliable salary and compensation comparisons for United States" ID="ID_1597547927" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Machine Learning Engineer Is The Best Job In The U.S " FOLDED="true" ID="ID_1479397214" CREATED="1557224068559" MODIFIED="1557224277328" LINK="https://www.forbes.com/sites/louiscolumbus/2019/03/17/machine-learning-engineer-is-the-best-job-in-the-u-s-according-to-indeed/">
<node TEXT="Machine Learning Engineer job openings grew 344% between 2015 to 2018 and have an average base salary of $146085. At $158303 Computer Vision Engineers earn among the highest salaries in tech " ID="ID_1442717140" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Machine Learning Engineer Salary | PayScale" FOLDED="true" ID="ID_363849833" CREATED="1557224068559" MODIFIED="1557224277328" LINK="https://www.payscale.com/research/US/Job=Machine_Learning_Engineer/Salary">
<node TEXT="The average salary for a Machine Learning Engineer is $110840. Visit PayScale to research machine learning engineer salaries by city experience skill employer and more." ID="ID_429841518" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="What salary should a PhD in machine learning with a good " FOLDED="true" ID="ID_372438613" CREATED="1557224068559" MODIFIED="1557224277328" LINK="https://www.quora.com/What-salary-should-a-PhD-in-machine-learning-with-a-good-publication-record-and-a-strong-programming-background-ask-for-in-the-Bay-Area">
<node TEXT="What salary should a PhD in machine learning with a good publication record and a strong programming background ask for in the Bay Area?  What is the salary of fresh PhD (machine learning) at Google Facebook Apple in 2016?  What are the highest paying companies for Machine Learning / Data scientist positions in the Bay Area?" ID="ID_71130590" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="AI Machine Learning and Salesforce Positions Among Top 11 " FOLDED="true" ID="ID_542958637" CREATED="1557224068559" MODIFIED="1557224277328" LINK="https://www.globenewswire.com/news-release/2019/01/23/1704264/0/en/AI-Machine-Learning-and-Salesforce-Positions-Among-Top-11-Tech-Jobs-in-2019-with-Salaries-Exceeding-200K.html">
<node TEXT="AI Machine Learning and Salesforce Positions Among Top 11 Tech Jobs in 2019 with Salaries Exceeding $200K New Tech Salary Guide Released by National Tech Staffing Agency Mondo" ID="ID_347638556" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="How much does a Deep Learning Researcher get paid in " FOLDED="true" ID="ID_1164947303" CREATED="1557224068559" MODIFIED="1557224277328" LINK="https://www.reddit.com/r/MachineLearning/comments/458a02/how_much_does_a_deep_learning_researcher_get_paid/">
<node TEXT="Another example: A 50+ years old guy worked for master cards in the risk department used a lot of machine learning techniques since several years and is now building credit scorecards etc gets currently in a mid-size company (120 people) 100k+ Euro (which is quite a big salary in Germany top 1%)." ID="ID_122781440" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="What are the AI and ML starting salaries in India? - Quora" FOLDED="true" ID="ID_287928820" CREATED="1557224068559" MODIFIED="1557224277329" LINK="https://www.quora.com/What-are-the-AI-and-ML-starting-salaries-in-India">
<node TEXT="Check out my recent writeup on the demand for AI and ML skills globally (ref: &#x201c;Huge Salaries for scarce A.I. Talent : And why it matters&#x201d;). Multinational tech companies with RD centers in India including Google Microsoft and others are paying large salaries and joining bonuses - Numbers floating around range from 1.5 - 2 million rupees / annum." ID="ID_318967304" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="The 11 highest paid technology jobs for 2019 | Information " FOLDED="true" ID="ID_1441820994" CREATED="1557224068559" MODIFIED="1557224277329" LINK="https://www.information-management.com/list/the-11-highest-paid-technology-jobs-for-2019">
<node TEXT="According to the firm 11 tech jobs are garnering salaries of $200000 or more for 2019. Artificial intelligence and machine learning skills are in high demand with AI developer and machine learning engineer salaries now reaching $200000. As found in past years the top salary continues to be for CTO/CIOs (earning a range of $175000 " ID="ID_1033137696" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="The 6 Highest Paid Engineering Jobs" FOLDED="true" ID="ID_894896288" CREATED="1557224068559" MODIFIED="1557224277329" LINK="https://typesofengineeringdegrees.org/highest-paid-engineering-jobs/">
<node TEXT="There are over 40 different types of engineering careers in 5 different sub disciplines. Learn more about the top engineering career paths compare the highest paid engineering jobs view salary ranges for each engineering career and figure out which is best for you." ID="ID_1427472054" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
</node>
<node TEXT="Company Specific Salaries  MachineLearning#$D$#" FOLDED="true" ID="ID_79495439" CREATED="1557224068559" MODIFIED="1557224845476">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning Jobs Employment | Indeed.com" ID="ID_2566467" CREATED="1557224068559" MODIFIED="1557224522983" LINK="https://www.indeed.com/q-machine-learning-jobs.html">
<node TEXT="27905 Machine Learning jobs available on Indeed.com. Apply to Machine Learning Engineer Data Scientist Data Engineer and more! Skip to Job Postings Search Close. Find Jobs Company Reviews Find Salaries Find  Machine Learning Engineer salaries by company in United States " ID="ID_1168918046" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Machine Learning Salary | PayScale" ID="ID_1632841464" CREATED="1557224068559" MODIFIED="1557224520121" LINK="https://www.payscale.com/research/AE/Skill=Machine_Learning/Salary">
<node TEXT="Machine Learning - Salary - Get a free salary comparison based on job title skills experience and education. Accurate reliable salary and compensation comparisons for United Arab Emirates" ID="ID_558719284" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Machine Learning Salary | PayScale" ID="ID_249532056" CREATED="1557224068559" MODIFIED="1557224526730" LINK="https://www.payscale.com/research/IN/Skill=Machine_Learning/Salary">
<node TEXT="Machine Learning - Salary - Get a free salary comparison based on job title skills experience and education. Accurate reliable salary and compensation comparisons for India" ID="ID_266607795" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Associate - Machine Learning | Careers | McKinsey  Company" ID="ID_429147128" CREATED="1557224068559" MODIFIED="1557224528827" LINK="https://www.mckinsey.com/careers/search-jobs/jobs/associate-machine-learning-3349">
<node TEXT="5+ years of professional experience in machine learning mathematical modeling statistical modeling optimization or data mining involving large data sets; Ideally have professional experience in a financial services related industry (e.g. banking and securities asset management insurance)" ID="ID_1609644368" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="What is the salary of fresh PhD (machine learning) at " ID="ID_1688437628" CREATED="1557224068559" MODIFIED="1557224530052" LINK="https://www.quora.com/What-is-the-salary-of-fresh-PhD-machine-learning-at-Google-Facebook-Apple-in-2016">
<node TEXT="What is the salary of fresh PhD (machine learning) at Google Facebook Apple in 2016? Update Cancel.  I don&#x2019;t know the specific answer to your question. However as a person with nearly three decades of working in the Silicon Valley I can tell you that on the average Apple Facebook and Google&#x2019;s compensation is usually lower than the " ID="ID_550508812" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="44000+ Machine Learning jobs in United States" ID="ID_458300535" CREATED="1557224068559" MODIFIED="1557224530819" LINK="https://www.linkedin.com/jobs/machine-learning-jobs">
<node TEXT="Todays top 44000+ Machine Learning jobs in United States. Leverage your professional network and get hired. New Machine Learning jobs added daily." ID="ID_1807406079" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Machine Learning For Robotics Jobs Employment | Indeed.com" ID="ID_35794932" CREATED="1557224068559" MODIFIED="1557224531523" LINK="https://www.indeed.com/q-Machine-Learning-For-Robotics-jobs.html">
<node TEXT="2117 Machine Learning For Robotics jobs available on Indeed.com. Apply to Robotics Engineer Computer Vision Engineer Machine Learning Engineer and more! Skip to Job Postings Search Close. Find Jobs Company Reviews  Machine Learning Engineer salaries by company in United States " ID="ID_1479035085" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Salary.com - Salary Calculator Salary Comparison " ID="ID_1194569316" CREATED="1557224068559" MODIFIED="1557224532491" LINK="https://www.salary.com/">
<node TEXT="Salary.com has partnered with compensation industry experts to create a catalog of free courses addressing key elements of the compensation agenda. Gain the skills you need to succeed in your organization. Compensation: Preparing Merit and Salary Increase Budgets. Michael C. Sturman Cornell University." ID="ID_1845549411" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Machine Learning Jobs 6771 Machine Learning Openings " ID="ID_1267821786" CREATED="1557224068559" MODIFIED="1557224533145" LINK="https://www.naukri.com/machine-learning-jobs">
<node TEXT="Apply to 6771 Machine Learning Jobs on Naukri.com Indias No.1 Job Portal. Explore Machine Learning Openings in your desired locations Now!" ID="ID_1112056851" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="bing" ID="ID_435723101" CREATED="1557224068559" MODIFIED="1557224838544">
<node TEXT="Top Salaries MachineLearning#$D$#" ID="ID_1305767872" CREATED="1557224068559" MODIFIED="1557224068559">
<node TEXT="Salary: Machine Learning Engineer | Glassdoor" ID="ID_1992121504" CREATED="1557224068559" MODIFIED="1557224068559" LINK="https://www.glassdoor.com/Salaries/machine-learning-engineer-salary-SRCH_KO0">
<node TEXT="25.htm" ID="ID_699018965" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Salary: Machine Learning | Glassdoor" ID="ID_532955649" CREATED="1557224068559" MODIFIED="1557224068559" LINK="https://www.glassdoor.com/Salaries/machine-learning-salary-SRCH_KO0">
<node TEXT="16.htm" ID="ID_1206246703" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
</node>
<node TEXT="Company Specific Salaries  MachineLearning#$D$#" ID="ID_788524482" CREATED="1557224068559" MODIFIED="1557224068559">
<node TEXT="Salary: Machine Learning | Glassdoor" ID="ID_1490264309" CREATED="1557224068559" MODIFIED="1557224068559" LINK="https://www.glassdoor.com/Salaries/machine-learning-salary-SRCH_KO0">
<node TEXT="16.htm" ID="ID_1480116967" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Median Salary (Country-wise)" ID="ID_1958188626" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Salary Report MachineLearning#$D$#" FOLDED="true" ID="ID_1081128130" CREATED="1557224068559" MODIFIED="1557224288256">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine Learning Engineer Salary | PayScale" FOLDED="true" ID="ID_347283987" CREATED="1557224068559" MODIFIED="1557224277326" LINK="https://www.payscale.com/research/US/Job=Machine_Learning_Engineer/Salary">
<node TEXT="The average salary for a Machine Learning Engineer is $110840. Visit PayScale to research machine learning engineer salaries by city experience skill employer and more." ID="ID_1979940122" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Machine Learning Salary | PayScale" FOLDED="true" ID="ID_1688109728" CREATED="1557224068559" MODIFIED="1557224277326" LINK="https://www.payscale.com/research/US/Skill=Machine_Learning/Salary">
<node TEXT="Machine Learning - Salary - Get a free salary comparison based on job title skills experience and education. Accurate reliable salary and compensation comparisons for United States" ID="ID_1067567264" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Machine Learning Jobs Employment | Indeed.com" FOLDED="true" ID="ID_1078907661" CREATED="1557224068559" MODIFIED="1557224277326" LINK="https://www.indeed.com/q-machine-learning-jobs.html">
<node TEXT="27905 Machine Learning jobs available on Indeed.com. Apply to Machine Learning Engineer Data Scientist Data Engineer and more! Skip to Job Postings Search Close. Find Jobs Company Reviews Find Salaries Find  Machine Learning Engineer salaries in United States. $142924 per year." ID="ID_269679379" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="A Machine Learning Tutorial with Examples | Toptal" FOLDED="true" ID="ID_1053570399" CREATED="1557224068559" MODIFIED="1557224277326" LINK="https://www.toptal.com/machine-learning/machine-learning-theory-an-introductory-primer">
<node TEXT="Nicholas is a professional software engineer with a passion for quality craftsmanship. He loves architecting and writing top-notch code. Machine Learning (ML) is coming into its own with a growing recognition that ML can play a key role in a wide range of critical applications such as data mining " ID="ID_1851259443" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="I want to be a machine learning engineer &#x2026; what will my " FOLDED="true" ID="ID_472024533" CREATED="1557224068559" MODIFIED="1557224277327" LINK="https://www.theglobeandmail.com/report-on-business/careers/career-advice/i-want-to-be-a-machine-learning-engineer-what-will-my-salary-be/article37369628/">
<node TEXT="According to Indeed.com the average annual salary of machine learning engineers across Canada is $102822 with those based in Toronto and Vancouver earning an average of approximately $110000 a " ID="ID_1088337423" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Machine Learning Engineer Jobs Resume  Salary | Machine " FOLDED="true" ID="ID_1801655835" CREATED="1557224068559" MODIFIED="1557224277327" LINK="https://www.youtube.com/watch?v=uMxQI2tJtKQ">
<node TEXT="This video will provide you with detailed knowledge of who is a Machine Learning Engineer what are the salary trends the job trends and the correct format of an ML engineers resume." ID="ID_1234811062" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Automated Machine Learning and the Future of Data Science " FOLDED="true" ID="ID_531352042" CREATED="1557224068559" MODIFIED="1557224277327" LINK="https://tdwi.org/Articles/2019/04/12/ADV-ALL-Automated-Machine-Learning-and-Future-of-Data-Science-Teams.aspx">
<node TEXT="Automated machine learning (autoML) is being adopted more broadly across all industries as companies try to get the most out of their data science programs. As this trend continues many data scientists are questioning their value to the organization and what they can offer that autoML cannot. To " ID="ID_981774903" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="CompAnalyst Market Data - salary.com" FOLDED="true" ID="ID_1295980820" CREATED="1557224068559" MODIFIED="1557224277327" LINK="https://www.salary.com/business/compensation-data/market-data/">
<node TEXT="CompAnalyst Market Data delivers accurate up-to-date market pricing information from 16 countries in real time to teams across your business. Say goodbye to cumbersome spreadsheets stale data and tedious work. CompAnalyst Market Data makes pricing jobs in multiple markets fast and simple. Access " ID="ID_1776022754" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Become a Machine Learning Engineer | Udacity" FOLDED="true" ID="ID_166079761" CREATED="1557224068559" MODIFIED="1557224277327" LINK="https://www.udacity.com/course/machine-learning-engineer-nanodegree--nd009t">
<node TEXT="The Machine Learning Engineer Nanodegree program is built by engineers for programmers and learners to help prepare you for a job as a machine learning engineer. Udacity supports your career journey throughout the preparation and search process. Our goal is to move you forward in your career." ID="ID_1823336735" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="These are the Best Jobs of 2019 according to Indeed.com" FOLDED="true" ID="ID_85199392" CREATED="1557224068559" MODIFIED="1557224277327" LINK="https://www.nbcnews.com/better/lifestyle/these-are-best-jobs-2019-according-indeed-com-ncna984301">
<node TEXT="Tech jobs take first place on numerous lists with machine learning engineer as the top job on Indeeds Best Jobs of 2019 list while software engineer took the number one spot on U.S News  World " ID="ID_793065754" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="Technology  IT Salaries | 2019 Salary Guide | Robert Half" FOLDED="true" ID="ID_229450075" CREATED="1557224068559" MODIFIED="1557224277328" LINK="https://www.roberthalf.com/salary-guide/technology">
<node TEXT="Get the 2019 Robert Half Technology Salary Guide to see starting salary ranges for nearly 80 jobs in the tech industry learn about the hottest benefits and perks and discover what trends will impact your hiring or job search efforts in 2019. What the job&#x2019;s worth Our guide gives you detailed pay " ID="ID_1776634748" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
<node TEXT="2018 Data Scientist Salary Report Highlights - Burtch Works" FOLDED="true" ID="ID_1034760610" CREATED="1557224068559" MODIFIED="1557224277328" LINK="https://www.burtchworks.com/2018/07/09/2018-data-scientist-salary-report-highlights/">
<node TEXT="The new set of data for The Burtch Works Study: Salaries of Data Scientists May 2018 was collected by our recruiters during the 12 months ending March 2018. This report contains data scientist salary information including how salaries have changed since the last study was published in April 2017." ID="ID_1288365027" CREATED="1557224068559" MODIFIED="1557224068559"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Social Impact" POSITION="left" ID="ID_1637286188" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge COLOR="#ff0000"/>
<node TEXT="Education" ID="ID_1657703345" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Social Impact Education MachineLearning#$D$#" FOLDED="true" ID="ID_1709024641" CREATED="1557224068554" MODIFIED="1557224288253">
<icon BUILTIN="stop-sign"/>
<node TEXT="Can Machine Learning Double Your Social Impact? - ssir.org" FOLDED="true" ID="ID_1271009887" CREATED="1557224068554" MODIFIED="1557224277099" LINK="https://ssir.org/articles/entry/can_machine_learning_double_your_social_impact">
<node TEXT="The next big thing in the social sector has officially arrived. Machine learning is now at the center of international conferences $25 million dollar funding competitions fellowships at prestigious universities and Davos-launched initiatives. Yet amidst all of the hype it can be difficult to " ID="ID_1916150983" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="New machine learning model measures social impact of large " FOLDED="true" ID="ID_475970135" CREATED="1557224068554" MODIFIED="1557224277099" LINK="https://www.techrepublic.com/article/new-machine-learning-model-measures-social-impact-of-large-corporate-investments/">
<node TEXT="The professional services network created a new Social Impact Measurement Model (SIMM) which uses machine learning technology to predict possible outcomes of major corporate investments in a " ID="ID_1617769076" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Deloitte machine learning model quantifies social impact " FOLDED="true" ID="ID_1837329584" CREATED="1557224068554" MODIFIED="1557224277100" LINK="https://azbigmedia.com/deloitte-machine-learning-model-quantifies-social-impact-of-a-business/">
<node TEXT="As companies are becoming increasingly focused on the social impact of their business operations Deloitte has developed a new Social Impact Measurement Model (SIMM) pioneering a machine learning " ID="ID_80075900" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="Data Science for Social Good Summer Fellowship Chicago" FOLDED="true" ID="ID_1820424161" CREATED="1557224068555" MODIFIED="1557224277100" LINK="https://dssg.uchicago.edu/">
<node TEXT="The Data Science for Social Good Fellowship is a University of Chicago summer program to train aspiring data scientists to work on data mining machine learning big data and data science projects with social impact. Working closely with governments and nonprofits fellows take on real-world problems in education health energy public safety transportation economic development " ID="ID_164638476" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="AI For Social Impact - Forbes" FOLDED="true" ID="ID_29970198" CREATED="1557224068555" MODIFIED="1557224277100" LINK="https://www.forbes.com/sites/fridapolli/2018/01/30/ai-for-social-impact/">
<node TEXT="When talking about algorithms a positive social impact isn&#x2019;t usually the first topic of conversation. However technology can be an incredible way to improve various social causes at scale " ID="ID_694027738" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="The Impact of Machine Learning on Economics" FOLDED="true" ID="ID_1799660712" CREATED="1557224068555" MODIFIED="1557224277101" LINK="http://www.nber.org/chapters/c14009.pdf">
<node TEXT="The Impact of Machine Learning on Economics Susan Athey athey@stanford.edu Current version January 2018 Abstract This paper provides an assessment of the early contributions of machine learning to economics as" ID="ID_1821408861" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Social Impact - Advancing Development Effectiveness" FOLDED="true" ID="ID_1294262634" CREATED="1557224068555" MODIFIED="1557224277101" LINK="https://socialimpact.com/">
<node TEXT="A global development management consulting firm. We provide monitoring evaluation and capacity building services to advance development effectiveness." ID="ID_988961008" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="What Will The Impact Of Machine Learning Be On Economics?" FOLDED="true" ID="ID_1328586788" CREATED="1557224068555" MODIFIED="1557224277101" LINK="https://www.forbes.com/sites/quora/2016/01/27/what-will-the-impact-of-machine-learning-be-on-economics/">
<node TEXT="What will be the impact of machine learning on economics? originally appeared on Quora - the knowledge sharing network where compelling questions are answered by people with unique insights." ID="ID_1097690241" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="New Deloitte Machine Learning Model Helps Predict and " FOLDED="true" ID="ID_753820456" CREATED="1557224068555" MODIFIED="1557224277101" LINK="https://www.prnewswire.com/news-releases/new-deloitte-machine-learning-model-helps-predict-and-quantify-the-social-impact-of-corporate-investment-300795368.html">
<node TEXT="NEW YORK Feb. 14 2019 /PRNewswire/ -- As companies are becoming increasingly focused on the social impact of their business operations Deloitte has developed a new Social Impact Measurement " ID="ID_965641415" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="How Social Media is Reshaping Todays Education System " FOLDED="true" ID="ID_1343825664" CREATED="1557224068555" MODIFIED="1557224277102" LINK="http://csic.georgetown.edu/magazine/social-media-reshaping-todays-education-system/">
<node TEXT="by Lori Wade There&#x2019;s no denying that ever since social networks and social media made way into our lives everything is different. Beginning with the way we socialize interact plan for parties or even how often we go out. We won&#x2019;t go into a debate regarding the ethical aspects of the way Social Media is influencing our lives. Instead this article proposes to focus on the numerous ways " ID="ID_1658543997" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
</node>
<node TEXT="Machine Learning for Social Good - Machine Learning for " FOLDED="true" ID="ID_831258194" CREATED="1557224068555" MODIFIED="1557224277102" LINK="https://www.cmu.edu/scs/ml4sg/">
<node TEXT="Machine Learning for Social Good (ML4SG) is an undertaking of Carnegie Mellon University&#x2019;s School of Computer Science to enhance SCS&#x2019;s research and education in applying machine learning to problems of societal impact." ID="ID_634323595" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="8 Ways Machine Learning Will Improve Education" FOLDED="true" ID="ID_63680449" CREATED="1557224068554" MODIFIED="1557224277099" LINK="https://www.gettingsmart.com/2015/11/8-ways-machine-learning-will-improve-education/">
<node TEXT="It was the constant stories about self-driving cars that made machine learning the breakthrough tech topic of 2015. Five years ago news stories talked about robots that could do repetitive tasks but they said real complex tasks requiring seasoned judgement&#x2014;like driving a car&#x2014;were years away." ID="ID_1327553468" CREATED="1557224068554" MODIFIED="1557224068554"/>
</node>
<node TEXT="How Does Quora Use Machine Learning In 2017? - Forbes" FOLDED="true" ID="ID_474648428" CREATED="1557224068550" MODIFIED="1557224306278" LINK="https://www.forbes.com/sites/quora/2017/04/19/how-does-quora-use-machine-learning-in-2017/">
<node TEXT="How does Quora use machine learning in 2017? originally appeared on Quora: the place to gain and share knowledge empowering people to learn from others and better understand the world. Answer by " ID="ID_1197870825" CREATED="1557224068550" MODIFIED="1557224068550"/>
</node>
</node>
<node TEXT="Environment" ID="ID_746766822" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Social Impact Environment MachineLearning#$D$#" FOLDED="true" ID="ID_1076960115" CREATED="1557224068555" MODIFIED="1557224288253">
<icon BUILTIN="stop-sign"/>
<node TEXT="Behavioral Science + Machine Learning = More Social Impact" FOLDED="true" ID="ID_204931874" CREATED="1557224068555" MODIFIED="1557224277129" LINK="http://www.ideas42.org/blog/behavioral-science-machine-learning-social-impact/">
<node TEXT="At ideas42 we&#x2019;ve been working at the intersection of these disciplines for many years to design effective and beneficial programs and we can now fully leverage the power of data science and machine learning to magnify our social impact at scale. We believe machine learning is poised to revolutionize the application of behavioral science." ID="ID_1717725978" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Can Machine Learning Double Your Social Impact? - ssir.org" FOLDED="true" ID="ID_547287932" CREATED="1557224068555" MODIFIED="1557224277129" LINK="https://ssir.org/articles/entry/can_machine_learning_double_your_social_impact">
<node TEXT="Making accurate predictions is only half the battle. To truly drive social impact with machine learning social sector leaders must be willing and able to change how their organization operates based on predictions. Governments and nonprofits are often accustomed to one-size-fits-all programs." ID="ID_1019083907" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="The impact of machine learning on the customer experience " FOLDED="true" ID="ID_1455000726" CREATED="1557224068555" MODIFIED="1557224277130" LINK="https://venturebeat.com/2017/01/14/the-impact-of-machine-learning-on-the-customer-experience/">
<node TEXT="The impact of machine learning on the customer experience  Beyond the big headline-grabbing examples of how machine learning will impact our lives &#x2014; such as through driverless cars &#x2014; it has " ID="ID_34074323" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="The Impact of Machine Learning on Economics" FOLDED="true" ID="ID_604945247" CREATED="1557224068555" MODIFIED="1557224277130" LINK="http://www.nber.org/chapters/c14009.pdf">
<node TEXT="The Impact of Machine Learning on Economics Susan Athey athey@stanford.edu Current version January 2018 Abstract This paper provides an assessment of the early contributions of machine learning to economics as well as predictions about its future contributions. It begins by brie y overviewing some themes" ID="ID_1827358816" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Survey Results - Impact Of AI/Machine Learning On " FOLDED="true" ID="ID_63727116" CREATED="1557224068555" MODIFIED="1557224277130" LINK="https://elearningindustry.com/ai-machine-learning-on-workforce-capability-survey-results-impact">
<node TEXT="How can LD support the rapid and complex learning needs in this new automated environment? Our recent survey on our webinar on Impact of Artificial Intelligence/Machine Learning on Workforce Capability highlights the effects of new and emerging technologies like AI/ML and what this will require of HR/LD teams." ID="ID_1924718184" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="AI For Social Impact - Forbes" ID="ID_817433338" CREATED="1557224068555" MODIFIED="1557224277130" LINK="https://www.forbes.com/sites/fridapolli/2018/01/30/ai-for-social-impact/">
<node TEXT="AI For Social Impact. Frida Polli  By applying DeepMind&#x2019;s machine learning methods to their Google data centers they were able to decrease their energy usage drastically. The implications of " ID="ID_1270420020" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="What Will The Impact Of Machine Learning Be On Economics?" FOLDED="true" ID="ID_156226295" CREATED="1557224068555" MODIFIED="1557224277130" LINK="https://www.forbes.com/sites/quora/2016/01/27/what-will-the-impact-of-machine-learning-be-on-economics/">
<node TEXT="What will be the impact of machine learning on economics? originally appeared on Quora - the knowledge sharing network where compelling questions are answered by people with unique insights." ID="ID_1344268080" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="(PDF) Machine learning to analyze the social-ecological " FOLDED="true" ID="ID_1180075865" CREATED="1557224068555" MODIFIED="1557224277132" LINK="https://www.researchgate.net/publication/329856157_Machine_learning_to_analyze_the_social-ecological_impacts_of_natural_resource_policy_insights_from_community_forest_management_in_the_Indian_Himalaya">
<node TEXT="PDF | Machine learning promises to advance analysis of the social and ecological impacts of forest and other natural resource policies around the world. However realizing this promise requires " ID="ID_806294221" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Machine learning for the environment | NCEAS" FOLDED="true" ID="ID_623815716" CREATED="1557224068555" MODIFIED="1557224277132" LINK="https://www.nceas.ucsb.edu/projects/10921">
<node TEXT="Machine learning for the environment. Principal Investigators: John M. Drake and William T. Langford.  and conservation biology would be greatly enriched by expanding the ecologists analytical toolbox to include machine learning (ML) approaches to data analysis. We use the term ML loosely to distinguish between parametric statistics and a " ID="ID_637215648" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Cognitive for social good &#x2013; sustainability - IBM" FOLDED="true" ID="ID_572022951" CREATED="1557224068555" MODIFIED="1557224277133" LINK="https://www.ibm.com/watson/advantage-reports/ai-social-good-sustainability.html">
<node TEXT="Protecting the environment.  The companys next step is to develop a machine learning model that couples weather forecasts with the soil measurements to better predict salinity levels and water absorption rates. In addition to advancing sustainable land-use management Vegis expects foris.io to provide agricultural advice to farmers such as " ID="ID_985858268" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Artificial Intelligence and Machine Learning: Policy Paper" FOLDED="true" ID="ID_1840867647" CREATED="1557224068555" MODIFIED="1557224277133" LINK="https://www.internetsociety.org/resources/doc/2017/artificial-intelligence-and-machine-learning-policy-paper/">
<node TEXT="Artificial Intelligence and Machine Learning: Policy Paper.  ensuring accountability; and creating a social and economic environment that is formed through the open participation of different stakeholders. Introduction.  the social impact of AI cannot be fully mitigated by governing the technology but will require efforts to govern the " ID="ID_1115650743" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Deloitte machine learning model quantifies social impact " FOLDED="true" ID="ID_176477479" CREATED="1557224068555" MODIFIED="1557224277133" LINK="https://azbigmedia.com/deloitte-machine-learning-model-quantifies-social-impact-of-a-business/">
<node TEXT="As companies are becoming increasingly focused on the social impact of their business operations Deloitte has developed a new Social Impact Measurement Model (SIMM) pioneering a machine learning " ID="ID_1937858293" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
</node>
<node TEXT="Social Story Environment MachineLearning#$D$#" FOLDED="true" ID="ID_680957829" CREATED="1557224068556" MODIFIED="1557224288254">
<icon BUILTIN="stop-sign"/>
<node TEXT="AI Supporting The Earth - kdnuggets.com" FOLDED="true" ID="ID_1141868501" CREATED="1557224068556" MODIFIED="1557224277221" LINK="https://www.kdnuggets.com/2019/04/ai-environment.html">
<node TEXT="Supporting Social Good. Intel is committed to advancing uses of AI that positively impact our world by providing mission driven organizations with technologies and expertise to accelerate their work. Read more on how AI is helping us better understand the environment and check out Intel&#x2019;s AI4SocialGood page to see additional projects. We are " ID="ID_1086991891" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Machine learning - Wikipedia" FOLDED="true" ID="ID_533983021" CREATED="1557224068556" MODIFIED="1557224277221" LINK="https://en.wikipedia.org/wiki/Machine_learning">
<node TEXT="Machine learning (ML) is the scientific study of algorithms and statistical models that computer systems use to effectively perform a specific task without using explicit instructions relying on patterns and inference instead. It is seen as a subset of artificial intelligence.Machine learning algorithms build a mathematical model based on sample data known as training data in order to " ID="ID_1228667978" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Social Story Sampler - Carol Gray - Social Stories" FOLDED="true" ID="ID_225900109" CREATED="1557224068556" MODIFIED="1557224277221" LINK="https://carolgraysocialstories.com/social-stories/social-story-sampler/">
<node TEXT="The Stories introduce a concept that echoes throughout The Social Story Sampler: autism is a personal factor but it never defines who someone is. Story 6 contains more detail. Please note: Stories in The Sampler assume that readers with autism are aware of their diagnosis and understand it at a basic level. 7." ID="ID_407029666" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Africa: How Machine Learning Can Help Fight Illegal " FOLDED="true" ID="ID_280459014" CREATED="1557224068556" MODIFIED="1557224277221" LINK="https://allafrica.com/stories/201904240131.html">
<node TEXT="Machine learning can be used to save experts time when manually classifying content on social media. It can also be used by social media platforms to identify and promptly remove suspicious posts." ID="ID_886033289" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="USING SOCIAL STORIES TO TEACH SOCIAL SKILLS: A " FOLDED="true" ID="ID_1634997666" CREATED="1557224068556" MODIFIED="1557224277221" LINK="http://www.sbbh.pitt.edu/files/Powerpoint%20Presentations%202524%20Spring%202010/USING%20SOCIAL%20STORIES%20TO%20TEACH%20SOCIAL%20SKILLS.pdf">
<node TEXT="USING SOCIAL STORIES TO TEACH SOCIAL SKILLS: A PROFESSIONAL&#x2019;S GUIDE PAGE 7 OF 12 COPYRIGHT 2010 M. O&#x2019;HARA UNIVERSITY OF PITTSBURGH Discussion Questions: What is an example of a Social Story? An example of a Social Story for &#x201c;Looking and Talking&#x201d; (Scattone 2007 p.399)." ID="ID_1660429336" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Council Post: The Role Of AI And Machine Learning In " FOLDED="true" ID="ID_1000917989" CREATED="1557224068556" MODIFIED="1557224277221" LINK="https://www.forbes.com/sites/forbeshumanresourcescouncil/2019/04/12/the-role-of-ai-and-machine-learning-in-talent-acquisition/">
<node TEXT="We can use the efficiency of AI and machine learning to give our recruiters the bandwidth they need to turn candidates into hires.  In an environment where there is a scarcity of talent and " ID="ID_150379009" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="40 Best Social Stories images | Social stories Speech " FOLDED="true" ID="ID_627410859" CREATED="1557224068556" MODIFIED="1557224277221" LINK="https://www.pinterest.com/sensoryprocessi/social-stories/">
<node TEXT="This is a social story example for a person with autism or other disabilities. Social stories work very well with children with autism. Relates to disability and education. Stop it I dont like it poster  social story book. Social stories are incredibly helpful to teach a child with autism." ID="ID_606982957" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="The 10 Algorithms Machine Learning Engineers Need to Know" FOLDED="true" ID="ID_1236073155" CREATED="1557224068556" MODIFIED="1557224277222" LINK="https://www.kdnuggets.com/2016/08/10-algorithms-machine-learning-engineers.html">
<node TEXT="It is no doubt that the sub-field of machine learning / artificial intelligence has increasingly gained more popularity in the past couple of years. As Big Data is the hottest trend in the tech industry at the moment machine learning is incredibly powerful to make predictions or calculated " ID="ID_233903452" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Social Stories for the SCHOOL ENVIRONMENT with Student " FOLDED="true" ID="ID_1238003788" CREATED="1557224068556" MODIFIED="1557224277222" LINK="http://autismeducators.com/autism-social-stories-for-the-school-environment-with-student-booklets">
<node TEXT="Given a social story to explain the steps or expectations of an event or situation within the school environment STUDENT will read or have read to the appropriate social story and acknowledge each expectation or rule with an appropriate response in 4 out of 5 opportunities by MONTH YEAR." ID="ID_1230974785" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Know how this organisation is teaching young minds how to " FOLDED="true" ID="ID_1033377249" CREATED="1557224068556" MODIFIED="1557224277222" LINK="https://yourstory.com/socialstory/2019/04/organisation-teaching-students-environment-sustainability">
<node TEXT="Know how this organisation is teaching young minds how to save the environment and lead a sustainable lifestyle .  If you have such a story to share with the world " ID="ID_423399838" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="BlueData Launches SaaS Accelerator for AI Machine " FOLDED="true" ID="ID_771467177" CREATED="1557224068556" MODIFIED="1557224277222" LINK="https://www.eweek.com/development/bluedata-invites-ai-ml-developers-to-play-in-its-bdaas-sandbox">
<node TEXT="BlueData which offers a new-gen big-data-as-a-service (BDaaS) software platform has made available a new environment for AI and machine-learning developers to try out new ideas and have fun " ID="ID_1989115715" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="A Machine Learning Tutorial with Examples | Toptal" FOLDED="true" ID="ID_492449870" CREATED="1557224068556" MODIFIED="1557224277222" LINK="https://www.toptal.com/machine-learning/machine-learning-theory-an-introductory-primer">
<node TEXT="Nicholas is a professional software engineer with a passion for quality craftsmanship. He loves architecting and writing top-notch code. Machine Learning (ML) is coming into its own with a growing recognition that ML can play a key role in a wide range of critical applications such as data mining " ID="ID_1117756395" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
</node>
</node>
<node TEXT="HealthCare" ID="ID_357582230" CREATED="1563179125257" MODIFIED="1563179125257">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Social Impact HealthCare MachineLearning#$D$#" FOLDED="true" ID="ID_758952130" CREATED="1557224068555" MODIFIED="1557224288253">
<icon BUILTIN="stop-sign"/>
<node TEXT="The Potential Impact of Machine Learning in Healthcare " FOLDED="true" ID="ID_22354328" CREATED="1557224068555" MODIFIED="1557224277156" LINK="http://rx4group.com/the-potential-impact-of-machine-learning-in-healthcare/">
<node TEXT="The Potential Impact of Machine Learning in Healthcare Machine learning is a data analysis approach that automates analytical model building. Using algorithms that iterate based on the data returned to them machine learning uses software to locate hard to discover information without being explicitly programmed on where to look." ID="ID_1025703549" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Can Machine Learning Double Your Social Impact? - ssir.org" FOLDED="true" ID="ID_1961346902" CREATED="1557224068555" MODIFIED="1557224277157" LINK="https://ssir.org/articles/entry/can_machine_learning_double_your_social_impact">
<node TEXT="The next big thing in the social sector has officially arrived. Machine learning is now at the center of international conferences $25 million dollar funding competitions fellowships at prestigious universities and Davos-launched initiatives.Yet amidst all of the hype it can be difficult to understand which social sector problems machine learning is best positioned to solve how " ID="ID_502348723" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Machine Learning Healthcare Applications - emerj.com" FOLDED="true" ID="ID_563668153" CREATED="1557224068555" MODIFIED="1557224277157" LINK="https://emerj.com/ai-sector-overviews/machine-learning-healthcare-applications/">
<node TEXT="At least when it comes to machine learning it&#x2019;s likely that useful and widespread applications will develop first in narrow use-cases &#x2013; for example a machine learning healthcare application that detects the percentage growth or shrinkage of a tumor over time based on image data from dozens or hundreds of X-ray images from various angles." ID="ID_1308392934" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="The Amazing Ways How Artificial Intelligence And Machine " FOLDED="true" ID="ID_1407550836" CREATED="1557224068555" MODIFIED="1557224277157" LINK="https://www.forbes.com/sites/bernardmarr/2017/10/09/the-amazing-ways-how-artificial-intelligence-and-machine-learning-is-used-in-healthcare/">
<node TEXT="Artificial intelligence and machine learning in healthcare will continue to get better and impact disease prevention and diagnosis extract more meaning from data across various clinical trials " ID="ID_271508463" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Data Science for Social Good Summer Fellowship Chicago" FOLDED="true" ID="ID_301213509" CREATED="1557224068555" MODIFIED="1557224277157" LINK="https://dssg.uchicago.edu/">
<node TEXT="The Data Science for Social Good Fellowship is a University of Chicago summer program to train aspiring data scientists to work on data mining machine learning big data and data science projects with social impact. Working closely with governments and nonprofits fellows take on real-world problems in education health energy public safety transportation economic development " ID="ID_27280243" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="The Social Determinants of Health: Applying AI  Machine " FOLDED="true" ID="ID_1323337641" CREATED="1557224068555" MODIFIED="1557224277157" LINK="https://www.cognizant.com/whitepapers/the-social-determinants-of-health-applying-ai-and-machine-learning-to-achieve-whole-person-care-codex4379.pdf">
<node TEXT="The Social Determinants of Health: Applying AI  Machine Learning to Achieve Whole Person Care / 11 SDH identification  integration: The foundation for whole-person care As the industry adopts value-based care and outcome-based reimbursements healthcare organizations are revisiting the concept of whole-person care to reduce costs and improve" ID="ID_644373194" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Using Machine Learning to Target Behavioral Health " FOLDED="true" ID="ID_439103692" CREATED="1557224068555" MODIFIED="1557224277158" LINK="https://healthitanalytics.com/news/using-machine-learning-to-target-behavioral-health-interventions">
<node TEXT="Using Machine Learning to Target Behavioral Health Interventions Machine learning tools can help providers target behavioral health interventions to patients who need help managing mental and physical chronic conditions." ID="ID_123195604" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Machine Learning: What it is and why it matters | SAS" FOLDED="true" ID="ID_1535676162" CREATED="1557224068555" MODIFIED="1557224277158" LINK="https://www.sas.com/en_us/insights/analytics/machine-learning.html">
<node TEXT="Health care. Machine learning is a fast-growing trend in the health care industry thanks to the advent of wearable devices and sensors that can use data to assess a patients health in real time. The technology can also help medical experts analyze data to identify trends or red flags that may lead to improved diagnoses and treatment." ID="ID_1256627392" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Machine-learning will revolutionise cardiovascular healthcare" FOLDED="true" ID="ID_1879021607" CREATED="1557224068555" MODIFIED="1557224277158" LINK="https://www.raconteur.net/healthcare/machine-learning-heart-health">
<node TEXT="&#x201c;The impact of machine-learning will be as transformational to modern medicine as the discovery of penicillin was in the last century&#x201d; enthuses Dr Mitesh Patel UK medical director of health insurers Aetna International." ID="ID_245708145" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="Artificial Intelligence and Machine Learning: Policy Paper" FOLDED="true" ID="ID_1354534291" CREATED="1557224068555" MODIFIED="1557224277158" LINK="https://www.internetsociety.org/resources/doc/2017/artificial-intelligence-and-machine-learning-policy-paper/">
<node TEXT="Artificial Intelligence and Machine Learning: Policy Paper.  Applications based on AI are already visible in healthcare diagnostics targeted treatment transportation public safety service robots education and entertainment but will be applied in more fields in the coming years.  Furthermore the social impact of AI cannot be fully " ID="ID_1611384406" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="A new study shows what it might take to make AI useful in " FOLDED="true" ID="ID_1917783243" CREATED="1557224068555" MODIFIED="1557224277158" LINK="https://www.technologyreview.com/s/613165/a-new-study-shows-what-it-might-take-to-make-ai-useful-in-health-care/">
<node TEXT="A new study shows what it might take to make AI useful in health care.  Machine learning has great potential to transform disease diagnosis and detection but it&#x2019;s been held back by patients " ID="ID_703078370" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
<node TEXT="FHIR cloud pop health and social determinants spark new " FOLDED="true" ID="ID_1024962385" CREATED="1557224068555" MODIFIED="1557224277158" LINK="https://www.healthcareitnews.com/news/fhir-cloud-pop-health-and-social-determinants-spark-new-security-challenges">
<node TEXT="With increasing buzz around population health and social determinants of health those two forces are poised to change philosophies around care delivery and how a hospital or health system works to keep the surrounding community healthy. While that likely means good things for patients and outcomes it also drives more sharing more data and more risk of losing your privacy." ID="ID_320705144" CREATED="1557224068555" MODIFIED="1557224068555"/>
</node>
</node>
<node TEXT="Social Story HealthCare MachineLearning#$D$#" FOLDED="true" ID="ID_1018901242" CREATED="1557224068556" MODIFIED="1557224288254">
<icon BUILTIN="stop-sign"/>
<node TEXT="Machine learning: what&#x2019;s the diagnosis? | Hitachi in UK" FOLDED="true" ID="ID_412126028" CREATED="1557224068556" MODIFIED="1557224277242" LINK="http://www.hitachi.eu/en-gb/social-innovation-stories/health/machine-learning-whats-diagnosis">
<node TEXT="Machine learning isn&#x2019;t restricted to analysing physical ailments using patient data. In 2015 a team of researchers developed an AI model that correctly predicted which members of a group of young people would develop psychosis&#x2014;a major feature of schizophrenia&#x2014;by analysing transcripts of their speech. This model focused on tell-tale " ID="ID_192638381" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="A new study shows what it might take to make AI useful in " FOLDED="true" ID="ID_1873041826" CREATED="1557224068556" MODIFIED="1557224277242" LINK="https://www.technologyreview.com/s/613165/a-new-study-shows-what-it-might-take-to-make-ai-useful-in-health-care/">
<node TEXT="Hospital intensive care units can be frightening places for patients. And for good reason. In the US the ICU has a higher mortality rate than any other hospital unit&#x2014;between 8% and 19% " ID="ID_1529823988" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="FHIR cloud pop health and social determinants spark new " FOLDED="true" ID="ID_1370644580" CREATED="1557224068556" MODIFIED="1557224277242" LINK="https://www.healthcareitnews.com/news/fhir-cloud-pop-health-and-social-determinants-spark-new-security-challenges">
<node TEXT="With increasing buzz around population health and social determinants of health those two forces are poised to change philosophies around care delivery and how a hospital or health system works to keep the surrounding community healthy. While that likely means good things for patients and outcomes it also drives more sharing more data and more risk of losing your privacy." ID="ID_457034329" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Social Determinants of Health and the EHR: One HIMSS " FOLDED="true" ID="ID_377874205" CREATED="1557224068556" MODIFIED="1557224277242" LINK="https://www.hcinnovationgroup.com/population-health-management/social-determinants-of-health/article/21067860/social-determinants-of-health-and-the-ehr-one-himss-presenters-story">
<node TEXT="Population Health Management Social Determinants of Health Social Determinants of Health and the EHR: One HIMSS Presenter&#x2019;s Story Jitendra Barmecha M.D. vice president and CIO at SBH Health System in the Bronx will speak at HIMSS about his organization&#x2019;s journey around social determinants of health data and the EHR" ID="ID_1332770998" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Machine Learning: What it is and why it matters | SAS" FOLDED="true" ID="ID_1507634378" CREATED="1557224068556" MODIFIED="1557224277242" LINK="https://www.sas.com/en_us/insights/analytics/machine-learning.html">
<node TEXT="Health care. Machine learning is a fast-growing trend in the health care industry thanks to the advent of wearable devices and sensors that can use data to assess a patients health in real time. The technology can also help medical experts analyze data to identify trends or red flags that may lead to improved diagnoses and treatment." ID="ID_1517581208" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="The Transformation of Healthcare with AI and Machine Learning" ID="ID_1256887350" CREATED="1557224068556" MODIFIED="1557224277242" LINK="https://www.informationweek.com/big-data/ai-machine-learning/the-transformation-of-healthcare-with-ai-and-machine-learning/a/d-id/1333039">
<node TEXT="Healthcare stands poised for a transformation driven by AI and ML and fueled by an abundance of data sources &#x2013; electronic health records genome sequences mobile devices embedded sensors and even billing records. AI and ML solutions are already being used by thousands of companies with the goal of improving the healthcare experience." ID="ID_416890851" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Researchers use machine-learning system to diagnose " FOLDED="true" ID="ID_1866526640" CREATED="1557224068556" MODIFIED="1557224277243" LINK="https://medicalxpress.com/news/2019-04-machine-learning-genetic-diseases.html">
<node TEXT="Researchers at Rady Childrens Institute for Genomic Medicine (RCIGM) have utilized a machine-learning process and clinical natural language processing (CNLP) to diagnose rare genetic diseases in " ID="ID_696248465" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="HealthCare.gov - Get 2019 health coverage. Health " FOLDED="true" ID="ID_806830202" CREATED="1557224068556" MODIFIED="1557224277243" LINK="https://www.healthcare.gov/">
<node TEXT="Official site of Affordable Care Act. Enroll now for 2019 coverage. See health coverage choices ways to save today how law affects you." ID="ID_1105083617" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Machine Learning In Analytics To Limit Healthcare Fraud" FOLDED="true" ID="ID_1222197165" CREATED="1557224068556" MODIFIED="1557224277243" LINK="https://www.forbes.com/sites/davidteich/2018/11/27/machine-learning-in-analytics-to-limit-healthcare-fraud/">
<node TEXT="That is where machine learning can come in. Given the large data sets in today&#x2019;s medical industry ML can be trained to analyze refill patterns for individuals pharmacies and regions." ID="ID_368410054" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Addressing social determinants of health? Consider " FOLDED="true" ID="ID_556843002" CREATED="1557224068556" MODIFIED="1557224277243" LINK="https://www.healthcarefinancenews.com/news/addressing-social-determinants-health-consider-artificial-intelligence-and-machine-learning">
<node TEXT="Social determinants of health is one of the hot buzz-phrases in healthcare these days and for good reason. SDOH refers to outside factors that may impact a patients health such as employment status and access to education and providers can improve efficiency and curb costs by addressing these factors." ID="ID_1247824480" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="What Is A Social Story? - Carol Gray - Social Stories" FOLDED="true" ID="ID_1470524140" CREATED="1557224068556" MODIFIED="1557224277243" LINK="https://carolgraysocialstories.com/social-stories/what-is-it/">
<node TEXT="Social Stories are a social learning tool that supports the safe and meaningful exchange of information between parents professionals and people with autism of all ages. The people who develop Social Stories are referred to as Authors and they work on behalf of a child adolescent or adult with autism the Audience. Authors follow a [&#x2026;]" ID="ID_1139668023" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
<node TEXT="Alberta scientists use machine learning and Twitter to " FOLDED="true" ID="ID_1218816112" CREATED="1557224068556" MODIFIED="1557224277243" LINK="https://globalnews.ca/news/5117599/university-of-alberta-machine-learning-twitter-health/">
<node TEXT="Many people share their well-being on social media and University of Alberta scientists are using machine learning and Twitter to better understand your health. Machine learning is an application " ID="ID_1290319831" CREATED="1557224068556" MODIFIED="1557224068556"/>
</node>
</node>
</node>
</node>
<node TEXT="Research Papers" POSITION="left" ID="ID_1155092512" CREATED="1563179125257" MODIFIED="1563179543878">
<attribute NAME="Type" VALUE="syllabus_point"/>
<edge COLOR="#ff0000"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      This will be modified taking into consideration, unique needs of each subject
    </p>
  </body>
</html>
</richcontent>
<node TEXT="[Discussion] Best Research Paper in" ID="ID_658753720" CREATED="1563179125257" MODIFIED="1563179125257">
<node TEXT="2019" ID="ID_1797099291" CREATED="1563179125257" MODIFIED="1563179125257"/>
<node TEXT="2018" ID="ID_638213396" CREATED="1563179125257" MODIFIED="1563179125257"/>
<node TEXT="2017" ID="ID_1111123111" CREATED="1563179125257" MODIFIED="1563179125257"/>
<node TEXT="2016" ID="ID_59885777" CREATED="1563179125257" MODIFIED="1563179125257"/>
<node TEXT="2010 to 2015" ID="ID_1058809156" CREATED="1563179125257" MODIFIED="1563179125257"/>
<node TEXT="2000 to 2010" ID="ID_1400664810" CREATED="1563179125257" MODIFIED="1563179125257"/>
<node TEXT="All Time" ID="ID_44182410" CREATED="1563179125257" MODIFIED="1563179125257"/>
</node>
<node TEXT="Video Explaining the Papers" ID="ID_219049345" CREATED="1563179125257" MODIFIED="1563179125257"/>
</node>
<node TEXT="Your Reasons for Studying  Machine Learning" POSITION="left" ID="ID_1515836531" CREATED="1563179125257" MODIFIED="1563179534968">
<edge COLOR="#ff0000"/>
<node TEXT="" ID="ID_935384807" CREATED="1563190750032" MODIFIED="1563190752497">
<icon BUILTIN="full-1"/>
</node>
<node TEXT="" ID="ID_520527552" CREATED="1563190757217" MODIFIED="1563190760961">
<icon BUILTIN="full-2"/>
</node>
<node TEXT="" ID="ID_1380994775" CREATED="1563190764665" MODIFIED="1563190767001">
<icon BUILTIN="full-3"/>
</node>
</node>
<node TEXT="Units" FOLDED="true" POSITION="left" ID="ID_70543241" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<edge COLOR="#ff0000"/>
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Introduction To Machine Learning" FOLDED="true" ID="ID_368113565" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<edge COLOR="#ff0000"/>
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Classical and Adaptive Machines" ID="ID_220014530" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Machine Learning Matters" ID="ID_663539355" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Beyond Machine Learning" ID="ID_1021536735" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Deep Learning" ID="ID_573087113" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Bio Inspired adaptive Systems" ID="ID_1096700227" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Machine Learning and Big Data" ID="ID_1354686289" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Elements of Machine Learning" ID="ID_615557757" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Data formats" ID="ID_1099673569" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Learnability" ID="ID_408218053" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Elements of Information Theory" ID="ID_1182152265" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Statistical Learning Approaches" ID="ID_1543024479" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Research Paper Map " ID="ID_826594249" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Resources" ID="ID_1425081709" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Podcasts" ID="ID_1080128078" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Linear Disgressions " ID="ID_1775066708" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
</node>
</node>
<node TEXT="Feature Selection" FOLDED="true" ID="ID_1432632160" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<edge COLOR="#ff0000"/>
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Scikit-learn" ID="ID_1063651286" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Dataset" ID="ID_1753383418" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Creating training and test sets" ID="ID_779601205" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Managing Categorical data" ID="ID_1862938472" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Managing Missing features" ID="ID_65276676" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Data scaling and normalization" ID="ID_357798751" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Feature Selection and Filtering" ID="ID_334442606" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Principal Component Analysis" ID="ID_1500717604" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Non negative matrix factorization" ID="ID_1317341696" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Sparse PCA" ID="ID_651855692" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Kernel PCA" ID="ID_1963615093" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Interactive Visualization " ID="ID_67311828" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Atom Extraction" ID="ID_1808226776" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Dictionary Learning" ID="ID_632515536" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Regression" FOLDED="true" ID="ID_529250362" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<edge COLOR="#ff0000"/>
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Linear Regression" ID="ID_1575772684" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Linear Models" ID="ID_1208275087" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="A bi-dimensional example" ID="ID_1019665384" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Linear Regression and Higher dimensionality" ID="ID_76868782" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Regularization" ID="ID_774433713" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Ridge" ID="ID_1667295530" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Blog " ID="ID_1334743966" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Lasso" ID="ID_210980709" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Blog " ID="ID_1655441614" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="ElasticNet" ID="ID_1118660429" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Blog " ID="ID_862393928" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Example Anecdote " ID="ID_1026851660" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Code " ID="ID_80031627" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Interactive Visualization " ID="ID_507565631" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Robust Regression with Random Sample Consensus" ID="ID_1755638177" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Polynomial Regression" ID="ID_1616275146" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Isotonic Regression" ID="ID_1274590879" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Logistic Regression" ID="ID_9099750" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Linear Classification" ID="ID_158663185" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Implementation" ID="ID_654990865" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Optimizations" ID="ID_638862964" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Stochastic Gradient Descent Algorithms" ID="ID_1454756718" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Finding the Optimal hyper-parameters through Grid Search" ID="ID_931448523" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Classification Metric" ID="ID_1159424921" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="ROC Curve" ID="ID_1413096345" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
</node>
<node TEXT="Naive Bayes and Support Vector Machine" FOLDED="true" ID="ID_590976702" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<edge COLOR="#ff0000"/>
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Naive Bayes" ID="ID_1310261714" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Bayes Theorem" ID="ID_1014045771" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Naive Bayes Classifiers" ID="ID_539846210" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Naive Bayes in Scikit-learn" ID="ID_646875735" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Types" ID="ID_1423028607" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Bernoulli Naive Bayes" ID="ID_1058851753" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Multinomial Naive Bayes" ID="ID_1639563047" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Gaussian Naive Bayes" ID="ID_1305410196" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Interactive Visualization " ID="ID_1824486523" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Support Vector Machine" ID="ID_89555584" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Linear Support Vector Machines" ID="ID_1827242830" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Scikit-learn implementation" ID="ID_675675541" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Classification" ID="ID_1391071500" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Kernel based classification" ID="ID_624223047" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Polynomial Kernel Visualization" ID="ID_268513940" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Visualization 1 " ID="ID_1153000683" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Visualization 2 " ID="ID_1863231686" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
</node>
<node TEXT="Linear Classification" ID="ID_1813303547" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Non-Linear Examples" ID="ID_798751775" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Controlled Support Vector Machines" ID="ID_343942341" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Support Vector Regression" ID="ID_1854867875" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Blog" ID="ID_475048769" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Analytics Vidya " ID="ID_350688114" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
</node>
</node>
<node TEXT="Decision Trees and Ensemble Learning" FOLDED="true" ID="ID_282142392" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<edge COLOR="#ff0000"/>
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Decision Trees" ID="ID_739895270" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Impurity Measures" ID="ID_1576003715" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Feature Importance" ID="ID_1125656250" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="DT Classification using Scikit-learn" ID="ID_264248188" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Interactive Visualization " ID="ID_1150787721" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Decision Tree Visualization Blog(T2) " ID="ID_1026143856" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT=" Ensemble Learning" ID="ID_1882220770" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Random Forests" ID="ID_201219154" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="AdaBoost" ID="ID_1650608914" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Gradient Tree Boosting" ID="ID_392418822" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Voting Classifier" ID="ID_266182809" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Ensemble methods" ID="ID_1916004123" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Bagging" ID="ID_1583576194" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Boosting" ID="ID_432165081" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Random Forests" ID="ID_564777989" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Blog" ID="ID_1856328680" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Analytics Vidya " ID="ID_1687696440" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Code " ID="ID_1272261953" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT=" Introduction to Meta Classifier:" ID="ID_1470825490" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Concept of Weak Learner" ID="ID_1934466098" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Concept of Eager Learner" ID="ID_1615346627" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Clustering" ID="ID_302522187" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Clustering Fundamentals" ID="ID_1633402169" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Basics" ID="ID_451269945" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Kmeans" ID="ID_782953950" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Finding Optimal number of Clusters" ID="ID_806638375" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="DBSCAN" ID="ID_1044206355" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Spectral Clustering" ID="ID_1807506649" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Evaluation Methods based on Ground Truth" ID="ID_736486569" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Homogeneity" ID="ID_855898096" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Completeness" ID="ID_932250958" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Adjusted Rand Index" ID="ID_1028581210" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
</node>
</node>
<node TEXT="Clustering Techniques" FOLDED="true" ID="ID_1154651198" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<edge COLOR="#ff0000"/>
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Hierarchical Clustering" ID="ID_939089541" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Expectation Maximization Clustering" ID="ID_1393211253" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Agglomerative Clustering" ID="ID_1018490940" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Dendograms" ID="ID_1488353289" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Agglomerative Clustering in Scikit-learn" ID="ID_1364538282" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Connectivity Constraints" ID="ID_1177956139" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Introduction to Recommendation Systems" ID="ID_675257088" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Naive User based systems" ID="ID_75835069" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Content based Systems" ID="ID_77750440" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Blog" ID="ID_33547508" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Analytics Vidya " ID="ID_16842595" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
</node>
<node TEXT="Model free collaborative filtering" ID="ID_754866883" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Singular Value Decomposition" ID="ID_826439508" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Alternating least squares" ID="ID_1245558476" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
<node TEXT="Fundamentals of Deep Networks" ID="ID_477624489" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
<node TEXT="Defining Deep learning" ID="ID_1609133772" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Common Architectural Principles of deep networks" ID="ID_1766206556" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Building blocks of deep networks" ID="ID_1746855847" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
<node TEXT="Cheatsheet" ID="ID_409620810" CREATED="1563516968639" MODIFIED="1563516968639" Folded="true">
<attribute NAME="Type" VALUE="syllabus_point"/>
</node>
</node>
</node>
</node>
</node>
</map>
