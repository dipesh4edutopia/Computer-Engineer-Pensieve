<map version="freeplane 1.7.0">

<attribute_registry SHOW_ATTRIBUTES="hide" />
<node CREATED="1562675315160" FOLDED="false" ICON_SIZE="36.0 pt" ID="ID_191153586" LINK="../1_Machine%20Learning_MasterLookup.mm" LOCALIZED_STYLE_REF="AutomaticLayout.level.root" MODIFIED="1563517413228" TEXT="MachineLearning"><hook NAME="MapStyle">
    <properties edgeColorConfiguration="#00cc33ff,#00cc33ff,#00cc33ff,#00cc33ff,#00cc33ff,#00cc33ff,#00cc33ff,#00cc33ff,#00cc33ff,#00cc33ff,#00cc33ff,#00cc33ff" fit_to_viewport="false" show_icon_for_attributes="false" />

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt">
<font SIZE="24" />
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" STYLE="bubble">
<stylenode COLOR="#000000" ICON_SIZE="12.0 pt" LOCALIZED_TEXT="default" STYLE="fork">
<font BOLD="false" ITALIC="false" NAME="SansSerif" SIZE="10" />
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details" />
<stylenode LOCALIZED_TEXT="defaultstyle.attributes">
<font SIZE="9" />
</stylenode>
<stylenode BACKGROUND_COLOR="#ffffff" COLOR="#000000" LOCALIZED_TEXT="defaultstyle.note" TEXT_ALIGN="LEFT" />
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge" />
<cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT" />
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" STYLE="bubble">
<stylenode COLOR="#18898b" LOCALIZED_TEXT="styles.topic" STYLE="fork">
<font BOLD="true" NAME="Liberation Sans" SIZE="10" />
</stylenode>
<stylenode COLOR="#cc3300" LOCALIZED_TEXT="styles.subtopic" STYLE="fork">
<font BOLD="true" NAME="Liberation Sans" SIZE="10" />
</stylenode>
<stylenode COLOR="#669900" LOCALIZED_TEXT="styles.subsubtopic">
<font BOLD="true" NAME="Liberation Sans" SIZE="10" />
</stylenode>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes" />
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" STYLE="bubble">
<stylenode COLOR="#000000" ICON_SIZE="14.0 pt" LOCALIZED_TEXT="AutomaticLayout.level.root" STYLE="oval">
<font NAME="Segoe Print" SIZE="22" />
<edge COLOR="#ffffff" />
</stylenode>
<stylenode BORDER_WIDTH_LIKE_EDGE="true" COLOR="#000000" ICON_SIZE="18.0 px" LOCALIZED_TEXT="AutomaticLayout.level,1" SHAPE_HORIZONTAL_MARGIN="0.1 pt" SHAPE_VERTICAL_MARGIN="0.1 pt">
<font BOLD="false" ITALIC="true" SIZE="18" />
<edge COLOR="#00cc33" STYLE="sharp_bezier" WIDTH="8" />
</stylenode>
<stylenode BORDER_WIDTH_LIKE_EDGE="true" COLOR="#000000" ICON_SIZE="16.0 px" LOCALIZED_TEXT="AutomaticLayout.level,2">
<font SIZE="16" />
<edge COLOR="#00cc33" STYLE="sharp_bezier" WIDTH="3" />
</stylenode>
<stylenode BORDER_WIDTH_LIKE_EDGE="true" COLOR="#000000" ICON_SIZE="14.0 px" LOCALIZED_TEXT="AutomaticLayout.level,3">
<font SIZE="14" />
<edge COLOR="#00cc33" STYLE="sharp_bezier" WIDTH="3" />
</stylenode>
<stylenode BORDER_WIDTH_LIKE_EDGE="true" COLOR="#000000" ICON_SIZE="14.0 px" LOCALIZED_TEXT="AutomaticLayout.level,4">
<font SIZE="13" />
<edge COLOR="#00cc33" STYLE="sharp_bezier" WIDTH="2" />
</stylenode>
<stylenode BORDER_WIDTH_LIKE_EDGE="true" ICON_SIZE="14.0 px" LOCALIZED_TEXT="AutomaticLayout.level,5">
<font SIZE="13" />
<edge COLOR="#00cc33" STYLE="sharp_bezier" WIDTH="1" />
</stylenode>
<stylenode ICON_SIZE="14.0 px" LOCALIZED_TEXT="AutomaticLayout.level,6">
<font SIZE="13" />
<edge STYLE="bezier" />
</stylenode>
<stylenode ICON_SIZE="14.0 px" LOCALIZED_TEXT="AutomaticLayout.level,7">
<font SIZE="13" />
<edge STYLE="bezier" />
</stylenode>
<stylenode ICON_SIZE="14.0 px" LOCALIZED_TEXT="AutomaticLayout.level,8">
<edge STYLE="bezier" />
<font SIZE="13" />
</stylenode>
<stylenode ICON_SIZE="14.0 px" LOCALIZED_TEXT="AutomaticLayout.level,9">
<font SIZE="13" />
<edge STYLE="bezier" />
</stylenode>
<stylenode ICON_SIZE="14.0 px" LOCALIZED_TEXT="AutomaticLayout.level,10">
<font SIZE="13" />
<edge STYLE="bezier" />
</stylenode>
<stylenode ICON_SIZE="14.0 px" LOCALIZED_TEXT="AutomaticLayout.level,11">
<edge STYLE="bezier" />
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook COUNTER="27" NAME="AutomaticEdgeColor" RULE="ON_BRANCH_CREATION" />
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL" />
<font SIZE="20" />
<node CREATED="1549426121539" ID="ID_356339431" LOCALIZED_STYLE_REF="defaultstyle.floating" MODIFIED="1549434098401" POSITION="left" TEXT="ADEPT">
<node CREATED="1549426179088" ID="ID_621380803" MODIFIED="1549426291603" TEXT="A">
<edge STYLE="bezier" />
<node CREATED="1549426193173" ID="ID_182396775" MODIFIED="1549426291602" TEXT="Analogy">
<edge STYLE="bezier" />
</node>
</node>
<node CREATED="1549426181833" ID="ID_688331787" MODIFIED="1549426291603" TEXT="D">
<edge STYLE="bezier" />
<node CREATED="1549426199017" ID="ID_424948524" MODIFIED="1549426291602" TEXT="Diagram">
<edge STYLE="bezier" />
<node CREATED="1549426225828" ID="ID_1239223974" MODIFIED="1549426291602" TEXT="Visualisation">
<edge STYLE="bezier" />
</node>
<node CREATED="1549426230717" ID="ID_993378749" MODIFIED="1549426291601" TEXT="Animation">
<edge STYLE="bezier" />
</node>
</node>
</node>
<node CREATED="1549426185556" ID="ID_579018414" MODIFIED="1549426291604" TEXT="E">
<edge STYLE="bezier" />
<node CREATED="1549426205652" ID="ID_789271875" MODIFIED="1549426291601" TEXT="Example">
<edge STYLE="bezier" />
</node>
</node>
<node CREATED="1549426187712" ID="ID_396767372" MODIFIED="1549426291604" TEXT="P">
<edge STYLE="bezier" />
<node CREATED="1549426212197" ID="ID_1805083165" MODIFIED="1549426291599" TEXT="Plain English">
<edge STYLE="bezier" />
<node CREATED="1551437777014" ID="ID_1482302333" MODIFIED="1551437795883" TEXT="LIM5YO" />
</node>
</node>
<node CREATED="1549426189926" ID="ID_1508620179" MODIFIED="1549426291604" TEXT="T">
<edge STYLE="bezier" />
<node CREATED="1549426217333" ID="ID_874459994" MODIFIED="1549426291601" TEXT="Technical">
<edge STYLE="bezier" />
<node CREATED="1549426242238" ID="ID_1104101457" MODIFIED="1549426291601" TEXT="Colorized Formulae">
<edge STYLE="bezier" />
</node>
</node>
</node>
<node CREATED="1549451938894" ID="ID_34939331" MODIFIED="1549451940980" TEXT="Video" />
</node>
<node CREATED="1563517391360" FOLDED="true" Folded="true" ID="ID_1594697030" MODIFIED="1563517391360" POSITION="right" TEXT="Introduction To Machine Learning">
<edge COLOR="#00cc33" />
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1070786091" MODIFIED="1563517391360" TEXT="Classical and Adaptive Machines">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068596" FOLDED="true" ID="ID_551192887" MODIFIED="1557225483420" TEXT="Classical and Adaptive Machines#$D$#">
<node CREATED="1557224068596" FOLDED="true" ID="ID_615778129" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781785889622/1/ch01lvl1sec8/introduction-classic-and-adaptive-machines" MODIFIED="1557225479614" TEXT="Introduction - classic and adaptive machines - Machine Learning ">
<node CREATED="1557224068596" ID="ID_775057903" MODIFIED="1557224068596" TEXT="Introduction - classic and adaptive machinesSince time immemorial human beings have built tools and machines to simplify their" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1461953241" LINK="https://www.youtube.com/watch?v=YHcAQKrh3E4" MODIFIED="1557225479614" TEXT="Classic Machine And Adaptive Machine ll Machine Learning Course ">
<node CREATED="1557224068596" ID="ID_1547078448" MODIFIED="1557224068596" TEXT="Feb 16 2019  Classic Machine And Adaptive Machine ll Machine Learning Course Explained in Hindi. 5 Minutes Engineering. Loading Unsubscribe from 5&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1156146738" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781789347999/1/ch01lvl1sec10/introduction-classic-and-adaptive-machines" MODIFIED="1557225479614" TEXT="Introduction &#8211; classic and adaptive machines - Machine Learning ">
<node CREATED="1557224068596" ID="ID_1328506197" MODIFIED="1557224068596" TEXT="Introduction &#8211; classic and adaptive machinesSince time immemorial human beings have built tools and machines to simplify thei" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_265652766" LINK="https://www.oreilly.com/library/view/machine-learning-algorithms/9781785889622/3a598806-5896-4de5-9949-8ea3ba4625c4.xhtml" MODIFIED="1557225479614" TEXT="Introduction - classic and adaptive machines - Machine Learning ">
<node CREATED="1557224068596" ID="ID_1695365418" MODIFIED="1557224068596" TEXT="Introduction - classic and adaptive machines Since time immemorial human beings have built tools and machines to simplify their work and reduce the overall&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_187012359" LINK="https://en.wikipedia.org/wiki/Machine_learning" MODIFIED="1557225479614" TEXT="Machine learning - Wikipedia">
<node CREATED="1557224068596" ID="ID_195610842" MODIFIED="1557224068596" TEXT="Machine learning (ML) is the scientific study of algorithms and statistical models that computer .. Classic examples include principal components analysis and cluster analysis. Feature .. Agriculture &#183; Anatomy &#183; Adaptive websites &#183; Affective computing &#183; Bioinformatics &#183; Brain&#8211;machine interfaces &#183; Cheminformatics &#183; Computer&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1293918709" LINK="https://mitpress.mit.edu/books/series/adaptive-computation-and-machine-learning-series" MODIFIED="1557225479614" TEXT="Adaptive Computation and Machine Learning series | The MIT Press">
<node CREATED="1557224068596" ID="ID_1972243619" MODIFIED="1557224068596" TEXT="Adaptive Computation and Machine Learning series  classical statistical theory minimum description length theory and statistical mechanics approaches." />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1454474106" LINK="https://www.autosar.org/fileadmin/user_upload/standards/adaptive/17-10/AUTOSAR_TR_AdaptiveMethodology.pdf" MODIFIED="1557225479614" TEXT="Methodology for Adaptive Platform">
<node CREATED="1557224068596" ID="ID_837682621" MODIFIED="1557224068596" TEXT="In contrast to the AUTOSAR Classic Platform instances of Adaptive Applica- tions for  In this spirit one real ECU could run several machines even though the." />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1576239097" LINK="https://www.amazon.com/LectroFan-Fidelity-Machine-Unique-Non-Looping/dp/B00JU8P8VY" MODIFIED="1557225479614" TEXT="Amazon.com: LectroFan High Fidelity White Noise Machine with 20 ">
<node CREATED="1557224068596" ID="ID_1019452852" MODIFIED="1557224068596" TEXT="Adaptive Sound Technologies Lectrofan Travel Case Black 3.2 Ounce. + .. Marpac Dohm Classic (White) | White noise machine | 101 Night Trial  1 Year&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1191262747" LINK="http://ieeexplore.ieee.org/document/7077072" MODIFIED="1557225479614" TEXT="Adaptive hysteresis controller for the Switched Reluctance Machines ">
<node CREATED="1557224068596" ID="ID_426995449" MODIFIED="1557224068596" TEXT="Abstract: This paper deals with an adaptive hysteresis controller for the Switched Reluctance Machine (SRM). The classical hysteresis controller provides a high&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_922069107" LINK="https://tel.archives-ouvertes.fr/tel-01812044v2/document" MODIFIED="1557225479614" TEXT="Adaptive machine learning algorithms for data streams subject to ">
<node CREATED="1557224068596" ID="ID_1884171775" MODIFIED="1557224068596" TEXT="Dec 3 2018  8.3.3.3 Adaptive machine learning for quantitative trading . .. of a machine learning algorithm in this framework is similar to the classical off-." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1609612442" MODIFIED="1563517391360" TEXT="Machine Learning Matters">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_521141213" MODIFIED="1563517391360" TEXT="Beyond Machine Learning">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_594133549" MODIFIED="1563517391360" TEXT="Deep Learning">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068596" FOLDED="true" ID="ID_840326465" MODIFIED="1557225483420" TEXT="Machine Learning Matters#$D$#">
<node CREATED="1557224068596" FOLDED="true" ID="ID_1060317631" LINK="https://machinelearningmastery.com/machine-learning-matters/" MODIFIED="1557225479614" TEXT="Machine Learning Matters">
<node CREATED="1557224068596" ID="ID_1291491047" MODIFIED="1557224068596" TEXT="Dec 9 2013  It is important to know why machine learning matters so that you know the intrinsic value of the field and of methods and open questions in the&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_507336525" LINK="https://www.sas.com/en_us/insights/analytics/machine-learning.html" MODIFIED="1557225479614" TEXT="Machine Learning: What it is and why it matters | SAS">
<node CREATED="1557224068596" ID="ID_1320471041" MODIFIED="1557224068596" TEXT="Machine learning is a method of data analysis that automates analytical model building. It is a branch of artificial intelligence based on the idea that systems can&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_474415884" LINK="https://medium.com/machine-learning-for-humans/why-machine-learning-matters-6164faf1df12" MODIFIED="1557225479614" TEXT="A Beginners Guide to AI/ML &#65533;&#65533;   &#8211; Machine Learning for Humans ">
<node CREATED="1557224068596" ID="ID_1781982626" MODIFIED="1557224068596" TEXT="Aug 19 2017  Roadmap. Part 1: Why Machine Learning Matters. The big picture of artificial intelligence and machine learning &#8212; past present and future." />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_893769439" LINK="https://arxiv.org/abs/1709.06560" MODIFIED="1557225479614" TEXT="Deep Reinforcement Learning that Matters">
<node CREATED="1557224068596" ID="ID_1675883710" MODIFIED="1557224068596" TEXT="Sep 19 2017  Computer Science  Machine Learning  in solving challenging problems across various domains using deep reinforcement learning (RL)." />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_326307266" LINK="https://www.simplilearn.com/what-is-machine-learning-and-why-it-matters-article" MODIFIED="1557225479614" TEXT="Machine Learning: What it is and Why it Matters">
<node CREATED="1557224068596" ID="ID_541923950" MODIFIED="1557224068596" TEXT="Feb 14 2019  Find out all you need to know about machine learning and what its  how we live and its time we understood what it is and why it matters." />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1076813695" LINK="http://www.wkiri.com/research/papers/wagstaff-MLmatters-12.pdf" MODIFIED="1557225479614" TEXT="Machine Learning that Matters">
<node CREATED="1557224068596" ID="ID_568294967" MODIFIED="1557224068596" TEXT="Machine Learning that Matters. Kiri L. Wagstaff kiri.l.wagstaff@jpl.nasa.gov. Jet Propulsion Laboratory California Institute of Technology 4800 Oak Grove Drive&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1804328578" LINK="https://insidebigdata.com/2017/02/18/machine-learning-matters/" MODIFIED="1557225479614" TEXT="Machine Learning: Why it Matters? - insideBIGDATA">
<node CREATED="1557224068596" ID="ID_1190845648" MODIFIED="1557224068596" TEXT="Feb 18 2017  Are you into Machine Learning OR are you &#8220;just&#8221; a Statistician?  grow change and develop by themselves in a matter of seconds &#8230; and we&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1837679035" LINK="https://erikbern.com/2016/08/05/when-machine-learning-matters.html" MODIFIED="1557225479614" TEXT="When machine learning matters &#183; Erik Bernhardsson">
<node CREATED="1557224068596" ID="ID_1700462431" MODIFIED="1557224068596" TEXT="Aug 5 2016  I joined Spotify in 2008 to focus on machine learning and music recommendations. Its easy to forget but Spotifys key differentiator back then&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_871888106" LINK="https://bigdata-madesimple.com/why-machine-learning-matters/" MODIFIED="1557225479614" TEXT="Why Machine Learning Matters">
<node CREATED="1557224068596" ID="ID_416591647" MODIFIED="1557224068596" TEXT="May 14 2014  While big data vendors offer many unique advantages and benefits to businesses machine learning in particular is an important feature all&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_278447183" LINK="https://blog.algorithmia.com/ai-why-deep-learning-matters/" MODIFIED="1557225479614" TEXT="Why Deep Learning Matters and Whats Next for AI - Algorithmia">
<node CREATED="1557224068596" ID="ID_1121730804" MODIFIED="1557224068596" TEXT="Nov 24 2016  Deep learning matters because its ushering in an era that will fundamentally alter the way we live work and communicate like the industrial&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_842213902" MODIFIED="1557225483421" TEXT="Beyond Machine Learning#$D$#">
<node CREATED="1557224068596" FOLDED="true" ID="ID_1360412578" LINK="https://blogs.wsj.com/cio/2019/01/11/beyond-machine-learning-capturing-cause-and-effect-relationships/" MODIFIED="1557225479614" TEXT="Beyond Machine Learning: Capturing Cause-and-Effect Relationships">
<node CREATED="1557224068596" ID="ID_1006090429" MODIFIED="1557224068596" TEXT="Jan 11 2019  Companies using machine learning to identify that needle-in-the-haystack bit of business insight could learn from the scientists who succeeded&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1837288495" LINK="https://medium.com/the-future-beyond/beyond-machine-learning-55000cae5da4" MODIFIED="1557225479614" TEXT="Beyond Machine Learning &#8211; The Future Beyond &#8211; Medium">
<node CREATED="1557224068596" ID="ID_275412806" MODIFIED="1557224068596" TEXT="Jan 11 2016  We live in dangerous times for us humans. Technology is moving so fast and there is lots of noise an ocean of noise. Although isolated noise&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_42118505" LINK="https://blog.irvingwb.com/blog/2019/01/correlation-does-not-imply-causation.html" MODIFIED="1557225479614" TEXT="Irving Wladawsky-Berger: Beyond Machine Learning: Capturing ">
<node CREATED="1557224068596" ID="ID_1244189269" MODIFIED="1557224068596" TEXT="Jan 7 2019  Beyond Machine Learning: Capturing Cause-and-Effect Relationships. Artificial intelligence is rapidly becoming one of the most important&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_43513031" LINK="https://www.topbots.com/deeper-than-deep-learning-beyond-backpropagation-geoffrey-hinton/" MODIFIED="1557225479614" TEXT="Beyond Backpropagation: Can We Go Deeper Than Deep Learning?">
<node CREATED="1557224068596" ID="ID_831026569" MODIFIED="1557224068596" TEXT="Nov 9 2017  As the public latches onto AI hype the pioneers behind deep learning question whether it is the right approach to achieve true machine&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_981450959" LINK="https://www.wired.com/story/greedy-brittle-opaque-and-shallow-the-downsides-to-deep-learning/" MODIFIED="1557225479614" TEXT="The Limits of Artificial Intelligence and Deep Learning | WIRED">
<node CREATED="1557224068596" ID="ID_1549487870" MODIFIED="1557224068596" TEXT="Feb 2 2018  But there are many things that people can do quickly that smart machines cannot. Natural language is beyond deep learning; new situations&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_227284067" LINK="https://blog.outsellinc.com/beyond-machine-learning-and-ai-10x-faster-deployments-and-indico-4f412fd87b22" MODIFIED="1557225479614" TEXT="Beyond Machine Learning and AI 10x Faster Deployments and Indico">
<node CREATED="1557224068596" ID="ID_1290010836" MODIFIED="1557224068596" TEXT="Jul 3 2018  If youve listened to this show it is no secret that Ive covered a large number of AI and Machine Learning companies. I promise you this one is&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_182399669" LINK="https://www.forbes.com/sites/forbestechcouncil/2019/03/26/artificial-intelligence-beyond-deep-neural-networks/" MODIFIED="1557225479614" TEXT="Council Post: Artificial Intelligence Beyond Deep Neural Networks">
<node CREATED="1557224068596" ID="ID_1851190638" MODIFIED="1557224068596" TEXT="Mar 26 2019  Several AI techniques could potentially address the shortcomings of deep neural networks." />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_581816377" LINK="https://analyticsweek.com/content/2018-trends-artificial-intelligence-beyond-machine-learning-internal-external-personalization/" MODIFIED="1557225479614" TEXT="2018 Trends in Artificial Intelligence: Beyond Machine Learning for ">
<node CREATED="1557224068596" ID="ID_1764621746" MODIFIED="1557224068596" TEXT="Nov 13 2017  The collective form of Artificial Intelligence is evolving. Granted its still a fundamental aspect of big data analytics and numerous cloud&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1258018993" LINK="https://www.youtube.com/watch?v=vyRi9MTgUQU" MODIFIED="1557225479614" TEXT="Artificial intelligence beyond Machine Learning Daniel Gillblad SICS">
<node CREATED="1557224068596" ID="ID_1803447487" MODIFIED="1557224068596" TEXT="May 18 2017  Daniel Gillblad PhD Director Decisions Networks and Analytics Laboratory RISE SICS AB .Artificial intelligence beyond Machine Learning&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1149979356" LINK="https://beyond-machine.com/" MODIFIED="1557225479614" TEXT="Home &#8212; Beyond Machine">
<node CREATED="1557224068596" ID="ID_1756778842" MODIFIED="1557224068596" TEXT="MIE (rebranded to Beyond Machine) was spawned from Lele and Irene  for a more developed community an outlet for media around Machine Intelligence." />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_234154688" MODIFIED="1557225483423" TEXT="Statistical Learning Approaches#$D$#">
<node CREATED="1557224068597" FOLDED="true" ID="ID_1024384588" LINK="https://en.wikipedia.org/wiki/Statistical_learning_theory" MODIFIED="1557225479614" TEXT="Statistical learning theory - Wikipedia">
<node CREATED="1557224068597" ID="ID_1479279676" MODIFIED="1557224068597" TEXT="Statistical learning theory is a framework for machine learning drawing from the fields of statistics and functional analysis. Statistical learning theory deals with&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_406792989" LINK="https://link.springer.com/article/10.1007/BF03192556" MODIFIED="1557225479614" TEXT="Statistical learning approaches for discriminant features selection ">
<node CREATED="1557224068597" ID="ID_676926863" MODIFIED="1557224068597" TEXT="Supervised statistical learning covers important models like Support Vector Machines (SVM) and Linear Discriminant Analysis (LDA). In this paper we describe&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_198130704" LINK="https://ieeexplore.ieee.org/document/7795911/" MODIFIED="1557225479630" TEXT="A statistical learning approach for estimating the reliability of crash ">
<node CREATED="1557224068597" ID="ID_1063016512" MODIFIED="1557224068597" TEXT="A statistical learning approach for estimating the reliability of crash severity  In this work a machine learning driven reliability estimator for crash severity&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_397841714" LINK="https://www.crcpress.com/A-Computational-Approach-to-Statistical-Learning/Arnold-Kane-Lewis/p/book/9781138046375" MODIFIED="1557225479630" TEXT="A Computational Approach to Statistical Learning - CRC Press Book">
<node CREATED="1557224068597" ID="ID_816001472" MODIFIED="1557224068597" TEXT="A Computational Approach to Statistical Learning gives a novel introduction to predictive modeling by focusing on the algorithmic and numeric motivations&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1199056395" LINK="https://www.analyticsvidhya.com/blog/2015/07/difference-machine-learning-statistical-modeling/" MODIFIED="1557225479630" TEXT="What Is The Difference Between Machine Learning  Statistical ">
<node CREATED="1557224068597" ID="ID_1009986423" MODIFIED="1557224068597" TEXT="Jul 1 2015  Both these approaches aim to learn about the underlying phenomena by  Differences between Machine Learning and Statistical Modeling:." />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1181363256" LINK="https://arxiv.org/abs/1702.05960" MODIFIED="1557225479630" TEXT="A Statistical Learning Approach to Modal Regression">
<node CREATED="1557224068597" ID="ID_209586597" MODIFIED="1557224068597" TEXT="Feb 20 2017  Statistics  Machine Learning  This paper studies the nonparametric modal regression problem systematically from a statistical learning view." />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1514101611" LINK="https://www.ncbi.nlm.nih.gov/pubmed/28821546" MODIFIED="1557225479630" TEXT="A Supervised Statistical Learning Approach for Accurate Legionella ">
<node CREATED="1557224068597" ID="ID_945589819" MODIFIED="1557224068597" TEXT="Nov 1 2017  A Supervised Statistical Learning Approach for Accurate Legionella pneumophila Source Attribution during Outbreaks. Buultjens AH(1)(2)&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1608894893" LINK="http://www.scielo.br/scielo.php?script=sci_arttextpid=S0104-65002008000200002" MODIFIED="1557225479630" TEXT="Statistical learning approaches for discriminant features selection">
<node CREATED="1557224068597" ID="ID_206348082" MODIFIED="1557224068597" TEXT="ARTICLES. Statistical learning approaches for discriminant features selection. Gilson A. GiraldiI; Paulo S. RodriguesIV; Edson C. KitaniII; Jo&#227;o R. SatoIII; Carlos&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1537324752" LINK="https://www.ncbi.nlm.nih.gov/pubmed/16616590" MODIFIED="1557225479630" TEXT="Implicit learning and statistical learning: one phenomenon two ">
<node CREATED="1557224068597" ID="ID_2546428" MODIFIED="1557224068597" TEXT="Trends Cogn Sci. 2006 May;10(5):233-8. Epub 2006 Apr 17. Implicit learning and statistical learning: one phenomenon two approaches. Perruchet P(1) Pacton&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_364379631" LINK="https://towardsdatascience.com/statistical-learning-for-data-science-b61b263c1196" MODIFIED="1557225479630" TEXT="Statistical Learning for Data Science &#8211; Towards Data Science">
<node CREATED="1557224068597" ID="ID_692846765" MODIFIED="1557224068597" TEXT="Aug 19 2018  This is the 6th  last post of blog post series Probability  Statistics for Data Science this post covers these topics related to Statistical&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_198396965" MODIFIED="1563517391360" TEXT="Bio Inspired adaptive Systems">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068597" FOLDED="true" ID="ID_1955840330" MODIFIED="1557225483422" TEXT="Bio Inspired adaptive Systems#$D$#">
<node CREATED="1557224068597" FOLDED="true" ID="ID_1202316181" LINK="https://en.wikipedia.org/wiki/Bio-inspired_computing" MODIFIED="1557225479614" TEXT="Bio-inspired computing - Wikipedia">
<node CREATED="1557224068597" ID="ID_1416254507" MODIFIED="1557224068597" TEXT="Bio-inspired computing short for biologically inspired computing is a field of study that loosely . The most basic computer system such as storage and computational fusion pulse discharge mechanism the . SymbioticSphere: A Biologically-inspired Architecture for Scalable Adaptive and Survivable Network Systems&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1463692288" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781785889622/1/ch01lvl1sec10/beyond-machine-learning-deep-learning-and-bio-inspired-adaptive-systems" MODIFIED="1557225479614" TEXT="Beyond machine learning - deep learning and bio-inspired adaptive ">
<node CREATED="1557224068597" ID="ID_3670067" MODIFIED="1557224068597" TEXT="Introduction - classic and adaptive machines &#183; Only learning matters &#183; Beyond machine learning - deep learning and bio-inspired adaptive systems &#183; Machine&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_426920229" LINK="https://gow.epsrc.ukri.org/NGBOViewGrant.aspx?GrantRef=EP/K040820/1" MODIFIED="1557225479614" TEXT="Bio-inspired Adaptive Architectures and Systems">
<node CREATED="1557224068597" ID="ID_375958416" MODIFIED="1557224068597" TEXT="EPSRC Reference: EP/K040820/1. Title: Bio-inspired Adaptive Architectures and Systems. Principal Investigator: Tyrrell Professor A. Other Investigators:&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1432907275" LINK="https://www.sciencedirect.com/science/article/pii/S1877050914007030" MODIFIED="1557225479614" TEXT="Bio-inspired Approaches for Engineering Adaptive Systems ">
<node CREATED="1557224068597" ID="ID_601737677" MODIFIED="1557224068597" TEXT="Adaptive systems are composed of different heterogeneous parts or entities that interact and perform actions favouring the emer- gence of global desired&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1996387092" LINK="https://www.oreilly.com/library/view/machine-learning-algorithms/9781785889622/ca8c45fe-2c94-476c-bbbc-6244d27df5d6.xhtml" MODIFIED="1557225479614" TEXT="Beyond machine learning - deep learning and bio-inspired adaptive ">
<node CREATED="1557224068597" ID="ID_1290722091" MODIFIED="1557224068597" TEXT="Beyond machine learning - deep learning and bio-inspired adaptive systems During the last few years thanks to more powerful and cheaper computers many&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1283269728" LINK="https://www.researchgate.net/publication/270979969_Bio-inspired_Approaches_for_Engineering_Adaptive_Systems" MODIFIED="1557225479614" TEXT="(&#65533;&#65533;&#65533;&#65533;&#65533;&#65533;) Bio-inspired Approaches for Engineering Adaptive Systems">
<node CREATED="1557224068597" ID="ID_232381067" MODIFIED="1557224068597" TEXT="Oct 21 2015  &#65533;&#65533;&#65533;&#65533;&#65533;&#65533; | Adaptive systems are composed of different heterogeneous parts or entities that interact and perform actions favouring the emer- gence&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1759200275" LINK="https://bamlab.mechse.illinois.edu/" MODIFIED="1557225479614" TEXT="Bio-inspired Adaptive Morphology (BAM) Laboratory">
<node CREATED="1557224068597" ID="ID_537937364" MODIFIED="1557224068597" TEXT="Bio-inspired is defined as inspired by or based on biological structures or processes  It is a biological system that continuously changes and adapts its form in&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1481738318" LINK="https://ieeexplore.ieee.org/document/7172033/" MODIFIED="1557225479614" TEXT="Bio-inspired underwater electrolocation through adaptive system ">
<node CREATED="1557224068597" ID="ID_376721707" MODIFIED="1557224068597" TEXT="Bio-inspired underwater electrolocation through adaptive system identification. Abstract: Electrolocation is a method of sensing and navigating around nearby&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_849852863" LINK="https://cyberleninka.org/article/n/195609.pdf" MODIFIED="1557225479614" TEXT="Bio-inspired Approaches for Engineering Adaptive Systems">
<node CREATED="1557224068597" ID="ID_1469876581" MODIFIED="1557224068597" TEXT="related to the development of adaptive systems and approaches and shed light on  Keywords: Natural and biological systems Adaptive systems Bio-inspired&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1366947672" LINK="http://mechanicaldesign.asmedigitalcollection.asme.org/article.aspx?articleid=2682441" MODIFIED="1557225479614" TEXT="Exploring Natural Strategies for Bio-Inspired Fault Adaptive Systems ">
<node CREATED="1557224068597" ID="ID_1436688230" MODIFIED="1557224068597" TEXT="Fault adaptive design seeks to find the principles and properties that enable robustness reliability and resilience to implement those features into engineering&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_149028068" MODIFIED="1563517391360" TEXT="Machine Learning and Big Data">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068597" FOLDED="true" ID="ID_1840329845" MODIFIED="1557225483422" TEXT="Machine Learning and Big Data#$D$#">
<node CREATED="1557224068597" FOLDED="true" ID="ID_634602372" LINK="https://towardsdatascience.com/machine-learning-with-big-data-86bcb39f2f0b" MODIFIED="1557225479614" TEXT="Machine Learning with Big Data &#8211; Towards Data Science">
<node CREATED="1557224068597" ID="ID_1769064803" MODIFIED="1557224068597" TEXT="Mar 11 2019  Storing this data is one thing but what about processing it and developing machine learning algorithms to work with it? In this article we will&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_673666224" LINK="https://www.coursera.org/learn/big-data-machine-learning" MODIFIED="1557225479614" TEXT="Machine Learning With Big Data | Coursera">
<node CREATED="1557224068597" ID="ID_144864898" MODIFIED="1557224068597" TEXT="Learn Machine Learning With Big Data from University of California San Diego. Want to make sense of the volumes of data you have collected? Need to&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1371707256" LINK="https://www.educba.com/big-data-vs-machine-learning/" MODIFIED="1557225479614" TEXT="5 Best Difference Between Big Data Vs Machine Learning">
<node CREATED="1557224068597" ID="ID_878145644" MODIFIED="1557224068597" TEXT="Feb 27 2018  In this Article Big Data vs Machine Learning we will look at their Meaning Head to Head Comparison and Key Differences in relatively easy&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_535765461" LINK="https://www.quora.com/How-are-big-data-and-machine-learning-related" MODIFIED="1557225479614" TEXT="How are big data and machine learning related? - Quora">
<node CREATED="1557224068597" ID="ID_1167907522" MODIFIED="1557224068597" TEXT="Big data machine learning statistics statistical machine learning; so many terms surfacing. What are these and how are they related is a question the answer to&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1936036775" LINK="https://www.sas.com/en_us/insights/analytics/machine-learning.html" MODIFIED="1557225479614" TEXT="Machine Learning: What it is and why it matters | SAS">
<node CREATED="1557224068597" ID="ID_1432181083" MODIFIED="1557224068597" TEXT="While many machine learning algorithms have been around for a long time the ability to automatically apply complex mathematical calculations to big data&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1851314956" LINK="https://www.kdnuggets.com/2017/07/machine-learning-big-data-explained.html" MODIFIED="1557225479614" TEXT="Machine Learning Applied to Big Data Explained">
<node CREATED="1557224068597" ID="ID_944308391" MODIFIED="1557224068597" TEXT="Machine learning with Big Data is in many ways different than regular machine learning. This informative image is helpful in identifying the steps in machine&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1506977649" LINK="https://www.forbes.com/sites/forbestechcouncil/2019/01/07/why-big-data-and-machine-learning-are-important-in-our-society/" MODIFIED="1557225479614" TEXT="Council Post: Why Big Data And Machine Learning Are Important In ">
<node CREATED="1557224068597" ID="ID_501963685" MODIFIED="1557224068597" TEXT="Jan 7 2019  The singularity is near or maybe were already in it. Whatever the case is machine learning and big data will have a tremendous influence on&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1787557398" LINK="https://sloanreview.mit.edu/article/how-big-data-is-empowering-ai-and-machine-learning-at-scale/" MODIFIED="1557225479614" TEXT="How Big Data Is Empowering AI and Machine Learning at Scale">
<node CREATED="1557224068597" ID="ID_429865966" MODIFIED="1557224068597" TEXT="May 8 2017  Big data is moving to a new stage of maturity &#8212; one that promises even greater business impact and industry disruption over the course of the&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_143190919" LINK="https://www.expertsystem.com/machine-learning-big-data-analytics/" MODIFIED="1557225479614" TEXT="Machine Learning for Big Data Analytics - Expert System">
<node CREATED="1557224068597" ID="ID_971241542" MODIFIED="1557224068597" TEXT="Lots of data equals lots of examples for the system equals good results. But is that really so? Learn more about machine learning for big data analytics." />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_168290409" LINK="https://www.youtube.com/watch?v=b3jizIvpa20" MODIFIED="1557225479614" TEXT="Big Data and Machine Learning - YouTube">
<node CREATED="1557224068597" ID="ID_1882919928" MODIFIED="1557224068597" TEXT="Jun 21 2016  Chair: Steven Drucker Microsoft Research Speakers: Mike Zyskowski Microsoft Research Lihong Li Microsoft Research Jonathan Huang&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_189575949" MODIFIED="1557225483423" TEXT="Data formats#$D$#">
<node CREATED="1557224068597" FOLDED="true" ID="ID_667495620" LINK="https://data.library.virginia.edu/data-management/plan/format-types/" MODIFIED="1557225479614" TEXT="Data Types  File Formats | University of Virginia Library Research ">
<node CREATED="1557224068597" ID="ID_572489508" MODIFIED="1557224068597" TEXT="Data Types  File Formats. What types of data are we talking about? Data can mean many different things and there are many ways to classify it. Two of the&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_965147042" LINK="https://en.wikipedia.org/wiki/Data_format" MODIFIED="1557225479614" TEXT="Data format - Wikipedia">
<node CREATED="1557224068597" ID="ID_711396775" MODIFIED="1557224068597" TEXT="Data format in information technology may refer to: Data type constraint placed upon the interpretation of data in a type system; Signal (electrical engineering)&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_15954318" LINK="http://camel.apache.org/data-format.html" MODIFIED="1557225479614" TEXT="Apache Camel: Data Format">
<node CREATED="1557224068597" ID="ID_688090301" MODIFIED="1557224068597" TEXT="Data Format. Camel supports a pluggable DataFormat to allow messages to be marshalled to and from binary or text formats to support a kind of Message&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1226331746" LINK="http://opendatahandbook.org/guide/en/appendices/file-formats/" MODIFIED="1557225479614" TEXT="File Formats">
<node CREATED="1557224068597" ID="ID_392455100" MODIFIED="1557224068597" TEXT="XML is a widely used format for data exchange because it gives good opportunities to keep the structure in the data and the way files are built on and allows&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_667309377" LINK="https://docs.microsoft.com/en-us/dotnet/api/system.windows.dataformats" MODIFIED="1557225479614" TEXT="DataFormats Class (System.Windows) | Microsoft Docs">
<node CREATED="1557224068597" ID="ID_1698463998" MODIFIED="1557224068597" TEXT="The DataObject class and other classes that implement the IDataObject interface use the static formats defined by DataFormats to describe each data format that&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1006940470" LINK="http://www.svds.com/dataformats/" MODIFIED="1557225479614" TEXT="Data Formats">
<node CREATED="1557224068597" ID="ID_1318907662" MODIFIED="1557224068597" TEXT="There are several data formats to choose from to load your data into the Hadoop Distributed File System (HDFS). Each of the data formats has its own strengths&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_759678416" LINK="https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.dataformats" MODIFIED="1557225479614" TEXT="DataFormats Class (System.Windows.Forms) | Microsoft Docs">
<node CREATED="1557224068597" ID="ID_65864721" MODIFIED="1557224068597" TEXT="DataFormats.Format myFormat = DataFormats.GetFormat(myFormat); /* Creates a new object and stores it in a DataObject using myFormat * as the type of&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1389381286" LINK="https://zapier.com/learn/apis/chapter-3-data-formats/" MODIFIED="1557225479614" TEXT="Chapter 3: Data Formats - An Introduction to APIs | Zapier">
<node CREATED="1557224068597" ID="ID_1512158902" MODIFIED="1557224068597" TEXT="Apr 22 2014  Read or Download Chapter 3: Data Formats from our An Introduction to APIs e-book for FREE and start learning today!" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_360546165" LINK="https://guides.library.oregonstate.edu/research-data-services/data-management-types-formats" MODIFIED="1557225479614" TEXT="Data Types  File Formats - Research Data Services - LibGuides at ">
<node CREATED="1557224068597" ID="ID_527176910" MODIFIED="1557224068597" TEXT="Apr 15 2019  The ETDplus project has published a File Formats guidance brief. It is a short how to document written for a student audience designed to&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1576621521" LINK="https://www.ibm.com/support/knowledgecenter/en/ssw_ibm_i_72/rzasd/dtdf.htm" MODIFIED="1557225479614" TEXT="Data Types and Data Formats">
<node CREATED="1557224068597" ID="ID_1834559160" MODIFIED="1557224068597" TEXT="This chapter describes the data types supported by RPG IV and their special characteristics. The supported data types are: Character Format &#183; Numeric Data&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_458794552" MODIFIED="1563517391360" TEXT="Elements of Machine Learning">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1121640281" MODIFIED="1563517391360" TEXT="Data formats">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068597" FOLDED="true" ID="ID_728531281" MODIFIED="1557225483422" TEXT="Elements of Machine Learning#$D$#">
<node CREATED="1557224068597" FOLDED="true" ID="ID_804965596" LINK="https://web.stanford.edu/~hastie/Papers/ESLII.pdf" MODIFIED="1557225479614" TEXT="The Elements of Statistical Learning">
<node CREATED="1557224068597" ID="ID_1604458616" MODIFIED="1557224068597" TEXT="The Elements of Statistical Learning  Support Vector Machines and. Flexible  &#8220;Kernel Smoothing Methods&#8221; to avoid confusion with the machine- learning&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1619162787" LINK="https://www.amazon.com/Elements-Statistical-Learning-Prediction-Statistics/dp/0387848576" MODIFIED="1557225479614" TEXT="Amazon.com: The Elements of Statistical Learning: Data Mining ">
<node CREATED="1557224068597" ID="ID_1520599102" MODIFIED="1557224068597" TEXT="Amazon.com: The Elements of Statistical Learning: Data Mining Inference and  Deep Learning (Adaptive Computation and Machine Learning series)." />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1767055907" LINK="http://web.stanford.edu/~hastie/ElemStatLearn/" MODIFIED="1557225479614" TEXT="Elements of Statistical Learning: data mining inference and ">
<node CREATED="1557224068597" ID="ID_973195575" MODIFIED="1557224068597" TEXT="The Elements of. Statistical Learning: Data Mining Inference and Prediction. Second Edition. February 2009. Trevor Hastie &#183; Robert Tibshirani." />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_62394165" LINK="https://www.itspmagazine.com/from-the-newsroom/machine-learning-and-the-5-key-elements-of-a-layered-defense" MODIFIED="1557225479614" TEXT="Machine Learning And The 5 Key Elements Of A Layered Defense ">
<node CREATED="1557224068597" ID="ID_1146099455" MODIFIED="1557224068597" TEXT="Mar 6 2018  While machine learning an application of artificial intelligence is not new customers still struggle to understand how it will benefit their efforts&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_114090055" LINK="https://www.datasciencecentral.com/profiles/blogs/elements-of-machine-learning" MODIFIED="1557225479614" TEXT="Elements of machine learning - Data Science Central">
<node CREATED="1557224068597" ID="ID_1050443966" MODIFIED="1557224068597" TEXT="Sep 29 2014  The official title of this free book available in PDF format is Machine Learning Cheat Sheet. But its more about elements of machine learning&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_834170350" LINK="https://machinelearningmastery.com/basic-concepts-in-machine-learning/" MODIFIED="1557225479614" TEXT="Basic Concepts in Machine Learning">
<node CREATED="1557224068597" ID="ID_1401569311" MODIFIED="1557224068597" TEXT="Dec 25 2015  Key Elements of Machine Learning. There are tens of thousands of machine learning algorithms and hundreds of new algorithms are&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_689590006" LINK="https://link.aps.org/doi/10.1103/PhysRevA.99.022110" MODIFIED="1557225479614" TEXT="Classifying superheavy elements by machine learning">
<node CREATED="1557224068597" ID="ID_1695258306" MODIFIED="1557224068597" TEXT="Feb 8 2019  By using cutting-edge machine learning techniques we find the relationship between atomic data and classification of elements and further&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1130946393" LINK="http://www-bcf.usc.edu/~gareth/ISL/" MODIFIED="1557225479614" TEXT="Introduction to Statistical Learning">
<node CREATED="1557224068597" ID="ID_676409397" MODIFIED="1557224068597" TEXT="Inspired by The Elements of Statistical Learning (Hastie Tibshirani and  As a textbook for an introduction to data science through machine learning there is&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1133618103" LINK="https://www.codingelements.com/course/ml" MODIFIED="1557225479614" TEXT="Machine Learning | Coding Elements">
<node CREATED="1557224068597" ID="ID_1952600728" MODIFIED="1557224068597" TEXT="How does this transform my career? Machine Learning is one of the hottest fields for elite tech jobs. Almost all large companies have a data science team." />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1107869411" LINK="https://www.elementai.com/" MODIFIED="1557225479614" TEXT="Element AI: Global AI Software Provider">
<node CREATED="1557224068597" ID="ID_1651609765" MODIFIED="1557224068597" TEXT="Element AI delivers products designed to help people work smarter and make businesses stronger safer and more agile. AI helps build and execute stronger&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_384202286" MODIFIED="1563517391360" TEXT="Learnability">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_524155393" MODIFIED="1563517391360" TEXT="Elements of Information Theory">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068597" FOLDED="true" ID="ID_692785531" MODIFIED="1557225483423" TEXT="Elements of Information Theory#$D$#">
<node CREATED="1557224068597" FOLDED="true" ID="ID_1905544750" LINK="https://www.amazon.com/Elements-Information-Theory-Telecommunications-Processing/dp/0471241954" MODIFIED="1557225479614" TEXT="Elements of Information Theory 2nd Edition (Wiley Series in ">
<node CREATED="1557224068597" ID="ID_1713515550" MODIFIED="1557224068597" TEXT="Elements of Information Theory 2nd Edition (Wiley Series in Telecommunications and Signal Processing) [Thomas M. Cover Joy A. Thomas] on Amazon.com." />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1733296795" LINK="http://www.cs-114.org/wp-content/uploads/2015/01/Elements_of_Information_Theory_Elements.pdf" MODIFIED="1557225479614" TEXT="Elements of Information Theory">
<node CREATED="1557224068597" ID="ID_1656413339" MODIFIED="1557224068597" TEXT="John Bellamy. Elements of Information Theory. Thomas M. Cover and Joy A. Thomas. Telecommunication System Engineering 2nd Edition. Roger L. Freeman." />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1941697406" LINK="http://staff.ustc.edu.cn/~cgong821/Wiley.Interscience.Elements.of.Information.Theory.Jul.2006.eBook-DDU.pdf" MODIFIED="1557225479614" TEXT="Elements of Information Theory (Wiley Series in ">
<node CREATED="1557224068597" ID="ID_1651927140" MODIFIED="1557224068597" TEXT="Elements of information theory/by Thomas M. Cover Joy A. Thomas.&#8211;2nd ed. p. cm. &#8220;A Wiley-Interscience publication.&#8221; Includes bibliographical references and&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_753907755" LINK="https://www.wiley.com/en-us/Elements+of+Information+Theory%2C+2nd+Edition-p-9780471241959" MODIFIED="1557225479614" TEXT="Elements of Information Theory 2nd Edition | Information ">
<node CREATED="1557224068597" ID="ID_403674018" MODIFIED="1557224068597" TEXT="All the essential topics in information theory are covered in detail including entropy data compression channel capacity rate distortion network information&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1323028843" LINK="https://dl.acm.org/citation.cfm?id=1146355" MODIFIED="1557225479614" TEXT="Elements of Information Theory (Wiley Series in ">
<node CREATED="1557224068597" ID="ID_381375627" MODIFIED="1557224068597" TEXT="Sep 29 2017  Yoichiro Watanabe  Koichi Kamoi A formulation of the channel capacity of multiple-access channel IEEE Transactions on Information Theory&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1481775299" LINK="https://archive.org/details/ElementsOfInformationTheory2ndEd" MODIFIED="1557225479614" TEXT="Elements Of Information Theory 2nd Ed : Thomas M. Cover Joy A ">
<node CREATED="1557224068597" ID="ID_1380676541" MODIFIED="1557224068597" TEXT="Mar 25 2017  Elements Of Information Theory 2nd EdWiley 2006 Thomas M. CoverJoy A. ThomasISBN-13 978-0-471-24195-9ISBN-10 0-471-24195-4." />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_163366019" LINK="https://www.amazon.in/Elements-Information-Theory-2ed-WILEY-Interscience/dp/8126541946" MODIFIED="1557225479614" TEXT="Buy Elements of Information Theory 2ed (WILEY-Interscience) Book ">
<node CREATED="1557224068597" ID="ID_591385523" MODIFIED="1557224068597" TEXT="Read Elements of Information Theory 2ed (WILEY-Interscience) book reviews  author details and more at Amazon.in. Free delivery on qualified orders." />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_942634522" LINK="https://www.goodreads.com/book/show/433439.Elements_of_Information_Theory" MODIFIED="1557225479614" TEXT="Elements of Information Theory by Thomas M. Cover">
<node CREATED="1557224068597" ID="ID_1033174983" MODIFIED="1557224068597" TEXT="Elements of Information Theory book. Read 9 reviews from the worlds largest community for readers. The latest edition of this classic is updated with ne" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_1658740575" LINK="https://onlinelibrary.wiley.com/doi/book/10.1002/047174882X" MODIFIED="1557225479614" TEXT="Elements of Information Theory | Wiley Online Books">
<node CREATED="1557224068597" ID="ID_855531279" MODIFIED="1557224068597" TEXT="Apr 7 2005  Share. Email; Facebook; Twitter; Linked In; Reddit; CiteULike. View Table of Contents for Elements of Information Theory&#160;" />
</node>
<node CREATED="1557224068597" FOLDED="true" ID="ID_302382903" LINK="http://www.elementsofinformationtheory.com/" MODIFIED="1557225479614" TEXT="Elements of Information Theory Second Edition 2006">
<node CREATED="1557224068597" ID="ID_1746633638" MODIFIED="1557224068597" TEXT="Elements of Information Theory 2nd Edition Thomas M. Cover Joy A. Thomas ISBN: 0-471-24195-4. Hardcover 776 pages. July 2006&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_402321144" MODIFIED="1563517391360" TEXT="Statistical Learning Approaches">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1426825221" MODIFIED="1563517391360" TEXT="Research Paper Map ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1641750420" MODIFIED="1563517391360" TEXT="Resources">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1273389358" MODIFIED="1563517391360" TEXT="Podcasts">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1400940697" MODIFIED="1563517391360" TEXT="Linear Disgressions ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
</node>
</node>
<node CREATED="1563517391360" FOLDED="true" Folded="true" ID="ID_1769910463" MODIFIED="1563517391360" POSITION="right" TEXT="Feature Selection">
<edge COLOR="#00cc33" />
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_714755836" MODIFIED="1563517391360" TEXT="Scikit-learn">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_617902190" MODIFIED="1563517391360" TEXT="Dataset">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1170775304" MODIFIED="1563517391360" TEXT="Creating training and test sets">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068598" FOLDED="true" ID="ID_1404356426" MODIFIED="1557225483434" TEXT="Creating training and test sets#$D$#">
<node CREATED="1557224068598" FOLDED="true" ID="ID_190070146" LINK="https://cran.r-project.org/web/packages/dataPreparation/vignettes/train_test_prep.html" MODIFIED="1557225479630" TEXT="Tutorial to prepare train and test set using dataPreparation">
<node CREATED="1557224068598" ID="ID_1863659892" MODIFIED="1557224068598" TEXT="Mar 25 2019  This vignette is a tutorial to prepare a train and a test set using . Even if its not kept in the log a progress bar has been created to see if the&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1118881845" LINK="https://towardsdatascience.com/train-validation-and-test-sets-72cb40cba9e7" MODIFIED="1557225479630" TEXT="About Train Validation and Test Sets in Machine Learning">
<node CREATED="1557224068598" ID="ID_1987167801" MODIFIED="1557224068598" TEXT="Dec 6 2017  About Train Validation and Test Sets in Machine Learning  Training Dataset: The sample of data used to fit the model. . Generally when you design or create a new model it helps to keep a separate test and validation set." />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1479070369" LINK="https://stackoverflow.com/questions/17200114/how-to-split-data-into-training-testing-sets-using-sample-function" MODIFIED="1557225479630" TEXT="How to split data into training/testing sets using sample function ">
<node CREATED="1557224068598" ID="ID_1510274477" MODIFIED="1557224068598" TEXT="bound - floor((nrow(df)/4)*3) #define % of training and test set df  is a good idea anyway not only for creating sets but also for traceability during your project." />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_727329082" LINK="https://medium.com/@HollyEmblem/training-and-test-dataset-creation-with-dplyr-41d9aa7eab31" MODIFIED="1557225479630" TEXT="Training and test dataset creation with dplyr &#8211; Holly Emblem &#8211; Medium">
<node CREATED="1557224068598" ID="ID_1081723083" MODIFIED="1557224068598" TEXT="Jul 7 2018  If youre prototyping models for machine learning then chances are you might need to create training and test sets from your existing dataset." />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_992806441" LINK="https://www.youtube.com/watch?v=uiDFa7iY9yo" MODIFIED="1557225479630" TEXT="Weka Tutorial 35: Creating Training Validation and Test Sets (Data ">
<node CREATED="1557224068598" ID="ID_1891443776" MODIFIED="1557224068598" TEXT="Jan 20 2014  The tutorial that demonstrates how to create training test and cross validation sets from a given dataset." />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_493579100" LINK="https://www.youtube.com/watch?v=fwY9Qv96DJY" MODIFIED="1557225479630" TEXT="Machine Learning Tutorial Python - 7: Training and Testing Data ">
<node CREATED="1557224068598" ID="ID_89107612" MODIFIED="1557224068598" TEXT="Aug 9 2018  This way you can train and test on seperate datasets.  Weka Tutorial 35: Creating Training Validation and Test Sets (Data Preprocessing)&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1626538934" LINK="https://docs.microsoft.com/en-us/sql/analysis-services/data-mining/training-and-testing-data-sets" MODIFIED="1557225479630" TEXT="Training and Testing Data Sets | Microsoft Docs">
<node CREATED="1557224068598" ID="ID_227810775" MODIFIED="1557224068598" TEXT="The information about the size of the training and testing data sets and which&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1499810089" LINK="https://developers.google.com/machine-learning/crash-course/training-and-test-sets/splitting-data" MODIFIED="1557225479630" TEXT="Training and Test Sets: Splitting Data | Machine Learning Crash ">
<node CREATED="1557224068598" ID="ID_1740433812" MODIFIED="1557224068598" TEXT="Mar 5 2019  Assuming that your test set meets the preceding two conditions your goal is to create a model that generalizes well to new data. Our test set&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1276287190" LINK="https://www.fast.ai/2017/11/13/validation-sets/" MODIFIED="1557225479630" TEXT="How (and why) to create a good validation set &#183; fast.ai">
<node CREATED="1557224068598" ID="ID_1561247041" MODIFIED="1557224068598" TEXT="Nov 13 2017  Kaggle only provides training and test sets yet to do well you will need to split their training set into your own validation and training sets. Also&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_244943393" MODIFIED="1563517391360" TEXT="Managing Categorical data">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068598" FOLDED="true" ID="ID_1903157067" MODIFIED="1557225483434" TEXT="Managing Categorical data#$D$#">
<node CREATED="1557224068598" FOLDED="true" ID="ID_189976170" LINK="https://www.datacamp.com/community/tutorials/categorical-data" MODIFIED="1557225479630" TEXT="Handling Categorical Data in Python (article) - DataCamp">
<node CREATED="1557224068598" ID="ID_775577568" MODIFIED="1557224068598" TEXT="May 22 2018  Learn the common tricks to handle categorical data and preprocess it to build machine learning models!" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1482491737" LINK="https://towardsdatascience.com/understanding-feature-engineering-part-2-categorical-data-f54324193e63" MODIFIED="1557225479630" TEXT="Categorical Data &#8211; Towards Data Science">
<node CREATED="1557224068598" ID="ID_466826450" MODIFIED="1557224068598" TEXT="Jan 6 2018  In this article we will look at another type of structured data which is discrete in nature and is popularly termed as categorical data. Dealing&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1077832399" LINK="https://www.analyticsvidhya.com/blog/2015/11/easy-methods-deal-categorical-variables-predictive-modeling/" MODIFIED="1557225479630" TEXT="Simple Methods to deal with Categorical Variables in Predictive ">
<node CREATED="1557224068598" ID="ID_1460111830" MODIFIED="1557224068598" TEXT="Nov 26 2015  Here are simple methods to treat categorical variables in a data set and their various levels using label encoding dummy one hot encoding." />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_873759842" LINK="https://www.pluralsight.com/guides/handling-categorical-data-in-machine-learning-models" MODIFIED="1557225479630" TEXT="Handling Categorical Data in Machine Learning Models | Pluralsight">
<node CREATED="1557224068598" ID="ID_1280659462" MODIFIED="1557224068598" TEXT="Feb 20 2019  Categorical Data is the data that generally takes a limited number of possible values. Also the data in the category need not be numerical&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1148303835" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781785889622/3/ch03lvl1sec22/managing-categorical-data" MODIFIED="1557225479630" TEXT="Managing categorical data - Machine Learning Algorithms">
<node CREATED="1557224068598" ID="ID_1739506816" MODIFIED="1557224068598" TEXT="Managing categorical dataIn many classification problems the target dataset is made up of categorical labels which cannot imm" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_170317647" LINK="http://www.real-statistics.com/logistic-regression/handling-categorical-data/" MODIFIED="1557225479630" TEXT="Handling Categorical Data | Real Statistics Using Excel">
<node CREATED="1557224068598" ID="ID_335509094" MODIFIED="1557224068598" TEXT="Describes how to code categorical data in Excel especially for logistic regression." />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1512369957" LINK="https://www.talentica.com/blogs/handling-categorical-features-in-machine-learning/" MODIFIED="1557225479630" TEXT="Handling Categorical Features in Machine Learning | Talentica Blog">
<node CREATED="1557224068598" ID="ID_889216886" MODIFIED="1557224068598" TEXT="Mar 21 2017  Introduction: Every dataset has two type of variables Continuous(Numerical) and Categorical. Regression based algorithms use continuous&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1534170159" LINK="https://blog.myyellowroad.com/using-categorical-data-in-machine-learning-with-python-from-dummy-variables-to-deep-category-66041f734512" MODIFIED="1557225479630" TEXT="Using categorical data in machine learning with python: from dummy ">
<node CREATED="1557224068598" ID="ID_1270236948" MODIFIED="1557224068598" TEXT="Sep 19 2017  Categorical data is very common in business datasets for example users are typically described by country gender age group etc. products&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_831665477" LINK="https://www.youtube.com/watch?v=ZRWHjdIZyxo" MODIFIED="1557225479630" TEXT="Data management: How to convert categorical string variables to ">
<node CREATED="1557224068598" ID="ID_388623330" MODIFIED="1557224068598" TEXT="Dec 1 2016  This video demonstrates how to convert categorical string variables to labeled numeric variables. Copyright 2011-2017 StataCorp LLC." />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1987974829" LINK="https://www.kaggle.com/c/titanic/discussion/5379" MODIFIED="1557225479630" TEXT="Handling categorical data with sklearn. | Kaggle">
<node CREATED="1557224068598" ID="ID_935184886" MODIFIED="1557224068598" TEXT="I use sklearn(scikit-learn) package in python. In sklearn I cannot directly put categorical column Sex which has string like male and female. So I have to&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1823632424" MODIFIED="1563517391360" TEXT="Managing Missing features">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068598" FOLDED="true" ID="ID_752729996" MODIFIED="1557225483434" TEXT="Managing Missing features#$D$#">
<node CREATED="1557224068598" FOLDED="true" ID="ID_1771177161" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781785889622/3/ch03lvl1sec23/managing-missing-features" MODIFIED="1557225479630" TEXT="Managing missing features - Machine Learning Algorithms">
<node CREATED="1557224068598" ID="ID_1853918770" MODIFIED="1557224068598" TEXT="Managing missing featuresSometimes a dataset can contain missing features so there are a few options that can be taken into a" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_33557853" LINK="https://towardsdatascience.com/how-to-handle-missing-data-8646b18db0d4" MODIFIED="1557225479630" TEXT="How to Handle Missing Data &#8211; Towards Data Science">
<node CREATED="1557224068598" ID="ID_1196115677" MODIFIED="1557224068598" TEXT="Jan 30 2018   faced in Data Cleaning/Exploratory Analysis is handling the missing values.  rows which have a feature to fill in each rows missing features" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_719361307" LINK="https://www.analyticsindiamag.com/5-ways-handle-missing-values-machine-learning-datasets/" MODIFIED="1557225479630" TEXT="5 Ways To Handle Missing Values In Machine Learning Datasets">
<node CREATED="1557224068598" ID="ID_878059704" MODIFIED="1557224068598" TEXT="Feb 9 2018  Handling the missing values is one of the greatest challenges faced by  This strategy can be applied on a feature which has numeric data like&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_373746330" LINK="https://medium.com/all-things-product-management/the-difficulty-of-feature-parity-9dafa4bc0b16" MODIFIED="1557225479630" TEXT="The Difficulty of &#8220;Feature Parity&#8221; &#8211; All Things Product Management ">
<node CREATED="1557224068598" ID="ID_902294618" MODIFIED="1557224068598" TEXT="Feb 12 2017  &#8220;What happens if we get bad PR about missing feature X?&#8221; or leaderships requirements  Managing Feature Parity During a Product Rewrite." />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1930029077" LINK="https://www.oreilly.com/library/view/machine-learning-algorithms/9781789347999/72fd6808-8b76-4c9c-91ff-7f13502e752f.xhtml" MODIFIED="1557225479630" TEXT="Managing missing features - Machine Learning Algorithms - Second ">
<node CREATED="1557224068598" ID="ID_671417330" MODIFIED="1557224068598" TEXT="Managing missing features Sometimes a dataset can contain missing features so there are a few options that can be taken into account: Removing the whole&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1766849122" LINK="https://help.figma.com/article/250-working-with-fonts" MODIFIED="1557225479630" TEXT="Working with Fonts - Figma">
<node CREATED="1557224068598" ID="ID_388018490" MODIFIED="1557224068598" TEXT="In this article well cover: Applying Fonts; Using Local Fonts; Using Icon Fonts; Using OpenType Features; Managing Missing Fonts; Writing in Other Languages&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_274622915" LINK="https://www.youtube.com/watch?v=9agiwBvCpHA" MODIFIED="1557225479630" TEXT="Managing Missing Features Explained with Examples in Hindi ll ">
<node CREATED="1557224068598" ID="ID_647712235" MODIFIED="1557224068598" TEXT="Mar 9 2019  Managing Missing Features Explained with Examples in Hindi ll Machine Learning Course. 5 Minutes Engineering. Loading Unsubscribe&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1816225155" LINK="https://about.gitlab.com/features/" MODIFIED="1557225479630" TEXT="Features | GitLab">
<node CREATED="1557224068598" ID="ID_376931344" MODIFIED="1557224068598" TEXT=" authentication and more. You can manage an entire GitLab instance through the LDAP / AD integration.  Authentication and Authorization - Missing Features&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1880782310" LINK="https://www.kaggle.com/dansbecker/handling-missing-values" MODIFIED="1557225479630" TEXT="Handling Missing Values | Kaggle">
<node CREATED="1557224068598" ID="ID_899767684" MODIFIED="1557224068598" TEXT="2019 Kaggle Inc. Our Team Terms Privacy Contact/Support." />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_38640041" LINK="https://www.coworkingnext.com/features" MODIFIED="1557225479630" TEXT="MISSING: app.Features that Make Managing Coworking Spaces ">
<node CREATED="1557224068598" ID="ID_152765176" MODIFIED="1557224068598" TEXT="Best in class features including automated invoicing online payments resource management members directory calendar and more." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_267412613" MODIFIED="1563517391360" TEXT="Data scaling and normalization">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068598" FOLDED="true" ID="ID_737735452" MODIFIED="1557225483434" TEXT="Data scaling and normalization#$D$#">
<node CREATED="1557224068598" FOLDED="true" ID="ID_1532765916" LINK="https://stats.stackexchange.com/questions/35591/normalization-vs-scaling" MODIFIED="1557225479630" TEXT="data transformation - Normalization vs. scaling - Cross Validated">
<node CREATED="1557224068599" ID="ID_693888894" MODIFIED="1557224068599" TEXT="Normalizing can either mean applying a transformation so that you  I also see people using the term Normalization for Data Scaling as in&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_495089035" LINK="https://kharshit.github.io/blog/2018/03/23/scaling-vs-normalization" MODIFIED="1557225479630" TEXT="Scaling vs Normalization">
<node CREATED="1557224068599" ID="ID_1591110531" MODIFIED="1557224068599" TEXT="Mar 23 2018  Feature scaling (also known as data normalization) is the method used to standardize the range of features of data. Since the range of values&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1058063843" LINK="https://www.kaggle.com/rtatman/data-cleaning-challenge-scale-and-normalize-data" MODIFIED="1557225479630" TEXT="Data Cleaning Challenge: Scale and Normalize Data | Kaggle">
<node CREATED="1557224068599" ID="ID_599627162" MODIFIED="1557224068599" TEXT="Context. Im a crowdfunding enthusiast and im watching kickstarter since its early days. Right now I just collect data and the only app ive made is this twitter bot&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1848485952" LINK="https://sebastianraschka.com/Articles/2014_about_feature_scaling.html" MODIFIED="1557225479630" TEXT="About Feature Scaling and Normalization">
<node CREATED="1557224068599" ID="ID_1740118394" MODIFIED="1557224068599" TEXT="Jul 11 2014  The result of standardization (or Z-score normalization) is that the features  In this approach the data is scaled to a fixed range - usually 0 to 1." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1061128191" LINK="https://en.wikipedia.org/wiki/Feature_scaling" MODIFIED="1557225479630" TEXT="Feature scaling - Wikipedia">
<node CREATED="1557224068599" ID="ID_1802714768" MODIFIED="1557224068599" TEXT=" as min-max scaling or min-max normalization is the  the target range depends on the nature of the data." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1526015938" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781785889622/3/ch03lvl1sec24/data-scaling-and-normalization" MODIFIED="1557225479630" TEXT="Data scaling and normalization - Machine Learning Algorithms">
<node CREATED="1557224068599" ID="ID_550620472" MODIFIED="1557224068599" TEXT="Data scaling and normalizationA generic dataset (we assume here that it is always numerical) is made up of different values wh" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_514997329" LINK="https://medium.com/@rrfd/standardize-or-normalize-examples-in-python-e3f174b65dfc" MODIFIED="1557225479630" TEXT="Standardize or Normalize? &#8212; Examples in Python &#8211; Robert R.F. ">
<node CREATED="1557224068599" ID="ID_1561178444" MODIFIED="1557224068599" TEXT="Apr 29 2018  Normalization makes training less sensitive to the scale of features  Or the scale between your data features does matters so you want to&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1789768742" LINK="https://towardsdatascience.com/scale-standardize-or-normalize-with-scikit-learn-6ccc7d176a02" MODIFIED="1557225479630" TEXT="Scale Standardize or Normalize with Scikit-Learn &#8211; Towards Data ">
<node CREATED="1557224068599" ID="ID_1411963885" MODIFIED="1557224068599" TEXT="Mar 4 2019  Many machine learning algorithms work better when features are on a relatively similar scale and close to normally distributed. MinMaxScaler&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_490962163" LINK="https://en.wikipedia.org/wiki/Normalization_(statistics)" MODIFIED="1557225479630" TEXT="Normalization (statistics) - Wikipedia">
<node CREATED="1557224068599" ID="ID_1276942368" MODIFIED="1557224068599" TEXT="In statistics and applications of statistics normalization can have a range of meanings. In the simplest cases normalization of ratings means adjusting values measured on different scales to a notionally common scale  when parameters are estimated particularly across different data points in regression analysis." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1898041330" LINK="http://datareality.blogspot.com/2016/11/scaling-normalizing-standardizing-which.html" MODIFIED="1557225479630" TEXT="Scaling? Normalizing/? Standardizing? Which do I use when? | Data ">
<node CREATED="1557224068599" ID="ID_1295636349" MODIFIED="1557224068599" TEXT="Nov 29 2016  Whats the difference between scaling to 0 and 1 taking a unit norm or z score? Ive been taught all of these to normalize data but dont know&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_35838212" MODIFIED="1563517391360" TEXT="Feature Selection and Filtering">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068598" FOLDED="true" ID="ID_457758042" MODIFIED="1557225483423" TEXT="Feature Selection#$D$#">
<node CREATED="1557224068598" FOLDED="true" ID="ID_1507637636" LINK="https://en.wikipedia.org/wiki/Feature_selection" MODIFIED="1557225479630" TEXT="Feature selection - Wikipedia">
<node CREATED="1557224068598" ID="ID_671589642" MODIFIED="1557224068598" TEXT="In machine learning and statistics feature selection also known as variable selection attribute selection or variable subset selection is the process of selecting&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_194571426" LINK="http://scikit-learn.org/stable/modules/feature_selection.html" MODIFIED="1557225479630" TEXT="1.13. Feature selection &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068598" ID="ID_858849307" MODIFIED="1557224068598" TEXT="The classes in the sklearn.feature_selection module can be used for feature selection/dimensionality reduction on sample sets either to improve estimators&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1266133535" LINK="https://towardsdatascience.com/feature-selection-techniques-in-machine-learning-with-python-f24e7da3f36e" MODIFIED="1557225479630" TEXT="Feature Selection Techniques in Machine Learning with Python">
<node CREATED="1557224068598" ID="ID_482416267" MODIFIED="1557224068598" TEXT="Oct 27 2018  Feature Selection is one of the core concepts in machine learning which hugely impacts the performance of your model. The data features that&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_838953473" LINK="https://machinelearningmastery.com/an-introduction-to-feature-selection/" MODIFIED="1557225479630" TEXT="An Introduction to Feature Selection">
<node CREATED="1557224068598" ID="ID_359743196" MODIFIED="1557224068598" TEXT="Oct 6 2014  It is possible to automatically select those features in your data that are most useful or most relevant for the problem you are working on. This is&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_40658732" LINK="https://www.cs.cmu.edu/~kdeng/thesis/feature.pdf" MODIFIED="1557225479630" TEXT="Chapter 7 Feature Selection">
<node CREATED="1557224068598" ID="ID_658764658" MODIFIED="1557224068598" TEXT="Feature selection is not used in the system classification experiments which will  However as an autonomous system OMEGA includes feature selection as." />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1453608247" LINK="https://www.analyticsvidhya.com/blog/2016/12/introduction-to-feature-selection-methods-with-an-example-or-how-to-select-the-right-variables/" MODIFIED="1557225479630" TEXT="Feature Selection methods with example (Variable selection methods)">
<node CREATED="1557224068598" ID="ID_1506147719" MODIFIED="1557224068598" TEXT="Dec 1 2016  This article is on feature selection used to build an effective predictive model. Learn about flitter method wrapper method and embedded&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_514742408" LINK="https://www.machinelearningplus.com/machine-learning/feature-selection/" MODIFIED="1557225479630" TEXT="Feature Selection - Ten Effective Techniques with Examples | ML+">
<node CREATED="1557224068598" ID="ID_1128660552" MODIFIED="1557224068598" TEXT="In machine learning Feature selection is the process of choosing variables that are useful in predicting the response (Y). It is considered a good practice to&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_822230787" LINK="https://www.techopedia.com/definition/32755/feature-selection" MODIFIED="1557225479630" TEXT="What is Feature Selection? - Definition from Techopedia">
<node CREATED="1557224068598" ID="ID_84739575" MODIFIED="1557224068598" TEXT="With feature selection engineers and data scientists are able to tune out a lot of the &#8220;noise&#8221; in a given system. Using feature selection helps to discard redundant&#160;" />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_1645427502" LINK="https://www.youtube.com/watch?v=YaKMeAlHgqQ" MODIFIED="1557225479630" TEXT="How do I select features for Machine Learning? - YouTube">
<node CREATED="1557224068598" ID="ID_523188389" MODIFIED="1557224068598" TEXT="Nov 13 2018  Selecting the best features for your Machine Learning model will result in a better performing easier to understand and faster running model." />
</node>
<node CREATED="1557224068598" FOLDED="true" ID="ID_439583169" LINK="https://www.datacamp.com/community/tutorials/feature-selection-python" MODIFIED="1557225479630" TEXT="Beginners Guide to Feature Selection in Python (article) - DataCamp">
<node CREATED="1557224068598" ID="ID_433766269" MODIFIED="1557224068598" TEXT="Sep 25 2018  Learn about the basics of feature selection and how to implement and investigate various feature selection techniques in Python." />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_819590017" MODIFIED="1557225483434" TEXT="Feature Selection and Filtering#$D$#">
<node CREATED="1557224068599" FOLDED="true" ID="ID_1043940545" LINK="https://en.wikipedia.org/wiki/Feature_selection" MODIFIED="1557225479630" TEXT="Feature selection - Wikipedia">
<node CREATED="1557224068599" ID="ID_1692974043" MODIFIED="1557224068599" TEXT="Filter Method for feature selection. Filter type methods select variables regardless of the model. They are based only on general&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_174381689" LINK="https://machinelearningmastery.com/an-introduction-to-feature-selection/" MODIFIED="1557225479630" TEXT="An Introduction to Feature Selection">
<node CREATED="1557224068599" ID="ID_1722659285" MODIFIED="1557224068599" TEXT="Oct 6 2014  Filter feature selection methods apply a statistical measure to assign a scoring to each feature. The features are ranked by the score and either&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1640531063" LINK="https://docs.microsoft.com/en-us/azure/machine-learning/studio-module-reference/filter-based-feature-selection" MODIFIED="1557225479630" TEXT="Filter Based Feature Selection - Azure Machine Learning Studio ">
<node CREATED="1557224068599" ID="ID_1648370080" MODIFIED="1557224068599" TEXT="Jan 16 2018  This article describes how to use the Filter Based Feature Selection module in Azure Machine Learning Studio to identify the columns in your&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_920414474" LINK="https://www.analyticsvidhya.com/blog/2016/12/introduction-to-feature-selection-methods-with-an-example-or-how-to-select-the-right-variables/" MODIFIED="1557225479630" TEXT="Feature Selection methods with example (Variable selection methods)">
<node CREATED="1557224068599" ID="ID_695659398" MODIFIED="1557224068599" TEXT="Dec 1 2016  Filter methods are generally used as a preprocessing step. The selection of features is independent of any machine learning algorithms." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_394478098" LINK="https://www.youtube.com/watch?v=UOadhDKRbPM" MODIFIED="1557225479630" TEXT="Weka Tutorial 10: Feature Selection with Filter (Data Dimensionality ">
<node CREATED="1557224068599" ID="ID_1011841226" MODIFIED="1557224068599" TEXT="Jun 6 2012  This tutorial shows how to select features from a set of features that performs best with a classification algorithm using filter method." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_765687916" LINK="https://stackabuse.com/applying-filter-methods-in-python-for-feature-selection/" MODIFIED="1557225479630" TEXT="Applying Filter Methods in Python for Feature Selection">
<node CREATED="1557224068599" ID="ID_1542467301" MODIFIED="1557224068599" TEXT="Oct 30 2018  One category of such methods is called filter methods. In this article we will study some of the basic filter methods for feature selection." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_426675873" LINK="https://topepo.github.io/caret/feature-selection-using-univariate-filters.html" MODIFIED="1557225479630" TEXT="19 Feature Selection using Univariate Filters | The caret Package">
<node CREATED="1557224068599" ID="ID_1255199426" MODIFIED="1557224068599" TEXT="The caret function sbf (for selection by filter) can be used to cross-validate such feature selection schemes. Similar to rfe  functions can be passed into sbf for the&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_188153576" LINK="https://mlr.mlr-org.com/articles/tutorial/feature_selection.html" MODIFIED="1557225479630" TEXT="Feature Selection &#8226; mlr">
<node CREATED="1557224068599" ID="ID_32389750" MODIFIED="1557224068599" TEXT="In the literature two different approaches exist: One is called &#8220;Filtering&#8221; and the other approach is often referred to as &#8220;feature subset selection&#8221; or &#8220;wrapper&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1827981944" LINK="https://sebastianraschka.com/faq/docs/feature_sele_categories.html" MODIFIED="1557225479630" TEXT="What is the difference between filter wrapper and embedded ">
<node CREATED="1557224068599" ID="ID_1095176928" MODIFIED="1557224068599" TEXT="In contrast the filter methods pick up the intrinsic properties of the features (i.e.  recursive feature elimination; sequential feature selection algorithms; genetic&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_905991235" LINK="http://dl.ifip.org/db/conf/ideal/ideal2007/Sanchez-MaronoAT07.pdf" MODIFIED="1557225479630" TEXT="Filter Methods for Feature Selection - A Comparative Study.">
<node CREATED="1557224068599" ID="ID_1310590500" MODIFIED="1557224068599" TEXT="Filter methods for feature selection. A comparative study *. Noelia S&#225;nchez-Maro&#732;no Amparo Alonso-Betanzos and Mar&#305;a. Tombilla-Sanrom&#225;n. University of A&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_114737170" MODIFIED="1563517391360" TEXT="Principal Component Analysis">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1235406897" MODIFIED="1563517391360" TEXT="Non negative matrix factorization">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068599" FOLDED="true" ID="ID_1103589671" MODIFIED="1557225483434" TEXT="Principal Component Analysis#$D$#">
<node CREATED="1557224068599" FOLDED="true" ID="ID_18130387" LINK="https://en.wikipedia.org/wiki/Principal_component_analysis" MODIFIED="1557225479630" TEXT="Principal component analysis - Wikipedia">
<node CREATED="1557224068599" ID="ID_1039958546" MODIFIED="1557224068599" TEXT="Principal component analysis (PCA) is a statistical procedure that uses an orthogonal transformation to convert a set of observations of possibly correlated&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_176871539" LINK="http://setosa.io/ev/principal-component-analysis/" MODIFIED="1557225479630" TEXT="Principal Component Analysis explained visually">
<node CREATED="1557224068599" ID="ID_658426074" MODIFIED="1557224068599" TEXT="Principal component analysis (PCA) is a technique used to emphasize variation and bring out strong patterns in a dataset. Its often used to make data easy to&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1058819658" LINK="https://towardsdatascience.com/a-one-stop-shop-for-principal-component-analysis-5582fb7e0a9c" MODIFIED="1557225479630" TEXT="A One-Stop Shop for Principal Component Analysis &#8211; Towards Data ">
<node CREATED="1557224068599" ID="ID_1344900427" MODIFIED="1557224068599" TEXT="Apr 17 2017  Principal component analysis is a technique for feature extraction &#8212; so it combines our input variables in a specific way then we can drop the&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1998865201" LINK="ftp://statgen.ncsu.edu/pub/thorne/molevoclass/AtchleyOct19.pdf" MODIFIED="1557225479630" TEXT="Principal Component Analysis">
<node CREATED="1557224068599" ID="ID_1554435667" MODIFIED="1557224068599" TEXT="Principal component analysis (PCA) is a mathematical procedure that transforms a number of (possibly) correlated variables into a (smaller) number of." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_692728301" LINK="https://www.youtube.com/watch?v=HMOI_lkzW08" MODIFIED="1557225479630" TEXT="StatQuest: PCA main ideas in only 5 minutes!!! - YouTube">
<node CREATED="1557224068599" ID="ID_1685136454" MODIFIED="1557224068599" TEXT="Dec 4 2017  The main ideas behind PCA are actually super simple and that means its easy to interpret a PCA plot: Samples that are correlated will cluster together apart  StatQuest: Principal Component Analysis (PCA) Step-by-Step&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_989556791" LINK="https://www.nature.com/articles/nmeth.4346" MODIFIED="1557225479630" TEXT="Principal component analysis | Nature Methods">
<node CREATED="1557224068599" ID="ID_379371581" MODIFIED="1557224068599" TEXT="Jun 29 2017  Principal component analysis (PCA) simplifies the complexity in high-dimensional data while retaining trends and patterns. It does this by&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_75193029" LINK="https://www.youtube.com/watch?v=FgakZw6K1QQ" MODIFIED="1557225479630" TEXT="StatQuest: Principal Component Analysis (PCA) Step-by-Step ">
<node CREATED="1557224068599" ID="ID_1082871628" MODIFIED="1557224068599" TEXT="Apr 2 2018  Principal Component Analysis is one of the most useful data analysis and machine learning methods out there. It can be used to identify&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_795043299" LINK="https://www.utdallas.edu/~herve/abdi-awPCA2010.pdf" MODIFIED="1557225479630" TEXT="Principal component analysis">
<node CREATED="1557224068599" ID="ID_808839102" MODIFIED="1557224068599" TEXT="Principal component analysis (PCA) is a multivariate technique that analyzes a data  The quality of the PCA model can be evaluated using cross-validation." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1176160221" LINK="https://www.springer.com/us/book/9780387954424" MODIFIED="1557225479630" TEXT="Principal Component Analysis | I.T. Jolliffe | Springer">
<node CREATED="1557224068599" ID="ID_1071735586" MODIFIED="1557224068599" TEXT="Principal component analysis is central to the study of multivariate data. Although one of the earliest multivariate techniques it continues to be the subject of&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_177636044" LINK="https://newonlinecourses.science.psu.edu/stat505/node/49/" MODIFIED="1557225479630" TEXT="Lesson 11: Principal Components Analysis (PCA) | STAT 505">
<node CREATED="1557224068599" ID="ID_672159379" MODIFIED="1557224068599" TEXT="Printer-friendly version. Introduction. Sometimes data are collected on a large number of variables from a single population. As an example consider the Places&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1270031287" MODIFIED="1557225483435" TEXT="Non negative matrix factorization#$D$#">
<node CREATED="1557224068599" FOLDED="true" ID="ID_1090813714" LINK="https://en.wikipedia.org/wiki/Non-negative_matrix_factorization" MODIFIED="1557225479630" TEXT="Non-negative matrix factorization - Wikipedia">
<node CREATED="1557224068599" ID="ID_232942632" MODIFIED="1557224068599" TEXT="Non-negative matrix factorization (NMF or NNMF) also non-negative matrix approximation is a group of algorithms in multivariate analysis and linear algebra&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1398795186" LINK="http://mlexplained.com/2017/12/28/a-practical-introduction-to-nmf-nonnegative-matrix-factorization/" MODIFIED="1557225479630" TEXT="A Practical Introduction to NMF (nonnegative matrix factorization ">
<node CREATED="1557224068599" ID="ID_1071152753" MODIFIED="1557224068599" TEXT="Dec 28 2017  NMF (Nonnegative Matrix Factorization) is a matrix factorization method where we constrain the matrices to be nonnegative. In order to&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_834537504" LINK="https://blog.acolyer.org/2019/02/18/the-why-and-how-of-nonnegative-matrix-factorization/" MODIFIED="1557225479630" TEXT="The why and how of nonnegative matrix factorization | the morning ">
<node CREATED="1557224068599" ID="ID_1432092677" MODIFIED="1557224068599" TEXT="Feb 18 2019  NMF was first introduced by Paatero andTapper in 1994 and popularised in a article by Lee and Seung in 1999. Since then the number of&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_419096403" LINK="https://papers.nips.cc/paper/1861-algorithms-for-non-negative-matrix-factorization.pdf" MODIFIED="1557225479630" TEXT="Algorithms for Non-negative Matrix Factorization">
<node CREATED="1557224068599" ID="ID_619673278" MODIFIED="1557224068599" TEXT="Non-negative matrix factorization (NMF) has previously been shown to be a useful decomposition for multivariate data. Two different multi- plicative algorithms&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_768807411" LINK="https://arxiv.org/abs/1401.5226" MODIFIED="1557225479630" TEXT="The Why and How of Nonnegative Matrix Factorization">
<node CREATED="1557224068599" ID="ID_554078836" MODIFIED="1557224068599" TEXT="Jan 21 2014  We first illustrate this property of NMF on three applications in image  and computer science closely related to NMF via the nonnegative rank." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1815405385" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.decomposition.NMF.html" MODIFIED="1557225479630" TEXT="sklearn.decomposition.NMF &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068599" ID="ID_1214674872" MODIFIED="1557224068599" TEXT="Non-Negative Matrix Factorization (NMF). Find two non-negative matrices (W H) whose product approximates the non- negative matrix X. This factorization can&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1578446888" LINK="http://www.jmlr.org/papers/volume5/hoyer04a/hoyer04a.pdf" MODIFIED="1557225479630" TEXT="Non-negative Matrix Factorization with Sparseness Constraints">
<node CREATED="1557224068599" ID="ID_1352385119" MODIFIED="1557224068599" TEXT="Abstract. Non-negative matrix factorization (NMF) is a recently developed technique for finding parts-based linear representations of non-negative data." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_472078431" LINK="https://www.youtube.com/watch?v=UQGEB3Q5-fQ" MODIFIED="1557225479630" TEXT="10701: Non-Negative Matrix Factorization - YouTube">
<node CREATED="1557224068599" ID="ID_556337376" MODIFIED="1557224068599" TEXT="Dec 11 2013  This is an extra credit assignment for the class 10-701 at Carnegie Mellon University. Here are my sources:&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_755638200" LINK="https://docs.oracle.com/cd/B28359_01/datamine.111/b28129/algo_nmf.htm" MODIFIED="1557225479630" TEXT="Non-Negative Matrix Factorization">
<node CREATED="1557224068599" ID="ID_106362966" MODIFIED="1557224068599" TEXT="About NMF. Non-negative Matrix Factorization (NMF) is a state of the art feature extraction algorithm. NMF is useful when there are many attributes and the&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1847411711" LINK="http://statweb.stanford.edu/~tibs/sta306bfiles/nnmf.pdf" MODIFIED="1557225479630" TEXT="Non-negative matrix factorization">
<node CREATED="1557224068599" ID="ID_176899831" MODIFIED="1557224068599" TEXT="Figure 1 Non-negative matrix factorization (NMF) learns a parts-based representation of faces whereas vector quantization (VQ) and principal components&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_198096891" MODIFIED="1563517391360" TEXT="Sparse PCA">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068599" FOLDED="true" ID="ID_1337827623" MODIFIED="1557225483435" TEXT="Sparse PCA#$D$#">
<node CREATED="1557224068599" FOLDED="true" ID="ID_186701612" LINK="https://web.stanford.edu/~hastie/Papers/spc_jcgs.pdf" MODIFIED="1557225479630" TEXT="Sparse Principal Component Analysis">
<node CREATED="1557224068599" ID="ID_263706030" MODIFIED="1557224068599" TEXT="introduce a new method called sparse principal component analysis (SPCA)  that PCA can be formulated as a regression-type optimization problem; sparse&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_141282387" LINK="https://en.wikipedia.org/wiki/Sparse_PCA" MODIFIED="1557225479630" TEXT="Sparse PCA - Wikipedia">
<node CREATED="1557224068599" ID="ID_798472577" MODIFIED="1557224068599" TEXT="Sparse principal component analysis (sparse PCA) is a specialised technique used in statistical analysis and in particular in the analysis of multivariate data&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_907271570" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.decomposition.SparsePCA.html" MODIFIED="1557225479630" TEXT="sklearn.decomposition.SparsePCA &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068599" ID="ID_1078574170" MODIFIED="1557224068599" TEXT="Sparse Principal Components Analysis (SparsePCA). Finds the set of sparse components that can optimally reconstruct the data. The amount of sparseness is&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_560945773" LINK="https://projecteuclid.org/euclid.aos/1388545679" MODIFIED="1557225479630" TEXT="Cai  Ma  Wu : Sparse PCA: Optimal rates and adaptive estimation">
<node CREATED="1557224068599" ID="ID_1547524527" MODIFIED="1557224068599" TEXT="A key idea in our construction is a reduction scheme which reduces the sparse PCA problem to a high-dimensional multivariate regression problem." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_745801477" LINK="https://www.tandfonline.com/doi/abs/10.1198/106186006X113430" MODIFIED="1557225479630" TEXT="Sparse Principal Component Analysis: Journal of Computational ">
<node CREATED="1557224068599" ID="ID_1652216879" MODIFIED="1557224068599" TEXT="Jan 1 2012  Principal component analysis (PCA) is widely used in data processing and dimensionality reduction. However PCA suffers from the fact that&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1202413964" LINK="https://stats.stackexchange.com/questions/79168/how-exactly-is-sparse-pca-better-than-pca" MODIFIED="1557225479630" TEXT="machine learning - How exactly is sparse PCA better than PCA ">
<node CREATED="1557224068599" ID="ID_1320127811" MODIFIED="1557224068599" TEXT="Whether sparse PCA is easier to interpret than standard PCA or not depends on the dataset you are investigating. Here is how I think about it:&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_683426222" LINK="https://www.ml.uni-saarland.de/code/sparsePCA/sparsePCA.htm" MODIFIED="1557225479645" TEXT="Sparse PCA">
<node CREATED="1557224068599" ID="ID_367827437" MODIFIED="1557224068599" TEXT="Principal Component Analysis (PCA) is a standard technique for dimensionality  In sparse PCA one wants to get a small number of features which still capture&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_973037813" LINK="https://www.di.ens.fr/~fbach/SPO.pdf" MODIFIED="1557225479645" TEXT="Optimal solutions for Sparse Principal Component Analysis">
<node CREATED="1557224068599" ID="ID_497728447" MODIFIED="1557224068599" TEXT="Sparse PCA. &#8226; Get sparse factors capturing a maximum of variance. &#8226; Numerically hard: combinatorial problem. &#8226; Controlling the sparsity of the solution is also&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_468344872" LINK="http://www.stat.cmu.edu/~jinglei/201312-simons.pdf" MODIFIED="1557225479645" TEXT="Sparse PCA in High Dimensions">
<node CREATED="1557224068599" ID="ID_1522172678" MODIFIED="1557224068599" TEXT="Sparse PCA in High Dimensions. Jing Lei Department of Statistics Carnegie Mellon. Workshop on Big Data and Differential Privacy. Simons Institute Dec 2013." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_668271336" LINK="https://www.youtube.com/watch?v=QtS3xQzNMlY" MODIFIED="1557225479645" TEXT="Sparse PCA in High Dimensions - YouTube">
<node CREATED="1557224068599" ID="ID_1411783578" MODIFIED="1557224068599" TEXT="Dec 17 2013  Jing Lei Carnegie Mellon University Big Data and Differential Privacy http://simons.berkeley.edu/talks/jing-lei-2013-12-13." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_159001383" MODIFIED="1563517391360" TEXT="Kernel PCA">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1082675605" MODIFIED="1563517391360" TEXT="Interactive Visualization ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_362664360" MODIFIED="1563517391360" TEXT="Atom Extraction">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068599" FOLDED="true" ID="ID_1572125485" MODIFIED="1557225483435" TEXT="Atom Extraction#$D$#">
<node CREATED="1557224068599" FOLDED="true" ID="ID_1170852951" LINK="https://www.ncbi.nlm.nih.gov/pubmed/17358656" MODIFIED="1557225479645" TEXT="Atom-by-atom extraction using the scanning tunneling microscope ">
<node CREATED="1557224068599" ID="ID_1954562832" MODIFIED="1557224068599" TEXT="Phys Rev Lett. 2007 Jan 12;98(2):028304. Epub 2007 Jan 11. Atom-by-atom extraction using the scanning tunneling microscope tip-cluster interaction." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_875059573" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781785889622/3/ch03lvl1sec27/atom-extraction-and-dictionary-learning" MODIFIED="1557225479645" TEXT="Atom extraction and dictionary learning - Machine Learning Algorithms">
<node CREATED="1557224068599" ID="ID_547533953" MODIFIED="1557224068599" TEXT="Atom extraction and dictionary learningDictionary learning is a technique which allows rebuilding a sample starting from a spa" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_42511879" LINK="https://arxiv.org/abs/cond-mat/0611099" MODIFIED="1557225479645" TEXT="Atom-by-atom extraction using scanning tunneling microscope tip ">
<node CREATED="1557224068599" ID="ID_947127103" MODIFIED="1557224068599" TEXT="Nov 3 2006  Abstract: We investigate atomistic details of a single atom extraction process realized by using scanning tunneling microscope (STM) tip-cluster&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_817666148" LINK="https://www.researchgate.net/publication/6447875_Atom-By-Atom_Extraction_Using_the_Scanning_Tunneling_Microscope_Tip-Cluster_Interaction" MODIFIED="1557225479645" TEXT="(PDF) Atom-By-Atom Extraction Using the Scanning Tunneling ">
<node CREATED="1557224068599" ID="ID_1775984803" MODIFIED="1557224068599" TEXT="Apr 16 2019  PDF | We investigate atomistic details of a single atom extraction process realized by using scanning tunneling microscope (STM) tip-cluster&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_252440316" LINK="https://www.youtube.com/watch?v=xGmYLBpDNCw" MODIFIED="1557225479645" TEXT="ATOM - Extraction - YouTube">
<node CREATED="1557224068599" ID="ID_404520726" MODIFIED="1557224068599" TEXT="Dec 16 2014  Lien Itunes // https://itunes.apple.com/fr/album/extraction/id950747664?i=950747667uo=4 ATOM - Extraction [EP-EXTRACTOR] Website&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_337236411" LINK="https://link.aps.org/doi/10.1103/PhysRevLett.98.028304" MODIFIED="1557225479645" TEXT="Atom-By-Atom Extraction Using the Scanning Tunneling Microscope ">
<node CREATED="1557224068599" ID="ID_1405425530" MODIFIED="1557224068599" TEXT="Jan 11 2007  We investigate the atomistic details of a single atom-extraction process realized by using the scanning tunneling microscope tip-cluster&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_602178725" LINK="https://www.youtube.com/watch?v=dBGf5e9lUnY" MODIFIED="1557225479645" TEXT="ATOM - Extraction Live [Pad Session] - YouTube">
<node CREATED="1557224068599" ID="ID_285024098" MODIFIED="1557224068599" TEXT="Apr 30 2015  Session Live du titre Extraction extrait de notre EP Extractor Lien EP - https://itunes.apple.com/fr/album/extractor-ep/id950747664 Facebook&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_786780897" LINK="https://www.oreilly.com/library/view/machine-learning-algorithms/9781789347999/b99bfb97-9a32-4421-9659-b5b3236928c5.xhtml" MODIFIED="1557225479645" TEXT="Atom extraction and dictionary learning - Machine Learning ">
<node CREATED="1557224068599" ID="ID_955331526" MODIFIED="1557224068599" TEXT="Atom extraction and dictionary learning Dictionary learning is a technique that allows you to rebuild a sample starting from a sparse dictionary of atoms (similar&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1745625255" LINK="https://atom.io/packages/psd-extract" MODIFIED="1557225479645" TEXT="psd-extract">
<node CREATED="1557224068599" ID="ID_477730416" MODIFIED="1557224068599" TEXT="psd-extract. Atom.io package which helps to extract information from photoshop layers. psd-extract. Its very early version so it only collects css information&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1049855541" LINK="https://pubs.acs.org/doi/abs/10.1021/nl0487065" MODIFIED="1557225479645" TEXT="Single-Atom Extraction by Scanning Tunneling Microscope Tip ">
<node CREATED="1557224068599" ID="ID_591080324" MODIFIED="1557224068599" TEXT="We report a novel atom extraction mechanism from the native substrate by means of a scanning tunneling microscope tip crash on a Ag(111) surface at 5 K." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_618052741" MODIFIED="1563517391360" TEXT="Dictionary Learning">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068599" FOLDED="true" ID="ID_679004634" MODIFIED="1557225483435" TEXT="Dictionary Learning#$D$#">
<node CREATED="1557224068599" FOLDED="true" ID="ID_1271891966" LINK="https://en.wikipedia.org/wiki/Sparse_dictionary_learning" MODIFIED="1557225479645" TEXT="Sparse dictionary learning - Wikipedia">
<node CREATED="1557224068599" ID="ID_985522234" MODIFIED="1557224068599" TEXT="Sparse dictionary learning is a representation learning method which aims at finding a sparse representation of the input data in the form of a linear combination&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_698701014" LINK="https://team.inria.fr/panama/en/projects/please/dictionary-learning/" MODIFIED="1557225479645" TEXT="Dictionary learning: theory and algorithms | PANAMA">
<node CREATED="1557224068599" ID="ID_366243905" MODIFIED="1557224068599" TEXT="Dictionary learning is a branch of signal processing and machine learning that aims at finding a frame (called dictionary) in which some training data admits a&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1484412037" LINK="https://www.quora.com/What-is-dictionary-learning" MODIFIED="1557225479645" TEXT="What is dictionary learning? - Quora">
<node CREATED="1557224068599" ID="ID_1320309119" MODIFIED="1557224068599" TEXT="In Machine Learning complex input can be seen as a sparse (mostly zeros) combination of primitive components (dictionary elements). An example is: digit&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1022412911" LINK="http://www.math.nus.edu.sg/~matzuows/BJQS1.pdf" MODIFIED="1557225479645" TEXT="Dictionary learning for sparse coding: Algorithms and convergence ">
<node CREATED="1557224068600" ID="ID_813511844" MODIFIED="1557224068600" TEXT="Dictionary learning for sparse coding: Algorithms and convergence analysis. Chenglong Bao Hui Ji Yuhui Quan and Zuowei Shen. Abstract&#8212;In recent years&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1671585545" LINK="http://learnersdictionary.com/" MODIFIED="1557225479645" TEXT="Merriam-Websters Learners Dictionary">
<node CREATED="1557224068600" ID="ID_1843604351" MODIFIED="1557224068600" TEXT="Clear and simple definitions in basic American English from North Americas leading language experts. More usage examples than any other dictionary." />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_528715065" LINK="https://www.sciencedirect.com/topics/engineering/dictionary-learning" MODIFIED="1557225479645" TEXT="Dictionary Learning - an overview | ScienceDirect Topics">
<node CREATED="1557224068600" ID="ID_664059402" MODIFIED="1557224068600" TEXT="In [35] we described a dictionary learning approach to the image-based analysis of heterogeneity. The underlying idea behind dictionary learning is in the&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1570880740" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.decomposition.DictionaryLearning.html" MODIFIED="1557225479645" TEXT="sklearn.decomposition.DictionaryLearning &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068600" ID="ID_626273500" MODIFIED="1557224068600" TEXT="Dictionary learning. Finds a dictionary (a set of atoms) that can best be used to represent data using a sparse code. Solves the optimization problem: (U^*V^*)&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_837332583" LINK="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2944020/" MODIFIED="1557225479645" TEXT="Dictionary Learning Algorithms for Sparse Representation">
<node CREATED="1557224068600" ID="ID_1733340600" MODIFIED="1557224068600" TEXT="Algorithms for data-driven learning of domain-specific overcomplete dictionaries are developed to obtain maximum likelihood and maximum a posteriori&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_4948713" LINK="https://arxiv.org/abs/1708.01955" MODIFIED="1557225479645" TEXT="Wasserstein Dictionary Learning: Optimal Transport-based ">
<node CREATED="1557224068600" ID="ID_577698521" MODIFIED="1557224068600" TEXT="Aug 7 2017  Abstract: This paper introduces a new nonlinear dictionary learning method for histograms in the probability simplex. The method leverages&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_143426626" LINK="http://www.numerical-tours.com/matlab/sparsity_4_dictionary_learning/" MODIFIED="1557225479645" TEXT="Dictionary Learning">
<node CREATED="1557224068600" ID="ID_1960563736" MODIFIED="1557224068600" TEXT="Given a set Y=(yj)mj=1&#8712;Rn&#215;m of m signals yj&#8712;Rm dictionary learning aims at finding the best dictionary D=(di)pi=1 of p atoms di&#8712;Rn to sparse code all the&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
<node CREATED="1563517391360" FOLDED="true" Folded="true" ID="ID_1484471850" MODIFIED="1563517391360" POSITION="right" TEXT="Regression">
<edge COLOR="#00cc33" />
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" FOLDED="true" Folded="true" ID="ID_1656709819" MODIFIED="1563517391360" TEXT="Linear Regression">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1383662250" MODIFIED="1563517391360" TEXT="Linear Models">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068600" FOLDED="true" ID="ID_1892064283" MODIFIED="1557225483435" TEXT="Linear Regression#$D$#">
<node CREATED="1557224068600" FOLDED="true" ID="ID_483420749" LINK="https://en.wikipedia.org/wiki/Linear_regression" MODIFIED="1557225479645" TEXT="Linear regression - Wikipedia">
<node CREATED="1557224068600" ID="ID_741754546" MODIFIED="1557224068600" TEXT="In statistics linear regression is a linear approach to modelling the relationship between a scalar response (or dependent variable) and one or more explanatory&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_961069570" LINK="https://newonlinecourses.science.psu.edu/stat501/node/251/" MODIFIED="1557225479645" TEXT="1.1 - What is Simple Linear Regression? | STAT 501">
<node CREATED="1557224068600" ID="ID_1252535144" MODIFIED="1557224068600" TEXT="Simple linear regression is a statistical method that allows us to summarize and study relationships between two continuous (quantitative) variables:." />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_761629115" LINK="http://www.stat.yale.edu/Courses/1997-98/101/linreg.htm" MODIFIED="1557225479645" TEXT="Linear Regression">
<node CREATED="1557224068600" ID="ID_1816321857" MODIFIED="1557224068600" TEXT="A linear regression line has an equation of the form Y = a + bX where X is the explanatory variable and Y is the dependent variable. The slope of the line is b&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1408605138" LINK="https://towardsdatascience.com/linear-regression-detailed-view-ea73175f6e86" MODIFIED="1557225479645" TEXT="Linear Regression &#8212; Detailed View &#8211; Towards Data Science">
<node CREATED="1557224068600" ID="ID_383146833" MODIFIED="1557224068600" TEXT="Feb 26 2018  Linear regression is used for finding linear relationship between target and one or more predictors. There are two types of linear regression-&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1131426410" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html" MODIFIED="1557225479645" TEXT="sklearn.linear_model.LinearRegression &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068600" ID="ID_1894248838" MODIFIED="1557224068600" TEXT="Estimated coefficients for the linear regression problem. If multiple targets are passed during the fit (y 2D) this is a 2D array of shape (n_targets n_features)&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_599912774" LINK="https://www.youtube.com/watch?v=zPG4NjIkCjc" MODIFIED="1557225479645" TEXT="An Introduction to Linear Regression Analysis - YouTube">
<node CREATED="1557224068600" ID="ID_318733390" MODIFIED="1557224068600" TEXT="Feb 5 2012  Tutorial introducing the idea of linear regression analysis and the least square method. Typically used in a statistics class. Playlist on Linear&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1567396021" LINK="https://www.khanacademy.org/math/statistics-probability/describing-relationships-quantitative-data/more-on-regression/v/regression-line-example" MODIFIED="1557225479645" TEXT="Regression line example (video) | Khan Academy">
<node CREATED="1557224068600" ID="ID_1962130865" MODIFIED="1557224068600" TEXT="The regression part just ended up stuck as part of the name from then on. Other than that linear regression has nothing to do with regression to the mean." />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_582428153" LINK="https://stattrek.com/regression/linear-regression.aspx" MODIFIED="1557225479645" TEXT="Linear Regression">
<node CREATED="1557224068600" ID="ID_1391614383" MODIFIED="1557224068600" TEXT="Simple linear regression. How to define least-squares regression line. How to find coefficient of determination. Includes video lesson on regression analysis." />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1056670317" LINK="https://www.statisticssolutions.com/what-is-linear-regression/" MODIFIED="1557225479645" TEXT="What is Linear Regression? - Statistics Solutions">
<node CREATED="1557224068600" ID="ID_580495805" MODIFIED="1557224068600" TEXT="Linear regression is a basic and commonly used type of predictive analysis. The overall idea of regression is to examine two things: (1) does a set of predictor&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1919769497" LINK="https://xkcd.com/1725/" MODIFIED="1557225479645" TEXT="xkcd: Linear Regression">
<node CREATED="1557224068600" ID="ID_395400515" MODIFIED="1557224068600" TEXT="sarcasm math and language. Still mourning the demise of Google Reader? You can sign up to get new comics delivered by email here. Linear Regression." />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_784479341" MODIFIED="1557225483435" TEXT="Linear Models#$D$#">
<node CREATED="1557224068600" FOLDED="true" ID="ID_1868719593" LINK="https://en.wikipedia.org/wiki/Linear_model" MODIFIED="1557225479645" TEXT="Linear model - Wikipedia">
<node CREATED="1557224068600" ID="ID_1860439897" MODIFIED="1557224068600" TEXT="In statistics the term linear model is used in different ways according to the context. The most common occurrence is in connection with regression models and&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1433146309" LINK="https://www.mathworks.com/discovery/linear-model.html" MODIFIED="1557225479645" TEXT="Linear Model - MATLAB  Simulink">
<node CREATED="1557224068600" ID="ID_375774528" MODIFIED="1557224068600" TEXT="Learn about MATLAB support for linear models. Resources include code examples documentation and videos describing linear model and regression&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1108349081" LINK="https://www.youtube.com/watch?v=W3flX500w5g" MODIFIED="1557225479645" TEXT="Linear models example 1 | Algebra I | Khan Academy - YouTube">
<node CREATED="1557224068600" ID="ID_392286328" MODIFIED="1557224068600" TEXT="Aug 6 2015  Linear model for book reading Practice this lesson yourself on KhanAcademy.org right now:&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_356031997" LINK="http://scikit-learn.org/stable/modules/linear_model.html" MODIFIED="1557225479645" TEXT="1.1. Generalized Linear Models &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068600" ID="ID_666282244" MODIFIED="1557224068600" TEXT="LinearRegression will take in its fit method arrays X y and will store the coefficients w of the linear model in its coef_ member:   from sklearn import&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1069311575" LINK="https://www.khanacademy.org/math/algebra/linear-word-problems/linear-models-word-problems/v/linear-models-1" MODIFIED="1557225479645" TEXT="Linear models word problem: book (video) | Khan Academy">
<node CREATED="1557224068600" ID="ID_1251513896" MODIFIED="1557224068600" TEXT="Sal solves a word problem about a person reading a book The solution involves the modeling of the situation as a linear function." />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_471080466" LINK="http://www.utstat.toronto.edu/~brunner/books/LinearModelsInStatistics.pdf" MODIFIED="1557225479645" TEXT="LINEAR MODELS IN STATISTICS">
<node CREATED="1557224068600" ID="ID_1508849355" MODIFIED="1557224068600" TEXT="LINEAR MODELS IN. STATISTICS. Second Edition. Alvin C. Rencher and G. Bruce Schaalje. Department of Statistics Brigham Young University Provo Utah&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1536288804" LINK="https://www.khanacademy.org/tag/linear-models" MODIFIED="1557225479645" TEXT="Linear models | Khan Academy">
<node CREATED="1557224068600" ID="ID_1752321609" MODIFIED="1557224068600" TEXT="Learn for free about math art computer programming economics physics chemistry biology medicine finance history and more. Khan Academy is a&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1591537781" LINK="https://content.nexosis.com/blog/what-is-linear-model" MODIFIED="1557225479645" TEXT="What is a Linear Model?">
<node CREATED="1557224068600" ID="ID_800312406" MODIFIED="1557224068600" TEXT="Nov 10 2016  Our data scientist dons his nerd hat and explains linear models and when and why to use them." />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_139684879" LINK="https://www.khanacademy.org/math/cc-eighth-grade-math/cc-8th-data/cc-8th-line-of-best-fit/v/example-estimating-from-regression-line" MODIFIED="1557225479645" TEXT="Estimating with linear regression (linear models) (video) | Khan ">
<node CREATED="1557224068600" ID="ID_1820769582" MODIFIED="1557224068600" TEXT="Yes. The question specifically asks you to use the equation in which case the answer would be 96 not 97 but since the true values seem to be varying by up to&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_430910865" LINK="https://www.edx.org/course/machine-learning-with-python-from-linear-models-to-deep-learning" MODIFIED="1557225479645" TEXT="Machine Learning with Python: from Linear Models to Deep ">
<node CREATED="1557224068600" ID="ID_690820390" MODIFIED="1557224068600" TEXT="An in-depth introduction to the field of machine learning from linear models to deep learning and reinforcement learning through hands-on Python projects." />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1822241724" MODIFIED="1557225483436" TEXT="Linear Classification#$D$#">
<node CREATED="1557224068601" FOLDED="true" ID="ID_202038803" LINK="https://en.wikipedia.org/wiki/Linear_classifier" MODIFIED="1557225479661" TEXT="Linear classifier - Wikipedia">
<node CREATED="1557224068601" ID="ID_710052388" MODIFIED="1557224068601" TEXT="In the field of machine learning the goal of statistical classification is to use an objects characteristics to identify which class (or group) it belongs to. A linear&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_549438229" LINK="http://compneurosci.com/wiki/images/c/c0/Linear_Classification.pdf" MODIFIED="1557225479661" TEXT="Linear Classification">
<node CREATED="1557224068601" ID="ID_1764151002" MODIFIED="1557224068601" TEXT="Linear classification. A classification algorithm (Classifier) that makes its classification based on a linear predictor function combining a set of weights with the&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1823926676" LINK="https://www.cs.toronto.edu/~rgrosse/courses/csc321_2018/readings/L03%20Linear%20Classifiers.pdf" MODIFIED="1557225479661" TEXT="Lecture 3: Linear Classification">
<node CREATED="1557224068601" ID="ID_1669198229" MODIFIED="1557224068601" TEXT="Lecture 3: Linear Classification. Roger Grosse. 1 Introduction. Last week we saw an example of a learning task called regression. There the goal was to predict&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_630768963" LINK="http://cs231n.github.io/linear-classify/" MODIFIED="1557225479661" TEXT="Linear classification: Support Vector Machine Softmax">
<node CREATED="1557224068601" ID="ID_1354272344" MODIFIED="1557224068601" TEXT="Intro to Linear classification; Linear score function; Interpreting a linear classifier; Loss function. Multiclass SVM; Softmax classifier; SVM vs Softmax. Interactive&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1388482020" LINK="https://www.cs.princeton.edu/courses/archive/spring16/cos495/slides/ML_basics_lecture2_linear_classification.pdf" MODIFIED="1557225479661" TEXT="Machine Learning Basics Lecture 2: linear classification">
<node CREATED="1557224068601" ID="ID_648800418" MODIFIED="1557224068601" TEXT="Machine Learning Basics. Lecture 2: Linear Classification. Princeton University COS 495. Instructor: Yingyu Liang. Page 2. Review: machine learning basics&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_979116085" LINK="http://vision.stanford.edu/teaching/cs231n/linear-classify-demo/" MODIFIED="1557225479661" TEXT="Multiclass SVM optimization demo">
<node CREATED="1557224068601" ID="ID_657827773" MODIFIED="1557224068601" TEXT="Linear Classification Loss Visualization. These linear classifiers were written in Javascript for Stanfords CS231n: Convolutional Neural Networks for Visual&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1998379884" LINK="http://www.cs.ucf.edu/~mtappen/cap5415/lecs/lec6.pdf" MODIFIED="1557225479661" TEXT="Lecture 6 - Linear Classification">
<node CREATED="1557224068601" ID="ID_1052336771" MODIFIED="1557224068601" TEXT="In building mathematical models for classifying we are going to focus on dividing these points with a straight line. &#9655; This is called linear classification. -5. 0. 5. -6." />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_774551061" LINK="https://nlp.stanford.edu/IR-book/html/htmledition/linear-versus-nonlinear-classifiers-1.html" MODIFIED="1557225479661" TEXT="Linear versus nonlinear classifiers">
<node CREATED="1557224068601" ID="ID_1462419185" MODIFIED="1557224068601" TEXT="Linear classification at first seems trivial given the simplicity of this algorithm. However the difficulty is in training the linear classifier that is in determining the&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_410562916" LINK="https://www.youtube.com/watch?v=h08kTk6p2Zs" MODIFIED="1557225479661" TEXT="17: Linear Classification - YouTube">
<node CREATED="1557224068601" ID="ID_1969252916" MODIFIED="1557224068601" TEXT="Nov 6 2014  Linear Classification. See http://www.brml.org/  17: Linear Classification. Patrick van der Smagt. Loading Unsubscribe from Patrick van der&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_731645144" LINK="https://arxiv.org/abs/1809.06514" MODIFIED="1557225479661" TEXT="Actionable Recourse in Linear Classification">
<node CREATED="1557224068601" ID="ID_256890974" MODIFIED="1557224068601" TEXT="Sep 18 2018  In this paper we propose to audit a linear classification model in terms of recourse which we define as the ability of a person to change the&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_477978821" MODIFIED="1563517391360" TEXT="A bi-dimensional example">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1510664775" MODIFIED="1563517391360" TEXT="Linear Regression and Higher dimensionality">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068600" FOLDED="true" ID="ID_1708275511" MODIFIED="1557225483435" TEXT="Linear Regression bi-dimensional example#$D$#">
<node CREATED="1557224068600" FOLDED="true" ID="ID_230368325" LINK="https://onlinelibrary.wiley.com/doi/pdf/10.1111/j.1538-4632.1994.tb00320.x" MODIFIED="1557225479645" TEXT="Bidimensional Regression">
<node CREATED="1557224068600" ID="ID_1157257759" MODIFIED="1557224068600" TEXT="example in biology for the comparison of shapes of leaves fish faces or skulls afer . In the bidimensional case each variable has two components. Thus the&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1032437716" LINK="http://web.psych.ualberta.ca/~alinda/PDFs/Friedman%20Kohler%20%5B03-Psych%20Methods%5D.pdf" MODIFIED="1557225479645" TEXT="Bidimensional Regression: Assessing the Configural Similarity and ">
<node CREATED="1557224068600" ID="ID_102874245" MODIFIED="1557224068600" TEXT="Bidimensional regression is a method for comparing the degree of resemblance between 2 planar  For example it can assess the similarity be- tween location&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1715153281" LINK="https://pdfs.semanticscholar.org/3b57/ba5bbdb0f6a8ab8bf33305ba65f03f86374d.pdf" MODIFIED="1557225479645" TEXT="Bidimensional regression: Issues with interpolation">
<node CREATED="1557224068600" ID="ID_785854032" MODIFIED="1557224068600" TEXT="the fit of bidimensional regression models increased with the  For example interpolation maintains . pairs per sample in terms of inflation and the linear." />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_52413283" LINK="https://cran.r-project.org/web/packages/BiDimRegression/BiDimRegression.pdf" MODIFIED="1557225479645" TEXT="Package BiDimRegression">
<node CREATED="1557224068600" ID="ID_373699318" MODIFIED="1557224068600" TEXT="May 16 2018  Title Calculates the Bidimensional Regression Between Two 2D . Example 1 from the domain of aesthetics to show how the method can be&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1090797617" LINK="https://www.academia.edu/10155026/Bidimensional_Regression_in_Spatial_Analysis" MODIFIED="1557225479645" TEXT="(PDF) Bidimensional Regression in Spatial Analysis | Regional ">
<node CREATED="1557224068600" ID="ID_1869612436" MODIFIED="1557224068600" TEXT="In his demonstrative example Tobler compared a medieval map2 of Britannia  This paper presents the main characteristics of the bidimensional regression&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_45132345" LINK="https://en.wikipedia.org/wiki/Simple_linear_regression" MODIFIED="1557225479645" TEXT="Simple linear regression - Wikipedia">
<node CREATED="1557224068600" ID="ID_238626140" MODIFIED="1557224068600" TEXT="In statistics simple linear regression is a linear regression model with a single explanatory variable. That is it concerns two-dimensional sample points with one&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_14983114" LINK="http://mezeylab.cb.bscb.cornell.edu/labmembers/documents/supplement%205%20-%20multiple%20regression.pdf" MODIFIED="1557225479645" TEXT="Multiple Linear Regression">
<node CREATED="1557224068600" ID="ID_1860679408" MODIFIED="1557224068600" TEXT="be understood as a two-dimensional surface in space. The shape of  Example: The simplest multiple regression model for two predictor variables is y = &#946;0 +&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_361014681" LINK="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3446205/" MODIFIED="1557225479645" TEXT="A Comparison of Regression Techniques for a Two-Dimensional ">
<node CREATED="1557224068600" ID="ID_1101292317" MODIFIED="1557224068600" TEXT="Numerous studies over the past two decades show that scalp-recorded EEG .. For example if the features are normalized the coefficients of a regression that&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_899796113" LINK="https://github.com/morelinq/MoreLINQ/issues/298" MODIFIED="1557225479645" TEXT="Simple linear regression for two-dimensional sample data points #298">
<node CREATED="1557224068600" ID="ID_1936522646" MODIFIED="1557224068600" TEXT="May 17 2017  Given a sample of two-dimensional (x y) data points the operator will calculate and return the following components of the a simple linear&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1224327384" LINK="https://www.researchgate.net/figure/Example-of-non-linear-regression-the-two-dimensional-data-points-xi-yi-in-this-sample_fig1_273872578" MODIFIED="1557225479645" TEXT="Example of non-linear regression; the two-dimensional data points ">
<node CREATED="1557224068600" ID="ID_117629164" MODIFIED="1557224068600" TEXT="Example of non-linear regression; the two-dimensional data points (xi yi) in this sample were generated using yi = 0.2 x 3 i + 0.4 x 2 i &#8722; 2.1 xi &#8722; 1.5 + where&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1330651134" MODIFIED="1557225483435" TEXT="Linear Regression and Higher dimensionality#$D$#">
<node CREATED="1557224068600" FOLDED="true" ID="ID_1763334011" LINK="http://www.math.univ-toulouse.fr/~besse/Wikistat/pdf/st-m-datSc2-regHD.pdf" MODIFIED="1557225479645" TEXT="Data Science - High dimensional regression">
<node CREATED="1557224068600" ID="ID_54445994" MODIFIED="1557224068600" TEXT="Data Science - High dimensional regression. Summary. Linear models are popular methods for providing a regression of a response variable Y  that depends&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_256581788" LINK="http://www.stat.cmu.edu/~ryantibs/advmethods/notes/highdim.pdf" MODIFIED="1557225479645" TEXT="High-dimensional regression">
<node CREATED="1557224068600" ID="ID_1592099612" MODIFIED="1557224068600" TEXT="High-dimensional regression. Advanced Methods for Data Analysis (36-402/36-608). Spring 2014. 1 Back to linear regression. 1.1 Shortcomings. &#8226; Suppose that&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_70740447" LINK="https://web.stanford.edu/class/stats202/content/lec16.pdf" MODIFIED="1557225479645" TEXT="Lecture 16: High-dimensional regression non-linear regression">
<node CREATED="1557224068600" ID="ID_1217862191" MODIFIED="1557224068600" TEXT="Nov 2 2018  Lecture 16: High-dimensional regression non-linear regression. Reading: Sections 6.4 7.1. STATS 202: Data mining and analysis. Jonathan&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_609604580" LINK="https://www.mathworks.com/help/stats/fitrlinear.html" MODIFIED="1557225479645" TEXT="Fit linear regression model to high-dimensional data - MATLAB ">
<node CREATED="1557224068600" ID="ID_1446190580" MODIFIED="1557224068600" TEXT="fitrlinear efficiently trains linear regression models with high-dimensional full or sparse predictor data. Available linear regression models include regularized&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1521391403" LINK="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2865881/" MODIFIED="1557225479645" TEXT="Statistical challenges of high-dimensional data">
<node CREATED="1557224068600" ID="ID_1313862291" MODIFIED="1557224068600" TEXT="In this section we attempt to indicate the nature of the general issue of high dimension&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_231700518" LINK="https://eprint.iacr.org/2016/892.pdf" MODIFIED="1557225479645" TEXT="Privacy-Preserving Distributed Linear Regression on High ">
<node CREATED="1557224068600" ID="ID_693518508" MODIFIED="1557224068600" TEXT="High-Dimensional Data. Abstract: We propose privacy-preserving protocols for com- puting linear regression models in the setting where the train- ing dataset is&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_284881538" LINK="http://scikit-learn.org/stable/tutorial/statistical_inference/supervised_learning.html" MODIFIED="1557225479645" TEXT="Supervised learning: predicting an output variable from high ">
<node CREATED="1557224068600" ID="ID_1071437746" MODIFIED="1557224068600" TEXT="All supervised estimators in scikit-learn implement a fit(X y) method to fit the . A solution in high-dimensional statistical learning is to shrink the regression&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_299655845" LINK="https://stats.stackexchange.com/questions/226172/is-multiple-linear-regression-in-3-dimensions-a-plane-of-best-fit-or-a-line-of-b" MODIFIED="1557225479645" TEXT="high dimensional - Is Multiple Linear Regression in 3 dimensions a ">
<node CREATED="1557224068600" ID="ID_311087456" MODIFIED="1557224068600" TEXT="Youre right the solution surface is going to be a hyperplane in general. Its just that the word hyperplane is a mouthful plane is shorter and&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1223627377" LINK="https://academic.oup.com/biomet/article/103/1/147/2389939" MODIFIED="1557225479645" TEXT="Partially functional linear regression in high dimensions | Biometrika ">
<node CREATED="1557224068600" ID="ID_1034448879" MODIFIED="1557224068600" TEXT="Jan 19 2016  We propose a unified framework that combines the regularization of each functional predictor as a whole with a penalty on high-dimensional&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_181549375" LINK="https://www.researchgate.net/post/Can_you_recommend_a_model_to_perform_regression_with_high_dimension_data" MODIFIED="1557225479645" TEXT="Can you recommend a model to perform regression with high ">
<node CREATED="1557224068600" ID="ID_657074896" MODIFIED="1557224068600" TEXT="My data-set has 23377 instances for training (7792 for testing). The dimension of the data is approximately 28000. Each instance represents a document and the&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1353679299" MODIFIED="1563517391360" TEXT="Regularization">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_634568555" MODIFIED="1563517391360" TEXT="Ridge">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1456541363" MODIFIED="1563517391360" TEXT="Blog ">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068600" FOLDED="true" ID="ID_1499117241" MODIFIED="1557225483436" TEXT="Regularization Ridge#$D$#">
<node CREATED="1557224068600" FOLDED="true" ID="ID_1174637270" LINK="https://www.datacamp.com/community/tutorials/tutorial-ridge-lasso-elastic-net" MODIFIED="1557225479645" TEXT="Regularization: Ridge Lasso and Elastic Net (article) - DataCamp">
<node CREATED="1557224068600" ID="ID_1031697267" MODIFIED="1557224068600" TEXT="Nov 29 2018  In this tutorial you will get acquainted with the bias-variance trade-off problem in linear regression and how it can be solved with regularization." />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1447039229" LINK="https://www.youtube.com/watch?v=Q81RR3yKn30" MODIFIED="1557225479645" TEXT="Regularization Part 1: Ridge Regression - YouTube">
<node CREATED="1557224068600" ID="ID_1131921391" MODIFIED="1557224068600" TEXT="Sep 24 2018  Ridge Regression is a neat little way to ensure you dont overfit your training data - essentially you are desensitizing your model to the training&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1760786737" LINK="https://en.wikipedia.org/wiki/Tikhonov_regularization" MODIFIED="1557225479645" TEXT="Tikhonov regularization - Wikipedia">
<node CREATED="1557224068600" ID="ID_1870841796" MODIFIED="1557224068600" TEXT="Tikhonov regularization named for Andrey Tikhonov is the most commonly used method of regularization of ill-posed problems. In statistics the method is known as ridge regression in machine learning it&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1976512065" LINK="http://statweb.stanford.edu/~tibs/sta305files/Rudyregularization.pdf" MODIFIED="1557225479645" TEXT="Regularization: Ridge Regression and the LASSO">
<node CREATED="1557224068600" ID="ID_1125358780" MODIFIED="1557224068600" TEXT="Nov 29 2006  Part I. The Bias-Variance Tradeoff. Statistics 305: Autumn Quarter 2006/2007. Regularization: Ridge Regression and the LASSO&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1002485212" LINK="https://towardsdatascience.com/l1-and-l2-regularization-methods-ce25e7fc831c" MODIFIED="1557225479645" TEXT="L1 and L2 Regularization Methods &#8211; Towards Data Science">
<node CREATED="1557224068600" ID="ID_174021645" MODIFIED="1557224068600" TEXT="Oct 13 2017  A regression model that uses L1 regularization technique is called Lasso Regression and model which uses L2 is called Ridge Regression." />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1719185556" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.linear_model.Ridge.html" MODIFIED="1557225479645" TEXT="sklearn.linear_model.Ridge &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068600" ID="ID_1067456411" MODIFIED="1557224068600" TEXT="Also known as Ridge Regression or Tikhonov regularization. This estimator has built-in support for multi-variate regression (i.e. when y is a 2d-array of shape&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_922884106" LINK="https://www.analyticsvidhya.com/blog/2017/06/a-comprehensive-guide-for-linear-ridge-and-lasso-regression/" MODIFIED="1557225479645" TEXT="A comprehensive beginners guide for Linear Ridge and Lasso ">
<node CREATED="1557224068600" ID="ID_1345427812" MODIFIED="1557224068600" TEXT="Jun 22 2017  A comprehensive beginners guide for Linear Ridge and Lasso  Bias and Variance; Regularization; Ridge Regression; Lasso Regression&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_525446247" LINK="https://medium.com/datadriveninvestor/the-math-behind-ridge-regularization-and-lasso-regularization-c4473332dbda" MODIFIED="1557225479661" TEXT="The Math Behind Ridge Regularization and Lasso Regularization">
<node CREATED="1557224068600" ID="ID_1324999920" MODIFIED="1557224068600" TEXT="Oct 10 2018  This blog post is part 1 in a series about strategies to select and engineer quality features for supervised machine learning models. &#8220;You are&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1412925758" LINK="https://www.analyticsvidhya.com/blog/2016/01/complete-tutorial-ridge-lasso-regression-python/" MODIFIED="1557225479661" TEXT="A Complete Tutorial on Ridge and Lasso Regression in Python">
<node CREATED="1557224068600" ID="ID_968061506" MODIFIED="1557224068600" TEXT="Jan 28 2016  Here is a complete tutorial on the regularization techniques of ridge and lasso regression to prevent overfitting in prediction in python." />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1168630447" LINK="https://courses.cs.washington.edu/courses/csep546/14wi/slides/regularization-xvalidation-lasso.pdf" MODIFIED="1557225479661" TEXT="Regularization Ridge Regression">
<node CREATED="1557224068600" ID="ID_1373001734" MODIFIED="1557224068600" TEXT="Jan 13 2014  Regularization in Linear Regression  Regularized or penalized regression aims to impose a  Ridge Regression: Effect of Regularization. 14." />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_567534877" MODIFIED="1557225483436" TEXT="Regularization Lasso#$D$#">
<node CREATED="1557224068600" FOLDED="true" ID="ID_1893797619" LINK="https://en.wikipedia.org/wiki/Lasso_(statistics)" MODIFIED="1557225479661" TEXT="Lasso (statistics) - Wikipedia">
<node CREATED="1557224068600" ID="ID_1128680877" MODIFIED="1557224068600" TEXT="In statistics and machine learning lasso is a regression analysis method that performs both variable selection and regularization in order to enhance the&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1420833357" LINK="https://towardsdatascience.com/l1-and-l2-regularization-methods-ce25e7fc831c" MODIFIED="1557225479661" TEXT="L1 and L2 Regularization Methods &#8211; Towards Data Science">
<node CREATED="1557224068600" ID="ID_1161920521" MODIFIED="1557224068600" TEXT="Oct 13 2017  A regression model that uses L1 regularization technique is called Lasso Regression and model which uses L2 is called Ridge Regression." />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_1599882259" LINK="https://www.youtube.com/watch?v=NGf0voTMlcs" MODIFIED="1557225479661" TEXT="Regularization Part 2: Lasso Regression - YouTube">
<node CREATED="1557224068600" ID="ID_581843671" MODIFIED="1557224068600" TEXT="Oct 1 2018  Lasso Regression is super similar to Ridge Regression but there is one big huge difference between the two. In this video I start by talking&#160;" />
</node>
<node CREATED="1557224068600" FOLDED="true" ID="ID_179125409" LINK="https://www.datacamp.com/community/tutorials/tutorial-ridge-lasso-elastic-net" MODIFIED="1557225479661" TEXT="Regularization: Ridge Lasso and Elastic Net (article) - DataCamp">
<node CREATED="1557224068600" ID="ID_1735570199" MODIFIED="1557224068600" TEXT="Nov 29 2018  In this tutorial you will get acquainted with the bias-variance trade-off problem in linear regression and how it can be solved with regularization." />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_292201055" LINK="http://statweb.stanford.edu/~tibs/sta305files/Rudyregularization.pdf" MODIFIED="1557225479661" TEXT="Regularization: Ridge Regression and the LASSO">
<node CREATED="1557224068601" ID="ID_26770299" MODIFIED="1557224068601" TEXT="Nov 29 2006  Part I. The Bias-Variance Tradeoff. Statistics 305: Autumn Quarter 2006/2007. Regularization: Ridge Regression and the LASSO&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1999699186" LINK="https://www.analyticsvidhya.com/blog/2016/01/complete-tutorial-ridge-lasso-regression-python/" MODIFIED="1557225479661" TEXT="A Complete Tutorial on Ridge and Lasso Regression in Python">
<node CREATED="1557224068601" ID="ID_1882435541" MODIFIED="1557224068601" TEXT="Jan 28 2016  Here is a complete tutorial on the regularization techniques of ridge and lasso regression to prevent overfitting in prediction in python." />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1233525189" LINK="https://hackernoon.com/practical-machine-learning-ridge-regression-vs-lasso-a00326371ece" MODIFIED="1557225479661" TEXT="Practical machine learning: Ridge Regression vs. Lasso">
<node CREATED="1557224068601" ID="ID_1082100591" MODIFIED="1557224068601" TEXT="Aug 28 2017  Lasso is another extension built on regularized linear regression but with  The only difference from Ridge regression is that the regularization&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_898689777" LINK="https://www.analyticsvidhya.com/blog/2017/06/a-comprehensive-guide-for-linear-ridge-and-lasso-regression/" MODIFIED="1557225479661" TEXT="A comprehensive beginners guide for Linear Ridge and Lasso ">
<node CREATED="1557224068601" ID="ID_1131846278" MODIFIED="1557224068601" TEXT="Jun 22 2017  A comprehensive beginners guide for Linear Ridge and Lasso  Bias and Variance; Regularization; Ridge Regression; Lasso Regression&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_18860613" LINK="https://stats.stackexchange.com/questions/200416/is-regression-with-l1-regularization-the-same-as-lasso-and-with-l2-regularizati" MODIFIED="1557225479661" TEXT="terminology - Is regression with L1 regularization the same as Lasso ">
<node CREATED="1557224068601" ID="ID_1524659300" MODIFIED="1557224068601" TEXT="LASSO is actually an acronym (least absolute shrinkage and selection  Ridge regression should probably be called Tikhonov regularization&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1162336182" LINK="http://scikit-learn.org/stable/modules/linear_model.html" MODIFIED="1557225479661" TEXT="1.1. Generalized Linear Models &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068601" ID="ID_1356033264" MODIFIED="1557224068601" TEXT="This combination allows for learning a sparse model where few of the weights are non-zero like Lasso  while still maintaining the regularization properties of&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1535644421" MODIFIED="1557225483436" TEXT="Regularization ElasticNet#$D$#">
<node CREATED="1557224068601" FOLDED="true" ID="ID_194768878" LINK="https://en.wikipedia.org/wiki/Elastic_net_regularization" MODIFIED="1557225479661" TEXT="Elastic net regularization - Wikipedia">
<node CREATED="1557224068601" ID="ID_1244596286" MODIFIED="1557224068601" TEXT="In statistics and in particular in the fitting of linear or logistic regression models the elastic net is a regularized regression method that linearly combines the L1&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_132304611" LINK="https://web.stanford.edu/~hastie/Papers/B67.2%20%282005%29%20301-320%20Zou%20%20Hastie.pdf" MODIFIED="1557225479661" TEXT="Regularization and variable selection via the elastic net">
<node CREATED="1557224068601" ID="ID_95542627" MODIFIED="1557224068601" TEXT="Summary. We propose the elastic net a new regularization and variable selection method. Real world data and a simulation study show that the elastic net often&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1159200685" LINK="https://www.datacamp.com/community/tutorials/tutorial-ridge-lasso-elastic-net" MODIFIED="1557225479661" TEXT="Regularization: Ridge Lasso and Elastic Net (article) - DataCamp">
<node CREATED="1557224068601" ID="ID_1742114268" MODIFIED="1557224068601" TEXT="Nov 29 2018  In this tutorial you will get acquainted with the bias-variance trade-off problem in linear regression and how it can be solved with regularization." />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1912116603" LINK="https://www.youtube.com/watch?v=1dKRdX9bfIo" MODIFIED="1557225479661" TEXT="Regularization Part 3: Elastic Net Regression - YouTube">
<node CREATED="1557224068601" ID="ID_468715728" MODIFIED="1557224068601" TEXT="Oct 8 2018  Elastic-Net Regression is combines Lasso Regression with Ridge Regression to give you the best of both worlds. It works well when there are&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1312292980" LINK="https://web.stanford.edu/~hastie/TALKS/enet_talk.pdf" MODIFIED="1557225479661" TEXT="Regularization and Variable Selection via the Elastic Net">
<node CREATED="1557224068601" ID="ID_870736102" MODIFIED="1557224068601" TEXT="ElasticNet. Hui Zou Stanford University. 2. Outline. &#8226; Variable selection problem. &#8226; Sparsity by regularization and the lasso. &#8226; The elastic net&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_661969034" LINK="https://medium.com/@jayeshbahire/lasso-ridge-and-elastic-net-regularization-4807897cb722" MODIFIED="1557225479661" TEXT="Lasso Ridge and Elastic Net Regularization &#8211; Jayesh Bapu Ahire ">
<node CREATED="1557224068601" ID="ID_276535880" MODIFIED="1557224068601" TEXT="Mar 20 2018  Regularization techniques in Generalized Linear Models (GLM) are used during a modeling process for many reasons. A regularization&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_806982782" LINK="https://stats.stackexchange.com/questions/184029/what-is-elastic-net-regularization-and-how-does-it-solve-the-drawbacks-of-ridge" MODIFIED="1557225479661" TEXT="regression - What is elastic net regularization and how does it solve ">
<node CREATED="1557224068601" ID="ID_343598472" MODIFIED="1557224068601" TEXT="1. Which method is preferred? Yes elastic net is always preferred over lasso  ridge regression because it solves the limitations of both&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_241265895" LINK="https://blog.alexlenail.me/what-is-the-difference-between-ridge-regression-the-lasso-and-elasticnet-ec19c71c9028" MODIFIED="1557225479661" TEXT="What is the difference between Ridge Regression the LASSO and ">
<node CREATED="1557224068601" ID="ID_166044359" MODIFIED="1557224068601" TEXT="Jul 31 2017  tldr: &#8220;Ridge&#8221; is a fancy name for L2-regularization &#8220;LASSO&#8221; means L1-regularization &#8220;ElasticNet&#8221; is a ratio of L1 and L2 regularization." />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_62556362" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.linear_model.ElasticNet.html" MODIFIED="1557225479661" TEXT="sklearn.linear_model.ElasticNet &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068601" ID="ID_1314681155" MODIFIED="1557224068601" TEXT="ElasticNet (alpha=1.0 l1_ratio=0.5 fit_intercept=True normalize=False precompute=False max_iter=1000 . Number of alphas along the regularization path." />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_913546551" LINK="https://arxiv.org/abs/0807.3423" MODIFIED="1557225479661" TEXT="Elastic-Net Regularization in Learning Theory">
<node CREATED="1557224068601" ID="ID_1273479484" MODIFIED="1557224068601" TEXT="Jul 22 2008   we analyze in detail the so-called elastic-net regularization scheme  the elastic-net estimator is consistent not only for prediction but also for&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1824622633" MODIFIED="1563517391360" TEXT="Lasso">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_374422213" MODIFIED="1563517391360" TEXT="Blog ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1263257695" MODIFIED="1563517391360" TEXT="ElasticNet">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_26432251" MODIFIED="1563517391360" TEXT="Blog ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_630151500" MODIFIED="1563517391360" TEXT="Example Anecdote ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1976797020" MODIFIED="1563517391360" TEXT="Code ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1176462349" MODIFIED="1563517391360" TEXT="Interactive Visualization ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_682588513" MODIFIED="1563517391360" TEXT="Robust Regression with Random Sample Consensus">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068601" FOLDED="true" ID="ID_929415712" MODIFIED="1557225483436" TEXT="Robust Regression with Random Sample Consensus#$D$#">
<node CREATED="1557224068601" FOLDED="true" ID="ID_474349083" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781785889622/4/ch04lvl1sec34/robust-regression-with-random-sample-consensus" MODIFIED="1557225479661" TEXT="Robust regression with random sample consensus - Machine ">
<node CREATED="1557224068601" ID="ID_1362083366" MODIFIED="1557224068601" TEXT="Robust regression with random sample consensusA common problem with linear regressions is caused by the presence of outliers. " />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_929446643" LINK="https://en.wikipedia.org/wiki/Random_sample_consensus" MODIFIED="1557225479661" TEXT="Random sample consensus - Wikipedia">
<node CREATED="1557224068601" ID="ID_1199467098" MODIFIED="1557224068601" TEXT="Random sample consensus (RANSAC) is an iterative method to estimate parameters of a  This is done by fitting linear models to several random samplings of the data and returning the model that has the best fit to a subset of the data." />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1065323723" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.linear_model.RANSACRegressor.html" MODIFIED="1557225479661" TEXT="sklearn.linear_model.RANSACRegressor &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068601" ID="ID_1268740879" MODIFIED="1557224068601" TEXT="RANSAC (RANdom SAmple Consensus) algorithm. RANSAC is an iterative algorithm for the robust estimation of parameters from a subset of inliers from the  Note that the current implementation only supports regression estimators." />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_365256121" LINK="https://www.oreilly.com/library/view/machine-learning-algorithms/9781785889622/a5cfbf2b-764b-42df-82b8-452f7f49a5af.xhtml" MODIFIED="1557225479661" TEXT="Robust regression with random sample consensus - Machine ">
<node CREATED="1557224068601" ID="ID_1271695448" MODIFIED="1557224068601" TEXT="Robust regression with random sample consensus A common problem with linear regressions is caused by the presence of outliers. An ordinary least square&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_878143713" LINK="http://hameddaily.blogspot.com/2015/04/using-ransac-for-robust-regression.html" MODIFIED="1557225479661" TEXT="Using RANSAC for Robust Regression | Ensemble Blogging">
<node CREATED="1557224068601" ID="ID_211288414" MODIFIED="1557224068601" TEXT="Apr 11 2015  In this post I would like to touch the surface of outlier detection and removal by introducing Random Sample Consensus. RANSAC is a a&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1892819716" LINK="https://www.sciencedirect.com/science/article/pii/S0893608014001464" MODIFIED="1557225479661" TEXT="Model-wise and point-wise random sample consensus for robust ">
<node CREATED="1557224068601" ID="ID_188045278" MODIFIED="1557224068601" TEXT="However the robustness gained from M-estimators is still low. This paper addresses robust regression and outlier detection in a random sample consensus&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_22849153" LINK="https://www.ncbi.nlm.nih.gov/pubmed/25047916" MODIFIED="1557225479661" TEXT="Model-wise and point-wise random sample consensus for robust ">
<node CREATED="1557224068601" ID="ID_641569562" MODIFIED="1557224068601" TEXT="Jul 7 2014  Model-wise and point-wise random sample consensus for robust regression and outlier detection. El-Melegy MT(1). Author information:" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1099199342" LINK="http://www.cse.psu.edu/~rtc12/CSE486/lecture15.pdf" MODIFIED="1557225479661" TEXT="Lecture 15 Robust Estimation : RANSAC">
<node CREATED="1557224068601" ID="ID_162667168" MODIFIED="1557224068601" TEXT="regression with outliers. Solution: Estimation methods that are robust to outliers.  Random. Sample Consensus: A Paradigm for Model Fitting with. Applications&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1909607390" LINK="http://ieeexplore.ieee.org/abstract/document/5495830/" MODIFIED="1557225479661" TEXT="Robust regression using sparse learning for high dimensional ">
<node CREATED="1557224068601" ID="ID_1340317748" MODIFIED="1557224068601" TEXT="Algorithms such as Least Median of Squares (LMedS) and Random Sample Consensus (RANSAC) have been very successful for low-dimensional robust&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_314775609" LINK="https://link.springer.com/chapter/10.1007/978-3-540-88690-7_14" MODIFIED="1557225479661" TEXT="Robust Scale Estimation from Ensemble Inlier Sets for Random ">
<node CREATED="1557224068601" ID="ID_1344179203" MODIFIED="1557224068601" TEXT="Fischler M.A. Bolles R.C.: Random sample consensus: A paradigm for  Subbarao R. Meer P.: Beyond RANSAC: User independent robust regression." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_451550627" MODIFIED="1563517391360" TEXT="Polynomial Regression">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068601" FOLDED="true" ID="ID_474089743" MODIFIED="1557225483436" TEXT="Polynomial Regression#$D$#">
<node CREATED="1557224068601" FOLDED="true" ID="ID_1190711777" LINK="https://en.wikipedia.org/wiki/Polynomial_regression" MODIFIED="1557225479661" TEXT="Polynomial regression - Wikipedia">
<node CREATED="1557224068601" ID="ID_1701187836" MODIFIED="1557224068601" TEXT="In statistics polynomial regression is a form of regression analysis in which the relationship between the independent variable x and the dependent variable y is&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_603710522" LINK="https://towardsdatascience.com/polynomial-regression-bbe8b9d97491" MODIFIED="1557225479661" TEXT="Polynomial Regression &#8211; Towards Data Science">
<node CREATED="1557224068601" ID="ID_1546163859" MODIFIED="1557224068601" TEXT="Oct 8 2018  This is my third blog in the Machine Learning series. This blog requires prior knowledge of Linear Regression. If you dont know about Linear&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1216306469" LINK="https://www.youtube.com/watch?v=Qnt2vBRW8Io" MODIFIED="1557225479661" TEXT="POLYNOMIAL REGRESSION - YouTube">
<node CREATED="1557224068601" ID="ID_836852007" MODIFIED="1557224068601" TEXT="Oct 26 2017  In statistics polynomial regression is a form of regression analysis in which the relationship between the independent variable x and the&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1403670981" LINK="https://towardsdatascience.com/introduction-to-linear-regression-and-polynomial-regression-f8adc96f31cb" MODIFIED="1557225479661" TEXT="Introduction to Linear Regression and Polynomial Regression">
<node CREATED="1557224068601" ID="ID_375631361" MODIFIED="1557224068601" TEXT="Jan 13 2019  In this blog we will discuss two important topics that will form a base for Machine Learning which is &#8220;Linear Regression&#8221; and &#8220;Polynomial&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1562735035" LINK="https://www.statsdirect.com/help/regression_and_correlation/polynomial.htm" MODIFIED="1557225479661" TEXT="Polynomial Regression - StatsDirect">
<node CREATED="1557224068601" ID="ID_339618024" MODIFIED="1557224068601" TEXT="where Y caret is the predicted outcome value for the polynomial model with regression coefficients b1 to k for each degree and Y intercept b0. The model is&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1661672536" LINK="https://www.theanalysisfactor.com/regression-modelshow-do-you-know-you-need-a-polynomial/" MODIFIED="1557225479661" TEXT="Regression Models:How do you know you need a polynomial? - The ">
<node CREATED="1557224068601" ID="ID_1876998497" MODIFIED="1557224068601" TEXT="A polynomial term&#8211;a quadratic (squared) or cubic (cubed) term turns a linear regression model into a curve. But because it is X that is squared or cubed not the&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_473201411" LINK="https://newonlinecourses.science.psu.edu/stat501/node/324/" MODIFIED="1557225479661" TEXT="9.7 - Polynomial Regression | STAT 501">
<node CREATED="1557224068601" ID="ID_1408983768" MODIFIED="1557224068601" TEXT="9.7 - Polynomial Regression. Printer-friendly version. In our earlier discussions on multiple linear regression we have outlined ways to check assumptions of&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1534920878" LINK="https://www.geeksforgeeks.org/python-implementation-of-polynomial-regression/" MODIFIED="1557225479661" TEXT="Python | Implementation of Polynomial Regression - GeeksforGeeks">
<node CREATED="1557224068601" ID="ID_594511369" MODIFIED="1557224068601" TEXT="Polynomial Regression is a form of linear regression in which the relationship between the independent variable x and dependent variable y is modeled as an&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1360447549" LINK="http://www.xuru.org/rt/pr.asp" MODIFIED="1557225479661" TEXT="Regression Tools - Online Polynomial Regression">
<node CREATED="1557224068601" ID="ID_1584249477" MODIFIED="1557224068601" TEXT="This page allows performing polynomial regressions (polynomial least squares fittings). For the relation between two variables it finds the polynomial function&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_699276137" LINK="http://home.iitk.ac.in/~shalab/regression/Chapter12-Regression-PolynomialRegression.pdf" MODIFIED="1557225479661" TEXT="Chapter 12 Polynomial Regression Models Polynomial models in ">
<node CREATED="1557224068601" ID="ID_1419570713" MODIFIED="1557224068601" TEXT="is a polynomial regression model in one variable and is called as second  fitting of higher order polynomials can be a serious abuse of regression analysis." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_692183878" MODIFIED="1563517391360" TEXT="Isotonic Regression">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068601" FOLDED="true" ID="ID_144814865" MODIFIED="1557225483436" TEXT="Isotonic Regression#$D$#">
<node CREATED="1557224068601" FOLDED="true" ID="ID_273301952" LINK="https://en.wikipedia.org/wiki/Isotonic_regression" MODIFIED="1557225479661" TEXT="Isotonic regression - Wikipedia">
<node CREATED="1557224068601" ID="ID_1376033512" MODIFIED="1557224068601" TEXT="In statistics isotonic regression or monotonic regression is the technique of fitting a free-form line to a sequence of observations under the following constraints:&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_402833476" LINK="http://scikit-learn.org/stable/auto_examples/plot_isotonic_regression.html" MODIFIED="1557225479661" TEXT="Isotonic Regression &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068601" ID="ID_761497103" MODIFIED="1557224068601" TEXT="An illustration of the isotonic regression on generated data. The isotonic regression finds a non-decreasing approximation of a function while minimizing the&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_214864405" LINK="https://stat.fandom.com/wiki/Isotonic_regression" MODIFIED="1557225479661" TEXT="Isotonic regression | Stat Wiki | FANDOM powered by Wikia">
<node CREATED="1557224068601" ID="ID_1699033802" MODIFIED="1557224068601" TEXT="Linear ordering isotonic regression can be understood as approximating given series of 1-dimensional observations with non-decreasing function. It is similar to&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1543247632" LINK="http://scikit-learn.org/stable/modules/isotonic.html" MODIFIED="1557225479661" TEXT="1.15. Isotonic regression &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068601" ID="ID_16292861" MODIFIED="1557224068601" TEXT="where each w i is strictly positive and each y i is an arbitrary real number. It yields the vector which is composed of non-decreasing elements the closest in terms&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1017879934" LINK="https://spark.apache.org/docs/latest/mllib-isotonic-regression.html" MODIFIED="1557225479661" TEXT="Isotonic regression - RDD-based API - Spark 2.4.1 Documentation">
<node CREATED="1557224068601" ID="ID_89802771" MODIFIED="1557224068601" TEXT="Isotonic regression belongs to the family of regression algorithms. Formally isotonic regression is a problem where given a finite set of real numbers Y=y1y2" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1309448945" LINK="http://www.stat.cmu.edu/~ryantibs/papers/neariso.pdf" MODIFIED="1557225479661" TEXT="Nearly-Isotonic Regression">
<node CREATED="1557224068601" ID="ID_1000936249" MODIFIED="1557224068601" TEXT="Key words: isotonic regression pool adjacent violators path algorithm degrees  Isotonic regression solves the following problem: given a sequence of n data&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1720167812" LINK="http://fa.bianp.net/blog/2013/isotonic-regression/" MODIFIED="1557225479661" TEXT="Isotonic Regression">
<node CREATED="1557224068601" ID="ID_1562067469" MODIFIED="1557224068601" TEXT="Apr 16 2013  My latest contribution for scikit-learn is an implementation of the isotonic regression model that I coded with Nelle Varoquaux and Alexandre&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1228210564" LINK="https://arxiv.org/abs/1810.03269" MODIFIED="1557225479661" TEXT="Causal isotonic regression">
<node CREATED="1557224068601" ID="ID_112289163" MODIFIED="1557224068601" TEXT="Oct 8 2018   our proposed estimation procedure generalizes the classical least-squares isotonic regression estimator of a monotone regression function." />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_352620546" LINK="https://projecteuclid.org/euclid.aos/1021379864" MODIFIED="1557225479661" TEXT="Zhang : Risk bounds in isotonic regression">
<node CREATED="1557224068601" ID="ID_1332118483" MODIFIED="1557224068601" TEXT="Nonasymptotic risk bounds are provided for maximum likelihood-type isotonic estimators of an unknown nondecreasing regression function with general&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1540368993" LINK="https://arxiv.org/abs/1708.09468" MODIFIED="1557225479661" TEXT="Isotonic regression in general dimensions">
<node CREATED="1557224068601" ID="ID_1971781770" MODIFIED="1557224068601" TEXT="Aug 30 2017  Further we prove a sharp oracle inequality which reveals in particular that when the true regression function is piecewise constant on&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" FOLDED="true" Folded="true" ID="ID_1910396275" MODIFIED="1563517391360" TEXT="Logistic Regression">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_368186500" MODIFIED="1563517391360" TEXT="Linear Classification">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068601" FOLDED="true" ID="ID_1381107734" MODIFIED="1557225483436" TEXT="Logistic Regression#$D$#">
<node CREATED="1557224068601" FOLDED="true" ID="ID_83615752" LINK="https://en.wikipedia.org/wiki/Logistic_regression" MODIFIED="1557225479661" TEXT="Logistic regression - Wikipedia">
<node CREATED="1557224068601" ID="ID_262742246" MODIFIED="1557224068601" TEXT="In statistics the logistic model (or logit model) is a widely used statistical model that in its basic form uses a logistic function to model a binary dependent variable&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_554425531" LINK="https://towardsdatascience.com/logistic-regression-detailed-overview-46c4da4303bc" MODIFIED="1557225479661" TEXT="Logistic Regression &#8212; Detailed Overview &#8211; Towards Data Science">
<node CREATED="1557224068601" ID="ID_1483984760" MODIFIED="1557224068601" TEXT="Mar 15 2018  Logistic Regression was used in the biological sciences in early twentieth century. It was then used in many social science applications." />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_749514" LINK="https://www.statisticssolutions.com/what-is-logistic-regression/" MODIFIED="1557225479661" TEXT="What is Logistic Regression? - Statistics Solutions">
<node CREATED="1557224068601" ID="ID_100414559" MODIFIED="1557224068601" TEXT="Like all regression analyses the logistic regression is a predictive analysis. Logistic regression is used to describe data and to explain the relationship between&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1301840289" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html" MODIFIED="1557225479661" TEXT="sklearn.linear_model.LogisticRegression &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068601" ID="ID_1727658910" MODIFIED="1557224068601" TEXT="This class implements regularized logistic regression using the liblinear library newton-cg sag and lbfgs solvers. It can handle both dense and sparse input&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_633256714" LINK="https://ml-cheatsheet.readthedocs.io/en/latest/logistic_regression.html" MODIFIED="1557225479661" TEXT="Logistic Regression &#8212; ML Cheatsheet documentation">
<node CREATED="1557224068601" ID="ID_543356884" MODIFIED="1557224068601" TEXT="Logistic regression is a classification algorithm used to assign observations to a discrete set of classes. Unlike linear regression which outputs continuous&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1569826318" LINK="https://www.youtube.com/watch?v=yIYKR4sgzI8" MODIFIED="1557225479661" TEXT="StatQuest: Logistic Regression - YouTube">
<node CREATED="1557224068601" ID="ID_1953396127" MODIFIED="1557224068601" TEXT="Mar 5 2018  Logistic regression is a traditional statistics technique that is also very popular as a machine learning tool. In this StatQuest I go over the main&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1193159632" LINK="https://developers.google.com/machine-learning/crash-course/logistic-regression/video-lecture" MODIFIED="1557225479661" TEXT="Logistic Regression | Machine Learning Crash Course | Google ">
<node CREATED="1557224068601" ID="ID_1124325912" MODIFIED="1557224068601" TEXT="Mar 5 2019  Instead of predicting exactly 0 or 1 logistic regression generates a probability&#8212;a value between 0 and 1 exclusive. For example consider a&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_200123797" LINK="https://www.sciencedirect.com/topics/medicine-and-dentistry/logistic-regression-analysis" MODIFIED="1557225479661" TEXT="Logistic Regression Analysis - an overview | ScienceDirect Topics">
<node CREATED="1557224068601" ID="ID_1021322472" MODIFIED="1557224068601" TEXT="An advantage of logistic regression is that it allows the evaluation of multiple explanatory variables by extension of the basic principles. The general equation is." />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_606952679" LINK="https://machinelearningmastery.com/logistic-regression-for-machine-learning/" MODIFIED="1557225479661" TEXT="Logistic Regression for Machine Learning">
<node CREATED="1557224068601" ID="ID_765815657" MODIFIED="1557224068601" TEXT="Apr 1 2016  Logistic regression is another technique borrowed by machine learning from the field of statistics. It is the go-to method for binary classification&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1513868491" LINK="https://newonlinecourses.science.psu.edu/stat504/node/149/" MODIFIED="1557225479661" TEXT="Lesson 6: Logistic Regression | STAT 504">
<node CREATED="1557224068601" ID="ID_1519080650" MODIFIED="1557224068601" TEXT="Binary Logistic Regression is a special type of regression where binary response variable is related to a set of explanatory variables which can be discrete&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_631068756" MODIFIED="1563517391360" TEXT="Implementation">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1640583517" MODIFIED="1563517391360" TEXT="Optimizations">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
<node CREATED="1563517391360" FOLDED="true" Folded="true" ID="ID_1119740706" MODIFIED="1563517391360" TEXT="Stochastic Gradient Descent Algorithms">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_467208729" MODIFIED="1563517391360" TEXT="Finding the Optimal hyper-parameters through Grid Search">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068602" FOLDED="true" ID="ID_1320963416" MODIFIED="1557225483437" TEXT="Stochastic Gradient Descent Algorithms#$D$#">
<node CREATED="1557224068602" FOLDED="true" ID="ID_42958663" LINK="https://en.wikipedia.org/wiki/Stochastic_gradient_descent" MODIFIED="1557225479661" TEXT="Stochastic gradient descent - Wikipedia">
<node CREATED="1557224068602" ID="ID_295528884" MODIFIED="1557224068602" TEXT="Stochastic gradient descent (often shortened to SGD) also known as incremental gradient .. models originally under the name ADALINE. Another stochastic gradient descent algorithm is the least mean squares (LMS) adaptive filter." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_824581286" LINK="http://ruder.io/optimizing-gradient-descent/" MODIFIED="1557225479661" TEXT="An overview of gradient descent optimization algorithms">
<node CREATED="1557224068602" ID="ID_206062363" MODIFIED="1557224068602" TEXT="Jan 19 2016  Gradient descent is one of the most popular algorithms to perform  Stochastic gradient descent (SGD) in contrast performs a parameter&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_99913295" LINK="https://towardsdatascience.com/stochastic-gradient-descent-with-momentum-a84097641a5d" MODIFIED="1557225479661" TEXT="Stochastic Gradient Descent with momentum &#8211; Towards Data Science">
<node CREATED="1557224068602" ID="ID_1391413969" MODIFIED="1557224068602" TEXT="Dec 4 2017  Part 1 was about Stochastic gradient descent. In this post I presume basic knowledge about neural networks and gradient descent algorithm." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_555031337" LINK="https://www.geeksforgeeks.org/ml-stochastic-gradient-descent-sgd/" MODIFIED="1557225479661" TEXT="ML | Stochastic Gradient Descent (SGD) - GeeksforGeeks">
<node CREATED="1557224068602" ID="ID_1019731106" MODIFIED="1557224068602" TEXT="Before talking about Stochastic Gradient Descent (SGD) lets first understand  Deep Learning and it can be used with most if not all of the learning algorithms." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1446964593" LINK="https://towardsdatascience.com/difference-between-batch-gradient-descent-and-stochastic-gradient-descent-1187f1291aa1" MODIFIED="1557225479661" TEXT="Difference between Batch Gradient Descent and Stochastic Gradient ">
<node CREATED="1557224068602" ID="ID_1058741279" MODIFIED="1557224068602" TEXT="Sep 20 2017  Above algorithm says to perform the GD we need to calculate the gradient of the cost function J. And to calculate the gradient of the cost&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_524299203" LINK="http://deeplearning.stanford.edu/tutorial/supervised/OptimizationStochasticGradientDescent/" MODIFIED="1557225479661" TEXT="Stochastic Gradient Descent">
<node CREATED="1557224068602" ID="ID_382549482" MODIFIED="1557224068602" TEXT="Stochastic Gradient Descent (SGD) addresses both of these issues by following the  The standard gradient descent algorithm updates the parameters &#952; of the&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_798140926" LINK="http://scikit-learn.org/stable/modules/sgd.html" MODIFIED="1557225479661" TEXT="1.5. Stochastic Gradient Descent &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068602" ID="ID_328310024" MODIFIED="1557224068602" TEXT="Stochastic Gradient Descent (SGD) is a simple yet very efficient approach to . is available with Stochastic Average Gradient (SAG) algorithm available as a&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_255954776" LINK="https://machinelearningmastery.com/gradient-descent-for-machine-learning/" MODIFIED="1557225479661" TEXT="Gradient Descent For Machine Learning">
<node CREATED="1557224068602" ID="ID_856044770" MODIFIED="1557224068602" TEXT="Mar 23 2016  Gradient descent is an optimization algorithm used to find the . The learning can be much faster with stochastic gradient descent for very large&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1309721262" LINK="https://gluon.mxnet.io/chapter06_optimization/gd-sgd-scratch.html" MODIFIED="1557225479661" TEXT="Gradient descent and stochastic gradient descent from scratch ">
<node CREATED="1557224068602" ID="ID_1165990683" MODIFIED="1557224068602" TEXT="Why doesnt the gradient descent algorithm get stuck on the way to a low loss? . To motivate the use of stochastic optimization algorithms note that when&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_59678504" LINK="http://arxiv.org/abs/1902.00635" MODIFIED="1557225479661" TEXT="Uniform-in-Time Weak Error Analysis for Stochastic Gradient ">
<node CREATED="1557224068602" ID="ID_1596830530" MODIFIED="1557224068602" TEXT="Feb 2 2019   for Stochastic Gradient Descent Algorithms via Diffusion Approximation  error analysis of numerical stochastic differential equations into the&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1353887158" MODIFIED="1557225483437" TEXT="Stochastic Gradient Descent Algorithms Finding the Optimal hyper-parameters through Grid Search#$D$#">
<node CREATED="1557224068602" FOLDED="true" ID="ID_1868940221" LINK="https://towardsdatascience.com/hyper-parameter-tuning-techniques-in-deep-learning-4dad592c63c8" MODIFIED="1557225479661" TEXT="Hyper-parameter Tuning Techniques in Deep Learning &#8211; Towards ">
<node CREATED="1557224068602" ID="ID_303035551" MODIFIED="1557224068602" TEXT="Mar 16 2019  Before discussing the ways to find the optimal hyper-parameters let us first  In the gradient descent algorithm we start with random model  In grid search [3] we try every possible configuration of the parameters. Steps:." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_747760307" LINK="https://en.wikipedia.org/wiki/Hyperparameter_optimization" MODIFIED="1557225479661" TEXT="Hyperparameter optimization - Wikipedia">
<node CREATED="1557224068602" ID="ID_1391807625" MODIFIED="1557224068602" TEXT="In machine learning hyperparameter optimization or tuning is the problem of choosing a set of optimal hyperparameters for a learning algorithm. A hyperparameter is a parameter whose value is used to control the learning  Both parameters are continuous so to perform grid search one selects a finite set of reasonable&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1003210161" LINK="https://towardsdatascience.com/hyperparameter-tuning-c5619e7e6624" MODIFIED="1557225479661" TEXT="Hyperparameter Tuning &#8211; Towards Data Science">
<node CREATED="1557224068602" ID="ID_671515457" MODIFIED="1557224068602" TEXT="Feb 16 2019   tuning is choosing a set of optimal hyperparameters for a learning algorithm&#8221;.  In sklearn hyperparameters are passed in as arguments to the  Our top performing models here are logistic regression and stochastic gradient descent.  The benefit of grid search is that it is guaranteed to find the optimal&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_781221845" LINK="https://machinelearningmastery.com/grid-search-hyperparameters-deep-learning-models-python-keras/" MODIFIED="1557225479661" TEXT="How to Grid Search Hyperparameters for Deep Learning Models in ">
<node CREATED="1557224068602" ID="ID_1108315412" MODIFIED="1557224068602" TEXT="Aug 9 2016  Update Oct/2016: Updated examples for Keras 1.1.0 TensorFlow . This is not the best way to grid search because parameters can .. By far the most common optimization algorithm is plain old Stochastic Gradient Descent&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_201562616" LINK="http://scikit-learn.org/stable/modules/grid_search.html" MODIFIED="1557225479661" TEXT="3.2. Tuning the hyper-parameters of an estimator &#8212; scikit-learn 0.20 ">
<node CREATED="1557224068602" ID="ID_515936738" MODIFIED="1557224068602" TEXT="Specifically to find the names and current values for all parameters for a given  The grid search provided by GridSearchCV exhaustively generates  Y. Random search for hyper-parameter optimization The Journal of Machine  Cross-validated Lasso using the LARS algorithm.  Gradient Boosting for classification." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1184749214" LINK="http://www.jmlr.org/papers/volume13/bergstra12a/bergstra12a.pdf" MODIFIED="1557225479661" TEXT="Random Search for Hyper-Parameter Optimization">
<node CREATED="1557224068602" ID="ID_1474876209" MODIFIED="1557224068602" TEXT="manual search and grid search purely random search over the same  called hyper-parameters &#955; and the actual learning algorithm is the one obtained  binations of values for the stochastic gradient descent learning rate of the supervised." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_31014306" LINK="https://medium.freecodecamp.org/an-introduction-to-high-dimensional-hyper-parameter-tuning-df5c0106e5a4" MODIFIED="1557225479661" TEXT="An introduction to high-dimensional hyper-parameter tuning">
<node CREATED="1557224068602" ID="ID_1554756910" MODIFIED="1557224068602" TEXT="Dec 13 2018  Hyper-parameter tuning refers to the problem of finding an optimal set of parameter values for a learning algorithm. Even for  Grid Search is usually a good choice when we have a small number of parameters to optimize. For two or . Machine Learning 101: An Intuitive Introduction to Gradient Descent" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1855796682" LINK="http://scikit-learn.org/stable/modules/sgd.html" MODIFIED="1557225479661" TEXT="1.5. Stochastic Gradient Descent &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068602" ID="ID_1917099579" MODIFIED="1557224068602" TEXT="Stochastic Gradient Descent (SGD) is a simple yet very efficient approach to  classifiers in this module easily scale to problems with more than 10^5 training examples and  SGD requires a number of hyperparameters such as the regularization . with Stochastic Average Gradient (SAG) algorithm available as a solver in&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1861905545" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781785889622/5/ch05lvl1sec43/finding-the-optimal-hyperparameters-through-grid-search" MODIFIED="1557225479661" TEXT="Finding the optimal hyperparameters through grid search - Machine ">
<node CREATED="1557224068602" ID="ID_1194087068" MODIFIED="1557224068602" TEXT="Finding the optimal hyperparameters through grid searchFinding the best hyperparameters (called this  Stochastic gradient descent algorithms  As an example we show how to use it to find the best penalty and strength factors for a linear&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_816563324" LINK="https://www.kaggle.com/willkoehrsen/intro-to-model-tuning-grid-and-random-search" MODIFIED="1557225479661" TEXT="Intro to Model Tuning: Grid and Random Search | Kaggle">
<node CREATED="1557224068602" ID="ID_260873769" MODIFIED="1557224068602" TEXT="Ill try to stick to using model hyperparameters or model settings and Ill point out when Im  use methods such as gradient descent Bayesian Optimization or evolutionary algorithms to conduct a guided search for the best hyperparameters." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1659849781" MODIFIED="1563517391360" TEXT="Classification Metric">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068602" FOLDED="true" ID="ID_297684779" MODIFIED="1557225483437" TEXT="Stochastic Gradient Descent Algorithms Classification Metric#$D$#">
<node CREATED="1557224068602" FOLDED="true" ID="ID_1739823686" LINK="https://ieeexplore.ieee.org/document/8552662/" MODIFIED="1557225479661" TEXT="Scalable Large-Margin Distance Metric Learning Using Stochastic ">
<node CREATED="1557224068602" ID="ID_340983662" MODIFIED="1557224068602" TEXT="Nov 29 2018  The main challenge of distance metric learning is the positive  we develop an efficient algorithm based on a stochastic gradient descent.  metric learning approaches regarding classification accuracy and training time." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1253964629" LINK="http://scikit-learn.org/stable/modules/sgd.html" MODIFIED="1557225479661" TEXT="1.5. Stochastic Gradient Descent &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068602" ID="ID_1164902695" MODIFIED="1557224068602" TEXT="Stochastic Gradient Descent (SGD) is a simple yet very efficient approach to . SGDClassifier supports multi-class classification by combining multiple binary  is available with Stochastic Average Gradient (SAG) algorithm available as a&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1241086145" LINK="https://machinelearningmastery.com/understand-the-dynamics-of-learning-rate-on-deep-learning-neural-networks/" MODIFIED="1557225479661" TEXT="Understand the Impact of Learning Rate on Model Performance With ">
<node CREATED="1557224068602" ID="ID_1582701203" MODIFIED="1557224068602" TEXT="Jan 25 2019  Stochastic gradient descent is an optimization algorithm that estimates the error . The ReduceLROnPlateau requires you to specify the metric to monitor . We will use a small multi-class classification problem as the basis to&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1793571160" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.ensemble.GradientBoostingClassifier.html" MODIFIED="1557225479661" TEXT="3.2.4.3.5. sklearn.ensemble.GradientBoostingClassifier &#8212; scikit ">
<node CREATED="1557224068602" ID="ID_127512091" MODIFIED="1557224068602" TEXT="Binary classification is a special case where only a single regression tree is induced.  For loss exponential gradient boosting recovers the AdaBoost algorithm.  If smaller than 1.0 this results in Stochastic Gradient Boosting. subsample .. In multi-label classification this is the subset accuracy which is a harsh metric&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_140815535" LINK="https://subscription.packtpub.com/video/big_data_and_business_intelligence/9781789134377/55288/55290/stochastic-gradient-descent-algorithms" MODIFIED="1557225479661" TEXT="Stochastic Gradient Descent Algorithms - Fundamentals of Machine ">
<node CREATED="1557224068602" ID="ID_342336582" MODIFIED="1557224068602" TEXT="Mar 28 2018  Generate example using function make classification - Check the score - Use the perceptron class t.  Stochastic Gradient Descent Algorithms&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_769025130" LINK="https://software.intel.com/en-us/daal-programming-guide-stochastic-gradient-descent-algorithm" MODIFIED="1557225479661" TEXT="Stochastic Gradient Descent Algorithm | Intel&#174; Data Analytics ">
<node CREATED="1557224068602" ID="ID_756268841" MODIFIED="1557224068602" TEXT="Mar 7 2019  The stochastic gradient descent (SGD) algorithm is a special case of an iterative solver. For more details see Iterative Solver. The following&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_320009371" LINK="https://machinelearningmastery.com/how-to-control-the-speed-and-stability-of-training-neural-networks-with-gradient-descent-batch-size/" MODIFIED="1557225479661" TEXT="How to Control the Speed and Stability of Training Neural Networks ">
<node CREATED="1557224068602" ID="ID_1273763204" MODIFIED="1557224068602" TEXT="Jan 21 2019  Batch Size and Gradient Descent; Stochastic Batch and Minibatch Gradient Descent in Keras; Multi-Class Classification Problem; MLP Fit  Optimization algorithms that use the entire training set are called batch or .. model.compile(loss=categorical_crossentropy optimizer=opt metrics=[accuracy])." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_515310911" LINK="https://www.researchgate.net/publication/329299351_Scalable_Large-Margin_Distance_Metric_Learning_Using_Stochastic_Gradient_Descent" MODIFIED="1557225479661" TEXT="Scalable Large-Margin Distance Metric Learning Using Stochastic ">
<node CREATED="1557224068602" ID="ID_809250888" MODIFIED="1557224068602" TEXT="Feb 19 2019  Extensive experiments show that the proposed algorithm is scalable to large  distance metric learning approaches regarding classification accuracy and training time. . Stochastic gradient descent with only one projection." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1275920177" LINK="https://topepo.github.io/caret/model-training-and-tuning.html" MODIFIED="1557225479661" TEXT="5 Model Training and Tuning | The caret Package">
<node CREATED="1557224068602" ID="ID_969845674" MODIFIED="1557224068602" TEXT="The first step in tuning the model (line 1 in the algorithm below) is to choose a set of  Stochastic Gradient Boosting ## ## 157 samples ## 60 predictor ## 2 classes: M . for regression while accuracy and Kappa are computed for classification.  The metric argument of the train function allows the user to control which the&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1940400899" LINK="https://developers.google.com/machine-learning/glossary/" MODIFIED="1557225479661" TEXT="Machine Learning Glossary | Google Developers">
<node CREATED="1557224068602" ID="ID_1690783773" MODIFIED="1557224068602" TEXT="Jan 22 2019  A sophisticated gradient descent algorithm that rescales the gradients of  An evaluation metric that considers all possible classification thresholds. .. Similarly many variations of stochastic gradient descent have a high&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1063740574" MODIFIED="1563517391360" TEXT="ROC Curve">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068602" FOLDED="true" ID="ID_1179998" MODIFIED="1557225483437" TEXT="Stochastic Gradient Descent Algorithms ROC Curve#$D$#">
<node CREATED="1557224068602" FOLDED="true" ID="ID_47498996" LINK="https://developers.google.com/machine-learning/glossary/" MODIFIED="1557225479661" TEXT="Machine Learning Glossary | Google Developers">
<node CREATED="1557224068602" ID="ID_734723994" MODIFIED="1557224068602" TEXT="Jan 22 2019  A sophisticated gradient descent algorithm that rescales the gradients of  The Area Under the ROC curve is the probability that a classifier will be more .. Similarly many variations of stochastic gradient descent have a high&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_262006376" LINK="https://towardsdatascience.com/understanding-gradient-boosting-machines-9be756fe76ab" MODIFIED="1557225479661" TEXT="Understanding Gradient Boosting Machines &#8211; Towards Data Science">
<node CREATED="1557224068602" ID="ID_1600298497" MODIFIED="1557224068602" TEXT="Nov 3 2018  The gradient boosting algorithm (gbm) can be most easily explained by  I have ensured that the same set of random numbers are generated every time. . positives I produced the ROC curve and calculated our AUC value." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_344006581" LINK="https://cran.r-project.org/web/packages/gbm/gbm.pdf" MODIFIED="1557225479661" TEXT="Package gbm">
<node CREATED="1557224068602" ID="ID_1520771094" MODIFIED="1557224068602" TEXT="Jan 14 2019  algorithm and Friedmans gradient boosting machine. Includes regression .. to the Area under the ROC Curve. : Fraction of concordant pairs;&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1221347103" LINK="https://icml.cc/Conferences/2004/proceedings/papers/132.pdf" MODIFIED="1557225479661" TEXT="Optimising Area Under the ROC Curve Using Gradient Descent">
<node CREATED="1557224068602" ID="ID_512654375" MODIFIED="1557224068602" TEXT="Optimising Area Under the ROC Curve Using Gradient Descent. Alan Herschtal. ALAN.  ROC curve (the AUC).  In this paper we introduce RankOpt an algorithm that op-  be expressed as the probability that for such a random ob-." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1779783060" LINK="https://elitedatascience.com/machine-learning-interview-questions-answers" MODIFIED="1557225479661" TEXT="21 Machine Learning Interview Questions and Answers">
<node CREATED="1557224068602" ID="ID_1535564868" MODIFIED="1557224068602" TEXT="Oct 9 2017  Algorithms for finding the best parameters for a model.  In stochastic gradient descent youll evaluate only 1 training sample for the set of . AUC is area under the ROC curve and its a common performance metric for&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_787285088" LINK="https://hansfricke.github.io/projects.html" MODIFIED="1557225479661" TEXT="Projects">
<node CREATED="1557224068602" ID="ID_22877670" MODIFIED="1557224068602" TEXT="I challenged myself to go beyond applying familiar algorithms such as  learning algorithms I used random forests stochastic gradient descent with  The model parameters were determined using the area under the ROC curve in the grid&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1211450429" LINK="http://proceedings.mlr.press/v80/natole18a/natole18a.pdf" MODIFIED="1557225479661" TEXT="Stochastic Proximal Algorithms for AUC Maximization">
<node CREATED="1557224068602" ID="ID_414428688" MODIFIED="1557224068602" TEXT="Abstract. Stochastic optimization algorithms such as stochastic gradient descent (SGD) update the  under the ROC curve (AUC) (Hanley  McNeil 1982;." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1026471347" LINK="http://www.ece.neu.edu/fac-ece/ioannidis/EECE5698.html" MODIFIED="1557225479661" TEXT="Stratis Ioannidis - &#931;&#964;&#961;&#945;&#964;&#942;&#962; &#921;&#969;&#945;&#957;&#957;&#943;&#948;&#951;&#962;: Teaching">
<node CREATED="1557224068602" ID="ID_1069936035" MODIFIED="1557224068602" TEXT="This course covers the fundamentals of parallel machine learning algorithms tailored specifically to  ROC curves and AUC. Stochastic gradient descent." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1561570081" LINK="http://people.eecs.berkeley.edu/~jrs/189/" MODIFIED="1557225479661" TEXT="CS 189/289A: Introduction to Machine Learning">
<node CREATED="1557224068602" ID="ID_1475571264" MODIFIED="1557224068602" TEXT="This class introduces algorithms for learning which constitute an important part of artificial  Lecture 3 (January 30): Gradient descent stochastic gradient descent and the  Optional: here is a fine short discussion of ROC curves&#8212;but skip the&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1437653590" LINK="http://www.roboticsproceedings.org/rss11/p02.pdf" MODIFIED="1557225479661" TEXT="Hilbert maps: scalable continuous occupancy mapping with ">
<node CREATED="1557224068602" ID="ID_1193978867" MODIFIED="1557224068602" TEXT="trained and updated using stochastic gradient descent making the computation .. acteristic (ROC) curve for the four approaches (Hilbert maps with Fourier&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
</node>
<node CREATED="1563517391360" FOLDED="true" Folded="true" ID="ID_986073883" MODIFIED="1563517391360" POSITION="left" TEXT="Naive Bayes and Support Vector Machine">
<edge COLOR="#00cc33" />
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_898218157" MODIFIED="1563517391360" TEXT="Naive Bayes">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_27345984" MODIFIED="1563517391360" TEXT="Bayes Theorem">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068603" FOLDED="true" ID="ID_93002203" MODIFIED="1557225483437" TEXT="Bayes Theorem#$D$#">
<node CREATED="1557224068603" FOLDED="true" ID="ID_511849847" LINK="https://en.wikipedia.org/wiki/Bayes%27_theorem" MODIFIED="1557225479661" TEXT="Bayes theorem - Wikipedia">
<node CREATED="1557224068603" ID="ID_399637890" MODIFIED="1557224068603" TEXT="In probability theory and statistics Bayes theorem describes the probability of an event based on prior knowledge of conditions that might be related to the&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_66949498" LINK="https://www.mathsisfun.com/data/bayes-theorem.html" MODIFIED="1557225479661" TEXT="Bayes Theorem">
<node CREATED="1557224068603" ID="ID_838021626" MODIFIED="1557224068603" TEXT="And it calculates that probability using Bayes Theorem. Bayes Theorem is a way of finding a probability when we know certain other probabilities. The formula&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1300111454" LINK="https://betterexplained.com/articles/an-intuitive-and-short-explanation-of-bayes-theorem/" MODIFIED="1557225479661" TEXT="An Intuitive (and Short) Explanation of Bayes Theorem ">
<node CREATED="1557224068603" ID="ID_1060395713" MODIFIED="1557224068603" TEXT="Bayes theorem was the subject of a detailed article. The essay is good but over 15000 words long &#8212; heres the condensed version for Bayesian newcomers&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_637566461" LINK="https://www.khanacademy.org/math/ap-statistics/probability-ap/stats-conditional-probability/v/bayes-theorem-visualized" MODIFIED="1557225479661" TEXT="Conditional probability with Bayes Theorem (video) | Khan Academy">
<node CREATED="1557224068603" ID="ID_372645747" MODIFIED="1557224068603" TEXT="Conditional probability with Bayes Theorem. About. Conditional probability visualized using trees. Created by Brit Cruise. Google Classroom Facebook Twitter." />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_481526400" LINK="http://mathworld.wolfram.com/BayesTheorem.html" MODIFIED="1557225479661" TEXT="Bayes Theorem -- from Wolfram MathWorld">
<node CREATED="1557224068603" ID="ID_902679881" MODIFIED="1557224068603" TEXT="Papoulis A. Bayes Theorem in Statistics and Bayes Theorem in Statistics (Reexamined). &#167;3-5 and 4-4 in Probability Random Variables and Stochastic&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_646874591" LINK="https://www.khanacademy.org/partner-content/wi-phi/wiphi-critical-thinking/wiphi-fundamentals/v/bayes-theorem" MODIFIED="1557225479661" TEXT="Bayes theorem of conditional probability (video) | Khan Academy">
<node CREATED="1557224068603" ID="ID_1560565577" MODIFIED="1557224068603" TEXT="In this Wireless Philosophy video Ian Olasov (CUNY) introduces Bayes Theorem of conditional probability and the related Base Rate Fallacy. Speaker: Ian&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1879296782" LINK="https://stattrek.com/probability/bayes-theorem.aspx" MODIFIED="1557225479661" TEXT="Bayes Theorem">
<node CREATED="1557224068603" ID="ID_612222578" MODIFIED="1557224068603" TEXT="This lesson covers Bayes theorem. Shows how to use Bayes rule to solve conditional probability problems. Includes sample problem with step-by-step solution." />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1925415695" LINK="https://towardsdatascience.com/bayes-theorem-the-holy-grail-of-data-science-55d93315defb" MODIFIED="1557225479661" TEXT="Bayes Theorem: The Holy Grail of Data Science &#8211; Towards Data ">
<node CREATED="1557224068603" ID="ID_649761816" MODIFIED="1557224068603" TEXT="Dec 22 2018  Bayes Theorem is perhaps the most important theorem in the field of mathematical statistics and probability theory. For this reason the&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1569377971" LINK="https://www.youtube.com/watch?v=BcvLAw-JRss" MODIFIED="1557225479661" TEXT="Everything You Ever Wanted to Know About Bayes Theorem But ">
<node CREATED="1557224068603" ID="ID_68396381" MODIFIED="1557224068603" TEXT="Oct 27 2015  Probability has an improbable history. Thomas Bayes deserves credit for introducing conditional probability but The Frequentists didnt make it&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_568488529" LINK="https://brilliant.org/wiki/bayes-theorem/" MODIFIED="1557225479661" TEXT="Bayes Theorem and Conditional Probability | Brilliant Math ">
<node CREATED="1557224068603" ID="ID_715637254" MODIFIED="1557224068603" TEXT="Bayes theorem is a formula that describes how to update the probabilities of hypotheses when given evidence. It follows simply from the axioms of conditional&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_758956338" MODIFIED="1563517391360" TEXT="Naive Bayes Classifiers">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068602" FOLDED="true" ID="ID_1931599025" MODIFIED="1557225483437" TEXT="Naive Bayes#$D$#">
<node CREATED="1557224068602" FOLDED="true" ID="ID_1674569310" LINK="https://en.wikipedia.org/wiki/Naive_Bayes_classifier" MODIFIED="1557225479661" TEXT="Naive Bayes classifier - Wikipedia">
<node CREATED="1557224068602" ID="ID_110903721" MODIFIED="1557224068602" TEXT="In machine learning naive Bayes classifiers are a family of simple probabilistic classifiers based on applying Bayes theorem with strong (naive) independence&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1638932138" LINK="http://scikit-learn.org/stable/modules/naive_bayes.html" MODIFIED="1557225479661" TEXT="1.9. Naive Bayes &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068602" ID="ID_396755788" MODIFIED="1557224068602" TEXT="Naive Bayes methods are a set of supervised learning algorithms based on applying Bayes theorem with the &#8220;naive&#8221; assumption of conditional independence&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_701140179" LINK="https://www.analyticsvidhya.com/blog/2017/09/naive-bayes-explained/" MODIFIED="1557225479661" TEXT="6 Easy Steps to Learn Naive Bayes Algorithm (with code in Python)">
<node CREATED="1557224068602" ID="ID_879232369" MODIFIED="1557224068602" TEXT="Sep 11 2017  This article describes the basic principle behind Naive Bayes algorithm its application pros  cons along with its implementation in Python&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_188782280" LINK="https://towardsdatascience.com/introduction-to-naive-bayes-classification-4cffabb1ae54" MODIFIED="1557225479661" TEXT="Introduction to Naive Bayes Classification &#8211; Towards Data Science">
<node CREATED="1557224068602" ID="ID_1671352786" MODIFIED="1557224068602" TEXT="May 16 2018  Naive Bayes is a simple yet effective and commonly-used machine learning classifier. It is a probabilistic classifier that makes classifications&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1590109918" LINK="https://www.youtube.com/watch?v=CPqOCI0ahss" MODIFIED="1557225479661" TEXT="Na&#239;ve Bayes Classifier - Fun and Easy Machine Learning - YouTube">
<node CREATED="1557224068602" ID="ID_153758326" MODIFIED="1557224068602" TEXT="Aug 26 2017  Naive Bayes Classifier- Fun and Easy Machine Learning &#9659;FREE YOLO GIFT - http://augmentedstartups.info/yolofreegiftsp &#9659;KERAS COURSE&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1314860866" LINK="https://www.geeksforgeeks.org/naive-bayes-classifiers/" MODIFIED="1557225479661" TEXT="Naive Bayes Classifiers - GeeksforGeeks">
<node CREATED="1557224068602" ID="ID_244597750" MODIFIED="1557224068602" TEXT="Naive Bayes classifiers are a collection of classification algorithms based on Bayes Theorem. It is not a single algorithm but a family of algorithms where all of&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1591805741" LINK="http://www.statsoft.com/textbook/naive-bayes-classifier" MODIFIED="1557225479661" TEXT="Naive Bayes Classifier">
<node CREATED="1557224068602" ID="ID_1210890250" MODIFIED="1557224068602" TEXT="The Naive Bayes Classifier technique is based on the so-called Bayesian theorem and is particularly suited when the dimensionality of the inputs is high." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1398849207" LINK="https://machinelearningmastery.com/naive-bayes-for-machine-learning/" MODIFIED="1557225479661" TEXT="Naive Bayes for Machine Learning">
<node CREATED="1557224068603" ID="ID_1259896205" MODIFIED="1557224068603" TEXT="Apr 11 2016  Naive Bayes is a simple but surprisingly powerful algorithm for predictive modeling. In this post you will discover the Naive Bayes algorithm for&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_397296104" LINK="https://www.youtube.com/watch?v=M59h7CFUwPU" MODIFIED="1557225479661" TEXT="Naive Bayes - Georgia Tech - Machine Learning - YouTube">
<node CREATED="1557224068603" ID="ID_469642790" MODIFIED="1557224068603" TEXT="Feb 23 2015  Watch on Udacity: https://www.udacity.com/course/viewer#!/c-ud262/l-478818537/m-482228628 Check out the full Advanced Operating&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1113566084" LINK="https://www.saedsayad.com/naive_bayesian.htm" MODIFIED="1557225479661" TEXT="Naive Bayesian">
<node CREATED="1557224068603" ID="ID_1426346198" MODIFIED="1557224068603" TEXT="The Naive Bayesian classifier is based on Bayes theorem with the independence assumptions between predictors. A Naive Bayesian model is easy to build&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_743377860" MODIFIED="1557225483437" TEXT="Naive Bayes Classifiers#$D$#">
<node CREATED="1557224068603" FOLDED="true" ID="ID_629645211" LINK="https://en.wikipedia.org/wiki/Naive_Bayes_classifier" MODIFIED="1557225479661" TEXT="Naive Bayes classifier - Wikipedia">
<node CREATED="1557224068603" ID="ID_1319240778" MODIFIED="1557224068603" TEXT="In machine learning naive Bayes classifiers are a family of simple probabilistic classifiers based on applying Bayes theorem with strong (naive) independence&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1966935517" LINK="https://www.geeksforgeeks.org/naive-bayes-classifiers/" MODIFIED="1557225479661" TEXT="Naive Bayes Classifiers - GeeksforGeeks">
<node CREATED="1557224068603" ID="ID_1917482097" MODIFIED="1557224068603" TEXT="Naive Bayes classifiers are a collection of classification algorithms based on Bayes Theorem. It is not a single algorithm but a family of algorithms where all of&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_602123734" LINK="http://www.statsoft.com/textbook/naive-bayes-classifier" MODIFIED="1557225479661" TEXT="Naive Bayes Classifier">
<node CREATED="1557224068603" ID="ID_650465761" MODIFIED="1557224068603" TEXT="The Naive Bayes Classifier technique is based on the so-called Bayesian theorem and is particularly suited when the dimensionality of the inputs is high." />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1320267752" LINK="https://www.youtube.com/watch?v=CPqOCI0ahss" MODIFIED="1557225479661" TEXT="Na&#239;ve Bayes Classifier - Fun and Easy Machine Learning - YouTube">
<node CREATED="1557224068603" ID="ID_1837949378" MODIFIED="1557224068603" TEXT="Aug 26 2017  Naive Bayes Classifier- Fun and Easy Machine Learning &#9659;FREE YOLO GIFT - http://augmentedstartups.info/yolofreegiftsp &#9659;KERAS COURSE&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_455958021" LINK="https://www.analyticsvidhya.com/blog/2017/09/naive-bayes-explained/" MODIFIED="1557225479661" TEXT="6 Easy Steps to Learn Naive Bayes Algorithm (with code in Python)">
<node CREATED="1557224068603" ID="ID_1036897213" MODIFIED="1557224068603" TEXT="Sep 11 2017  In simple terms a Naive Bayes classifier assumes that the presence of a particular feature in a class is unrelated to the presence of any other&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_805188346" LINK="https://towardsdatascience.com/introduction-to-naive-bayes-classification-4cffabb1ae54" MODIFIED="1557225479661" TEXT="Introduction to Naive Bayes Classification &#8211; Towards Data Science">
<node CREATED="1557224068603" ID="ID_1121758043" MODIFIED="1557224068603" TEXT="May 16 2018  Naive Bayes is a simple yet effective and commonly-used machine learning classifier. It is a probabilistic classifier that makes classifications&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1082350223" LINK="http://scikit-learn.org/stable/modules/naive_bayes.html" MODIFIED="1557225479661" TEXT="1.9. Naive Bayes &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068603" ID="ID_1397728150" MODIFIED="1557224068603" TEXT="Naive Bayes methods are a set of supervised learning algorithms based on . The different naive Bayes classifiers differ mainly by the assumptions they make&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1954282568" LINK="https://towardsdatascience.com/naive-bayes-classifier-81d512f50a7c" MODIFIED="1557225479661" TEXT="Naive Bayes Classifier &#8211; Towards Data Science">
<node CREATED="1557224068603" ID="ID_527881041" MODIFIED="1557224068603" TEXT="May 5 2018  A classifier is a machine learning model that is used to discriminate different objects based on certain features. A Naive Bayes classifier is a&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1098013204" LINK="https://machinelearningmastery.com/naive-bayes-for-machine-learning/" MODIFIED="1557225479661" TEXT="Naive Bayes for Machine Learning">
<node CREATED="1557224068603" ID="ID_396818099" MODIFIED="1557224068603" TEXT="Apr 11 2016  Naive Bayes Classifier. Naive Bayes is a classification algorithm for binary (two-class) and multi-class classification problems. The technique is&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_45956777" LINK="https://textblob.readthedocs.io/en/dev/classifiers.html" MODIFIED="1557225479661" TEXT="Tutorial: Building a Text Classification System &#8212; TextBlob 0.15.2 ">
<node CREATED="1557224068603" ID="ID_1555370547" MODIFIED="1557224068603" TEXT="The textblob.classifiers module makes it simple to create custom classifiers.  Now well create a Naive Bayes classifier passing the training data into the&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1349761713" MODIFIED="1557225483445" TEXT="Naive User based systems#$D$#">
<node CREATED="1557224068611" FOLDED="true" ID="ID_1114061712" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781785889622/11/ch11lvl1sec71/naive-user-based-systems" MODIFIED="1557225479739" TEXT="Naive user-based systems - Machine Learning Algorithms">
<node CREATED="1557224068611" ID="ID_106482095" MODIFIED="1557224068611" TEXT="Naive user-based systemsIn this first scenario we assume that we have a set of users represented by feature vectors:" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1473419947" LINK="https://www.oreilly.com/library/view/machine-learning-algorithms/9781785889622/cc56897a-011e-4204-9010-a29f44a4b8a7.xhtml" MODIFIED="1557225479739" TEXT="Naive user-based systems - Machine Learning Algorithms [Book]">
<node CREATED="1557224068611" ID="ID_908775217" MODIFIED="1557224068611" TEXT="Naive user-based systems In this first scenario we assume that we have a set of users represented by feature vectors: Typical features are age gender interests&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_120946306" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781789347999/12/ch12lvl1sec81/naive-user-based-systems" MODIFIED="1557225479739" TEXT="Naive user-based systems - Machine Learning Algorithms - Second ">
<node CREATED="1557224068611" ID="ID_114951026" MODIFIED="1557224068611" TEXT="Naive user-based systemsIn this first scenario we assume that we have " />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1998066518" LINK="https://link.springer.com/chapter/10.1007/978-3-642-41230-1_17" MODIFIED="1557225479739" TEXT="Authenticating Users of Recommender Systems Using Naive Bayes ">
<node CREATED="1557224068611" ID="ID_1582576772" MODIFIED="1557224068611" TEXT="Knowledge Based Authentication (KBA) verifies the credibility of claimed identities by matching various user-related data. Popular recommender systems hold&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1154087706" LINK="https://www.isres.org/books/chapters/RHES2016-8_10-09-2017.pdf" MODIFIED="1557225479739" TEXT="new recommender system using naive bayes for e- learning">
<node CREATED="1557224068611" ID="ID_1775923863" MODIFIED="1557224068611" TEXT="Computer-based recommender systems are the most appropriate methods in  and eventually the system recommends to user with Na&#239;ve Bayesian Classifier." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_222604314" LINK="https://ieeexplore.ieee.org/document/4609586/" MODIFIED="1557225479739" TEXT="User Preference Awareness in City Traveler Helper System Based ">
<node CREATED="1557224068611" ID="ID_1777250920" MODIFIED="1557224068611" TEXT="User Preference Awareness in City Traveler Helper System Based on Na&#239;ve Bayes Classification. Abstract: City traveler helper system (Wang and Qi 2008)&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1511318435" LINK="https://www.ncbi.nlm.nih.gov/pubmed/28269262" MODIFIED="1557225479739" TEXT="Movement imagery classification in EMOTIV cap based system by ">
<node CREATED="1557224068611" ID="ID_1202045521" MODIFIED="1557224068611" TEXT="Movement imagery classification in EMOTIV cap based system by Na&#239;ve Bayes.  in assistive technology which do not require motor activity from the user." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_494917044" LINK="https://www.aclweb.org/anthology/E03-1075" MODIFIED="1557225479739" TEXT="Targeted Help for Spoken Dialogue Systems: intelligent feedback ">
<node CREATED="1557224068611" ID="ID_1904080112" MODIFIED="1557224068611" TEXT="intelligent feedback improves naive users performance. Beth Ann  are out-of-coverage of the main dialogue system . We have designed a rule based system." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_831709598" LINK="http://www.itiis.org/digital-library/manuscript/1190" MODIFIED="1557225479739" TEXT="TIIS - Enhanced Cloud Service Discovery for Na&#239;ve users with ">
<node CREATED="1557224068611" ID="ID_1146314771" MODIFIED="1557224068611" TEXT="Jan 31 2016  KSII Transactions on Internet and Information Systems Monthly  Enhanced Cloud Service Discovery for Na&#239;ve users with Ontology based Representation  to find services especially from Internet-based service repositories." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_738420370" LINK="https://www.macs.hw.ac.uk/~dwcorne/ACMRecSys07/p73-pronk.pdf" MODIFIED="1557225479739" TEXT="Incorporating User Control into Recommender Systems Based on ">
<node CREATED="1557224068611" ID="ID_1743946552" MODIFIED="1557224068611" TEXT="Oct 20 2007  Keywords classification machine learning naive Bayes recommender user  A recommender learns the taste of a user based on ratings that." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_151252490" MODIFIED="1563517391360" TEXT="Naive Bayes in Scikit-learn">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068603" FOLDED="true" ID="ID_948548147" MODIFIED="1557225483438" TEXT="Naive Bayes in Scikit-learn#$D$#">
<node CREATED="1557224068603" FOLDED="true" ID="ID_205642850" LINK="http://scikit-learn.org/stable/modules/naive_bayes.html" MODIFIED="1557225479661" TEXT="1.9. Naive Bayes &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068603" ID="ID_306156652" MODIFIED="1557224068603" TEXT="Naive Bayes methods are a set of supervised learning algorithms based on applying Bayes theorem with the &#8220;naive&#8221; assumption of conditional independence&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_231750482" LINK="https://www.datacamp.com/community/tutorials/naive-bayes-scikit-learn" MODIFIED="1557225479661" TEXT="Naive Bayes Classification using Scikit-learn (article) - DataCamp">
<node CREATED="1557224068603" ID="ID_1661848895" MODIFIED="1557224068603" TEXT="Dec 4 2018  Learn how to build and evaluate a Naive Bayes Classifier using Pythons Scikit-learn package." />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_574683196" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.naive_bayes.GaussianNB.html" MODIFIED="1557225479661" TEXT="sklearn.naive_bayes.GaussianNB &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068603" ID="ID_1915620030" MODIFIED="1557224068603" TEXT="Examples using sklearn.naive_bayes.  Gaussian Naive Bayes (GaussianNB)  fit (X y[ sample_weight]) Fit Gaussian Naive Bayes according to X y." />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_451459408" LINK="https://blog.sicara.com/naive-bayes-classifier-sklearn-python-example-tips-42d100429e44" MODIFIED="1557225479661" TEXT="Naive Bayes Classification with Sklearn &#8211; Sicaras blog">
<node CREATED="1557224068603" ID="ID_1903050740" MODIFIED="1557224068603" TEXT="Feb 28 2018  This tutorial details Naive Bayes classifier algorithm its principle pros  cons and provide an example using the Sklearn python Library." />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_893995945" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.naive_bayes.MultinomialNB.html" MODIFIED="1557225479661" TEXT="sklearn.naive_bayes.MultinomialNB &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068603" ID="ID_1884507585" MODIFIED="1557224068603" TEXT="Naive Bayes classifier for multinomial models. The multinomial Naive Bayes classifier is suitable for classification with discrete features (e.g. word counts for text&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1737482649" LINK="https://stackabuse.com/the-naive-bayes-algorithm-in-python-with-scikit-learn/" MODIFIED="1557225479661" TEXT="The Naive Bayes Algorithm in Python with Scikit-Learn">
<node CREATED="1557224068603" ID="ID_1212606186" MODIFIED="1557224068603" TEXT="Jul 10 2018  The Naive Bayes Classifier brings the power of this theorem to Machine Learning building a very simple yet powerful classifier. In this article&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1421395898" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.naive_bayes.BernoulliNB.html" MODIFIED="1557225479661" TEXT="sklearn.naive_bayes.BernoulliNB &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068603" ID="ID_516131901" MODIFIED="1557224068603" TEXT="Naive Bayes classifier for multivariate Bernoulli models. Like MultinomialNB this classifier is suitable for discrete data. The difference is that while MultinomialNB&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_788596366" LINK="https://github.com/scikit-learn/scikit-learn/blob/master/sklearn/naive_bayes.py" MODIFIED="1557225479661" TEXT="scikit-learn/naive_bayes.py at master &#183; scikit-learn/scikit-learn &#183; GitHub">
<node CREATED="1557224068603" ID="ID_1044791896" MODIFIED="1557224068603" TEXT="The :mod:`sklearn.naive_bayes` module implements Naive Bayes algorithms. These. are supervised learning methods based on applying Bayes theorem with&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1149404276" LINK="https://hub.packtpub.com/implementing-3-naive-bayes-classifiers-in-scikit-learn/" MODIFIED="1557225479661" TEXT="Implementing 3 Naive Bayes classifiers in scikit-learn | Packt Hub">
<node CREATED="1557224068603" ID="ID_891960497" MODIFIED="1557224068603" TEXT="May 7 2018  Scikit-learn provide three naive Bayes classifiers: Bernoulli multinomial and Gaussian. The only difference is about the probability distribution&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1423823238" LINK="https://machinelearningmastery.com/get-your-hands-dirty-with-scikit-learn-now/" MODIFIED="1557225479661" TEXT="Machine Learning Algorithm Recipes in scikit-learn">
<node CREATED="1557224068603" ID="ID_1068729464" MODIFIED="1557224068603" TEXT="Jun 20 2014  The scikit-learn Python library is very easy to get up and running.  Naive Bayes uses Bayes Theorem to model the conditional relationship of&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1887900412" MODIFIED="1563517391360" TEXT="Types">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1178685457" MODIFIED="1563517391360" TEXT="Bernoulli Naive Bayes">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068603" FOLDED="true" ID="ID_700881619" MODIFIED="1557225483438" TEXT="Bernoulli Naive Bayes#$D$#">
<node CREATED="1557224068603" FOLDED="true" ID="ID_1109624203" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.naive_bayes.BernoulliNB.html" MODIFIED="1557225479661" TEXT="sklearn.naive_bayes.BernoulliNB &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068603" ID="ID_297845952" MODIFIED="1557224068603" TEXT="Naive Bayes classifier for multivariate Bernoulli models. Like MultinomialNB this classifier is suitable for discrete data. The difference is that while MultinomialNB&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_402590262" LINK="https://en.wikipedia.org/wiki/Naive_Bayes_classifier" MODIFIED="1557225479661" TEXT="Naive Bayes classifier - Wikipedia">
<node CREATED="1557224068603" ID="ID_1128411332" MODIFIED="1557224068603" TEXT="In the multivariate Bernoulli event model features are  Note that a naive Bayes classifier with a Bernoulli event model is&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1599969301" LINK="https://nlp.stanford.edu/IR-book/html/htmledition/the-bernoulli-model-1.html" MODIFIED="1557225479661" TEXT="The Bernoulli model">
<node CREATED="1557224068603" ID="ID_1843172952" MODIFIED="1557224068603" TEXT="Next: Properties of Naive Bayes Up: Text classification and Naive Previous:  An alternative to the multinomial model is the multivariate Bernoulli model or&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_342136839" LINK="http://scikit-learn.org/stable/modules/naive_bayes.html" MODIFIED="1557225479661" TEXT="1.9. Naive Bayes &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068603" ID="ID_170957012" MODIFIED="1557224068603" TEXT="Bernoulli Naive Bayes; 1.9.5. Out-of-core naive Bayes model fitting  Naive Bayes methods are a set of supervised learning algorithms based on applying&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_224506654" LINK="https://stats.stackexchange.com/questions/246101/when-to-use-bernoulli-naive-bayes" MODIFIED="1557225479661" TEXT="machine learning - When to use Bernoulli Naive Bayes? - Cross ">
<node CREATED="1557224068603" ID="ID_1883786544" MODIFIED="1557224068603" TEXT="Bernoulli Naive Bayes is for binary features only. Similarly multinomial naive Bayes treats features as event probabilities. Your example is&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_844411536" LINK="https://mattshomepage.com/articles/2016/Jun/07/bernoulli_nb/" MODIFIED="1557225479661" TEXT="Bernoulli Naive Bayes Classifier">
<node CREATED="1557224068603" ID="ID_1451648291" MODIFIED="1557224068603" TEXT="Jun 7 2016  Covers theory and implementation of a Bernoulli naive Bayes classifier." />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1858654552" LINK="https://www.youtube.com/watch?v=99MN-rl8jGY" MODIFIED="1557225479661" TEXT="Naive Bayes Classifier - Multinomial Bernoulli Gaussian Using ">
<node CREATED="1557224068603" ID="ID_1935516100" MODIFIED="1557224068603" TEXT="Sep 18 2017  In this Python for Data Science tutorial You will learn about Naive Bayes classifier (Multinomial Bernoulli Gaussian) using scikit learn and Urllib&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_930542072" LINK="https://www.cs.cmu.edu/~mgormley/courses/10701-f16/slides/lecture3.pdf" MODIFIED="1557225479661" TEXT="Na&#239;ve Bayes">
<node CREATED="1557224068603" ID="ID_1054880316" MODIFIED="1557224068603" TEXT="Sep 14 2016  Na&#239;ve Bayes Assumption. &#8211; Model 1: Bernoulli Na&#239;ve Bayes. &#8211; Model 2: Multinomial Na&#239;ve Bayes. &#8211; Model 3: Gaussian Na&#239;ve Bayes." />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_6203007" LINK="https://www.cs.ubc.ca/~murphyk/Teaching/CS340-Fall07/NB.pdf" MODIFIED="1557225479661" TEXT="CS340 Machine learning Na&#239;ve Bayes classifiers">
<node CREATED="1557224068603" ID="ID_1422921041" MODIFIED="1557224068603" TEXT="Bayes rule for classifiers p(y = c|x) =  independently (naive Bayes assumption). &#8226; E.g. prob of  focus on the multivariate Bernoulli (binary features) model for&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1889882197" LINK="https://datascience.stackexchange.com/questions/27624/difference-between-bernoulli-and-multinomial-naive-bayes" MODIFIED="1557225479661" TEXT="Difference between Bernoulli and Multinomial Naive Bayes - Data ">
<node CREATED="1557224068603" ID="ID_1782765562" MODIFIED="1557224068603" TEXT="Bernoulli models the presence/absence of a feature. Multinomial models the number of counts of a feature. Heres a concise explanation." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_827100250" MODIFIED="1563517391360" TEXT="Multinomial Naive Bayes">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068603" FOLDED="true" ID="ID_412309271" MODIFIED="1557225483438" TEXT="Multinomial Naive Bayes#$D$#">
<node CREATED="1557224068603" FOLDED="true" ID="ID_1118584997" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.naive_bayes.MultinomialNB.html" MODIFIED="1557225479661" TEXT="sklearn.naive_bayes.MultinomialNB &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068603" ID="ID_1231097154" MODIFIED="1557224068603" TEXT="The multinomial Naive Bayes classifier is suitable for classification with discrete features (e.g. word counts for text classification). The multinomial distribution&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_150722619" LINK="https://en.wikipedia.org/wiki/Naive_Bayes_classifier" MODIFIED="1557225479661" TEXT="Naive Bayes classifier - Wikipedia">
<node CREATED="1557224068603" ID="ID_87468608" MODIFIED="1557224068603" TEXT="With a multinomial event model samples (feature vectors) represent the frequencies with which certain events have&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1698223045" LINK="https://towardsdatascience.com/multinomial-naive-bayes-classifier-for-text-analysis-python-8dd6825ece67" MODIFIED="1557225479677" TEXT="Multinomial Naive Bayes Classifier for Text Analysis (Python)">
<node CREATED="1557224068603" ID="ID_622348314" MODIFIED="1557224068603" TEXT="Apr 9 2018  In this blog I will cover how you can implement a Multinomial Naive Bayes Classifier for the 20 Newsgroups dataset. The 20 newsgroups&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_796238031" LINK="https://stats.stackexchange.com/questions/33185/difference-between-naive-bayes-multinomial-naive-bayes" MODIFIED="1557225479677" TEXT="bayesian - Difference between naive Bayes  multinomial naive ">
<node CREATED="1557224068603" ID="ID_417631372" MODIFIED="1557224068603" TEXT="The general term Naive Bayes refers the the strong independence assumptions in the model rather than the particular distribution of each&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_340068158" LINK="https://www.geeksforgeeks.org/applying-multinomial-naive-bayes-to-nlp-problems/" MODIFIED="1557225479677" TEXT="Applying Multinomial Naive Bayes to NLP Problems - GeeksforGeeks">
<node CREATED="1557224068603" ID="ID_1487348245" MODIFIED="1557224068603" TEXT="Naive Bayes Classifier Algorithm is a family of probabilistic algorithms based on applying Bayes theorem with the &#8220;naive&#8221; assumption of conditional&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1763701142" LINK="https://www.3pillarglobal.com/insights/document-classification-using-multinomial-naive-bayes-classifier" MODIFIED="1557225479677" TEXT="Document Classification Using Multinomial Naive Bayes Classifier">
<node CREATED="1557224068603" ID="ID_1926165077" MODIFIED="1557224068603" TEXT="A machine learning technique for using the Multinomial Naive Bayes algorithms to classify certain documents with specific keywords." />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_623889698" LINK="https://www.youtube.com/watch?v=km2LoOpdB3A" MODIFIED="1557225479677" TEXT="6 - 6 - Multinomial Naive Bayes- A Worked Example .mp4 - YouTube">
<node CREATED="1557224068603" ID="ID_1561877858" MODIFIED="1557224068603" TEXT="Apr 6 2012  6 - 6 - Multinomial Naive Bayes- A Worked Example .mp4. Rafael Merino Garc&#237;a. Loading Unsubscribe from Rafael Merino Garc&#237;a? Cancel" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_497345406" LINK="https://medium.com/syncedreview/applying-multinomial-naive-bayes-to-nlp-problems-a-practical-explanation-4f5271768ebf" MODIFIED="1557225479677" TEXT="Applying Multinomial Naive Bayes to NLP Problems: A Practical ">
<node CREATED="1557224068603" ID="ID_441135984" MODIFIED="1557224068603" TEXT="Jul 17 2017  1.Introduction Naive Bayes is a family of algorithms based on applying Bayes theorem with a strong(naive) assumption that every feature is&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_41198304" LINK="https://www.quora.com/How-does-multinomial-Naive-Bayes-work" MODIFIED="1557225479677" TEXT="How does multinomial Naive Bayes work? - Quora">
<node CREATED="1557224068603" ID="ID_52772442" MODIFIED="1557224068603" TEXT="Check out this Naive Bayes Tutorial. It describes 3 Naive Bayes models (Multinomial Binarized and Benoulli) in the context of Text Classification. Note that&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1015436646" LINK="https://nlp.stanford.edu/IR-book/html/htmledition/naive-bayes-text-classification-1.html" MODIFIED="1557225479677" TEXT="Naive Bayes text classification">
<node CREATED="1557224068603" ID="ID_1562057620" MODIFIED="1557224068603" TEXT="The first supervised learning method we introduce is the multinomial Naive Bayes or multinomial NB model a probabilistic learning method. The probability of a&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1007021915" MODIFIED="1563517391360" TEXT="Gaussian Naive Bayes">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068603" FOLDED="true" ID="ID_1954517592" MODIFIED="1557225483438" TEXT="Gaussian Naive Bayes#$D$#">
<node CREATED="1557224068603" FOLDED="true" ID="ID_1647924165" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.naive_bayes.GaussianNB.html" MODIFIED="1557225479677" TEXT="sklearn.naive_bayes.GaussianNB &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068603" ID="ID_1754517328" MODIFIED="1557224068603" TEXT="Examples using sklearn.naive_bayes.  Gaussian Naive Bayes (GaussianNB)  fit (X y[ sample_weight]) Fit Gaussian Naive Bayes according to X y." />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_218213131" LINK="https://en.wikipedia.org/wiki/Naive_Bayes_classifier" MODIFIED="1557225479677" TEXT="Naive Bayes classifier - Wikipedia">
<node CREATED="1557224068603" ID="ID_383900606" MODIFIED="1557224068603" TEXT=" distributed according to a Gaussian distribution. For example suppose the training data contains a continuous attribute&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_700223067" LINK="https://machinelearningmastery.com/naive-bayes-for-machine-learning/" MODIFIED="1557225479677" TEXT="Naive Bayes for Machine Learning">
<node CREATED="1557224068603" ID="ID_1993760459" MODIFIED="1557224068603" TEXT="Apr 11 2016  Naive Bayes is a simple but surprisingly powerful algorithm for predictive . This extension of naive Bayes is called Gaussian Naive Bayes." />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_154197280" LINK="http://scikit-learn.org/stable/modules/naive_bayes.html" MODIFIED="1557225479677" TEXT="1.9. Naive Bayes &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068603" ID="ID_1735268797" MODIFIED="1557224068603" TEXT="Gaussian Naive Bayes; 1.9.2. Multinomial Naive Bayes; 1.9.3. Complement Naive Bayes; 1.9.4. Bernoulli Naive Bayes; 1.9.5. Out-of-core naive Bayes model&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_910270372" LINK="https://www.youtube.com/watch?v=r1in0YNetG8" MODIFIED="1557225479677" TEXT="Naive Bayes 3: Gaussian example - YouTube">
<node CREATED="1557224068603" ID="ID_11763341" MODIFIED="1557224068603" TEXT="Jan 15 2014  http://bit.ly/N-Bayes] How can we use Naive Bayes classifier with continuous (real-valued) attributes? We estimate the priors and the means&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1158793769" LINK="https://www.cs.cmu.edu/~epxing/Class/10701-10s/Lecture/lecture5.pdf" MODIFIED="1557225479677" TEXT="Gaussian Na&#239;ve Bayes and Logistic Regression">
<node CREATED="1557224068603" ID="ID_96099623" MODIFIED="1557224068603" TEXT="Jan 25 2010  Gaussian Na&#239;ve Bayes and. Logistic Regression. Machine Learning 10-701. Tom M. Mitchell. Machine Learning Department. Carnegie Mellon&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_770000882" LINK="https://www.youtube.com/watch?v=TcAQKPgymLE" MODIFIED="1557225479677" TEXT="IAML5.9: Gaussian Naive Bayes classifier - YouTube">
<node CREATED="1557224068603" ID="ID_1339439576" MODIFIED="1557224068603" TEXT="Sep 10 2015  IAML5.9: Gaussian Naive Bayes classifier. Victor Lavrenko. Loading Unsubscribe from Victor Lavrenko? Cancel Unsubscribe. Working." />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_972609173" LINK="https://hackernoon.com/implementation-of-gaussian-naive-bayes-in-python-from-scratch-c4ea64e3944d" MODIFIED="1557225479677" TEXT="Implementation of Gaussian Naive Bayes in Python from scratch">
<node CREATED="1557224068603" ID="ID_1848933879" MODIFIED="1557224068603" TEXT="Jan 23 2019  Gaussian Naive Bayes is an algorithm having a Probabilistic Approach. It involves prior and posterior probability calculation of the classes in&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1677495924" LINK="https://www.geeksforgeeks.org/naive-bayes-classifiers/" MODIFIED="1557225479677" TEXT="Naive Bayes Classifiers - GeeksforGeeks">
<node CREATED="1557224068603" ID="ID_1536629625" MODIFIED="1557224068603" TEXT="Naive Bayes classifiers are a collection of classification algorithms based on . Now we look at an implementation of Gaussian Naive Bayes classifier using&#160;" />
</node>
<node CREATED="1557224068603" FOLDED="true" ID="ID_1787633855" LINK="http://www.ritchieng.com/machine-learning-gaussian-naive-bayes/" MODIFIED="1557225479677" TEXT="Gaussian Naive Bayes | Machine Learning Deep Learning and ">
<node CREATED="1557224068603" ID="ID_1943797647" MODIFIED="1557224068603" TEXT="Bayes Rule: Intuitive Explanation. (Prior probability)(Test evidence) -- (Posterior probability); Example. P(C) = 0.01; 90% it is positive if you have C (Sensitivity)&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_701767515" MODIFIED="1563517391360" TEXT="Interactive Visualization ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1490097736" MODIFIED="1563517391360" TEXT="Support Vector Machine">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_100618802" MODIFIED="1563517391360" TEXT="Linear Support Vector Machines">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068603" FOLDED="true" ID="ID_1915441900" MODIFIED="1557225483438" TEXT="Support Vector Machine#$D$#">
<node CREATED="1557224068603" FOLDED="true" ID="ID_1384766945" LINK="https://en.wikipedia.org/wiki/Support-vector_machine" MODIFIED="1557225479677" TEXT="Support-vector machine - Wikipedia">
<node CREATED="1557224068603" ID="ID_1757120445" MODIFIED="1557224068603" TEXT="In machine learning support-vector machines are supervised learning models with associated learning algorithms that analyze data used for classification and&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_835860462" LINK="https://medium.com/machine-learning-101/chapter-2-svm-support-vector-machine-theory-f0812effc72" MODIFIED="1557225479677" TEXT="Chapter 2 : SVM (Support Vector Machine) &#8212; Theory &#8211; Machine ">
<node CREATED="1557224068604" ID="ID_570248485" MODIFIED="1557224068604" TEXT="May 3 2017  A Support Vector Machine (SVM) is a discriminative classifier formally defined by a separating hyperplane. In other words given labeled&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1830749926" LINK="http://scikit-learn.org/stable/modules/svm.html" MODIFIED="1557225479677" TEXT="1.4. Support Vector Machines &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068604" ID="ID_923304381" MODIFIED="1557224068604" TEXT="The support vector machines in scikit-learn support both dense ( numpy.ndarray and convertible to that by numpy.asarray ) and sparse (any scipy.sparse )&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1454122341" LINK="https://towardsdatascience.com/support-vector-machine-introduction-to-machine-learning-algorithms-934a444fca47" MODIFIED="1557225479677" TEXT="Support Vector Machine &#8212; Introduction to Machine Learning ">
<node CREATED="1557224068604" ID="ID_697056918" MODIFIED="1557224068604" TEXT="Jun 7 2018  If not I suggest you have a look at them before moving on to support vector machine. Support vector machine is another simple algorithm that&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_233298262" LINK="http://web.mit.edu/6.034/wwwbob/svm.pdf" MODIFIED="1557225479677" TEXT="An Idiots guide to Support vector machines (SVMs)">
<node CREATED="1557224068604" ID="ID_212234736" MODIFIED="1557224068604" TEXT="Basic idea of support vector machines: just like 1- layer or multi-layer neural nets. &#8211; Optimal hyperplane for linearly separable patterns. &#8211; Extend to patterns that&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1846758905" LINK="https://www.youtube.com/watch?v=Y6RRHw9uN9o" MODIFIED="1557225479677" TEXT="Support Vector Machine (SVM) - Fun and Easy Machine Learning ">
<node CREATED="1557224068604" ID="ID_283747083" MODIFIED="1557224068604" TEXT="Aug 15 2017  Support Vector Machine (SVM) - Fun and Easy Machine Learning &#9659;FREE YOLO GIFT - http://augmentedstartups.info/yolofreegiftsp &#9659;KERAS&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_135553798" LINK="http://cs229.stanford.edu/notes/cs229-notes3.pdf" MODIFIED="1557225479677" TEXT="Support Vector Machines">
<node CREATED="1557224068604" ID="ID_1265440132" MODIFIED="1557224068604" TEXT="This set of notes presents the Support Vector Machine (SVM) learning al- gorithm. SVMs are among the best (and many believe are indeed the best)." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_248523183" LINK="https://www.youtube.com/watch?v=1NxnPkZM9bc" MODIFIED="1557225479677" TEXT="How SVM (Support Vector Machine) algorithm works - YouTube">
<node CREATED="1557224068604" ID="ID_741957882" MODIFIED="1557224068604" TEXT="Jan 6 2014  In this video I explain how SVM (Support Vector Machine) algorithm works to classify a linearly separable binary data set. The original&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_314984385" LINK="https://www.analyticsvidhya.com/blog/2017/09/understaing-support-vector-machine-example-code/" MODIFIED="1557225479677" TEXT="Understanding Support Vector Machine algorithm from examples ">
<node CREATED="1557224068604" ID="ID_333539700" MODIFIED="1557224068604" TEXT="Sep 13 2017  This article explains support vector machine a machine learning algorithm and its uses in classification and regression. Its a supervised&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_335745816" LINK="https://docs.opencv.org/2.4/doc/tutorials/ml/introduction_to_svm/introduction_to_svm.html" MODIFIED="1557225479677" TEXT="Introduction to Support Vector Machines &#8212; OpenCV 2.4.13.7 ">
<node CREATED="1557224068604" ID="ID_1597983378" MODIFIED="1557224068604" TEXT="Then the operation of the SVM algorithm is based on finding the hyperplane that gives the largest minimum distance to the training examples. Twice this&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_308118577" MODIFIED="1557225483438" TEXT="Linear Support Vector Machines#$D$#">
<node CREATED="1557224068604" FOLDED="true" ID="ID_1899203657" LINK="https://en.wikipedia.org/wiki/Support-vector_machine" MODIFIED="1557225479677" TEXT="Support-vector machine - Wikipedia">
<node CREATED="1557224068604" ID="ID_1108674717" MODIFIED="1557224068604" TEXT="In machine learning support-vector machines are supervised learning models with associated learning algorithms that analyze data&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1693006103" LINK="https://towardsdatascience.com/support-vector-machine-introduction-to-machine-learning-algorithms-934a444fca47" MODIFIED="1557225479677" TEXT="Support Vector Machine &#8212; Introduction to Machine Learning ">
<node CREATED="1557224068604" ID="ID_1062319955" MODIFIED="1557224068604" TEXT="Jun 7 2018  Introduction. I guess by now you wouldve accustomed yourself with linear regression and logistic regression algorithms. If not I suggest you&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_731510204" LINK="https://medium.com/machine-learning-101/chapter-2-svm-support-vector-machine-theory-f0812effc72" MODIFIED="1557225479677" TEXT="Chapter 2 : SVM (Support Vector Machine) &#8212; Theory &#8211; Machine ">
<node CREATED="1557224068604" ID="ID_478119494" MODIFIED="1557224068604" TEXT="May 3 2017  A Support Vector Machine (SVM) is a discriminative classifier formally defined by a  The learning of the hyperplane in linear SVM is done by&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1961701562" LINK="http://scikit-learn.org/stable/modules/svm.html" MODIFIED="1557225479677" TEXT="1.4. Support Vector Machines &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068604" ID="ID_1946693875" MODIFIED="1557224068604" TEXT="On the other hand LinearSVC is another implementation of Support Vector Classification for the case of a linear kernel. Note that LinearSVC does not accept&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1265348689" LINK="http://web.mit.edu/6.034/wwwbob/svm.pdf" MODIFIED="1557225479677" TEXT="An Idiots guide to Support vector machines (SVMs)">
<node CREATED="1557224068604" ID="ID_1591063788" MODIFIED="1557224068604" TEXT="Basic idea of support vector machines: just like 1- layer or multi-layer neural nets. &#8211; Optimal hyperplane for linearly separable patterns. &#8211; Extend to patterns that&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1514746227" LINK="https://www.analyticsvidhya.com/blog/2017/09/understaing-support-vector-machine-example-code/" MODIFIED="1557225479677" TEXT="Understanding Support Vector Machine algorithm from examples ">
<node CREATED="1557224068604" ID="ID_88399608" MODIFIED="1557224068604" TEXT="Sep 13 2017  In SVM it is easy to have a linear hyper-plane between these two classes. But another burning question which arises is should we need to&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1760309943" LINK="https://www.youtube.com/watch?v=1NxnPkZM9bc" MODIFIED="1557225479677" TEXT="How SVM (Support Vector Machine) algorithm works - YouTube">
<node CREATED="1557224068604" ID="ID_77290943" MODIFIED="1557224068604" TEXT="Jan 6 2014  In this video I explain how SVM (Support Vector Machine) algorithm works to classify a linearly separable binary data set. The original&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1224090190" LINK="http://cs229.stanford.edu/notes/cs229-notes3.pdf" MODIFIED="1557225479677" TEXT="Support Vector Machines">
<node CREATED="1557224068604" ID="ID_1808721236" MODIFIED="1557224068604" TEXT="This set of notes presents the Support Vector Machine (SVM) learning al- gorithm.  Also rather than parameterizing our linear classifier with the vector &#952; we." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_766948950" LINK="https://www.youtube.com/watch?v=Y6RRHw9uN9o" MODIFIED="1557225479677" TEXT="Support Vector Machine (SVM) - Fun and Easy Machine Learning ">
<node CREATED="1557224068604" ID="ID_722382818" MODIFIED="1557224068604" TEXT="Aug 15 2017  Support Vector Machine (SVM) - Fun and Easy Machine Learning &#9659;FREE YOLO GIFT - http://augmentedstartups.info/yolofreegiftsp &#9659;KERAS&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1350143371" LINK="https://nlp.stanford.edu/IR-book/html/htmledition/support-vector-machines-the-linearly-separable-case-1.html" MODIFIED="1557225479677" TEXT="Support vector machines: The linearly separable case">
<node CREATED="1557224068604" ID="ID_433231424" MODIFIED="1557224068604" TEXT="The SVM in particular defines the criterion to be looking for a decision surface that is maximally far away from any data point. This distance from the decision&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1493811305" MODIFIED="1557225483438" TEXT="Support Vector Machine Scikit-learn implementation#$D$#">
<node CREATED="1557224068604" FOLDED="true" ID="ID_700847527" LINK="http://scikit-learn.org/stable/modules/svm.html" MODIFIED="1557225479677" TEXT="1.4. Support Vector Machines &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068604" ID="ID_1121143303" MODIFIED="1557224068604" TEXT="On the other hand LinearSVC is another implementation of Support Vector Classification for the case of a linear kernel. Note that LinearSVC does not accept&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_53029191" LINK="https://stackabuse.com/implementing-svm-and-kernel-svm-with-pythons-scikit-learn/" MODIFIED="1557225479677" TEXT="Implementing SVM and Kernel SVM with Pythons Scikit-Learn">
<node CREATED="1557224068604" ID="ID_1428258418" MODIFIED="1557224068604" TEXT="Apr 17 2018  We will then move towards an advanced SVM concept known as Kernel SVM and will also implement it with the help of Scikit-Learn." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1111988127" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.svm.SVC.html" MODIFIED="1557225479677" TEXT="sklearn.svm.SVC &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068604" ID="ID_1167451361" MODIFIED="1557224068604" TEXT="C-Support Vector Classification. The implementation is based on libsvm. The fit time complexity is more than quadratic with the number of samples which makes&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_341165515" LINK="https://www.datacamp.com/community/tutorials/svm-classification-scikit-learn-python" MODIFIED="1557225479677" TEXT="Support Vector Machines in Scikit-learn (article) - DataCamp">
<node CREATED="1557224068604" ID="ID_737940432" MODIFIED="1557224068604" TEXT="Jul 12 2018  Until now you have learned about the theoretical background of SVM. Now you will learn about its implementation in Python using scikit-learn." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1823920231" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.svm.SVR.html" MODIFIED="1557225479677" TEXT="sklearn.svm.SVR &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068604" ID="ID_420248456" MODIFIED="1557224068604" TEXT="Epsilon-Support Vector Regression. The free parameters in the model are C and epsilon. The implementation is based on libsvm. Read more in the User Guide." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1469117017" LINK="https://jakevdp.github.io/PythonDataScienceHandbook/05.07-support-vector-machines.html" MODIFIED="1557225479677" TEXT="In-Depth: Support Vector Machines | Python Data Science Handbook">
<node CREATED="1557224068604" ID="ID_1914889858" MODIFIED="1557224068604" TEXT="Support vector machines (SVMs) are a particularly powerful and flexible class of . will use Scikit-Learns support vector classifier to train an SVM model on this data. .. To handle this case the SVM implementation has a bit of a fudge-factor&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_47709568" LINK="http://dataaspirant.com/2017/01/25/svm-classifier-implemenation-python-scikit-learn/" MODIFIED="1557225479677" TEXT="(Svm classifier) implemenation in python with Scikit-learn">
<node CREATED="1557224068604" ID="ID_1522538863" MODIFIED="1557224068604" TEXT="Jan 25 2017  Svm classifier implementation in python with scikit-learn. Support vector machine classifier is one of the most popular machine learning&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_209309512" LINK="https://pythonprogramming.net/linear-svc-example-scikit-learn-svm-python/" MODIFIED="1557225479677" TEXT="Linear SVC Machine learning SVM example with Python">
<node CREATED="1557224068604" ID="ID_1138519987" MODIFIED="1557224068604" TEXT="The most applicable machine learning algorithm for our problem is Linear SVC. Before hopping into Linear SVC with our data were going to show a very simple&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_475902281" LINK="https://www.learnopencv.com/svm-using-scikit-learn-in-python/" MODIFIED="1557225479677" TEXT="SVM using Scikit-Learn in Python | Learn OpenCV">
<node CREATED="1557224068604" ID="ID_1050611566" MODIFIED="1557224068604" TEXT="Jul 27 2018  This post explains the implementation of Support Vector Machines (SVMs) using Scikit-Learn library in Python." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1997765846" LINK="https://www.analyticsvidhya.com/blog/2017/09/understaing-support-vector-machine-example-code/" MODIFIED="1557225479677" TEXT="Understanding Support Vector Machine algorithm from examples ">
<node CREATED="1557224068604" ID="ID_1889953780" MODIFIED="1557224068604" TEXT="Sep 13 2017  This article explains support vector machine a machine learning  How to implement SVM in Python and R? How to tune Parameters of SVM?" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1408156009" MODIFIED="1557225483438" TEXT="Support Vector Machine Classification#$D$#">
<node CREATED="1557224068604" FOLDED="true" ID="ID_1847239707" LINK="https://www.analyticsvidhya.com/blog/2017/09/understaing-support-vector-machine-example-code/" MODIFIED="1557225479677" TEXT="Understanding Support Vector Machine algorithm from examples ">
<node CREATED="1557224068604" ID="ID_1829462179" MODIFIED="1557224068604" TEXT="Sep 13 2017  This article explains support vector machine a machine learning algorithm and its uses in classification and regression. Its a supervised&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_909382203" LINK="https://en.wikipedia.org/wiki/Support-vector_machine" MODIFIED="1557225479677" TEXT="Support-vector machine - Wikipedia">
<node CREATED="1557224068604" ID="ID_1811190132" MODIFIED="1557224068604" TEXT="In machine learning support-vector machines are supervised learning models with associated learning algorithms that&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1907066594" LINK="https://towardsdatascience.com/support-vector-machine-introduction-to-machine-learning-algorithms-934a444fca47" MODIFIED="1557225479677" TEXT="Support Vector Machine &#8212; Introduction to Machine Learning ">
<node CREATED="1557224068604" ID="ID_616635521" MODIFIED="1557224068604" TEXT="Jun 7 2018  Support Vector Machine abbreviated as SVM can be used for both regression and classification tasks. But it is widely used in classification&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_400540857" LINK="http://scikit-learn.org/stable/modules/svm.html" MODIFIED="1557225479692" TEXT="1.4. Support Vector Machines &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068604" ID="ID_1414917076" MODIFIED="1557224068604" TEXT="Support vector machines (SVMs) are a set of supervised learning methods used  LinearSVC is another implementation of Support Vector Classification for the&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1206328890" LINK="https://medium.com/machine-learning-101/chapter-2-svm-support-vector-machine-theory-f0812effc72" MODIFIED="1557225479692" TEXT="Chapter 2 : SVM (Support Vector Machine) &#8212; Theory &#8211; Machine ">
<node CREATED="1557224068604" ID="ID_1679973099" MODIFIED="1557224068604" TEXT="May 3 2017  A Support Vector Machine (SVM) is a discriminative classifier formally  Varying those we can achive considerable non linear classification line&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1258609802" LINK="http://www.statsoft.com/textbook/support-vector-machines" MODIFIED="1557225479692" TEXT="Support Vector Machines (SVM)">
<node CREATED="1557224068604" ID="ID_967256493" MODIFIED="1557224068604" TEXT="Support Vector Machine (SVM) is primarily a classier method that performs classification tasks by constructing hyperplanes in a multidimensional space that&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1321971170" LINK="https://www.mathworks.com/help/stats/support-vector-machines-for-binary-classification.html" MODIFIED="1557225479692" TEXT="Support Vector Machines for Binary Classification - MATLAB ">
<node CREATED="1557224068604" ID="ID_449054866" MODIFIED="1557224068604" TEXT="Perform binary classification via SVM using separating hyperplanes and kernel transformations." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_505463998" LINK="https://www.ncbi.nlm.nih.gov/pubmed/11120680" MODIFIED="1557225479692" TEXT="Support vector machine classification and validation of cancer tissue ">
<node CREATED="1557224068604" ID="ID_990565267" MODIFIED="1557224068604" TEXT="Support vector machine classification and validation of cancer tissue samples using microarray expression data. Furey TS(1) Cristianini N Duffy N Bednarski&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_89160582" LINK="http://web.mit.edu/6.034/wwwbob/svm-notes-long-08.pdf" MODIFIED="1557225479692" TEXT="An Idiots guide to Support vector machines (SVMs)">
<node CREATED="1557224068604" ID="ID_287212662" MODIFIED="1557224068604" TEXT="3. Support Vectors. &#8226; Support vectors are the data points that lie closest to the decision surface (or hyperplane). &#8226; They are the data points most difficult to classify." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_687616440" LINK="https://www.youtube.com/watch?v=1NxnPkZM9bc" MODIFIED="1557225479692" TEXT="How SVM (Support Vector Machine) algorithm works - YouTube">
<node CREATED="1557224068604" ID="ID_1924848489" MODIFIED="1557224068604" TEXT="Jan 6 2014  In this video I explain how SVM (Support Vector Machine) algorithm works to classify a linearly separable binary data set. The original&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1423472133" MODIFIED="1557225483439" TEXT="Support Vector Machine Linear Classification#$D$#">
<node CREATED="1557224068604" FOLDED="true" ID="ID_1750338911" LINK="https://en.wikipedia.org/wiki/Support-vector_machine" MODIFIED="1557225479692" TEXT="Support-vector machine - Wikipedia">
<node CREATED="1557224068604" ID="ID_762187647" MODIFIED="1557224068604" TEXT="In machine learning support-vector machines are supervised learning .. Kernel machine. The original maximum-margin hyperplane algorithm proposed by Vapnik in 1963 constructed a linear classifier." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1237101402" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.svm.LinearSVC.html" MODIFIED="1557225479692" TEXT="sklearn.svm.LinearSVC &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068604" ID="ID_406674866" MODIFIED="1557224068604" TEXT="Linear Support Vector Classification. Similar to SVC with parameter kernel=linear but implemented in terms of liblinear rather than libsvm so it has more&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_812751338" LINK="https://courses.cs.washington.edu/courses/cse473/13au/slides/26-SVMs.pdf" MODIFIED="1557225479692" TEXT="Linear Classification and Support Vector Machines">
<node CREATED="1557224068604" ID="ID_670948434" MODIFIED="1557224068604" TEXT="Find a line (in general a hyperplane) separating the two sets of data points: g(x) = w&#8729;x + b = 0 i.e. w. 1 x. 1. + w. 2 x. 2. + b = 0. For any new point x choose:." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_758198830" LINK="http://scikit-learn.org/stable/modules/svm.html" MODIFIED="1557225479692" TEXT="1.4. Support Vector Machines &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068604" ID="ID_757999916" MODIFIED="1557224068604" TEXT="On the other hand LinearSVC is another implementation of Support Vector Classification for the case of a linear kernel. Note that LinearSVC does not accept&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1670399268" LINK="https://medium.com/machine-learning-101/chapter-2-svm-support-vector-machine-theory-f0812effc72" MODIFIED="1557225479692" TEXT="Chapter 2 : SVM (Support Vector Machine) &#8212; Theory &#8211; Machine ">
<node CREATED="1557224068604" ID="ID_1932788108" MODIFIED="1557224068604" TEXT="May 3 2017  A Support Vector Machine (SVM) is a discriminative classifier formally  Varying those we can achive considerable non linear classification line&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_295639493" LINK="https://towardsdatascience.com/support-vector-machine-vs-logistic-regression-94cc2975433f" MODIFIED="1557225479692" TEXT="Support Vector Machine vs Logistic Regression &#8211; Towards Data ">
<node CREATED="1557224068604" ID="ID_943654650" MODIFIED="1557224068604" TEXT="Aug 12 2018  Support Vector Machine (SVM) is an algorithm used for classification problems similar to Logistic Regression (LR). LR and SVM with linear&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1090586991" LINK="http://www.robots.ox.ac.uk/~az/lectures/ml/lect2.pdf" MODIFIED="1557225479692" TEXT="Lecture 2: The SVM classifier">
<node CREATED="1557224068604" ID="ID_280794097" MODIFIED="1557224068604" TEXT="C19 Machine Learning Hilary 2015. A. Zisserman. &#8226; Review of linear classifiers. &#8226; Linear separability. &#8226; Perceptron. &#8226; Support Vector Machine (SVM) classifier." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_737782395" LINK="http://cs231n.github.io/linear-classify/" MODIFIED="1557225479692" TEXT="Linear classification: Support Vector Machine Softmax">
<node CREATED="1557224068604" ID="ID_1120651676" MODIFIED="1557224068604" TEXT="Table of Contents: Intro to Linear classification; Linear score function; Interpreting a linear classifier; Loss function. Multiclass SVM; Softmax classifier; SVM vs&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_132696769" LINK="https://www.analyticsvidhya.com/blog/2017/09/understaing-support-vector-machine-example-code/" MODIFIED="1557225479692" TEXT="Understanding Support Vector Machine algorithm from examples ">
<node CREATED="1557224068604" ID="ID_937439457" MODIFIED="1557224068604" TEXT="Sep 13 2017  In SVM it is easy to have a linear hyper-plane between these two classes.  Create SVM classification object model = svm.svc(kernel=linear&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1581839908" LINK="https://www.mathworks.com/help/stats/support-vector-machines-for-binary-classification.html" MODIFIED="1557225479692" TEXT="Support Vector Machines for Binary Classification - MATLAB ">
<node CREATED="1557224068605" ID="ID_351849044" MODIFIED="1557224068605" TEXT="Create an SVM template that specifies storing the support vectors of the binary learners." />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1256277284" MODIFIED="1557225483439" TEXT="Support Vector Machine Non-Linear Examples#$D$#">
<node CREATED="1557224068605" FOLDED="true" ID="ID_363734764" LINK="https://www.youtube.com/watch?v=riFEO1pHS7A" MODIFIED="1557225479692" TEXT="5.3 Nonlinear SVM | 5 Support Vector Machines | Pattern ">
<node CREATED="1557224068605" ID="ID_651051281" MODIFIED="1557224068605" TEXT="Nov 22 2012  The Pattern Recognition Class 2012 by Prof. Fred Hamprecht. It took place at the HCI / University of Heidelberg during the summer term of&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1043521056" LINK="http://web.mit.edu/6.034/wwwbob/svm-notes-long-08.pdf" MODIFIED="1557225479692" TEXT="An Idiots guide to Support vector machines (SVMs)">
<node CREATED="1557224068605" ID="ID_1764899145" MODIFIED="1557224068605" TEXT="Efficient learning algorithms for non-linear functions based  Basic idea of support vector machines: just like 1- layer or  subset of training samples the support&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1512685686" LINK="https://en.wikipedia.org/wiki/Support-vector_machine" MODIFIED="1557225479692" TEXT="Support-vector machine - Wikipedia">
<node CREATED="1557224068605" ID="ID_1523655324" MODIFIED="1557224068605" TEXT="In machine learning support-vector machines are supervised learning models with associated learning algorithms that analyze data used for classification and regression analysis. Given a set of training examples each marked as belonging to one or the  6 Nonlinear classification; 7 Computing the SVM classifier." />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1997404075" LINK="https://nlp.stanford.edu/IR-book/html/htmledition/nonlinear-svms-1.html" MODIFIED="1557225479692" TEXT="Nonlinear SVMs">
<node CREATED="1557224068605" ID="ID_1692104674" MODIFIED="1557224068605" TEXT="Nonlinear SVMs.  The SVM linear classifier relies on a dot product between data point vectors. Let $K(\vec{x}_i \vec{x}_j .  Worked example. The quadratic&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_476954164" LINK="http://scikit-learn.org/stable/modules/svm.html" MODIFIED="1557225479692" TEXT="1.4. Support Vector Machines &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068605" ID="ID_1381337525" MODIFIED="1557224068605" TEXT="If the number of features is much greater than the number of samples avoid over-fitting .. Support Vector Regression (SVR) using linear and non-linear kernels&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1842919159" LINK="https://disi.unitn.it/~passerini/teaching/2011-2012/MachineLearning/slides/16_nonlinear_svm/talk.pdf" MODIFIED="1557225479692" TEXT="Non-linear Support Vector Machines">
<node CREATED="1557224068605" ID="ID_1142971733" MODIFIED="1557224068605" TEXT="Non-linear Support Vector Machines feature map. &#934; : X &#8594;H. &#934; is a function mapping each example to a higher dimensional space H. Examples x are replaced&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_979952515" LINK="http://axon.cs.byu.edu/Dan/678/miscellaneous/SVM.example.pdf" MODIFIED="1557225479692" TEXT="SVM Example">
<node CREATED="1557224068605" ID="ID_76787886" MODIFIED="1557224068605" TEXT="We try to give a helpful simple example that demonstrates a linear. SVM and then extend the example to a simple non-linear case to illustrate the use of mapping&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1856324919" LINK="https://www.analyticsvidhya.com/blog/2017/09/understaing-support-vector-machine-example-code/" MODIFIED="1557225479692" TEXT="Understanding Support Vector Machine algorithm from examples ">
<node CREATED="1557224068605" ID="ID_148220490" MODIFIED="1557224068605" TEXT="Sep 13 2017  You can look at support vector machines and a few examples of its working here.  It is mostly useful in non-linear separation problem. Simply&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_331071191" LINK="https://towardsdatascience.com/a-practical-guide-to-interpreting-and-visualising-support-vector-machines-97d2a5b0564e" MODIFIED="1557225479692" TEXT="A Practical Guide to Interpreting and Visualising Support Vector ">
<node CREATED="1557224068605" ID="ID_1807423030" MODIFIED="1557224068605" TEXT="Jan 12 2019  Introduction to Linear Models SVMs and Kernels; Interpreting high  The second example uses a non linear model (actually a kernel trick&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1059578803" LINK="https://ieeexplore.ieee.org/document/7293972" MODIFIED="1557225479692" TEXT="FPGA based nonlinear Support Vector Machine training using an ">
<node CREATED="1557224068605" ID="ID_1556089912" MODIFIED="1557224068605" TEXT="In this work a complete FPGA-based system for nonlinear SVM training using  whose computational cost scales quadratically with the number of examples." />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_337508365" MODIFIED="1557225512332" TEXT="Support Vector Regression#$D$#">
<node CREATED="1557224068605" FOLDED="true" ID="ID_1281914669" LINK="https://medium.com/coinmonks/support-vector-regression-or-svr-8eb3acf6d0ff" MODIFIED="1557225479692" TEXT="Support Vector Regression Or SVR &#8211; Coinmonks &#8211; Medium">
<node CREATED="1557224068605" ID="ID_1934394430" MODIFIED="1557224068605" TEXT="Jun 28 2018  This post is about SUPPORT VECTOR REGRESSION. Those who are in Machine Learning or Data Science are quite familiar with the term&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_634232909" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.svm.SVR.html" MODIFIED="1557225479692" TEXT="sklearn.svm.SVR &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068605" ID="ID_398416816" MODIFIED="1557224068605" TEXT="Epsilon-Support Vector Regression. The free parameters in the model are C and epsilon. The implementation is based on libsvm. Read more in the User Guide." />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1784986888" LINK="https://www.saedsayad.com/support_vector_machine_reg.htm" MODIFIED="1557225479692" TEXT="Support Vector Regression">
<node CREATED="1557224068605" ID="ID_1618547634" MODIFIED="1557224068605" TEXT="The Support Vector Regression (SVR) uses the same principles as the SVM for classification with only a few minor differences. First of all because output is a&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1112634199" LINK="https://en.wikipedia.org/wiki/Support-vector_machine" MODIFIED="1557225479692" TEXT="Support-vector machine - Wikipedia">
<node CREATED="1557224068605" ID="ID_1973624221" MODIFIED="1557224068605" TEXT="In machine learning support-vector machines are supervised learning models with associated learning algorithms that analyze data&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_743505241" LINK="https://www.mathworks.com/help/stats/understanding-support-vector-machine-regression.html" MODIFIED="1557225479692" TEXT="Understanding Support Vector Machine Regression - MATLAB ">
<node CREATED="1557224068605" ID="ID_770686970" MODIFIED="1557224068605" TEXT="Understand the mathematical formulation of linear and nonlinear SVM regression problems and solver algorithms." />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_851542453" LINK="https://alex.smola.org/papers/2003/SmoSch03b.pdf" MODIFIED="1557225479692" TEXT="A Tutorial on Support Vector Regression&#8727;">
<node CREATED="1557224068605" ID="ID_1670799165" MODIFIED="1557224068605" TEXT="A Tutorial on Support Vector Regression&#8727;. Alex J. Smola&#8224; and Bernhard Sch &#246;lkopf&#8225;. September 30 2003. Abstract. In this tutorial we give an overview of the&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1288768901" LINK="http://kernelsvm.tripod.com/" MODIFIED="1557225479692" TEXT="Support Vector Machine Regression">
<node CREATED="1557224068605" ID="ID_1385513422" MODIFIED="1557224068605" TEXT="Support Vector Machine Regression. Support Vector Machines are very specific class of algorithms characterized by usage of kernels absence of local minima&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_853292462" LINK="https://stats.stackexchange.com/questions/82044/how-does-support-vector-regression-work-intuitively" MODIFIED="1557225479692" TEXT="svm - How does support vector regression work intuitively? - Cross ">
<node CREATED="1557224068605" ID="ID_1013462957" MODIFIED="1557224068605" TEXT="In order to understand how you go from classification to regression it helps to see how both cases one applies the same SVM theory to&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_954945858" LINK="https://www.youtube.com/watch?v=8qsFI22c5Lk" MODIFIED="1557225479692" TEXT="Support Vector Regression - YouTube">
<node CREATED="1557224068605" ID="ID_724848989" MODIFIED="1557224068605" TEXT="Jul 25 2017  Training on Support Vector Regression by Vamsidhar Ambatipudi." />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_439891194" LINK="https://alex.smola.org/papers/2004/SmoSch04.pdf" MODIFIED="1557225479692" TEXT="A tutorial on support vector regression">
<node CREATED="1557224068605" ID="ID_291730816" MODIFIED="1557224068605" TEXT="A tutorial on support vector regression. &#8727;. ALEX J. SMOLA and BERNHARD SCH &#168;OLKOPF. RSISE Australian National University Canberra 0200 Australia." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_984354550" MODIFIED="1563517391360" TEXT="Scikit-learn implementation">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_561899328" MODIFIED="1563517391360" TEXT="Classification">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1116524624" MODIFIED="1563517391360" TEXT="Kernel based classification">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_681533924" MODIFIED="1563517391360" TEXT="Polynomial Kernel Visualization">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_643570974" MODIFIED="1563517391360" TEXT="Visualization 1 ">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068599" FOLDED="true" ID="ID_973056160" MODIFIED="1557225483435" TEXT="Kernel PCA#$D$#">
<node CREATED="1557224068599" FOLDED="true" ID="ID_374461244" LINK="https://en.wikipedia.org/wiki/Kernel_principal_component_analysis" MODIFIED="1557225479645" TEXT="Kernel principal component analysis - Wikipedia">
<node CREATED="1557224068599" ID="ID_1208819959" MODIFIED="1557224068599" TEXT="In the field of multivariate statistics kernel principal component analysis (kernel PCA) is an extension of principal component analysis (PCA) using techniques of&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1750752957" LINK="http://scikit-learn.org/stable/auto_examples/decomposition/plot_kernel_pca.html" MODIFIED="1557225479645" TEXT="Kernel PCA &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068599" ID="ID_1518390952" MODIFIED="1557224068599" TEXT="This example shows that Kernel PCA is able to find a projection of the data that  sklearn.decomposition import PCA KernelPCA from sklearn.datasets import&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1989016065" LINK="https://towardsdatascience.com/kernel-pca-vs-pca-vs-ica-in-tensorflow-sklearn-60e17eb15a64" MODIFIED="1557225479645" TEXT="Kernel PCA vs PCA vs ICA in Tensorflow/sklearn &#8211; Towards Data ">
<node CREATED="1557224068599" ID="ID_103838208" MODIFIED="1557224068599" TEXT="Sep 10 2018  Principle Component Analysis performs a linear transformation on a given data however many real-world data are not linearly separable." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_46433729" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.decomposition.KernelPCA.html" MODIFIED="1557225479645" TEXT="sklearn.decomposition.KernelPCA &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068599" ID="ID_1523588729" MODIFIED="1557224068599" TEXT="Kernel Principal component analysis (KPCA). Non-linear dimensionality reduction through the use of kernels (see Pairwise metrics Affinities and Kernels)." />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_891246857" LINK="http://www.cs.haifa.ac.il/~rita/uml_course/lectures/KPCA.pdf" MODIFIED="1557225479645" TEXT="Kernel PCA">
<node CREATED="1557224068599" ID="ID_1970263673" MODIFIED="1557224068599" TEXT="" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_79481976" LINK="https://www.cs.mcgill.ca/~dprecup/courses/ML/Lectures/ml-lecture13.pdf" MODIFIED="1557225479645" TEXT="Dimensionality reduction. PCA. Kernel PCA.">
<node CREATED="1557224068599" ID="ID_1273757169" MODIFIED="1557224068599" TEXT="Kernel PCA. &#8226; Dimensionality reduction. &#8226; Principal Component Analysis (PCA). &#8226; Kernelizing PCA. &#8226; If we have time: Autoencoders. COMP-652 and ECSE-608&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1608938768" LINK="http://fourier.eng.hmc.edu/e161/lectures/kernelPCA/node4.html" MODIFIED="1557225479645" TEXT="Kernel PCA">
<node CREATED="1557224068599" ID="ID_606611264" MODIFIED="1557224068599" TEXT="Kernel PCA. First consider nonlinearly mapping all data points ${\bf x}$ to $f({\bf x})$ in a higher dimensional feature space ${\cal F}$  where the covariance&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_1293230505" LINK="https://arxiv.org/pdf/1207.3538" MODIFIED="1557225479645" TEXT="Kernel Principal Component Analysis and its Applications in Face ">
<node CREATED="1557224068599" ID="ID_1480259461" MODIFIED="1557224068599" TEXT="Aug 31 2014  Principal component analysis (PCA) is a popular tool for linear dimensionality reduc- tion and feature extraction. Kernel PCA is the nonlinear&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_137008003" LINK="https://sebastianraschka.com/Articles/2014_kernel_pca.html" MODIFIED="1557225479645" TEXT="Kernel tricks and nonlinear dimensionality reduction via RBF kernel ">
<node CREATED="1557224068599" ID="ID_1370812760" MODIFIED="1557224068599" TEXT="In the linear PCA approach we are interested in  (Kernel Principal Component Analysis [2])&#160;" />
</node>
<node CREATED="1557224068599" FOLDED="true" ID="ID_397650947" LINK="http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.128.7613" MODIFIED="1557225479645" TEXT="Kernel principal component analysis">
<node CREATED="1557224068599" ID="ID_191466594" MODIFIED="1557224068599" TEXT="CiteSeerX - Document Details (Isaac Councill Lee Giles Pradeep Teregowda): A new method for performing a nonlinear form of Principal Component Analysis&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_270329902" MODIFIED="1557225483438" TEXT="Support Vector Machine Kernel based classification#$D$#">
<node CREATED="1557224068604" FOLDED="true" ID="ID_1504114368" LINK="https://en.wikipedia.org/wiki/Kernel_method" MODIFIED="1557225479692" TEXT="Kernel method - Wikipedia">
<node CREATED="1557224068604" ID="ID_921653002" MODIFIED="1557224068604" TEXT="In machine learning kernel methods are a class of algorithms for pattern analysis whose best known member is the support vector machine (SVM). The general task of pattern analysis is to find and study general types of  Most kernel algorithms are based on convex optimization or eigenproblems and are statistically&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_499957924" LINK="https://ieeexplore.ieee.org/document/6352380/" MODIFIED="1557225479692" TEXT="Support Vector Machine and Bhattacharrya kernel function for ">
<node CREATED="1557224068604" ID="ID_1648796477" MODIFIED="1557224068604" TEXT="This study presents a new approach for region based classification that consists in use the Support Vector Machine (SVM) method with Bhattacharyya kernel&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_902956791" LINK="https://en.wikipedia.org/wiki/Support-vector_machine" MODIFIED="1557225479692" TEXT="Support-vector machine - Wikipedia">
<node CREATED="1557224068604" ID="ID_1814197948" MODIFIED="1557224068604" TEXT="In machine learning support-vector machines are supervised learning models with associated . Permutation tests based on SVM weights have been suggested as a  classifiers by applying the kernel trick to maximum-margin hyperplanes." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1062824510" LINK="http://ieeexplore.ieee.org/document/6524743/" MODIFIED="1557225479692" TEXT="SVM kernel functions for classification - IEEE Conference Publication">
<node CREATED="1557224068604" ID="ID_221147381" MODIFIED="1557224068604" TEXT="SVM kernel functions for classification. Abstract: A new generation learning system based on recent advances in statistical learning theory deliver state-of-the-art&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1464010967" LINK="https://www.ncbi.nlm.nih.gov/pubmed/23556696" MODIFIED="1557225479692" TEXT="Minimum classification error-based weighted support vector ">
<node CREATED="1557224068604" ID="ID_238207775" MODIFIED="1557224068604" TEXT="J Acoust Soc Am. 2013 Apr;133(4):EL307-13. doi: 10.1121/1.4794350. Minimum classification error-based weighted support vector machine kernels for speaker&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_589791858" LINK="http://scikit-learn.org/stable/modules/svm.html" MODIFIED="1557225479692" TEXT="1.4. Support Vector Machines &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068604" ID="ID_1236134206" MODIFIED="1557224068604" TEXT="Support vector machines (SVMs) are a set of supervised learning methods used for  of Support Vector Classification for the case of a linear kernel. .. liblinear implementation is much more efficient than its libsvm-based SVC counterpart and&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_589512639" LINK="https://www.mathworks.com/help/stats/support-vector-machines-for-binary-classification.html" MODIFIED="1557225479692" TEXT="Support Vector Machines for Binary Classification - MATLAB ">
<node CREATED="1557224068604" ID="ID_847688560" MODIFIED="1557224068604" TEXT="Then generates a classifier based on the data with the  Train an SVM classifier with&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1667206446" LINK="https://link.springer.com/chapter/10.1007/978-3-540-71701-0_44" MODIFIED="1557225479692" TEXT="A Multiple Kernel Support Vector Machine Scheme for Simultaneous ">
<node CREATED="1557224068604" ID="ID_655469943" MODIFIED="1557224068604" TEXT="A Multiple Kernel Support Vector Machine Scheme for Simultaneous Feature Selection and Rule-Based Classification. Authors; Authors and affiliations." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1763382630" LINK="https://content.sciendo.com/view/journals/ipc/21/3/article-p45.xml" MODIFIED="1557225479692" TEXT="Object Classification Using Support Vector Machines with Kernel ">
<node CREATED="1557224068604" ID="ID_1857696810" MODIFIED="1557224068604" TEXT="Object Classification Using Support Vector Machines with Kernel-based Data Preprocessing. Krzysztof Adamiakkrzysztof.adam.adamiak@gmail.com Piotr Duch&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_991994240" LINK="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4168520/" MODIFIED="1557225479692" TEXT="Classification of EEG Signals Using a Multiple Kernel Learning ">
<node CREATED="1557224068604" ID="ID_641412930" MODIFIED="1557224068604" TEXT="Experimental results showed that the proposed method provided better classification performance compared with the SVM based on a single kernel. For mental&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1080428239" MODIFIED="1557225483439" TEXT="Support Vector Machine Polynomial Kernel Visualization#$D$#">
<node CREATED="1557224068604" FOLDED="true" ID="ID_1573652002" LINK="https://www.youtube.com/watch?v=3liCbRZPrZA" MODIFIED="1557225479692" TEXT="SVM with polynomial kernel visualization - YouTube">
<node CREATED="1557224068604" ID="ID_1030617" MODIFIED="1557224068604" TEXT="Feb 5 2007  A visual demonstration of the kernel trick in SVM. This short video demonstrates how vectors of two classes that cannot be linearly separated in&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_754447312" LINK="https://www.kaggle.com/joparga3/3-visualising-how-different-kernels-in-svms-work" MODIFIED="1557225479692" TEXT="3. Visualising how different kernels in SVMs work. | Kaggle">
<node CREATED="1557224068604" ID="ID_1095336535" MODIFIED="1557224068604" TEXT="This workbook will provide an understanding of how SVM (Support vector machines)  This is done for visualisation purposes which will enable us to better . SVMs using linear kernel have one important parameter that can be tuned and this&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_436477162" LINK="https://www.kdnuggets.com/2016/06/select-support-vector-machine-kernels.html" MODIFIED="1557225479692" TEXT="How to Select Support Vector Machine Kernels">
<node CREATED="1557224068604" ID="ID_1781774780" MODIFIED="1557224068604" TEXT="For simplicity (and visualization purposes) lets assume our dataset consists of 2 dimensions only. Below I plotted the decision regions of a linear SVM on 2&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_563991635" LINK="https://www.researchgate.net/figure/Visualization-of-the-SVM-model-with-polynomial-kernel-on-the-checkerboard-example-It-can_fig16_309004959" MODIFIED="1557225479692" TEXT="Visualization of the SVM model with polynomial kernel on the ">
<node CREATED="1557224068604" ID="ID_500752751" MODIFIED="1557224068604" TEXT="Visualization of the SVM model with polynomial kernel on the checkerboard example. It can be seen that all contributions involving x(3) do not contribute in a&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1001675097" LINK="https://stats.stackexchange.com/questions/152897/how-to-intuitively-explain-what-a-kernel-is" MODIFIED="1557225479692" TEXT="machine learning - How to intuitively explain what a kernel is ">
<node CREATED="1557224068604" ID="ID_1092289424" MODIFIED="1557224068604" TEXT="For example consider a simple polynomial kernel k(xy)=(1+xTy)2 with xy&#8712;R2. . Specifically lectures Support Vector Machines Kernel Methods and Radial Basis Functions . Visualizing the feature map and the resulting boundary line." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_991886477" LINK="https://medium.com/analytics-vidhya/comprehensive-support-vector-machines-guide-using-illusion-to-solve-reality-ad3136d8f877" MODIFIED="1557225479692" TEXT="Comprehensive Support Vector Machines Guide - Using Illusion to ">
<node CREATED="1557224068604" ID="ID_276352296" MODIFIED="1557224068604" TEXT="Sep 29 2018  Support Vector machine is a linear classifier that separates the various  SVM uses kernel trick as can be seen on the left to transform the  can then visualize our imaginary separating/classification boundary which is linear." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_478577033" LINK="https://www.datacamp.com/courses/support-vector-machines-in-r" MODIFIED="1557225479692" TEXT="Support Vector Machines in R | DataCamp">
<node CREATED="1557224068604" ID="ID_1915719871" MODIFIED="1557224068604" TEXT="Support Vector Classifiers - Linear Kernels. Introduces students to the basic concepts of support vector machines by applying the svm algorithm to a dataset that&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1041012483" LINK="https://www.analyticsvidhya.com/blog/2017/09/understaing-support-vector-machine-example-code/" MODIFIED="1557225479692" TEXT="Understanding Support Vector Machine algorithm from examples ">
<node CREATED="1557224068604" ID="ID_492912372" MODIFIED="1557224068604" TEXT="Sep 13 2017  We do not scale our # data since we want to plot the support vectors C = 1.0 # SVM regularization parameter svc = svm.SVC(kernel=linear&#160;" />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_528396634" LINK="https://www.mathworks.com/help/stats/support-vector-machines-for-binary-classification.html" MODIFIED="1557225479692" TEXT="Support Vector Machines for Binary Classification - MATLAB ">
<node CREATED="1557224068604" ID="ID_1799543574" MODIFIED="1557224068604" TEXT="Perform binary classification via SVM using separating hyperplanes and kernel transformations.  KernelFunction &#8212; The default value is linear for two-class learning which separates the data by a .. Visualize the optimized classifier." />
</node>
<node CREATED="1557224068604" FOLDED="true" ID="ID_1044094123" LINK="https://blog.statsbot.co/support-vector-machines-tutorial-c1618e635e93" MODIFIED="1557225479692" TEXT="Support Vector Machines Tutorial &#8211; Stats and Bots">
<node CREATED="1557224068604" ID="ID_592997444" MODIFIED="1557224068604" TEXT="Aug 15 2017  Its time to introduce you to support vector machines (SVM) without hard  For the 3D projection above I had used a polynomial kernel with c=0&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1310350169" MODIFIED="1563517391360" TEXT="Visualization 2 ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1645563476" MODIFIED="1563517391360" TEXT="Linear Classification">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068601" FOLDED="true" ID="ID_1973717366" MODIFIED="1557225483437" TEXT="Linear Classification Implementation#$D$#">
<node CREATED="1557224068601" FOLDED="true" ID="ID_1577088297" LINK="https://www.pyimagesearch.com/2016/08/22/an-intro-to-linear-classification-with-python/" MODIFIED="1557225479661" TEXT="An intro to linear classification with Python - PyImageSearch">
<node CREATED="1557224068601" ID="ID_1423329533" MODIFIED="1557224068601" TEXT="Aug 22 2016  From there I provide an actual linear classification implementation and example using the scikit-learn library that can be used to classify the&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_373653444" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.svm.LinearSVC.html" MODIFIED="1557225479661" TEXT="sklearn.svm.LinearSVC &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068601" ID="ID_1734759018" MODIFIED="1557224068601" TEXT="Linear Support Vector Classification. Similar to SVC with parameter kernel=linear but implemented in terms of liblinear rather than libsvm so it has more&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1099416030" LINK="https://github.com/williamd4112/simple-linear-classification" MODIFIED="1557225479661" TEXT="GitHub - williamd4112/simple-linear-classification: A python ">
<node CREATED="1557224068601" ID="ID_344626217" MODIFIED="1557224068601" TEXT="A python implementation of linear classification algorithm (including Probabilistic Generative Model Probabilistic Discriminative Model). (See Pattern&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_851339364" LINK="https://www.csie.ntu.edu.tw/~cjlin/liblinear/" MODIFIED="1557225479661" TEXT="LIBLINEAR -- A Library for Large Linear Classification">
<node CREATED="1557224068601" ID="ID_59076276" MODIFIED="1557224068601" TEXT="logistic regression support vector machines linear classification document  The appendices of this paper give all implementation details of LIBLINEAR." />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_1268220830" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html" MODIFIED="1557225479661" TEXT="sklearn.linear_model.LogisticRegression &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068601" ID="ID_1547851589" MODIFIED="1557224068601" TEXT="In the multiclass case the training algorithm uses the one-vs-rest (OvR)  This class implements regularized logistic regression using the liblinear library&#160;" />
</node>
<node CREATED="1557224068601" FOLDED="true" ID="ID_459783586" LINK="https://www.csie.ntu.edu.tw/~cjlin/papers/liblinear.pdf" MODIFIED="1557225479661" TEXT="LIBLINEAR: A Library for Large Linear Classification">
<node CREATED="1557224068601" ID="ID_1926482587" MODIFIED="1557224068601" TEXT="Dec 8 2017  Keywords: large-scale linear classification logistic regression support vector machines . Library calls are implemented in the file linear.cpp." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1061932017" LINK="http://www.jeannicholashould.com/what-i-learned-implementing-a-classifier-from-scratch.html" MODIFIED="1557225479661" TEXT="What I Learned Implementing a Classifier from Scratch in Python ">
<node CREATED="1557224068602" ID="ID_45805076" MODIFIED="1557224068602" TEXT="Jan 4 2017  The classifier algorithm falls under the supervised learning category. .. the capabilities of the Perceptron algorithm are attributable to linear&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_955614147" LINK="https://www.geeksforgeeks.org/linear-regression-python-implementation/" MODIFIED="1557225479661" TEXT="Linear Regression (Python Implementation) - GeeksforGeeks">
<node CREATED="1557224068602" ID="ID_460815013" MODIFIED="1557224068602" TEXT="This article discusses the basics of linear regression and its implementation in Python programming language. Linear regression is a statistical approach for&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1657607490" LINK="https://en.wikipedia.org/wiki/Perceptron" MODIFIED="1557225479661" TEXT="Perceptron - Wikipedia">
<node CREATED="1557224068602" ID="ID_290870457" MODIFIED="1557224068602" TEXT="In machine learning the perceptron is an algorithm for supervised learning of binary classifiers. A binary classifier is a function which can decide whether or not an input represented by a vector of numbers belongs to some specific class. It is a type of linear classifier i.e. a classification algorithm that makes its&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_196358265" LINK="https://www.mathworks.com/help/stats/classificationlinear.predict.html" MODIFIED="1557225479661" TEXT="Predict labels for linear classification models - MATLAB">
<node CREATED="1557224068602" ID="ID_465735078" MODIFIED="1557224068602" TEXT="Mdl &#8212; Binary linear classification model ClassificationLinear model object. Binary linear .. Generate C and C++ code using MATLAB&#174; Coder&#8482;. Usage notes&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_258292171" MODIFIED="1557225483437" TEXT="Linear Classification Optimizations#$D$#">
<node CREATED="1557224068602" FOLDED="true" ID="ID_1754567857" LINK="https://web.stanford.edu/class/ee392o/mit022702.pdf" MODIFIED="1557225479661" TEXT="Convex Optimization in Classification Problems">
<node CREATED="1557224068602" ID="ID_867922972" MODIFIED="1557224068602" TEXT="outline.  convex optimization. &#8226; SVMs and robust linear programming. &#8226; minimax probability machine. &#8226; learning the kernel matrix. 3&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_190568664" LINK="https://www.csie.ntu.edu.tw/~cjlin/papers/l1.pdf" MODIFIED="1557225479661" TEXT="A Comparison of Optimization Methods and Software for Large ">
<node CREATED="1557224068602" ID="ID_914211203" MODIFIED="1557224068602" TEXT="Keywords: L1 regularization linear classification optimization methods logistic . Comparing Methods and Software for L1-regularized Linear Classification." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1191649462" LINK="https://en.wikipedia.org/wiki/Linear_classifier" MODIFIED="1557225479661" TEXT="Linear classifier - Wikipedia">
<node CREATED="1557224068602" ID="ID_811321816" MODIFIED="1557224068602" TEXT="In the field of machine learning the goal of statistical classification is to use an objects . the discrepancy between the classifiers outputs and the desired outputs. Thus the learning algorithm solves an optimization problem of the form." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1492856749" LINK="https://link.springer.com/chapter/10.1007/978-3-662-49390-8_64" MODIFIED="1557225479661" TEXT="Online DC Optimization for Online Binary Linear Classification ">
<node CREATED="1557224068602" ID="ID_1177748938" MODIFIED="1557224068602" TEXT="This paper concerns online algorithms for online binary linear classification (OBLC) problems in Machine learning. In a sense of &#8220;online&#8221; classification&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_899358282" LINK="https://www.youtube.com/watch?v=qlLChbHhbg4" MODIFIED="1557225479661" TEXT="CS231n Winter 2016: Lecture 3: Linear Classification 2 ">
<node CREATED="1557224068602" ID="ID_847536979" MODIFIED="1557224068602" TEXT="Jan 11 2016  Stanford Winter Quarter 2016 class: CS231n: Convolutional Neural Networks for Visual Recognition. Lecture 3. Get in touch on Twitter&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_40302065" LINK="http://vision.stanford.edu/teaching/cs231n/linear-classify-demo/" MODIFIED="1557225479661" TEXT="Multiclass SVM optimization demo">
<node CREATED="1557224068602" ID="ID_1734518535" MODIFIED="1557224068602" TEXT="The class scores for linear classifiers are computed as f(xi;Wb)=Wxi+b where the  Each classifier is visualized by a line that indicates its zero score level set." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_639556911" LINK="https://www.youtube.com/watch?v=q3TZVNGtOug" MODIFIED="1557225479661" TEXT="CS231n Lecture 3 - Linear Classification 2 Optimization - YouTube">
<node CREATED="1557224068602" ID="ID_615369632" MODIFIED="1557224068602" TEXT="Jun 14 2016  Linear classification II Higher-level representations image features Optimization stochastic gradient descent." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_1424002655" LINK="https://www.mathworks.com/help/stats/fitclinear.html" MODIFIED="1557225479661" TEXT="Fit linear classification model to high-dimensional data - MATLAB ">
<node CREATED="1557224068602" ID="ID_1347537110" MODIFIED="1557224068602" TEXT="This example shows how to minimize the cross-validation error in a linear classifier using fitclinear . The example uses&#160;" />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_134828506" LINK="http://ieeexplore.ieee.org/document/6707017/" MODIFIED="1557225479661" TEXT="A hybrid optimization method for acceleration of building linear ">
<node CREATED="1557224068602" ID="ID_178075711" MODIFIED="1557224068602" TEXT="Linear classification is an important technique in machine learning and data mining and development of fast optimization methods for training linear class." />
</node>
<node CREATED="1557224068602" FOLDED="true" ID="ID_202128438" LINK="https://www.sciencedirect.com/science/article/pii/S0305054804001790" MODIFIED="1557225479661" TEXT="ABC inventory classification with multiple-criteria using weighted ">
<node CREATED="1557224068602" ID="ID_330847719" MODIFIED="1557224068602" TEXT="Inventory classification using ABC analysis is one of the most widely employed  In this paper we propose a simple weighted linear optimization model to&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_573761442" MODIFIED="1563517391360" TEXT="Non-Linear Examples">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1779924908" MODIFIED="1563517391360" TEXT="Controlled Support Vector Machines">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068605" FOLDED="true" ID="ID_1442143798" MODIFIED="1557225483439" TEXT="Controlled Support Vector Machines#$D$#">
<node CREATED="1557224068605" FOLDED="true" ID="ID_1390296332" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781785889622/7/ch07lvl1sec54/controlled-support-vector-machines" MODIFIED="1557225479692" TEXT="Controlled support vector machines - Machine Learning Algorithms">
<node CREATED="1557224068605" ID="ID_1561353601" MODIFIED="1557224068605" TEXT="Controlled support vector machinesWith real datasets SVM can extract a very large number of support vectors to increase accur" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1207540671" LINK="https://towardsdatascience.com/support-vector-machines-a-brief-overview-37e018ae310f" MODIFIED="1557225479692" TEXT="Support Vector Machines &#8212; A Brief Overview &#8211; Towards Data Science">
<node CREATED="1557224068605" ID="ID_598537553" MODIFIED="1557224068605" TEXT="Aug 2 2017  Support vector machines have become a great tool for the data scientist.  These close points are the support vectors because they control the&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1565038178" LINK="https://ieeexplore.ieee.org/iel5/10/4567608/04463647.pdf" MODIFIED="1557225479692" TEXT="Support Vector Machine-Based Classification Scheme for ">
<node CREATED="1557224068605" ID="ID_1457917998" MODIFIED="1557224068605" TEXT="support vector machine (SVM) to classify upper limb motions using myoelectric signals. It explores the optimum configuration of SVM- based myoelectric control&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_421946943" LINK="https://www.researchgate.net/publication/245441278_Support_Vector_Machines_A_Nonlinear_Modelling_and_Control_Perspective" MODIFIED="1557225479692" TEXT="(PDF) Support Vector Machines: A Nonlinear Modelling and Control ">
<node CREATED="1557224068605" ID="ID_365900001" MODIFIED="1557224068605" TEXT="We discuss a method of least squares support vector machines (LS-SVM) which has been extended to recurrent models and use in optimal control problems." />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1679825150" LINK="https://ieeexplore.ieee.org/document/5594843" MODIFIED="1557225479692" TEXT="Controlled spectral unmixing using extended Support Vector Machines">
<node CREATED="1557224068605" ID="ID_280846074" MODIFIED="1557224068605" TEXT="Controlled spectral unmixing using extended Support Vector Machines. Abstract: This paper presents an improved spectral unmixing framework for remote&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1106958315" LINK="https://www.sciencedirect.com/science/article/pii/S1537511017311194" MODIFIED="1557225479692" TEXT="Least Squares Support Vector Machines">
<node CREATED="1557224068605" ID="ID_306952593" MODIFIED="1557224068605" TEXT="Least Squares Support Vector Machines (LS-SVM) used to predict nutrient release  Keywords. Controlled release fertiliser. Nutrient release model. LS-SVM." />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_701721324" LINK="ftp://ftp.esat.kuleuven.be/sista/ida/reports/98-86.pdf" MODIFIED="1557225479692" TEXT="Optimal control by least squares support vector machines">
<node CREATED="1557224068605" ID="ID_1426427855" MODIFIED="1557224068605" TEXT="method for imposing local stability in the LS-SVM control scheme. The results are discussed for support vector machines with radial basis function kernel." />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1479488983" LINK="https://onlinelibrary.wiley.com/doi/abs/10.1002/rnc.1094" MODIFIED="1557225479692" TEXT="Support vector machines&#8208;based generalized predictive control ">
<node CREATED="1557224068605" ID="ID_50335265" MODIFIED="1557224068605" TEXT="Aug 22 2006  In this study we propose a novel control methodology that introduces the use of support vector machines (SVMs) in the generalized predictive&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1471999162" LINK="https://journals.sagepub.com/doi/full/10.5772/51192" MODIFIED="1557225479692" TEXT="SVM-Based Control System for a Robot Manipulator - Foudil ">
<node CREATED="1557224068605" ID="ID_1918017536" MODIFIED="1557224068605" TEXT="Real systems are usually non-linear ill-defined have variable parameters and are subject to external disturbances. Modelling these systems is often an approxi." />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1402554540" LINK="http://scikit-learn.org/stable/modules/svm.html" MODIFIED="1557225479692" TEXT="1.4. Support Vector Machines &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068605" ID="ID_452715217" MODIFIED="1557224068605" TEXT="Support vector machines (SVMs) are a set of supervised learning methods used for .. This randomness can be controlled with the random_state parameter." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1718088884" MODIFIED="1563517391360" TEXT="Support Vector Regression">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_59721775" MODIFIED="1563517391360" TEXT="Blog">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_261488283" MODIFIED="1563517391360" TEXT="Analytics Vidya ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
</node>
</node>
<node CREATED="1563517391360" FOLDED="true" Folded="true" ID="ID_935460987" MODIFIED="1563517391360" POSITION="left" TEXT="Decision Trees and Ensemble Learning">
<edge COLOR="#00cc33" />
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1307049531" MODIFIED="1563517391360" TEXT="Decision Trees">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1981315952" MODIFIED="1563517391360" TEXT="Impurity Measures">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068606" FOLDED="true" ID="ID_63069496" MODIFIED="1557225520011" TEXT="Decision Trees Impurity Measures#$D$#">
<node CREATED="1557224068606" FOLDED="true" ID="ID_1901347475" LINK="https://en.wikipedia.org/wiki/Decision_tree_learning" MODIFIED="1557225479692" TEXT="Decision tree learning - Wikipedia">
<node CREATED="1557224068606" ID="ID_278652681" MODIFIED="1557224068606" TEXT="Used by the CART (classification and regression tree) algorithm for classification trees Gini impurity is a measure of how often a&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1322256713" LINK="https://people.revoledu.com/kardi/tutorial/DecisionTree/how-to-measure-impurity.htm" MODIFIED="1557225479692" TEXT="Tutorial on Decision Tree: measure impurity">
<node CREATED="1557224068606" ID="ID_303019602" MODIFIED="1557224068606" TEXT="Most well known indices to measure degree of impurity are entropy gini index and classification error. The formulas are given below. Entropy. Gini Index." />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1283537082" LINK="https://people.cs.pitt.edu/~milos/courses/cs2750-Spring03/lectures/class19.pdf" MODIFIED="1557225479692" TEXT="Decision trees">
<node CREATED="1557224068606" ID="ID_1533922489" MODIFIED="1557224068606" TEXT="How to construct the decision tree? &#8226; Top-bottom algorithm: &#8211; Find the best split condition (quantified based on the impurity measure). &#8211; Stops when no&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1729966287" LINK="https://spark.apache.org/docs/2.2.0/mllib-decision-tree.html" MODIFIED="1557225479692" TEXT="Decision Trees - RDD-based API - Spark 2.2.0 Documentation">
<node CREATED="1557224068606" ID="ID_1483559422" MODIFIED="1557224068606" TEXT="The current implementation provides two impurity measures for classification (Gini impurity and entropy) and&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1802973162" LINK="https://medium.com/machine-learning-101/chapter-3-decision-trees-theory-e7398adac567" MODIFIED="1557225479692" TEXT="Chapter 3 : Decision Tree Classifier &#8212; Theory &#8211; Machine Learning ">
<node CREATED="1557224068606" ID="ID_1897131528" MODIFIED="1557224068606" TEXT="May 11 2017  In second part we modify spam classification code for decision tree  of randomness of elements or in other words it is measure of impurity." />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_839165807" LINK="https://sebastianraschka.com/faq/docs/decision-tree-binary.html" MODIFIED="1557225479692" TEXT="decision-tree-binary..">
<node CREATED="1557224068606" ID="ID_716565497" MODIFIED="1557224068606" TEXT="Why are implementations of decision tree algorithms usually binary and what  Now the two impurity measures or splitting criteria that are commonly used in&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1024125170" LINK="https://datascience.stackexchange.com/questions/10228/gini-impurity-vs-entropy" MODIFIED="1557225479692" TEXT="machine learning - Gini Impurity vs Entropy - Data Science Stack ">
<node CREATED="1557224068606" ID="ID_707631055" MODIFIED="1557224068606" TEXT="Gini impurity and Information Gain Entropy are pretty much the same. . measure has little effect on the performance of single decision tree&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_570463170" LINK="https://link.springer.com/chapter/10.1007/978-4-431-65950-1_21" MODIFIED="1557225479692" TEXT="Robust impurity measures in decision trees | SpringerLink">
<node CREATED="1557224068606" ID="ID_1603459830" MODIFIED="1557224068606" TEXT="Tree-based methods are a statistical procedure for automatic learning from data their main characteristic being the simplicity of the results obtained. Their virtue&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1839481767" LINK="https://bambielli.com/til/2017-10-29-gini-impurity/" MODIFIED="1557225479692" TEXT="Gini Impurity (With Examples) - Bambiellis Blog">
<node CREATED="1557224068606" ID="ID_1890918493" MODIFIED="1557224068606" TEXT="Oct 29 2017   about Gini Impurity: another metric that is used when training decision trees.  Gini Impurity is a measurement of the likelihood of an incorrect&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1071674589" LINK="http://mason.gmu.edu/~jgentle/csi772/16s/L10_CART_16s.pdf" MODIFIED="1557225479692" TEXT="Classification and Regression Trees">
<node CREATED="1557224068606" ID="ID_819647952" MODIFIED="1557224068606" TEXT="Nodes are split based on their &#8220;impurity&#8221;. Impurity is a measure of how badly the observations at a given node fit the model. In a regression tree for example the&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_224344853" MODIFIED="1563517391360" TEXT="Feature Importance">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068606" FOLDED="true" ID="ID_460895492" MODIFIED="1557225483440" TEXT="Decision Trees Feature Importance#$D$#">
<node CREATED="1557224068606" FOLDED="true" ID="ID_1586708443" LINK="https://medium.com/@srnghn/the-mathematics-of-decision-trees-random-forest-and-feature-importance-in-scikit-learn-and-spark-f2861df67e3" MODIFIED="1557225479692" TEXT="The Mathematics of Decision Trees Random Forest and Feature ">
<node CREATED="1557224068606" ID="ID_1200358761" MODIFIED="1557224068606" TEXT="May 11 2018  The Mathematics of Decision Trees Random Forest and Feature Importance in Scikit-learn and Spark. Go to the profile of Stacey Ronaghan." />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_964831953" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html" MODIFIED="1557225479692" TEXT="sklearn.tree.DecisionTreeClassifier &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068606" ID="ID_1205236181" MODIFIED="1557224068606" TEXT="For the default settings of a decision tree on large datasets setting this to true . The importance of a feature is computed as the (normalized) total reduction of&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_963741685" LINK="https://machinelearningmastery.com/feature-importance-and-feature-selection-with-xgboost-in-python/" MODIFIED="1557225479692" TEXT="Feature Importance and Feature Selection With XGBoost in Python">
<node CREATED="1557224068606" ID="ID_675036867" MODIFIED="1557224068606" TEXT="Aug 31 2016  A benefit of using ensembles of decision tree methods like gradient boosting is that they can automatically provide estimates of feature&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1535880502" LINK="https://stackoverflow.com/questions/49170296/scikit-learn-feature-importance-calculation-in-decision-trees" MODIFIED="1557225479692" TEXT="scikit learn - feature importance calculation in decision trees - Stack ">
<node CREATED="1557224068606" ID="ID_1548201535" MODIFIED="1557224068606" TEXT="Mar 8 2018  I think feature importance depends on the implementation so we need to look at the documentation of scikit-learn. The feature importances." />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_308528929" LINK="https://datascience.stackexchange.com/questions/16693/interpreting-decision-tree-in-context-of-feature-importances" MODIFIED="1557225479692" TEXT="machine learning - Interpreting Decision Tree in context of feature ">
<node CREATED="1557224068606" ID="ID_1113959848" MODIFIED="1557224068606" TEXT="It is not necessary that the more important a feature is then the higher its node is at the decision tree. This is simply because different criteria&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1768579772" LINK="https://www.youtube.com/watch?v=wpNl-JwwplA" MODIFIED="1557225479692" TEXT="StatQuest: Decision Trees Part 2 - Feature Selection and Missing Data">
<node CREATED="1557224068606" ID="ID_919075038" MODIFIED="1557224068606" TEXT="Jan 29 2018  This is just a short follow up to last weeks StatQuest where we introduced decision trees. Here we show how decision trees deal with variables&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_142217685" LINK="https://www.cs.cmu.edu/~atalwalk/dstump_nips17.pdf" MODIFIED="1557225479692" TEXT="Variable Importance using Decision Trees">
<node CREATED="1557224068606" ID="ID_17550896" MODIFIED="1557224068606" TEXT="Decision trees and random forests are well established models that not only offer good predictive performance but also provide rich feature importance&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_858348512" LINK="https://papers.nips.cc/paper/6646-variable-importance-using-decision-trees" MODIFIED="1557225479692" TEXT="Variable Importance Using Decision Trees">
<node CREATED="1557224068606" ID="ID_1226398400" MODIFIED="1557224068606" TEXT="Abstract. Decision trees and random forests are well established models that not only offer good predictive performance but also provide rich feature importance&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1876819646" LINK="https://becominghuman.ai/feature-importance-measures-for-tree-models-part-ii-20c9ff4329b" MODIFIED="1557225479692" TEXT="Feature Importance Measures for Tree Models &#8212; Part II">
<node CREATED="1557224068606" ID="ID_297131636" MODIFIED="1557224068606" TEXT="Oct 29 2017  In part II were going to apply the algorithms introduced in part I and explore the features in the Mushroom Classification dataset. Honestly&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1529820231" LINK="https://towardsdatascience.com/feature-selection-using-random-forest-26d7b747597f" MODIFIED="1557225479692" TEXT="Feature Selection Using Random forest &#8211; Towards Data Science">
<node CREATED="1557224068606" ID="ID_158305892" MODIFIED="1557224068606" TEXT="Dec 14 2018  This interpretability is given by the fact that it is straightforward to derive the importance of each variable on the tree decision. In other words it is&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1876294969" MODIFIED="1563517391360" TEXT="DT Classification using Scikit-learn">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068606" FOLDED="true" ID="ID_1898764742" MODIFIED="1557225483440" TEXT="Decision Trees Classification using Scikit-learn#$D$#">
<node CREATED="1557224068606" FOLDED="true" ID="ID_99229823" LINK="http://scikit-learn.org/stable/modules/tree.html" MODIFIED="1557225479692" TEXT="1.10. Decision Trees &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068606" ID="ID_1663172826" MODIFIED="1557224068606" TEXT="Classification; 1.10.2. Regression; 1.10.3. Multi-output problems; 1.10.4. Complexity; 1.10.5. Tips on practical use; 1.10.6. Tree algorithms: ID3 C4.5 C5.0 and&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_156738063" LINK="https://www.datacamp.com/community/tutorials/decision-tree-classification-python" MODIFIED="1557225479692" TEXT="Decision Tree Classification in Python (article) - DataCamp">
<node CREATED="1557224068606" ID="ID_923372119" MODIFIED="1557224068606" TEXT="Dec 28 2018  In this tutorial learn Decision Tree Classification attribute selection measures and how to build and optimize Decision Tree Classifier using&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1941437647" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html" MODIFIED="1557225479692" TEXT="sklearn.tree.DecisionTreeClassifier &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068606" ID="ID_1187571866" MODIFIED="1557224068606" TEXT="Examples using sklearn.tree.  A decision tree classifier. . For example for four-class multilabel classification weights should be [{0: 1 1: 1} {0: 1 1: 5} {0: 1&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1803460846" LINK="http://dataaspirant.com/2017/02/01/decision-tree-algorithm-python-with-scikit-learn/" MODIFIED="1557225479692" TEXT="Building Decision Tree Algorithm in Python with scikit learn">
<node CREATED="1557224068606" ID="ID_1670664944" MODIFIED="1557224068606" TEXT="Feb 1 2017  Learn how to build one of the cutest and lovable supervised algorithms Decision Tree classifier in Python using the scikit-learn package." />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1655361686" LINK="http://benalexkeen.com/decision-tree-classifier-in-python-using-scikit-learn/" MODIFIED="1557225479692" TEXT="Decision Tree Classifier in Python using Scikit-learn &#8211; Ben Alex Keen">
<node CREATED="1557224068606" ID="ID_519709242" MODIFIED="1557224068606" TEXT="May 31 2017  Decision Tree Classifier in Python using Scikit-learn. Decision Trees can be used as classifier or regression models. A tree structure is&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_517322704" LINK="https://www.geeksforgeeks.org/multiclass-classification-using-scikit-learn/" MODIFIED="1557225479692" TEXT="Multiclass classification using scikit-learn - GeeksforGeeks">
<node CREATED="1557224068606" ID="ID_1354850442" MODIFIED="1557224068606" TEXT="In a multiclass classification we train a classifier using our training data and use  In the following code snippet we train a decision tree classifier in scikit-learn." />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_152990814" LINK="https://stackabuse.com/decision-trees-in-python-with-scikit-learn/" MODIFIED="1557225479692" TEXT="Decision Trees in Python with Scikit-Learn">
<node CREATED="1557224068606" ID="ID_1998621450" MODIFIED="1557224068606" TEXT="Feb 28 2018  Implementing Decision Trees with Python Scikit Learn  well solve both classification as well as regression problems using the decision tree." />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1068458864" LINK="https://www.youtube.com/watch?v=9YcMzsFvfxU" MODIFIED="1557225479692" TEXT="Machine Learning with Scikit-Learn - The Cancer Dataset - 11 ">
<node CREATED="1557224068606" ID="ID_439286280" MODIFIED="1557224068606" TEXT="Apr 5 2017  In this machine learning series I will work on the Wisconsin Breast Cancer  with Scikit-Learn - The Cancer Dataset - 11 - Decision Trees 1." />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_717564183" LINK="https://adataanalyst.com/scikit-learn/decision-trees-scikit-learn/" MODIFIED="1557225479692" TEXT="Decision Trees in scikit-learn - A Data Analyst">
<node CREATED="1557224068606" ID="ID_1209872036" MODIFIED="1557224068606" TEXT="Decision Trees in scikit-learn  Sometimes feature selection may be done by using automatic tools to evaluate and  The preprocessing module of scikit-learn includes a LabelEncoder class whose fit . Training a decision tree classifier&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_388316299" LINK="http://chrisstrelioff.ws/sandbox/2015/06/08/decision_trees_in_python_with_scikit_learn_and_pandas.html" MODIFIED="1557225479692" TEXT="Decision trees in python with scikit-learn and pandas &#8212; chris sandbox">
<node CREATED="1557224068606" ID="ID_1139467910" MODIFIED="1557224068606" TEXT="Jun 8 2015  Decision trees in python with scikit-learn and pandas. In this post I will cover decision trees (for classification) in python using scikit-learn and&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1721520381" MODIFIED="1563517391360" TEXT="Interactive Visualization ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_84705570" MODIFIED="1563517391360" TEXT="Decision Tree Visualization Blog(T2) ">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068605" FOLDED="true" ID="ID_893483303" MODIFIED="1557225513316" TEXT="Decision Trees#$D$#">
<node CREATED="1557224068605" FOLDED="true" ID="ID_1033305211" LINK="https://en.wikipedia.org/wiki/Decision_tree" MODIFIED="1557225479692" TEXT="Decision tree - Wikipedia">
<node CREATED="1557224068605" ID="ID_1203388976" MODIFIED="1557224068605" TEXT="A decision tree is a decision support tool that uses a tree-like model of decisions and their possible consequences including chance event outcomes resource&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_211298486" LINK="https://www.geeksforgeeks.org/decision-tree/" MODIFIED="1557225479692" TEXT="Decision Tree - GeeksforGeeks">
<node CREATED="1557224068605" ID="ID_359389851" MODIFIED="1557224068605" TEXT="A Decision tree is a flowchart like tree structure where each internal node  Decision trees classify instances by sorting them down the tree from the root to&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1894028188" LINK="https://en.wikipedia.org/wiki/Decision_tree_learning" MODIFIED="1557225479692" TEXT="Decision tree learning - Wikipedia">
<node CREATED="1557224068605" ID="ID_1150337269" MODIFIED="1557224068605" TEXT="In computer science Decision tree learning uses a decision tree (as a predictive model) to go from observations about an item (represented in the branches) to&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1048356266" LINK="http://scikit-learn.org/stable/modules/tree.html" MODIFIED="1557225479692" TEXT="1.10. Decision Trees &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068605" ID="ID_491540004" MODIFIED="1557224068605" TEXT="Decision Trees (DTs) are a non-parametric supervised learning method used for classification and regression. The goal is to create a model that predicts the&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1629534620" LINK="https://www.mindtools.com/dectree.html" MODIFIED="1557225479692" TEXT="Decision Tree Analysis - Decision Skills from MindTools.com">
<node CREATED="1557224068605" ID="ID_536197979" MODIFIED="1557224068605" TEXT="Decision Trees are excellent tools for helping you to choose between several courses of action. They provide a highly effective structure within which you can lay&#160;" />
</node>
<node CREATED="1557224068605" FOLDED="true" ID="ID_1103367643" LINK="https://www.lucidchart.com/pages/decision-tree" MODIFIED="1557225479692" TEXT="What is a Decision Tree Diagram | Lucidchart">
<node CREATED="1557224068606" ID="ID_330352671" MODIFIED="1557224068606" TEXT="Need to break down a complex decision? Try using a decision tree maker. Read on to find out all about decision trees including what they are how theyre used&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_1880441549" LINK="https://towardsdatascience.com/decision-trees-in-machine-learning-641b9c4e8052" MODIFIED="1557225479692" TEXT="Decision Trees in Machine Learning &#8211; Towards Data Science">
<node CREATED="1557224068606" ID="ID_1808883553" MODIFIED="1557224068606" TEXT="May 17 2017  A decision tree is drawn upside down with its root at the top. In the image on the left the bold text in black represents a condition/internal node&#160;" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_917176974" LINK="https://www.investopedia.com/terms/d/decision-tree.asp" MODIFIED="1557225479692" TEXT="Decision Tree">
<node CREATED="1557224068606" ID="ID_853773909" MODIFIED="1557224068606" TEXT="Jul 23 2018  A decision tree os a schematic tree-shaped diagram used to determine a course of action or show a statistical probability." />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_72737617" LINK="https://medium.com/deep-math-machine-learning-ai/chapter-4-decision-trees-algorithms-b93975f7a1f1" MODIFIED="1557225479692" TEXT="Chapter 4: Decision Trees Algorithms &#8211; Deep Math Machine ">
<node CREATED="1557224068606" ID="ID_1184366064" MODIFIED="1557224068606" TEXT="Oct 6 2017  Decision tree is one of the most popular machine learning algorithms used all along This story I wanna talk about it so lets get started!" />
</node>
<node CREATED="1557224068606" FOLDED="true" ID="ID_206692042" LINK="https://www.youtube.com/watch?v=eKD5gxPPeY0" MODIFIED="1557225479692" TEXT="Decision Tree 1: how it works - YouTube">
<node CREATED="1557224068606" ID="ID_1249102854" MODIFIED="1557224068606" TEXT="Jan 19 2014  Full lecture: http://bit.ly/D-Tree A Decision Tree recursively splits training data into subsets based on the value of a single attribute. Each split&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_531884128" MODIFIED="1563517391360" TEXT=" Ensemble Learning">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_385062271" MODIFIED="1563517391360" TEXT="Random Forests">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068606" FOLDED="true" ID="ID_1981785204" MODIFIED="1557225483440" TEXT="Ensemble Learning#$D$#">
<node CREATED="1557224068606" FOLDED="true" ID="ID_146625453" LINK="https://en.wikipedia.org/wiki/Ensemble_learning" MODIFIED="1557225479692" TEXT="Ensemble learning - Wikipedia">
<node CREATED="1557224068606" ID="ID_78141601" MODIFIED="1557224068606" TEXT="In statistics and machine learning ensemble methods use multiple learning algorithms to obtain better predictive performance than could be obtained from any&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_531902139" LINK="https://cs.nju.edu.cn/zhouzh/zhouzh.files/publication/springerEBR09.pdf" MODIFIED="1557225479692" TEXT="Ensemble Learning">
<node CREATED="1557224068607" ID="ID_1354227912" MODIFIED="1557224068607" TEXT="Ensemble Learning. Zhi-Hua Zhou. National Key Laboratory for Novel Software Technology Nanjing University Nanjing 210093 China zhouzh@nju.edu.cn." />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1107515149" LINK="https://blog.statsbot.co/ensemble-learning-d1dcd548e936" MODIFIED="1557225479692" TEXT="Ensemble Learning to Improve Machine Learning Results">
<node CREATED="1557224068607" ID="ID_1635488830" MODIFIED="1557224068607" TEXT="Aug 22 2017  Ensemble learning helps improve machine learning results by combining several models. Ensemble methods allow the production of better&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1665422056" LINK="http://www.scholarpedia.org/article/Ensemble_learning" MODIFIED="1557225479692" TEXT="Ensemble learning - Scholarpedia">
<node CREATED="1557224068607" ID="ID_606861169" MODIFIED="1557224068607" TEXT="Dec 22 2008  Ensemble learning is the process by which multiple models such as classifiers or experts are strategically generated and combined to solve a&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1088482545" LINK="https://towardsdatascience.com/simple-guide-for-ensemble-learning-methods-d87cc68705a2" MODIFIED="1557225479692" TEXT="Simple guide for ensemble learning methods &#8211; Towards Data Science">
<node CREATED="1557224068607" ID="ID_1860197126" MODIFIED="1557224068607" TEXT="Feb 26 2019  Ensemble models in machine learning combine the decisions from multiple models to improve the overall performance. They operate on the&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1249769872" LINK="https://www.analyticsvidhya.com/blog/2018/06/comprehensive-guide-for-ensemble-models/" MODIFIED="1557225479692" TEXT="A Comprehensive Guide to Ensemble Learning (with Python codes)">
<node CREATED="1557224068607" ID="ID_1345727211" MODIFIED="1557224068607" TEXT="Jun 18 2018  Ensemble models in machine learning operate on a similar idea. They combine the decisions from multiple models to improve the overall&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1875279123" LINK="http://www.ensemblelearning.org/" MODIFIED="1557225479692" TEXT="Ensemble Learning &#8211; Together we grow strong schools">
<node CREATED="1557224068607" ID="ID_1833060407" MODIFIED="1557224068607" TEXT="Ensemble Learning formerly The College-Ready Promise is a national organization committed to fixing inequities in the education system by improving how&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1380459009" LINK="https://www.analyticsvidhya.com/blog/2015/08/introduction-ensemble-learning/" MODIFIED="1557225479692" TEXT="Basics of Ensemble Learning Explained in Simple English">
<node CREATED="1557224068607" ID="ID_1453064985" MODIFIED="1557224068607" TEXT="Aug 2 2015  Introduction. Ensemble modeling is a powerful way to improve the performance of your model. It usually pays off to apply ensemble learning&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1734992671" LINK="https://www.youtube.com/watch?v=Un9zObFjBH0" MODIFIED="1557225479692" TEXT="Ensemble learners - YouTube">
<node CREATED="1557224068607" ID="ID_1691979733" MODIFIED="1557224068607" TEXT="Jun 6 2016  This video is part of the Udacity course Machine Learning for Trading. Watch the full course at https://www.udacity.com/course/ud501." />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_154028552" LINK="https://becominghuman.ai/ensemble-learning-bagging-and-boosting-d20f38be9b1e" MODIFIED="1557225479692" TEXT="Ensemble Learning &#8212; Bagging and Boosting &#8211; Becoming Human ">
<node CREATED="1557224068607" ID="ID_1463893649" MODIFIED="1557224068607" TEXT="Jul 3 2018  Bagging and Boosting are similar in that they are both ensemble techniques where a set of weak learners are combined to create a strong&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_186862183" MODIFIED="1557225483440" TEXT="Random Forests    #$D$#">
<node CREATED="1557224068607" FOLDED="true" ID="ID_280319701" LINK="https://en.wikipedia.org/wiki/Random_forest" MODIFIED="1557225479692" TEXT="Random forest - Wikipedia">
<node CREATED="1557224068607" ID="ID_399435530" MODIFIED="1557224068607" TEXT="Random forests or random decision forests are an ensemble learning method for classification regression and other tasks that operates by constructing a&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_67794332" LINK="https://towardsdatascience.com/the-random-forest-algorithm-d457d499ffcd" MODIFIED="1557225479692" TEXT="The Random Forest Algorithm &#8211; Towards Data Science">
<node CREATED="1557224068607" ID="ID_642552941" MODIFIED="1557224068607" TEXT="Feb 22 2018  Random Forest is a flexible easy to use machine learning algorithm that produces even without hyper-parameter tuning a great result most of&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1078527336" LINK="https://www.stat.berkeley.edu/~breiman/RandomForests/cc_home.htm" MODIFIED="1557225479692" TEXT="Random forests - classification description">
<node CREATED="1557224068607" ID="ID_1590899500" MODIFIED="1557224068607" TEXT="Random Forests(tm) is a trademark of Leo Breiman and Adele Cutler and is  In the original paper on random forests it was shown that the forest error rate&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_535129743" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html" MODIFIED="1557225479692" TEXT="3.2.4.3.1. sklearn.ensemble.RandomForestClassifier &#8212; scikit-learn ">
<node CREATED="1557224068607" ID="ID_604302479" MODIFIED="1557224068607" TEXT="A random forest is a meta estimator that fits a number of decision tree classifiers on various sub-samples of the dataset and uses averaging to improve the&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_511104111" LINK="https://medium.com/@williamkoehrsen/random-forest-simple-explanation-377895a60d2d" MODIFIED="1557225479692" TEXT="Random Forest Simple Explanation &#8211; Will Koehrsen &#8211; Medium">
<node CREATED="1557224068607" ID="ID_1612640433" MODIFIED="1557224068607" TEXT="Dec 27 2017  Understanding the Random Forest with an intuitive example. When learning a technical concept I find its better to start with a high-level&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1294514012" LINK="https://link.springer.com/article/10.1023/A:1010933404324" MODIFIED="1557225479692" TEXT="Random Forests | SpringerLink">
<node CREATED="1557224068607" ID="ID_79016390" MODIFIED="1557224068607" TEXT="Random forests are a combination of tree predictors such that each tree depends on the values of a random vector sampled independently and with the same&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_130697376" LINK="https://victorzhou.com/blog/intro-to-random-forests/" MODIFIED="1557225479692" TEXT="Random Forests for Complete Beginners - victorzhou.com">
<node CREATED="1557224068607" ID="ID_81114341" MODIFIED="1557224068607" TEXT="Apr 10 2019  The definitive guide to Random Forests and Decision Trees." />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_417773122" LINK="https://www.datascience.com/resources/notebooks/random-forest-intro" MODIFIED="1557225479692" TEXT="Introduction to Random Forests">
<node CREATED="1557224068607" ID="ID_891547321" MODIFIED="1557224068607" TEXT="Dec 8 2017  Random forests are a popular ensemble method for building predictive models. This tutorial explains how to fit train and validate a random&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_842099539" LINK="https://www.youtube.com/watch?v=J4Wdy0Wc_xQ" MODIFIED="1557225479692" TEXT="StatQuest: Random Forests Part 1 - Building Using and Evaluating ">
<node CREATED="1557224068607" ID="ID_682345385" MODIFIED="1557224068607" TEXT="Feb 5 2018  NOTE: At 9:28 I say square when I meant to say square root. Oops! I would correct this minor error if it were easy to do but YouTube doesnt&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_894581814" LINK="https://spark.apache.org/docs/latest/mllib-ensembles.html" MODIFIED="1557225479692" TEXT="Ensembles - RDD-based API - Spark 2.4.2 Documentation">
<node CREATED="1557224068607" ID="ID_1189010311" MODIFIED="1557224068607" TEXT="Random forests are ensembles of decision trees. Random forests are one of the most successful machine learning models for classification and regression." />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_765800242" MODIFIED="1557225483441" TEXT="Ensemble methods#$D$#">
<node CREATED="1557224068608" FOLDED="true" ID="ID_999951715" LINK="https://en.wikipedia.org/wiki/Ensemble_learning" MODIFIED="1557225479708" TEXT="Ensemble learning - Wikipedia">
<node CREATED="1557224068608" ID="ID_1275689641" MODIFIED="1557224068608" TEXT="In statistics and machine learning ensemble methods use multiple learning algorithms to obtain better predictive performance than could be obtained from any&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_306753962" LINK="https://towardsdatascience.com/ensemble-methods-in-machine-learning-what-are-they-and-why-use-them-68ec3f9fef5f" MODIFIED="1557225479708" TEXT="Ensemble Methods in Machine Learning: What are They and Why ">
<node CREATED="1557224068608" ID="ID_1459089914" MODIFIED="1557224068608" TEXT="Aug 1 2017  Ensemble Methods what are they? Ensemble methods is a machine learning technique that combines several base models in order to&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_30887187" LINK="http://scikit-learn.org/stable/modules/ensemble.html" MODIFIED="1557225479708" TEXT="1.11. Ensemble methods &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068608" ID="ID_1837757601" MODIFIED="1557224068608" TEXT="The goal of ensemble methods is to combine the predictions of several base estimators built with a given learning algorithm in order to improve generalizability&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1063102278" LINK="https://blog.statsbot.co/ensemble-learning-d1dcd548e936" MODIFIED="1557225479708" TEXT="Ensemble Learning to Improve Machine Learning Results">
<node CREATED="1557224068608" ID="ID_619706812" MODIFIED="1557224068608" TEXT="Aug 22 2017  Ensemble learning helps improve machine learning results by combining several models. Ensemble methods allow the production of better&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_629952067" LINK="https://www.toptal.com/machine-learning/ensemble-methods-machine-learning" MODIFIED="1557225479708" TEXT="Ensemble Methods in Machine Learning | Toptal">
<node CREATED="1557224068608" ID="ID_604464241" MODIFIED="1557224068608" TEXT="Ensemble methods are techniques that create multiple models and then combine them to produce improved results. Ensemble methods usually produces more&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1569296988" LINK="http://web.engr.oregonstate.edu/~tgd/publications/mcs-ensembles.pdf" MODIFIED="1557225479708" TEXT="Ensemble Methods in Machine Learning">
<node CREATED="1557224068608" ID="ID_855531748" MODIFIED="1557224068608" TEXT="Abstract. Ensemble methods are learning algorithms that construct a set of classifiers and then classify new data points by taking a (weighted) vote of their&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1813374760" LINK="https://machinelearningmastery.com/ensemble-methods-for-deep-learning-neural-networks/" MODIFIED="1557225479708" TEXT="Ensemble Learning Methods for Deep Learning Neural Networks">
<node CREATED="1557224068608" ID="ID_1367761570" MODIFIED="1557224068608" TEXT="Dec 19 2018  Ensemble Methods to Reduce Variance and Improve Performance of Deep Learning Neural Networks Photo by University of San Franciscos&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1050270478" LINK="https://www3.nd.edu/~rjohns15/cse40647.sp14/www/content/lectures/31%20-%20Decision%20Tree%20Ensembles.pdf" MODIFIED="1557225479708" TEXT="Ensemble Methods">
<node CREATED="1557224068608" ID="ID_1106609525" MODIFIED="1557224068608" TEXT="Ensemble Methods. &#8226; An ensemble is a set of classifiers that learn a target function and their individual predictions are combined to classify new examples." />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1514885250" LINK="http://ciml.info/dl/v0_99/ciml-v0_99-ch13.pdf" MODIFIED="1557225479708" TEXT="13 | ENSEMBLE METHODS">
<node CREATED="1557224068608" ID="ID_1282085447" MODIFIED="1557224068608" TEXT="individuals especially when group members each come in with their own biases. The same is true in machine learning. Ensemble methods are learning models&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_393429935" LINK="https://www.datascience.com/blog/random-forests-decision-trees-ensemble-methods" MODIFIED="1557225479708" TEXT="Random Forests Decision Trees and Ensemble Methods Explained">
<node CREATED="1557224068608" ID="ID_1426526163" MODIFIED="1557224068608" TEXT="Dec 4 2018  The random forest first described by Breimen et al (2001) is an ensemble approach for building predictive models. The &#8220;forest&#8221; in this&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_268982315" MODIFIED="1563517391360" TEXT="AdaBoost">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1523033159" MODIFIED="1563517391360" TEXT="Gradient Tree Boosting">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068607" FOLDED="true" ID="ID_1472373422" MODIFIED="1557225483440" TEXT="Gradient Tree Boosting#$D$#">
<node CREATED="1557224068607" FOLDED="true" ID="ID_1923464127" LINK="https://en.wikipedia.org/wiki/Gradient_boosting" MODIFIED="1557225479692" TEXT="Gradient boosting - Wikipedia">
<node CREATED="1557224068607" ID="ID_1295200195" MODIFIED="1557224068607" TEXT="Gradient boosting is typically used with decision trees (especially CART trees) of a fixed size as base learners. For this&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1292391059" LINK="https://xgboost.readthedocs.io/en/latest/tutorials/model.html" MODIFIED="1557225479692" TEXT="Introduction to Boosted Trees &#8212; xgboost 0.83.dev0 documentation">
<node CREATED="1557224068607" ID="ID_1191603098" MODIFIED="1557224068607" TEXT="The gradient boosted trees has been around for a while and there are a lot of materials on the topic. This tutorial will explain boosted trees in a self-contained&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1198766274" LINK="https://machinelearningmastery.com/gentle-introduction-gradient-boosting-algorithm-machine-learning/" MODIFIED="1557225479692" TEXT="A Gentle Introduction to the Gradient Boosting Algorithm for Machine ">
<node CREATED="1557224068607" ID="ID_1223856890" MODIFIED="1557224068607" TEXT="Sep 9 2016  This framework was further developed by Friedman and called Gradient Boosting Machines. Later called just gradient boosting or gradient tree&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1909552198" LINK="https://medium.com/mlreview/gradient-boosting-from-scratch-1e317ae4587d" MODIFIED="1557225479692" TEXT="Gradient Boosting from scratch &#8211; ML Review &#8211; Medium">
<node CREATED="1557224068607" ID="ID_187912087" MODIFIED="1557224068607" TEXT="Dec 8 2017  Although tree-based models (considering decision tree as base models for our gradient boosting here) are not based on such assumptions&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1108572760" LINK="https://homes.cs.washington.edu/~tqchen/pdf/BoostedTree.pdf" MODIFIED="1557225479692" TEXT="Introduction to Boosted Trees">
<node CREATED="1557224068607" ID="ID_1881013114" MODIFIED="1557224068607" TEXT="Oct 22 2014  Outline. &#8226; Review of key concepts of supervised learning. &#8226; Regression Tree and Ensemble (What are we Learning). &#8226; Gradient Boosting (How&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_793171977" LINK="http://blog.kaggle.com/2017/01/23/a-kaggle-master-explains-gradient-boosting/" MODIFIED="1557225479692" TEXT="A Kaggle Master Explains Gradient Boosting | No Free Hunch">
<node CREATED="1557224068607" ID="ID_1536968124" MODIFIED="1557224068607" TEXT="Jan 23 2017  A particular implementation of gradient boosting XGBoost  Here in lies the drawback to using a single decision/regression tree &#8211; it fails to&#160;" />
</node>
<node CREATED="1557224068607" FOLDED="true" ID="ID_1830385268" LINK="https://towardsdatascience.com/understanding-gradient-boosting-machines-9be756fe76ab" MODIFIED="1557225479692" TEXT="Understanding Gradient Boosting Machines &#8211; Towards Data Science">
<node CREATED="1557224068608" ID="ID_1982376115" MODIFIED="1557224068608" TEXT="Nov 3 2018  In boosting each new tree is a fit on a modified version of the original data set. The gradient boosting algorithm (gbm) can be most easily&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_31238248" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.ensemble.GradientBoostingClassifier.html" MODIFIED="1557225479692" TEXT="3.2.4.3.5. sklearn.ensemble.GradientBoostingClassifier &#8212; scikit ">
<node CREATED="1557224068608" ID="ID_1051358788" MODIFIED="1557224068608" TEXT="In each stage n_classes_ regression trees are fit on the negative gradient of the binomial or multinomial deviance loss function. Binary classification is a special&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_365586483" LINK="http://www.statsoft.com/Textbook/Boosting-Trees-Regression-Classification" MODIFIED="1557225479692" TEXT="Introduction Boosting Trees for Regression and Classification">
<node CREATED="1557224068608" ID="ID_45959481" MODIFIED="1557224068608" TEXT="Boosting Trees for Regression and Classification Introductory Overview. The general computational approach of stochastic gradient boosting is also known by&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_945121328" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.ensemble.GradientBoostingRegressor.html" MODIFIED="1557225479692" TEXT="3.2.4.3.6. sklearn.ensemble.GradientBoostingRegressor &#8212; scikit ">
<node CREATED="1557224068608" ID="ID_1354851386" MODIFIED="1557224068608" TEXT="GradientBoostingRegressor (loss=ls learning_rate=0.1 n_estimators=100  In each stage a regression tree is fit on the negative gradient of the given loss&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_375887774" MODIFIED="1563517391360" TEXT="Voting Classifier">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068608" FOLDED="true" ID="ID_532094056" MODIFIED="1557225483441" TEXT="Voting Classifier#$D$#">
<node CREATED="1557224068608" FOLDED="true" ID="ID_1456377817" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.ensemble.VotingClassifier.html" MODIFIED="1557225479692" TEXT="sklearn.ensemble.VotingClassifier &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068608" ID="ID_1418404870" MODIFIED="1557224068608" TEXT="Parameters: estimators : list of (string estimator) tuples. Invoking the fit method on the VotingClassifier will fit clones of those original estimators that will be stored&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_754319798" LINK="http://rasbt.github.io/mlxtend/user_guide/classifier/EnsembleVoteClassifier/" MODIFIED="1557225479692" TEXT="EnsembleVoteClassifier - mlxtend">
<node CREATED="1557224068608" ID="ID_1917613622" MODIFIED="1557224068608" TEXT="Soft Voting/Majority Rule classifier for  an ensemble of well-calibrated classifiers." />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_524373980" LINK="http://scikit-learn.org/stable/modules/ensemble.html" MODIFIED="1557225479692" TEXT="1.11. Ensemble methods &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068608" ID="ID_1744549542" MODIFIED="1557224068608" TEXT="Weighted Average Probabilities (Soft Voting); 1.11.5.3.  means a diverse set of classifiers is created by introducing randomness in the classifier construction." />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_305478643" LINK="https://www.kaggle.com/den3b81/better-predictions-stacking-with-votingclassifier" MODIFIED="1557225479708" TEXT="Better predictions: stacking with VotingClassifier | Kaggle">
<node CREATED="1557224068608" ID="ID_52299668" MODIFIED="1557224068608" TEXT="Feb 23 2017  As you may well know in most Kaggle competitions the winners usually resort to stacking or meta-ensembling which is a technique involving&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1728679027" LINK="https://sebastianraschka.com/Articles/2014_ensemble_classifier.html" MODIFIED="1557225479708" TEXT="Implementing a Weighted Majority Rule Ensemble Classifier">
<node CREATED="1557224068608" ID="ID_768423764" MODIFIED="1557224068608" TEXT="classifier 1 - class 1; classifier 2  the majority rule voting will be applied to&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1540151470" LINK="https://ml.dask.org/examples/voting-classifier.html" MODIFIED="1557225479708" TEXT="Use Voting Classifiers &#8212; dask-ml 0.12.1 documentation">
<node CREATED="1557224068608" ID="ID_471703458" MODIFIED="1557224068608" TEXT="A Voting classifier model combines multiple different models (i.e.  What follows is an example of how one would deploy a voting classifier model in dask (using&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_672857320" LINK="https://stackoverflow.com/questions/48528933/how-does-voting-between-two-classifiers-work-in-sklearn" MODIFIED="1557225479708" TEXT="How does voting between two classifiers work in sklearn? - Stack ">
<node CREATED="1557224068608" ID="ID_1177256187" MODIFIED="1557224068608" TEXT="Jan 30 2018  Make sure that if you set voting=soft then the classifiers you provide can also calculate  To see the confidence of each classifier you can do:" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1793742209" LINK="https://www.oreilly.com/library/view/machine-learning-algorithms/9781789347999/e1a7f25d-f21b-4194-befd-771d708b25aa.xhtml" MODIFIED="1557225479708" TEXT="Voting classifier - Machine Learning Algorithms - Second Edition ">
<node CREATED="1557224068608" ID="ID_1210415007" MODIFIED="1557224068608" TEXT="Voting classifier A very interesting ensemble solution (which can be considered as part of the stacking subset) is offered by the VotingClassifier class which isnt&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_589502561" LINK="https://machinelearningmastery.com/ensemble-machine-learning-algorithms-python-scikit-learn/" MODIFIED="1557225479708" TEXT="Ensemble Machine Learning Algorithms in Python with scikit-learn">
<node CREATED="1557224068608" ID="ID_1040879095" MODIFIED="1557224068608" TEXT="Jun 3 2016  Voting. Building multiple models (typically of differing types) and simple .. A Voting Classifier can then be used to wrap your models and&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_821860061" LINK="https://www.programcreek.com/python/example/102435/sklearn.ensemble.VotingClassifier" MODIFIED="1557225479708" TEXT="sklearn.ensemble.VotingClassifier Python Example">
<node CREATED="1557224068608" ID="ID_1176571648" MODIFIED="1557224068608" TEXT="This page provides Python code examples for sklearn.ensemble.VotingClassifier." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1926968862" MODIFIED="1563517391360" TEXT="Ensemble methods">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1434499741" MODIFIED="1563517391360" TEXT="Bagging">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_496409952" MODIFIED="1563517391360" TEXT="Boosting">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_645132124" MODIFIED="1563517391360" TEXT="Random Forests">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1134223840" MODIFIED="1563517391360" TEXT="Blog">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_223995945" MODIFIED="1563517391360" TEXT="Analytics Vidya ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1315002497" MODIFIED="1563517391360" TEXT="Code ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1527896511" MODIFIED="1563517391360" TEXT=" Introduction to Meta Classifier:">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_946810075" MODIFIED="1563517391360" TEXT="Concept of Weak Learner">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068608" FOLDED="true" ID="ID_1506215767" MODIFIED="1557225483441" TEXT="Introduction to Meta Classifier:#$D$#">
<node CREATED="1557224068608" FOLDED="true" ID="ID_304549556" LINK="http://www.pymvpa.org/tutorial_meta_classifiers.html" MODIFIED="1557225479708" TEXT="Classifiers that do more &#8211; Meta Classifiers &#8212; PyMVPA 2.6.5.dev1 ">
<node CREATED="1557224068608" ID="ID_1484192625" MODIFIED="1557224068608" TEXT="Of course there is a solution to this problem &#8211; a meta-classifier. This is a classifier that . In this tutorial part we took a look at classifiers. We have seen that&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_834453325" LINK="https://medium.com/huggingface/from-zero-to-research-an-introduction-to-meta-learning-8e16e677f78a" MODIFIED="1557225479708" TEXT="From zero to research &#8212; An introduction to Meta-learning">
<node CREATED="1557224068608" ID="ID_1379663701" MODIFIED="1557224068608" TEXT="Apr 3 2018  Our introduction to meta-learning goes from zero to current research  and its recent developments as well as the Reptile algorithm of OpenAI." />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1816922276" LINK="http://www.cs.ubc.ca/labs/beta/Courses/CPSC532H-13/Slides/content-session-4-slides.pdf" MODIFIED="1557225479708" TEXT="Meta Learning">
<node CREATED="1557224068608" ID="ID_1150456924" MODIFIED="1557224068608" TEXT="Definition. Meta Learning affects the hypothesis space for the learning algorithm by either: Changing the hypothesis space of the learning algorithms&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1759086633" LINK="https://medium.com/walmartlabs/an-introduction-to-meta-learning-ced7072b80e7" MODIFIED="1557225479708" TEXT="An Introduction to Meta-Learning &#8211; WalmartLabs &#8211; Medium">
<node CREATED="1557224068608" ID="ID_1796048671" MODIFIED="1557224068608" TEXT="Mar 14 2019  At Walmart Labs we utilize meta-learning every day &#8212; whether its in our  our classifier f&#952; with parameter &#952; outputs a log probability of a data&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_279593376" LINK="https://ieeexplore.ieee.org/document/6916242/" MODIFIED="1557225479708" TEXT="Fuzzy-belief K-nearest neighbor classifier for uncertain data - IEEE ">
<node CREATED="1557224068608" ID="ID_433827956" MODIFIED="1557224068608" TEXT="The introduction of meta-classes in the classification procedure reduces the misclassification errors. The ignorant class is employed for outliers detections." />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1414986698" LINK="https://link.springer.com/content/pdf/10.1023/B:MACH.0000015881.36452.6e.pdf" MODIFIED="1557225479708" TEXT="Is Combining Classifiers with Stacking Better than Selecting the Best ">
<node CREATED="1557224068608" ID="ID_1507093863" MODIFIED="1557224068608" TEXT="Keywords: multi-response model trees stacking combining classifiers ensembles of classifiers meta-learning. 1. Introduction. An ensemble of classifiers is a&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_130278849" LINK="http://cgi.di.uoa.gr/~takis/atem03.pdf" MODIFIED="1557225479708" TEXT="Pdf here">
<node CREATED="1557224068608" ID="ID_1417457310" MODIFIED="1557224068608" TEXT="a meta-level classifier based on the output of base-level information  Wolpert [18] introduced an approach for constructing ensembles of classifiers known." />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_173163914" LINK="https://www.dataquest.io/blog/introduction-to-ensembles/" MODIFIED="1557225479708" TEXT="Introduction to Python Ensembles &#8211; Dataquest">
<node CREATED="1557224068608" ID="ID_1475050967" MODIFIED="1557224068608" TEXT="Jan 11 2018  Data is fed to a set of models and a meta learner combine model . For that reason an ensemble that averages classifier predictions is known&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1602897834" LINK="https://lilianweng.github.io/lil-log/2018/11/30/meta-learning.html" MODIFIED="1557225479708" TEXT="Meta-Learning: Learning to Learn Fast">
<node CREATED="1557224068608" ID="ID_1576244665" MODIFIED="1557224068608" TEXT="Nov 30 2018  Few-shot classification is an instantiation of meta-learning in the field . All the models introduced below learn embedding vectors of input data&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_362937990" LINK="https://www.isical.ac.in/~sankar/paper/SAHA-FI-2007.pdf" MODIFIED="1557225479708" TEXT="Rough set Based Ensemble Classifier for Web Page Classification 1 ">
<node CREATED="1557224068608" ID="ID_898849103" MODIFIED="1557224068608" TEXT="introduced a rough set based meta classifier to classify web pages. The proposed method  used on the decision table to construct a meta classifier. It has been&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_620234773" MODIFIED="1557225483441" TEXT="Concept of Weak Learner#$D$#">
<node CREATED="1557224068608" FOLDED="true" ID="ID_624935703" LINK="https://en.wikipedia.org/wiki/Boosting_(machine_learning)" MODIFIED="1557225479708" TEXT="Boosting (machine learning) - Wikipedia">
<node CREATED="1557224068608" ID="ID_1423934869" MODIFIED="1557224068608" TEXT="Boosting is a machine learning ensemble meta-algorithm for primarily reducing bias and also variance in supervised learning and a family of machine learning algorithms that convert weak learners to strong ones.  A weak learner is defined to be a classifier that is only slightly correlated with the true classification (it can&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_838464132" LINK="https://stats.stackexchange.com/questions/82049/what-is-meant-by-weak-learner" MODIFIED="1557225479708" TEXT="classification - What is meant by weak learner? - Cross Validated">
<node CREATED="1557224068608" ID="ID_119280415" MODIFIED="1557224068608" TEXT="Weak learner also suggests that many instances of the algorithm are . The idea is that you use a classifier that is well not that good but at&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_719175745" LINK="http://www.jennwv.com/courses/F11/lecture13.pdf" MODIFIED="1557225479708" TEXT="Machine Learning Theory Lecture 13: Weak vs. Strong Learning and ">
<node CREATED="1557224068608" ID="ID_863237388" MODIFIED="1557224068608" TEXT="Nov 7 2011  whether so-called &#8220;weak&#8221; learning implies &#8220;strong&#8221; learning (which is simply  A concept class C is strongly PAC learnable using a hypothesis." />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1576991678" LINK="https://www.quora.com/What-is-a-formal-definition-of-%E2%80%9Cweak-learner%E2%80%9D-and-an-intuitive-explanation-of-it" MODIFIED="1557225479708" TEXT="What is a formal definition of &#8220;weak learner&#8221; and an intuitive ">
<node CREATED="1557224068608" ID="ID_1393183672" MODIFIED="1557224068608" TEXT="Mar 8 2017  Assume that youre observing pairs where the values are iid observations from distribution and for some function . Assume youre also given&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1185767407" LINK="https://www.sciencedirect.com/topics/computer-science/weak-classifier" MODIFIED="1557225479708" TEXT="Weak Classifier - an overview | ScienceDirect Topics">
<node CREATED="1557224068608" ID="ID_808128030" MODIFIED="1557224068608" TEXT="Because the weak classifier is less powerful perhaps all training samples cannot be correctly classified. The basic idea of boosting is to assign large weight to&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1836332967" LINK="http://www.cs.tau.ac.il/~mansour/ml-course-10/scribe6.pdf" MODIFIED="1557225479708" TEXT="Lecture 6: November 21 2010 6.1 Weak and Strong Learners">
<node CREATED="1557224068608" ID="ID_1003598969" MODIFIED="1557224068608" TEXT="Nov 21 2010  Is it possible to drive those weak algorithms to be strong learners ? . concept class has a weak learning algorithm then there is a PAC&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1656914656" LINK="https://stackoverflow.com/questions/20435717/what-is-a-weak-learner" MODIFIED="1557225479708" TEXT="What is a weak learner? - Stack Overflow">
<node CREATED="1557224068608" ID="ID_32744153" MODIFIED="1557224068608" TEXT="Dec 7 2013  So my question is what are a few choices for a simple easy to process weak learner? Or do I understand the concept incorrectly and is a&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_524174236" LINK="http://rob.schapire.net/papers/strengthofweak.pdf" MODIFIED="1557225479708" TEXT="The strength of weak learnability">
<node CREATED="1557224068608" ID="ID_1400767813" MODIFIED="1557224068608" TEXT="given access to a Source of examples of the unknown concept the learner with  The notion of weak learnability was introduced by Kearns and Valiant (1988;&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1868797135" LINK="https://jeremykun.com/2015/05/18/boosting-census/" MODIFIED="1557225479708" TEXT="Weak Learning Boosting and the AdaBoost algorithm &#8211; Math ">
<node CREATED="1557224068608" ID="ID_83102063" MODIFIED="1557224068608" TEXT="May 18 2015  Well review the model of PAC-learning define what it means to be a weak learner &#8220;organically&#8221; come up with the AdaBoost algorithm from&#160;" />
</node>
<node CREATED="1557224068608" FOLDED="true" ID="ID_1282552390" LINK="https://ieeexplore.ieee.org/document/1410303/" MODIFIED="1557225479708" TEXT="Text classification by boosting weak learners based on terms and ">
<node CREATED="1557224068608" ID="ID_755975247" MODIFIED="1557224068608" TEXT="Text classification by boosting weak learners based on terms and concepts. Abstract: Document representations for text classification are typically based on the&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1487735355" MODIFIED="1563517391360" TEXT="Concept of Eager Learner">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068608" FOLDED="true" ID="ID_1081849711" MODIFIED="1557225483441" TEXT="Concept of Eager Learner#$D$#">
<node CREATED="1557224068608" FOLDED="true" ID="ID_1878462121" LINK="https://en.wikipedia.org/wiki/Eager_learning" MODIFIED="1557225479708" TEXT="Eager learning - Wikipedia">
<node CREATED="1557224068609" ID="ID_651677808" MODIFIED="1557224068609" TEXT="In artificial intelligence eager learning is a learning method in which the system tries to construct a general input-independent target function during training of&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1858862273" LINK="http://www.learnersdictionary.com/definition/eager" MODIFIED="1557225479708" TEXT="Eager - Definition for English-Language Learners from Merriam ">
<node CREATED="1557224068609" ID="ID_710213226" MODIFIED="1557224068609" TEXT="Definition of eager written for English Language Learners from the Merriam-Webster Learners Dictionary with audio pronunciations usage examples and&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_678797515" LINK="https://dictionary.cambridge.org/dictionary/learner-english/eager" MODIFIED="1557225479708" TEXT="eager | meaning in the Cambridge Learners Dictionary">
<node CREATED="1557224068609" ID="ID_1596241796" MODIFIED="1557224068609" TEXT="eager definition: wanting to do or have something very much: . Learn more." />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1337457858" LINK="https://towardsdatascience.com/machine-learning-classifiers-a5cc4e1b0623" MODIFIED="1557225479708" TEXT="Machine Learning Classifiers &#8211; Towards Data Science">
<node CREATED="1557224068609" ID="ID_1937732101" MODIFIED="1557224068609" TEXT="Jun 11 2018  Eager learners construct a classification model based on the given training data  and they are identified using the information gain concept." />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_103569805" LINK="https://www.oxfordlearnersdictionaries.com/us/definition/english/eager" MODIFIED="1557225479708" TEXT="eager adjective - Definition pictures pronunciation and usage notes ">
<node CREATED="1557224068609" ID="ID_17848562" MODIFIED="1557224068609" TEXT="Definition of eager adjective in Oxford Advanced Learners Dictionary. Meaning pronunciation picture example sentences grammar usage notes synonyms&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_361811057" LINK="https://stackoverflow.com/questions/5749867/is-a-neural-network-a-lazy-or-eager-learning-method" MODIFIED="1557225479708" TEXT="Is a neural network a lazy or eager learning method? - Stack Overflow">
<node CREATED="1557224068609" ID="ID_447558236" MODIFIED="1557224068609" TEXT="Looking at the definition of the terms lazy and eager learning and knowing how a neural network works I believe that it is clear that it is eager. A trained network&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_500289811" LINK="https://www.highlights.com/parents/articles/want-to-raise-eager-learner" MODIFIED="1557225479708" TEXT="Want to Raise an Eager Learner? | Highlights">
<node CREATED="1557224068609" ID="ID_54750134" MODIFIED="1557224068609" TEXT="Jan 10 2018  Promote the Real Skills Preschoolers Need for Learning.  Make the connection between the concept of &#8220;six&#8221; the sound of the word &#8220;six&#8221; and&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_983083868" LINK="https://www.quora.com/What-is-the-difference-between-eager-learning-and-lazy-learning" MODIFIED="1557225479708" TEXT="What is the difference between eager learning and lazy learning ">
<node CREATED="1557224068609" ID="ID_654463264" MODIFIED="1557224068609" TEXT="Eager learning is when you open your mind to receive new information and new  This translates to: Think not that all wisdom is in your school meaning that&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1674541422" LINK="https://www.talentlms.com/ebook/learner-engagement/definition" MODIFIED="1557225479708" TEXT="What is Learner Engagement? A Modern Definition for 2018 ">
<node CREATED="1557224068609" ID="ID_1212763363" MODIFIED="1557224068609" TEXT="What does an engaged learner look like? An engaged learner looks: &#9675; Active in their learning &#9675; Eager to participate &#9675; Willing to expend effort &#9675; Motivated" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_412915985" LINK="https://www.merriam-webster.com/dictionary/eager%20beaver" MODIFIED="1557225479708" TEXT="Eager Beaver | Definition of Eager Beaver by Merriam-Webster">
<node CREATED="1557224068609" ID="ID_1685804052" MODIFIED="1557224068609" TEXT="Eager beaver definition is - a person who is extremely zealous about  See the full definition for eager beaver in the English Language Learners Dictionary." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_299282937" MODIFIED="1563517391360" TEXT="Clustering">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1366986485" MODIFIED="1563517391360" TEXT="Clustering Fundamentals">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1314403634" MODIFIED="1563517391360" TEXT="Basics">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_735363804" MODIFIED="1563517391360" TEXT="Kmeans">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1532942946" MODIFIED="1563517391360" TEXT="Finding Optimal number of Clusters">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068609" FOLDED="true" ID="ID_1771234191" MODIFIED="1557225483442" TEXT="Finding Optimal number of Clusters Kmeans#$D$#">
<node CREATED="1557224068609" FOLDED="true" ID="ID_41004585" LINK="https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/" MODIFIED="1557225479708" TEXT="Determining The Optimal Number Of Clusters: 3 Must Know ">
<node CREATED="1557224068609" ID="ID_103857916" MODIFIED="1557224068609" TEXT="Determining the optimal number of clusters in a data set is a fundamental issue in partitioning clustering such as k-means clustering which requires the user to&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1537021761" LINK="https://blog.cambridgespark.com/how-to-determine-the-optimal-number-of-clusters-for-k-means-clustering-14f27070048f" MODIFIED="1557225479708" TEXT="Tutorial: How to determine the optimal number of clusters for k ">
<node CREATED="1557224068609" ID="ID_1251188129" MODIFIED="1557224068609" TEXT="May 27 2018  Introduction K-means is a type of unsupervised learning and one of the popular methods of clustering unlabelled data into k clusters. One of the&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_594086774" LINK="https://datascienceplus.com/finding-optimal-number-of-clusters/" MODIFIED="1557225479723" TEXT="Finding Optimal Number of Clusters | DataScience+">
<node CREATED="1557224068609" ID="ID_721072395" MODIFIED="1557224068609" TEXT="Feb 9 2017  In this post we are going to have a look at one of the problems while applying clustering algorithms such as k-means and expectation&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1262369206" LINK="https://en.wikipedia.org/wiki/Determining_the_number_of_clusters_in_a_data_set" MODIFIED="1557225479723" TEXT="Determining the number of clusters in a data set - Wikipedia">
<node CREATED="1557224068609" ID="ID_833744472" MODIFIED="1557224068609" TEXT="Determining the number of clusters in a data set a quantity often labelled k as in the k-means  Intuitively then the optimal choice of k will strike a balance between maximum compression of the data using a single cluster and maximum&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_777106988" LINK="http://scikit-learn.org/stable/auto_examples/cluster/plot_kmeans_silhouette_analysis.html" MODIFIED="1557225479723" TEXT="Selecting the number of clusters with silhouette analysis on KMeans ">
<node CREATED="1557224068609" ID="ID_319246451" MODIFIED="1557224068609" TEXT="In this example the silhouette analysis is used to choose an optimal value for n_clusters . The silhouette plot shows that the n_clusters value of 3 5 and 6 are a&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1327039931" LINK="https://stackoverflow.com/questions/15376075/cluster-analysis-in-r-determine-the-optimal-number-of-clusters" MODIFIED="1557225479723" TEXT="Cluster analysis in R: determine the optimal number of clusters ">
<node CREATED="1557224068609" ID="ID_48989930" MODIFIED="1557224068609" TEXT="If your question is how can I determine how many clusters are appropriate for a kmeans analysis of my data?  then here are some options. The wikipedia article&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_72346785" LINK="https://www.mathworks.com/matlabcentral/answers/152409-finding-optimal-number-of-clusters-for-kmeans" MODIFIED="1557225479723" TEXT="Finding Optimal Number Of Clusters for Kmeans - MATLAB Answers ">
<node CREATED="1557224068609" ID="ID_1158040850" MODIFIED="1557224068609" TEXT="I want to find the number of clusters for my data for which the correlation is above .9. I know you can use a sum of squared error (SSE) scree plot but I am not&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_443472752" LINK="https://towardsdatascience.com/10-tips-for-choosing-the-optimal-number-of-clusters-277e93d72d92" MODIFIED="1557225479723" TEXT="10 Tips for Choosing the Optimal Number of Clusters">
<node CREATED="1557224068609" ID="ID_1904582753" MODIFIED="1557224068609" TEXT="Jan 27 2019  Clustering is one of the most common unsupervised machine learning  and methods for identifying the optimal number of clusters so Ill just&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1240620238" LINK="https://blog.exploratory.io/k-means-clustering-deciding-how-many-clusters-to-build-d33fd9c68088" MODIFIED="1557225479723" TEXT="K-Means Clustering &#8212; Deciding How Many Clusters to Build">
<node CREATED="1557224068609" ID="ID_1630425813" MODIFIED="1557224068609" TEXT="Nov 1 2018  This is a follow-up post for Visualizing K-Means Clustering Results to Understand  Finding How Many Clusters to Create with Elbow Curve." />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1918263304" LINK="https://www.youtube.com/watch?v=ePfX6a7rsis" MODIFIED="1557225479723" TEXT="KMeans Clustering Part 1 - Determining The Optimal Number Of ">
<node CREATED="1557224068609" ID="ID_1091920659" MODIFIED="1557224068609" TEXT="Aug 18 2018  In this video Im going to walk you through how to determine the optimal number of clusters in a data set for a KMeans cluster analysis in R with&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1081340850" MODIFIED="1563517391360" TEXT="DBSCAN">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_928132396" MODIFIED="1563517391360" TEXT="Spectral Clustering">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068609" FOLDED="true" ID="ID_1041956216" MODIFIED="1557225483442" TEXT="Spectral Clustering#$D$#">
<node CREATED="1557224068609" FOLDED="true" ID="ID_375893770" LINK="https://en.wikipedia.org/wiki/Spectral_clustering" MODIFIED="1557225479723" TEXT="Spectral clustering - Wikipedia">
<node CREATED="1557224068609" ID="ID_1143408374" MODIFIED="1557224068609" TEXT="In multivariate statistics and the clustering of data spectral clustering techniques make use of the spectrum (eigenvalues) of the similarity matrix of the data to&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1869976812" LINK="https://towardsdatascience.com/spectral-clustering-82d3cff3d3b7" MODIFIED="1557225479723" TEXT="Spectral clustering &#8211; Towards Data Science">
<node CREATED="1557224068609" ID="ID_1456084530" MODIFIED="1557224068609" TEXT="Feb 4 2019  Clustering is a widely used unsupervised learning method. The grouping is such that points in a cluster are similar to each other and less&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1143811769" LINK="https://www.cs.cmu.edu/~aarti/Class/10701/readings/Luxburg06_TR.pdf" MODIFIED="1557225479723" TEXT="A Tutorial on Spectral Clustering">
<node CREATED="1557224068609" ID="ID_1217939459" MODIFIED="1557224068609" TEXT="Aug 1 2006  Abstract. In recent years spectral clustering has become one of the most popular modern  Nevertheless on the first glance spectral clustering." />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1629946833" LINK="https://towardsdatascience.com/spectral-clustering-for-beginners-d08b7d25b4d8" MODIFIED="1557225479723" TEXT="Spectral Clustering for beginners &#8211; Towards Data Science">
<node CREATED="1557224068609" ID="ID_581526475" MODIFIED="1557224068609" TEXT="May 7 2018  Spectral clustering has become increasingly popular due to its simple implementation and promising performance in many graph-based&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_261572791" LINK="https://ai.stanford.edu/~ang/papers/nips01-spectral.pdf" MODIFIED="1557225479723" TEXT="On Spectral Clustering: Analysis and an algorithm Andrew Y. Ng CS ">
<node CREATED="1557224068609" ID="ID_663264157" MODIFIED="1557224068609" TEXT="Abstract. Despite many empirical successes of spectral clustering methods&#8212; algorithms that cluster points using eigenvectors of matrices de- rived from the&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_776359070" LINK="http://www.cvl.isy.liu.se:82/education/graduate/spectral-clustering/SC_course_part1.pdf" MODIFIED="1557225479723" TEXT="Introduction to spectral clustering">
<node CREATED="1557224068609" ID="ID_1499956154" MODIFIED="1557224068609" TEXT="Basic introduction into the core ideas of spectral clustering. &#8226; Sufficient to get a basic understanding of how the method works. &#8226; Application mainly to computer&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1932662031" LINK="https://www.youtube.com/watch?v=uxsDKhZHDcc" MODIFIED="1557225479723" TEXT="Lecture 34 &#8212; Spectral Clustering Three Steps (Advanced) | Stanford ">
<node CREATED="1557224068609" ID="ID_1111627646" MODIFIED="1557224068609" TEXT="Apr 12 2016  Copyright Disclaimer Under Section 107 of the Copyright Act 1976 allowance is made for FAIR USE for purposes such as criticism comment&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_54064306" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.cluster.SpectralClustering.html" MODIFIED="1557225479723" TEXT="sklearn.cluster.SpectralClustering &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068609" ID="ID_845962247" MODIFIED="1557224068609" TEXT="In practice Spectral Clustering is very useful when the structure of the individual clusters is highly non-convex or more generally when a measure of the center&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1109745038" LINK="http://people.csail.mit.edu/dsontag/courses/ml13/slides/lecture16.pdf" MODIFIED="1557225479723" TEXT="Spectral Clustering Lecture 16">
<node CREATED="1557224068609" ID="ID_644116516" MODIFIED="1557224068609" TEXT="Spectral Clustering. Lecture 16. David Sontag. New York University. Slides adapted from James Hays Alan Fern and Tommi Jaakkola&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_461689390" LINK="https://www.youtube.com/watch?v=P-LEH-AFovE" MODIFIED="1557225479723" TEXT="Unit 6 7b Spectral Clustering Algorithm - YouTube">
<node CREATED="1557224068609" ID="ID_622599448" MODIFIED="1557224068609" TEXT="Oct 22 2011  Unit 6 7b Spectral Clustering Algorithm.  Ali Ghodsi Lec 6: Spectral Clustering Laplacian Eigenmap MVU - Duration: 1:17:28. Data Science&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1479096788" MODIFIED="1563517391360" TEXT="Evaluation Methods based on Ground Truth">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_444935184" MODIFIED="1563517391360" TEXT="Homogeneity">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068609" FOLDED="true" ID="ID_534326687" MODIFIED="1557225483443" TEXT="Evaluation Methods based on Ground Truth#$D$#">
<node CREATED="1557224068609" FOLDED="true" ID="ID_666898635" LINK="https://ieeexplore.ieee.org/document/6413740" MODIFIED="1557225479723" TEXT="Defining and Evaluating Network Communities Based on Ground ">
<node CREATED="1557224068609" ID="ID_292148415" MODIFIED="1557224068609" TEXT="Defining and Evaluating Network Communities Based on Ground-Truth  detection method that easily scales to networks with more than hundred million nodes." />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1923844850" LINK="https://subscription.packtpub.com/book/big_data_and_business_intelligence/9781785889622/9/ch09lvl1sec64/evaluation-methods-based-on-the-ground-truth" MODIFIED="1557225479723" TEXT="Evaluation methods based on the ground truth - Machine Learning ">
<node CREATED="1557224068609" ID="ID_373109508" MODIFIED="1557224068609" TEXT="Evaluation methods based on the ground truthIn this section we present some evaluation methods that require the knowledge of " />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1059480770" LINK="https://cs.stanford.edu/~jure/pubs/comscore-icdm12.pdf" MODIFIED="1557225479723" TEXT="Defining and Evaluating Network Communities based on Ground-truth">
<node CREATED="1557224068609" ID="ID_1365985919" MODIFIED="1557224068609" TEXT="of network communities correspond to ground-truth communi- ties. We choose 13  evaluation of community detection methods based on their performance to&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_143821576" LINK="https://www.ncbi.nlm.nih.gov/pubmed/21859033" MODIFIED="1557225479723" TEXT="Reference-free ground truth metric for metal artifact evaluation in CT ">
<node CREATED="1557224068609" ID="ID_548465430" MODIFIED="1557224068609" TEXT="Reference-free ground truth metric for metal artifact evaluation in CT images.  METHODS: The proposed metric is based on an inherent ground truth for metal&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1476478198" LINK="https://www.frontiersin.org/articles/10.3389/fnins.2016.00176" MODIFIED="1557225479723" TEXT="Evaluation of Event-Based Algorithms for Optical Flow with Ground ">
<node CREATED="1557224068609" ID="ID_232256972" MODIFIED="1557224068609" TEXT="In frame-based methods this property is typically  The consequence is that the ground truth from the IMU is not&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_881550587" LINK="http://proceedings.mlr.press/v84/viinikka18a/viinikka18a.pdf" MODIFIED="1557225479723" TEXT="Intersection-Validation: A Method for Evaluating Structure Learning ">
<node CREATED="1557224068609" ID="ID_1841357282" MODIFIED="1557224068609" TEXT="Structure Learning without Ground Truth  model the so-called ground truth then evaluating the  formance of the method in various scenarios based on." />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_929486910" LINK="https://www.biorxiv.org/content/10.1101/395780v1.full" MODIFIED="1557225479723" TEXT="Performance evaluation of inverse methods for identification and ">
<node CREATED="1557224068609" ID="ID_1506832090" MODIFIED="1557224068609" TEXT="Aug 20 2018  Most of these techniques are based on fitting single/ multiple dipolar cortical . to test a method provides mechanism for ground truth validation." />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1813353903" LINK="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2702211/" MODIFIED="1557225479723" TEXT="On Evaluating Brain Tissue Classifiers without a Ground Truth">
<node CREATED="1557224068609" ID="ID_1504035409" MODIFIED="1557224068609" TEXT="We apply these different evaluation methodologies to a set eleven different  We then validate our evaluation pipeline by building a ground truth based on&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_711506975" LINK="https://www.embedded-vision.com/sites/default/files/apress/computervisionmetrics/chapter7/9781430259299_Ch07.pdf" MODIFIED="1557225479723" TEXT="Ground Truth Data Content Metrics and Analysis">
<node CREATED="1557224068609" ID="ID_1276603596" MODIFIED="1557224068609" TEXT="propose a method and corresponding ground truth dataset for measuring  either by a human or automatically by image analysis depending on the . case study to generate both the ground truth dataset and the metric basis for evaluating." />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1269537963" LINK="https://www.ncbi.nlm.nih.gov/pubmed/19268708" MODIFIED="1557225479723" TEXT="On the construction of a ground truth framework for evaluating voxel ">
<node CREATED="1557224068609" ID="ID_1668475562" MODIFIED="1557224068609" TEXT="Mar 5 2009  On the construction of a ground truth framework for evaluating voxel-based diffusion tensor MRI analysis methods. Van Hecke W(1) Sijbers J&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_65526068" MODIFIED="1557225483443" TEXT="Clustering Evaluation Methods Homogeneity#$D$#">
<node CREATED="1557224068609" FOLDED="true" ID="ID_332097344" LINK="http://scikit-learn.org/stable/modules/clustering.html" MODIFIED="1557225479723" TEXT="2.3. Clustering &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068609" ID="ID_1239220905" MODIFIED="1557224068609" TEXT="Gaussian mixture models useful for clustering are described in another chapter of the  Evaluating the performance of a clustering algorithm is not as trivial as .. Homogeneity completeness and V-measure can be computed at once using&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1182173193" LINK="https://ieeexplore.ieee.org/document/886566/" MODIFIED="1557225479723" TEXT="On evaluation of clustering using homogeneity analysis - IEEE ">
<node CREATED="1557224068610" ID="ID_1077865082" MODIFIED="1557224068610" TEXT="Abstract: Proposes a new technique to evaluate the results of fuzzy clustering. Fuzzy clustering is a method to obtain natural groups from given observations by&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1076868300" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.metrics.homogeneity_score.html" MODIFIED="1557225479723" TEXT="sklearn.metrics.homogeneity_score &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068610" ID="ID_986681621" MODIFIED="1557224068610" TEXT="Homogeneity metric of a cluster labeling given a ground truth. A clustering result  V-Measure: A conditional entropy-based external cluster evaluation measure&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_537228617" LINK="https://towardsdatascience.com/k-means-clustering-algorithm-applications-evaluation-methods-and-drawbacks-aa03e644b48a" MODIFIED="1557225479723" TEXT="K-means Clustering: Algorithm Applications Evaluation Methods ">
<node CREATED="1557224068610" ID="ID_920294471" MODIFIED="1557224068610" TEXT="Sep 17 2018  In other words we try to find homogeneous subgroups within the data such that data points in each cluster are as similar as possible according&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1025886130" LINK="https://www.aclweb.org/anthology/D07-1043" MODIFIED="1557225479723" TEXT="A Conditional Entropy-Based External Cluster Evaluation Measure">
<node CREATED="1557224068610" ID="ID_23357789" MODIFIED="1557224068610" TEXT="Proceedings of the 2007 Joint Conference on Empirical Methods in Natural Language Processing and .. to evaluate the homogeneity of a clustering solution." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_422132807" LINK="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1590054/" MODIFIED="1557225479723" TEXT="Methods for evaluating clustering algorithms for gene expression ">
<node CREATED="1557224068610" ID="ID_502032687" MODIFIED="1557224068610" TEXT="Methods for evaluating clustering algorithms for gene expression data using a reference set of  The first measure is a biological homogeneity index (BHI)." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1953179377" LINK="http://nlp.uned.es/docs/amigo2007a.pdf" MODIFIED="1557225479723" TEXT="A comparison of Extrinsic Clustering Evaluation Metrics based on ">
<node CREATED="1557224068610" ID="ID_1638348124" MODIFIED="1557224068610" TEXT="May 11 2009  following methodology: each formal restriction consists of a pattern (D1D2) . Figure 5: Example of test to validate the Cluster Homogeneity&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_462345930" LINK="https://annals-csis.org/Volume_9/drp/371.html" MODIFIED="1557225479723" TEXT="Clustering Validity Indices Evaluation with Regard to Semantic ">
<node CREATED="1557224068610" ID="ID_604110842" MODIFIED="1557224068610" TEXT="Clustering Validity Indices Evaluation with Regard to Semantic Homogeneity  Clustering validity indices are a methods for examining and assessing quality of&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1721914956" LINK="https://www.researchgate.net/post/Evaluation_methods_for_a_clustering_techniques2" MODIFIED="1557225479723" TEXT="Evaluation methods for a clustering techniques ?">
<node CREATED="1557224068610" ID="ID_785644593" MODIFIED="1557224068610" TEXT="Jan 1 2017  If you want to evaluate the clustering techniques you should confirm . Entropy Homogeneity Completeness and V-measure are my favorite." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1483030985" LINK="https://link.springer.com/chapter/10.1007/978-3-642-22185-9_31" MODIFIED="1557225479723" TEXT="User Centric Homogeneity-Based Clustering Approach for ">
<node CREATED="1557224068610" ID="ID_1504910892" MODIFIED="1557224068610" TEXT="We evaluate the effectiveness of our proposal by modifying two most widely used clustering methods K-means and hierarchical according to the homogeneity&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_849841593" MODIFIED="1557225483443" TEXT="Clustering Evaluation Methods Completeness#$D$#">
<node CREATED="1557224068610" FOLDED="true" ID="ID_1913853326" LINK="http://scikit-learn.org/stable/modules/clustering.html" MODIFIED="1557225479723" TEXT="2.3. Clustering &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068610" ID="ID_1042443133" MODIFIED="1557224068610" TEXT="Gaussian mixture models useful for clustering are described in another chapter of the .. Connectivity constraints and single complete or average linkage can enhance . Evaluating the performance of a clustering algorithm is not as trivial as&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_802842333" LINK="https://en.wikipedia.org/wiki/Cluster_analysis" MODIFIED="1557225479723" TEXT="Cluster analysis - Wikipedia">
<node CREATED="1557224068610" ID="ID_1542060695" MODIFIED="1557224068610" TEXT="Cluster analysis or clustering is the task of grouping a set of objects in such a way that objects  Relaxations of the complete connectivity requirement (a fraction of the edges can be missing) are known as .. One drawback of using internal criteria in cluster evaluation is that high scores on an internal measure do not&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1940557071" LINK="http://www.lrec-conf.org/proceedings/lrec2014/pdf/829_Paper.pdf" MODIFIED="1557225479723" TEXT="An Evaluation Method for Cluster Analyses of Ambiguous Data">
<node CREATED="1557224068610" ID="ID_557796533" MODIFIED="1557224068610" TEXT="Fuzzy V-Measure &#8211; An Evaluation Method for  Keywords: clustering evaluation ambiguous data. 1. . This represents a maximally complete clustering in that." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_273532793" LINK="https://www.researchgate.net/post/Evaluation_methods_for_a_clustering_techniques2" MODIFIED="1557225479723" TEXT="Evaluation methods for a clustering techniques ?">
<node CREATED="1557224068610" ID="ID_1023883545" MODIFIED="1557224068610" TEXT="Jan 1 2017  If you want to evaluate the clustering techniques you should confirm . Entropy Homogeneity Completeness and V-measure are my favorite." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1229237276" LINK="https://www.aclweb.org/anthology/D07-1043" MODIFIED="1557225479723" TEXT="A Conditional Entropy-Based External Cluster Evaluation Measure">
<node CREATED="1557224068610" ID="ID_1821153688" MODIFIED="1557224068610" TEXT="cluster kj. To discuss cluster evaluation measures we intro- duce two criteria for a clustering solution: homo- geneity and completeness. A clustering result sat-." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_920138019" LINK="https://bmcbioinformatics.biomedcentral.com/articles/10.1186/s12859-019-2752-2" MODIFIED="1557225479723" TEXT="GO functional similarity clustering depends on similarity measure ">
<node CREATED="1557224068610" ID="ID_1641084705" MODIFIED="1557224068610" TEXT="Mar 27 2019  Finally we show that for semantic similarity-based clustering the  on similarity measure clustering method and annotation completeness." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_914030432" LINK="http://nlp.uned.es/docs/amigo2007a.pdf" MODIFIED="1557225479723" TEXT="A comparison of Extrinsic Clustering Evaluation Metrics based on ">
<node CREATED="1557224068610" ID="ID_1210777291" MODIFIED="1557224068610" TEXT="May 11 2009  following methodology: each formal restriction consists of a pattern (D1D2) . Figure 6: Example of test to validate the Cluster Completeness&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_844259300" LINK="https://webis.de/research/aitools/javadoc/de/aitools/dm/clustering/validation/external/Completeness.html" MODIFIED="1557225479723" TEXT="Completeness">
<node CREATED="1557224068610" ID="ID_1456247747" MODIFIED="1557224068610" TEXT="V-Measure: A conditional entropy-based external cluster evaluation measure. Version: $Id:  Methods inherited from class de.aitools.dm.clustering.validation." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_890836274" LINK="https://stats.stackexchange.com/questions/95782/what-are-the-most-common-metrics-for-comparing-two-clustering-algorithms-especi" MODIFIED="1557225479723" TEXT="model evaluation - What are the most common metrics for ">
<node CREATED="1557224068610" ID="ID_1570057542" MODIFIED="1557224068610" TEXT="Here are two standard approaches (there may be more). The first  This is still not straightforward -- a clustering can be consistent with a a gold&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1215892150" LINK="https://stackoverflow.com/questions/38980575/is-there-a-function-in-matlab-to-evaluate-homogeneity-and-completeness-of-a-clus" MODIFIED="1557225479723" TEXT="Is there a function in matlab to evaluate homogeneity and ">
<node CREATED="1557224068610" ID="ID_1669728725" MODIFIED="1557224068610" TEXT="Aug 16 2016  Yes. Almost every external cluster evaluation method is based on these concepts. Theynare maybe not exactly what you described - because&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_390083744" MODIFIED="1563517391360" TEXT="Completeness">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1168621958" MODIFIED="1563517391360" TEXT="Adjusted Rand Index">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068610" FOLDED="true" ID="ID_461340816" MODIFIED="1557225483443" TEXT="Clustering Evaluation Methods Adjusted Rand Index#$D$#">
<node CREATED="1557224068610" FOLDED="true" ID="ID_919870174" LINK="https://en.wikipedia.org/wiki/Rand_index" MODIFIED="1557225479723" TEXT="Rand index - Wikipedia">
<node CREATED="1557224068610" ID="ID_1493932849" MODIFIED="1557224068610" TEXT="The Rand index or Rand measure in statistics and in particular in data clustering is a measure of the similarity between two data clusterings. A form of the Rand index may be defined that is adjusted for the chance .. Variations of the adjusted Rand Index account for different models of random clusterings. Though the Rand&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_4039017" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.metrics.adjusted_rand_score.html" MODIFIED="1557225479723" TEXT="sklearn.metrics.adjusted_rand_score &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068610" ID="ID_1352592510" MODIFIED="1557224068610" TEXT="The adjusted Rand index is thus ensured to have a value close to 0.0 for random labeling independently of the  Cluster labels to evaluate  from sklearn.metrics.cluster import adjusted_rand_score  adjusted_rand_score([0 0 1 1] [0 0&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_32455108" LINK="https://link.springer.com/chapter/10.1007/978-3-642-04277-5_18" MODIFIED="1557225479723" TEXT="On the Use of the Adjusted Rand Index as a Metric for Evaluating ">
<node CREATED="1557224068610" ID="ID_1344007973" MODIFIED="1557224068610" TEXT="The Adjusted Rand Index (ARI) is frequently used in cluster validation since it is a  Rand W.M.: Objective criteria for the evaluation of clustering methods." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_469627835" LINK="http://scikit-learn.org/stable/modules/clustering.html" MODIFIED="1557225479723" TEXT="2.3. Clustering &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068610" ID="ID_1946857306" MODIFIED="1557224068610" TEXT="Gaussian mixture models useful for clustering are described in another chapter of the  Evaluating the performance of a clustering algorithm is not as trivial as  the adjusted Rand index is a function that measures the similarity of the two&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_310313674" LINK="http://faculty.washington.edu/kayee/pca/supp.pdf" MODIFIED="1557225479723" TEXT="Details of the Adjusted Rand index and Clustering algorithms ">
<node CREATED="1557224068610" ID="ID_1335663665" MODIFIED="1557224068610" TEXT="May 3 2001  In order to compare clustering results against external criteria  The adjusted Rand index proposed by [Hubert and Arabie 1985] .. [Rand 1971] Rand W. M. (1971) Objective criteria for the evaluation of clustering methods." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_875622190" LINK="https://www.researchgate.net/publication/216543682_ARImp_A_Generalized_Adjusted_Rand_Index_for_Cluster_Ensembles" MODIFIED="1557225479723" TEXT="(PDF) ARImp: A Generalized Adjusted Rand Index for Cluster ">
<node CREATED="1557224068610" ID="ID_1244421553" MODIFIED="1557224068610" TEXT="Adjusted Rand Index (ARI) is one of the most popular measure to evaluate the consistency between two partitions  the less effective cluster ensemble methods." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1107018985" LINK="https://ieeexplore.ieee.org/document/6889551/" MODIFIED="1557225479723" TEXT="AORS: Affinity-based outlier ranking score - IEEE Conference ">
<node CREATED="1557224068610" ID="ID_523160676" MODIFIED="1557224068610" TEXT="Outlier ranking methods can provide a quantitative measure to evaluate the outlierness of data instances in data clustering and attract great interest in p.  Consistent with the improvement of Adjusted Rand Index (ARI) over RAND we find that&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1306342599" LINK="http://www.ims.uni-stuttgart.de/institut/mitarbeiter/schulte/theses/phd/algorithm.pdf" MODIFIED="1557225479723" TEXT="Chapter 4 Clustering Algorithms and Evaluations">
<node CREATED="1557224068610" ID="ID_625679120" MODIFIED="1557224068610" TEXT="Clustering methods are applied in many domains such as medical research psychology  Table 4.6: Example evaluation for adjusted Rand index. Exp tij. 2." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1051405051" LINK="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6191196/" MODIFIED="1557225479723" TEXT="A Note on Using the Adjusted Rand Index for Link Prediction in ">
<node CREATED="1557224068610" ID="ID_760001487" MODIFIED="1557224068610" TEXT="3(Number of Clusters) &#215; 3(Density Within) &#215; 3(Density Between)  This can evaluate how much better than chance this method is&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1104433148" LINK="https://bmcbioinformatics.biomedcentral.com/articles/10.1186/1471-2105-8-44" MODIFIED="1557225479723" TEXT="Ranked Adjusted Rand: integrating distance and partition ">
<node CREATED="1557224068610" ID="ID_1542107506" MODIFIED="1557224068610" TEXT="Feb 7 2007  Biological information is commonly used to cluster or classify entities of interest  RAR differs from existing methods by evaluating the extent of  In the first case RAR is equal to its predecessor Adjusted Rand (HA) index." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
</node>
</node>
<node CREATED="1563517391360" FOLDED="true" Folded="true" ID="ID_250522630" MODIFIED="1563517391360" POSITION="left" TEXT="Clustering Techniques">
<edge COLOR="#00cc33" />
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_429291585" MODIFIED="1563517391360" TEXT="Hierarchical Clustering">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068610" FOLDED="true" ID="ID_1911415328" MODIFIED="1557225483444" TEXT="Hierarchical Clustering#$D$#">
<node CREATED="1557224068610" FOLDED="true" ID="ID_1326933476" LINK="https://en.wikipedia.org/wiki/Hierarchical_clustering" MODIFIED="1557225479723" TEXT="Hierarchical clustering - Wikipedia">
<node CREATED="1557224068610" ID="ID_1738790063" MODIFIED="1557224068610" TEXT="In data mining and statistics hierarchical clustering is a method of cluster analysis which seeks to build a hierarchy of clusters. Strategies for hierarchical&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1405118746" LINK="https://www.displayr.com/what-is-hierarchical-clustering/" MODIFIED="1557225479723" TEXT="What is Hierarchical Clustering? | Displayr.com">
<node CREATED="1557224068610" ID="ID_13926038" MODIFIED="1557224068610" TEXT="Hierarchical clustering also known as hierarchical cluster analysis is an algorithm that groups similar objects into groups called clusters. Learn more." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1535135285" LINK="https://towardsdatascience.com/understanding-the-concept-of-hierarchical-clustering-technique-c6e8243758ec" MODIFIED="1557225479723" TEXT="Understanding the concept of Hierarchical clustering Technique">
<node CREATED="1557224068610" ID="ID_1455056864" MODIFIED="1557224068610" TEXT="Dec 10 2018  Hierarchical clustering Technique is one of the popular Clustering techniques in Machine Learning. Before we try to understand the concept of&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1157194518" LINK="https://www.saedsayad.com/clustering_hierarchical.htm" MODIFIED="1557225479723" TEXT="Hierarchical Clustering">
<node CREATED="1557224068610" ID="ID_976012781" MODIFIED="1557224068610" TEXT="Hierarchical clustering involves creating clusters that have a predetermined ordering from top to bottom. For example all files and folders on the hard disk are&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_784526903" LINK="https://www.youtube.com/watch?v=7xHsRkOdVwo" MODIFIED="1557225479723" TEXT="StatQuest: Hierarchical Clustering - YouTube">
<node CREATED="1557224068610" ID="ID_877684824" MODIFIED="1557224068610" TEXT="Jun 20 2017  Hierarchical clustering is often used with heatmaps and with machine learning type stuff. Its no big deal though and based on just a few&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_328986039" LINK="https://docs.scipy.org/doc/scipy/reference/cluster.hierarchy.html" MODIFIED="1557225479723" TEXT="Hierarchical clustering (scipy.cluster.hierarchy) &#8212; SciPy v1.2.1 ">
<node CREATED="1557224068610" ID="ID_1076311700" MODIFIED="1557224068610" TEXT="These functions cut hierarchical clusterings into flat clusterings or find the roots of the forest formed by a cut by providing the flat cluster ids of each observation." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_207862388" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.cluster.AgglomerativeClustering.html" MODIFIED="1557225479723" TEXT="sklearn.cluster.AgglomerativeClustering &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068610" ID="ID_1197305306" MODIFIED="1557224068610" TEXT="Recursively merges the pair of clusters that minimally increases a given linkage  Default is None i.e the hierarchical clustering algorithm is unstructured." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1070342691" LINK="https://www.youtube.com/watch?v=rg2cjfMsCk4" MODIFIED="1557225479723" TEXT="Lecture 59 &#8212; Hierarchical Clustering | Stanford University - YouTube">
<node CREATED="1557224068610" ID="ID_806243825" MODIFIED="1557224068610" TEXT="Apr 13 2016  Copyright Disclaimer Under Section 107 of the Copyright Act 1976 allowance is made for FAIR USE for purposes such as criticism comment&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_816647311" LINK="http://www.econ.upf.edu/~michael/stanford/maeb7.pdf" MODIFIED="1557225479723" TEXT="Chapter 7 Hierarchical cluster analysis">
<node CREATED="1557224068610" ID="ID_626222613" MODIFIED="1557224068610" TEXT="The method of hierarchical cluster analysis is best explained by  this chapter we demonstrate hierarchical clustering on a small example and then list the." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_330827083" LINK="https://nlp.stanford.edu/IR-book/html/htmledition/hierarchical-agglomerative-clustering-1.html" MODIFIED="1557225479723" TEXT="Hierarchical agglomerative clustering">
<node CREATED="1557224068610" ID="ID_1784784582" MODIFIED="1557224068610" TEXT="Hierarchical clustering algorithms are either top-down or bottom-up. Bottom-up algorithms treat each document as a singleton cluster at the outset and then&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1413218592" MODIFIED="1563517391360" TEXT="Expectation Maximization Clustering">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068610" FOLDED="true" ID="ID_1421581972" MODIFIED="1557225483444" TEXT="Expectation Maximization Clustering#$D$#">
<node CREATED="1557224068610" FOLDED="true" ID="ID_1180617994" LINK="https://en.wikipedia.org/wiki/Expectation%E2%80%93maximization_algorithm" MODIFIED="1557225479723" TEXT="Expectation&#8211;maximization algorithm - Wikipedia">
<node CREATED="1557224068610" ID="ID_1181428488" MODIFIED="1557224068610" TEXT="In statistics an expectation&#8211;maximization (EM) algorithm is an iterative method to find .. EM is frequently used for data clustering in machine learning and computer vision. In natural language processing two prominent instances of the&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1502711848" LINK="https://docs.rapidminer.com/latest/studio/operators/modeling/segmentation/expectation_maximization_clustering.html" MODIFIED="1557225479723" TEXT="Expectation Maximization Clustering - RapidMiner Documentation">
<node CREATED="1557224068610" ID="ID_790913593" MODIFIED="1557224068610" TEXT="This operator performs clustering using the Expectation Maximization algorithm. Clustering is concerned with grouping objects together that are similar to each&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_600471794" LINK="https://www.youtube.com/watch?v=REypj2sy_5U" MODIFIED="1557225479723" TEXT="EM algorithm: how it works - YouTube">
<node CREATED="1557224068610" ID="ID_1943962397" MODIFIED="1557224068610" TEXT="Jan 19 2014  Full lecture: http://bit.ly/EM-alg Mixture models are a probabilistically-sound way to do soft clustering. We assume our data is sampled from K&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_204750622" LINK="http://www.cs.cmu.edu/~aarti/Class/10701_Spring14/slides/EM_annotatedonclass.pdf" MODIFIED="1557225479723" TEXT="EM (Annotated)">
<node CREATED="1557224068610" ID="ID_1126397577" MODIFIED="1557224068610" TEXT="Algorithm. Input. &#8211; Data + Desired number of clusters K. Initialize. &#8211; the K cluster centers (randomly if necessary). Iterate. 1. Decide the class memberships of the&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1691787134" LINK="https://www.math.univ-toulouse.fr/~besse/Wikistat/pdf/st-m-datSc4-EMmixt.pdf" MODIFIED="1557225479723" TEXT="Unsupervised clustering with E.M.">
<node CREATED="1557224068610" ID="ID_264948227" MODIFIED="1557224068610" TEXT="Unsupervised clustering with E.M.. Summary. We describe here the important framework of mixture models. These mixture models are rich flexible easy to&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1213666998" LINK="http://scikit-learn.org/stable/modules/mixture.html" MODIFIED="1557225479723" TEXT="2.1. Gaussian mixture models &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068610" ID="ID_472503510" MODIFIED="1557224068610" TEXT="One can think of mixture models as generalizing k-means clustering to  The GaussianMixture object implements the expectation-maximization (EM) algorithm&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_138514176" LINK="https://engineering.purdue.edu/kak/Tutorials/ExpectationMaximization.pdf" MODIFIED="1557225479723" TEXT="Expectation-Maximization Algorithm for Clustering Multidimensional ">
<node CREATED="1557224068610" ID="ID_1272259080" MODIFIED="1557224068610" TEXT="Jan 28 2017  Expectation Maximization Tutorial by Avi Kak. Expectation-Maximization Algorithm for. Clustering Multidimensional Numerical. Data. Avinash&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_865700617" LINK="https://www.kdnuggets.com/2016/08/tutorial-expectation-maximization-algorithm.html" MODIFIED="1557225479723" TEXT="A Tutorial on the Expectation Maximization (EM) Algorithm">
<node CREATED="1557224068610" ID="ID_196172390" MODIFIED="1557224068610" TEXT="This is a short tutorial on the Expectation Maximization algorithm and how it can  By looking at the spread of each cluster we can estimate that the variance of&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1858891375" LINK="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4433949/" MODIFIED="1557225479723" TEXT="Clustering performance comparison using K-means and expectation ">
<node CREATED="1557224068610" ID="ID_765685487" MODIFIED="1557224068610" TEXT="Two representatives of the clustering algorithms are the K-means and the expectation maximization (EM) algorithm. Linear regression analysis was extended to&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_433341725" LINK="https://stats.stackexchange.com/questions/76866/clustering-with-k-means-and-em-how-are-they-related" MODIFIED="1557225479723" TEXT="machine learning - Clustering with K-Means and EM: how are they ">
<node CREATED="1557224068610" ID="ID_838438067" MODIFIED="1557224068610" TEXT="Hard assign a data point to one particular cluster on convergence.  The most popular variant of EM is also known as Gaussian Mixture&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1143516169" MODIFIED="1563517391360" TEXT="Agglomerative Clustering">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_968512496" MODIFIED="1563517391360" TEXT="Dendograms">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_164548568" MODIFIED="1563517391360" TEXT="Agglomerative Clustering in Scikit-learn">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068609" FOLDED="true" ID="ID_1750380235" MODIFIED="1557225483442" TEXT="Clustering Fundamentals#$D$#">
<node CREATED="1557224068609" FOLDED="true" ID="ID_882502229" LINK="http://dbdmg.polito.it/wordpress/wp-content/uploads/2017/02/24e-DMClustering_6x.pdf" MODIFIED="1557225479708" TEXT="Clustering fundamentals">
<node CREATED="1557224068609" ID="ID_786113720" MODIFIED="1557224068609" TEXT="Clustering fundamentals. DataBase and Data Mining Group. 1. Clustering fundamentals. Elena Baralis Tania Cerquitelli. Politecnico di Torino. 2. DB. M. G." />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_70382876" LINK="https://www.pluralsight.com/courses/windows-failover-clustering-fundamentals" MODIFIED="1557225479708" TEXT="Windows Failover Clustering Fundamentals | Pluralsight">
<node CREATED="1557224068609" ID="ID_1569473522" MODIFIED="1557224068609" TEXT="Windows failover clusters are becoming increasingly prevalent in todays data centers. This course will teach you what you need to know about configuring&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_339497018" LINK="https://www.analyticsvidhya.com/blog/2016/11/an-introduction-to-clustering-and-different-methods-of-clustering/" MODIFIED="1557225479708" TEXT="An Introduction to Clustering  different methods of clustering">
<node CREATED="1557224068609" ID="ID_803501363" MODIFIED="1557224068609" TEXT="Nov 3 2016  This article is an introduction to clustering and its types. K-means clustering  Hierarchical clustering have been explained in details." />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1620133418" LINK="https://www-users.cs.umn.edu/~kumar/dmbook/ch8.pdf" MODIFIED="1557225479708" TEXT="Cluster Analysis: Basic Concepts and Algorithms">
<node CREATED="1557224068609" ID="ID_793616207" MODIFIED="1557224068609" TEXT="Cluster analysis divides data into groups (clusters) that are meaningful useful  dividing objects into groups (clustering) and assigning particular objects to." />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1296962724" LINK="https://www.ibm.com/developerworks/aix/tutorials/clustering/clustering.html" MODIFIED="1557225479708" TEXT="Clustering: A basic 101 tutorial">
<node CREATED="1557224068609" ID="ID_1701413764" MODIFIED="1557224068609" TEXT="Apr 3 2002  Confused by clusters? Were not talking grapes. Heres a sweet tutorial -- now updated -- on clustering high availability redundancy and&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_478382635" LINK="http://research.med.helsinki.fi/corefacilities/proteinchem/hierarchical_clustering_basics.pdf" MODIFIED="1557225479708" TEXT="Hierarchical Clustering Basics">
<node CREATED="1557224068609" ID="ID_1569782168" MODIFIED="1557224068609" TEXT="Basics. Please read the introduction to principal component analysis first. Please read the  Important parameters in hierarchical clustering are: The distance&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1775703324" LINK="https://www.udacity.com/course/segmentation-and-clustering--ud981" MODIFIED="1557225479708" TEXT="Segmentation and Clustering | Udacity">
<node CREATED="1557224068609" ID="ID_1770342935" MODIFIED="1557224068609" TEXT="Segmentation and Clustering Fundamentals. Learn the difference between standardization and localization. Learn about the concept of distance in clustering&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1033626888" LINK="https://www.uni-marburg.de/fb12/arbeitsgruppen/datenbionik/data" MODIFIED="1557225479708" TEXT="Fundamental Clustering Problems Suite">
<node CREATED="1557224068609" ID="ID_447740937" MODIFIED="1557224068609" TEXT="Dec 16 2013  The Fundamental Clustering Problems Suite (FCPS) offers a variety of clustering problems any algorithm shall be able to handle when facing&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_132163496" LINK="https://www.datascience.com/blog/k-means-clustering" MODIFIED="1557225479708" TEXT="Introduction to K-means Clustering">
<node CREATED="1557224068609" ID="ID_1044571056" MODIFIED="1557224068609" TEXT="Dec 6 2016  Learn data science with data scientist Dr. Andrea Trevinos step-by-step tutorial on the K-means clustering unsupervised machine learning&#160;" />
</node>
<node CREATED="1557224068609" FOLDED="true" ID="ID_1366656947" LINK="https://developer.ibm.com/articles/l-cluster1/" MODIFIED="1557225479708" TEXT="Clustering fundamentals &#8211; IBM Developer">
<node CREATED="1557224068609" ID="ID_461495402" MODIFIED="1557224068609" TEXT="Sep 27 2005  This part introduces the different types of clusters uses of clusters some fundamentals of HPC the role of Linux and the reasons for the growth&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_624791820" MODIFIED="1557225483444" TEXT="Clustering Techniques#$D$#">
<node CREATED="1557224068610" FOLDED="true" ID="ID_1693792071" LINK="https://towardsdatascience.com/the-5-clustering-algorithms-data-scientists-need-to-know-a36d136ef68" MODIFIED="1557225479723" TEXT="The 5 Clustering Algorithms Data Scientists Need to Know">
<node CREATED="1557224068610" ID="ID_230463635" MODIFIED="1557224068610" TEXT="Feb 5 2018  Clustering is a Machine Learning technique that involves the grouping of data points. Given a set of data points we can use a clustering&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1275590096" LINK="https://www.datanovia.com/en/blog/types-of-clustering-methods-overview-and-quick-start-r-code/" MODIFIED="1557225479723" TEXT="5 Amazing Types of Clustering Methods You Should Know - Datanovia">
<node CREATED="1557224068610" ID="ID_1321483810" MODIFIED="1557224068610" TEXT="We provide an overview of clustering methods and quick start R codes. You will also learn how to assess the quality of clustering analysis." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1600527571" LINK="https://en.wikipedia.org/wiki/Cluster_analysis" MODIFIED="1557225479723" TEXT="Cluster analysis - Wikipedia">
<node CREATED="1557224068610" ID="ID_1152047955" MODIFIED="1557224068610" TEXT="Cluster analysis or clustering is the task of grouping a set of objects in such a way that objects in the same group (called a cluster) are more similar (in some sense) to each other than to those in other groups (clusters). It is a main task of exploratory data mining and a common technique for&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1802257977" LINK="https://www.analyticsvidhya.com/blog/2016/11/an-introduction-to-clustering-and-different-methods-of-clustering/" MODIFIED="1557225479723" TEXT="An Introduction to Clustering  different methods of clustering">
<node CREATED="1557224068610" ID="ID_252878190" MODIFIED="1557224068610" TEXT="Nov 3 2016  The method of identifying similar groups of data in a dataset is called clustering. It is one of the most popular techniques in data science." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1458814955" LINK="https://medium.com/predict/three-popular-clustering-methods-and-when-to-use-each-4227c80ba2b6" MODIFIED="1557225479723" TEXT="Three Popular Clustering Methods and When to Use Each">
<node CREATED="1557224068610" ID="ID_120904822" MODIFIED="1557224068610" TEXT="Sep 21 2018  If youre interested in learning more about these techniques look up single link clustering complete link clustering clique margins and Wards&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1710684991" LINK="https://www.cs.swarthmore.edu/~meeden/cs63/s16/reading/Clustering.pdf" MODIFIED="1557225479723" TEXT="Chapter 15 CLUSTERING METHODS">
<node CREATED="1557224068610" ID="ID_226120859" MODIFIED="1557224068610" TEXT="and the mathematics underlying clustering techniques. The chapter begins by providing measures and criteria that are used for determining whether two ob-." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_823107839" LINK="https://www.tutorialspoint.com/data_mining/dm_cluster_analysis.htm" MODIFIED="1557225479723" TEXT="Data Mining Cluster Analysis">
<node CREATED="1557224068610" ID="ID_1461867708" MODIFIED="1557224068610" TEXT="Data Mining Cluster Analysis - Learn Data Mining in simple and easy steps starting  Miscellaneous Classification Methods Cluster Analysis Mining Text Data&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1310491271" LINK="https://www.analyticsindiamag.com/clustering-techniques-every-data-science-beginner-should-swear-by/" MODIFIED="1557225479723" TEXT="Clustering Techniques Every Data Science Beginner Should Swear By">
<node CREATED="1557224068610" ID="ID_538008877" MODIFIED="1557224068610" TEXT="Dec 20 2018  Cluster analysis is the statistical method of grouping data into subsets that have application in the context of a selective problem. This technique&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1748025375" LINK="http://members.tripod.com/asim_saeed/paper.htm" MODIFIED="1557225479723" TEXT="Different Techniques of Data Clustering">
<node CREATED="1557224068610" ID="ID_1399363435" MODIFIED="1557224068610" TEXT="Precisely Data Clustering is a technique in which the information that is logically similar is physically stored together. In order to increase the efficiency in the&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_53993631" LINK="http://www.iula.upf.edu/materials/040701wanner.pdf" MODIFIED="1557225479723" TEXT="Introduction to clustering techniques">
<node CREATED="1557224068610" ID="ID_1278674985" MODIFIED="1557224068610" TEXT="Jul 1 2004  Introduction to Clustering Techniques. Definition 1 (Clustering) Clustering is a division of data into groups of similar ob- jects. Each group (= a&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_790620560" MODIFIED="1557225483444" TEXT="Agglomerative Clustering#$D$#">
<node CREATED="1557224068610" FOLDED="true" ID="ID_1090149327" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.cluster.AgglomerativeClustering.html" MODIFIED="1557225479723" TEXT="sklearn.cluster.AgglomerativeClustering &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068610" ID="ID_925324945" MODIFIED="1557224068610" TEXT="class sklearn.cluster. AgglomerativeClustering (n_clusters=2 affinity=euclidean memory=None connectivity=None compute_full_tree=auto linkage=ward&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_400729258" LINK="https://en.wikipedia.org/wiki/Hierarchical_clustering" MODIFIED="1557225479723" TEXT="Hierarchical clustering - Wikipedia">
<node CREATED="1557224068610" ID="ID_1316190035" MODIFIED="1557224068610" TEXT="In data mining and statistics hierarchical clustering is a method of cluster analysis which seeks to build a&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_801587538" LINK="https://nlp.stanford.edu/IR-book/html/htmledition/hierarchical-agglomerative-clustering-1.html" MODIFIED="1557225479723" TEXT="Hierarchical agglomerative clustering">
<node CREATED="1557224068610" ID="ID_1974659006" MODIFIED="1557224068610" TEXT="Bottom-up hierarchical clustering is therefore called hierarchical agglomerative clustering or HAC . Top-down clustering requires a method for splitting a cluster." />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1263889556" LINK="https://www.youtube.com/watch?v=XJ3194AmH40" MODIFIED="1557225479723" TEXT="Agglomerative Clustering: how it works - YouTube">
<node CREATED="1557224068610" ID="ID_56977364" MODIFIED="1557224068610" TEXT="Jan 19 2014  http://bit.ly/s-link] Agglomerative clustering guarantees that similar instances end up in the same cluster. We start by having each instance being&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1941798902" LINK="https://www.datanovia.com/en/lessons/agglomerative-hierarchical-clustering/" MODIFIED="1557225479739" TEXT="Agglomerative Hierarchical Clustering - Datanovia">
<node CREATED="1557224068610" ID="ID_410144148" MODIFIED="1557224068610" TEXT="The agglomerative clustering is the most common type of hierarchical clustering used to group objects in clusters based on their similarity. Its also known as&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1507743628" LINK="https://towardsdatascience.com/hierarchical-clustering-and-its-applications-41c1ad4441a6" MODIFIED="1557225479739" TEXT="Hierarchical Clustering and its Applications &#8211; Towards Data Science">
<node CREATED="1557224068610" ID="ID_804878311" MODIFIED="1557224068610" TEXT="Oct 26 2018  Agglomerative clustering uses a bottom-up approach wherein each data point starts in its own cluster. These clusters are then joined greedily&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_932304253" LINK="https://docs.rapidminer.com/latest/studio/operators/modeling/segmentation/agglomerative_clustering.html" MODIFIED="1557225479739" TEXT="Agglomerative Clustering - RapidMiner Documentation">
<node CREATED="1557224068610" ID="ID_190306294" MODIFIED="1557224068610" TEXT="Agglomerative clustering is a strategy of hierarchical clustering. Hierarchical clustering (also known as Connectivity based clustering) is a method of cluster&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_836974939" LINK="http://www.improvedoutcomes.com/docs/WebSiteDocs/Clustering/Agglomerative_Hierarchical_Clustering_Overview.htm" MODIFIED="1557225479739" TEXT="Agglomerative Hierarchical Clustering Overview">
<node CREATED="1557224068610" ID="ID_1116135419" MODIFIED="1557224068610" TEXT="Agglomerative hierarchical clustering is a bottom-up clustering method where clusters have sub-clusters which in turn have sub-clusters etc. The classic&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_697668136" LINK="https://towardsdatascience.com/understanding-the-concept-of-hierarchical-clustering-technique-c6e8243758ec" MODIFIED="1557225479739" TEXT="Understanding the concept of Hierarchical clustering Technique">
<node CREATED="1557224068610" ID="ID_581253306" MODIFIED="1557224068610" TEXT="Dec 10 2018  To understand better lets see a pictorial representation of Agglomerative Hierarchical clustering Technique. Lets say we have six data points {A&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1002208916" LINK="https://arxiv.org/pdf/1109.2378" MODIFIED="1557225479739" TEXT="Modern hierarchical agglomerative clustering algorithms">
<node CREATED="1557224068610" ID="ID_686996847" MODIFIED="1557224068610" TEXT="Sep 12 2011  This paper presents algorithms for hierarchical agglomerative clustering which perform most efficiently in the general-purpose setup that is&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1551945484" MODIFIED="1557225483444" TEXT="Clustering Dendograms#$D$#">
<node CREATED="1557224068610" FOLDED="true" ID="ID_1558877376" LINK="https://en.wikipedia.org/wiki/Dendrogram" MODIFIED="1557225479739" TEXT="Dendrogram - Wikipedia">
<node CREATED="1557224068610" ID="ID_1676178884" MODIFIED="1557224068610" TEXT="have been clustered by UPGMA based on a matrix of genetic distances. The hierarchical clustering dendrogram would show&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1138456508" LINK="https://www.statisticshowto.datasciencecentral.com/hierarchical-clustering/" MODIFIED="1557225479739" TEXT="Hierarchical Clustering / Dendrogram: Simple Definition Examples ">
<node CREATED="1557224068610" ID="ID_1339384815" MODIFIED="1557224068610" TEXT="Nov 15 2016  What is hierarchical clustering (a dendrogram)? Definition and overview of clustering algorithms. Different linkage types and basic clustering&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_6044723" LINK="https://ncss-wpengine.netdna-ssl.com/wp-content/themes/ncss/pdf/Procedures/NCSS/Hierarchical_Clustering-Dendrograms.pdf" MODIFIED="1557225479739" TEXT="Hierarchical Clustering / Dendrograms">
<node CREATED="1557224068610" ID="ID_719811931" MODIFIED="1557224068610" TEXT="The agglomerative hierarchical clustering algorithms available in this program  Looking at this dendrogram you can see the three clusters as three branches&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1252752059" LINK="http://www.nonlinear.com/support/progenesis/comet/faq/v2.0/dendrogram.aspx" MODIFIED="1557225479739" TEXT="What does the dendrogram show or what is correlation analysis?">
<node CREATED="1557224068610" ID="ID_1377729076" MODIFIED="1557224068610" TEXT="Draw a dendrogram showing clusters of compounds according to how strongly correlated the compounds are. This correlation can be seen in the abundance&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_1761490746" LINK="https://docs.scipy.org/doc/scipy/reference/generated/scipy.cluster.hierarchy.dendrogram.html" MODIFIED="1557225479739" TEXT="scipy.cluster.hierarchy.dendrogram &#8212; SciPy v1.2.1 Reference Guide">
<node CREATED="1557224068610" ID="ID_1694016684" MODIFIED="1557224068610" TEXT="The dendrogram illustrates how each cluster is composed by drawing a U-shaped link between a non-singleton cluster and its children. The top of the U-link&#160;" />
</node>
<node CREATED="1557224068610" FOLDED="true" ID="ID_67231055" LINK="https://www.displayr.com/what-is-dendrogram/" MODIFIED="1557225479739" TEXT="What is a Dendrogram? How to use Dendrograms | Displayr">
<node CREATED="1557224068610" ID="ID_508992214" MODIFIED="1557224068610" TEXT="A dendrogram is a diagram that shows the hierarchical relationship between objects. It is commonly created as an output from hierarchical clustering." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1904701855" LINK="https://docs.scipy.org/doc/scipy-0.14.0/reference/generated/scipy.cluster.hierarchy.dendrogram.html" MODIFIED="1557225479739" TEXT="scipy.cluster.hierarchy.dendrogram &#8212; SciPy v0.14.0 Reference Guide">
<node CREATED="1557224068611" ID="ID_1098272441" MODIFIED="1557224068611" TEXT="The dendrogram illustrates how each cluster is composed by drawing a U-shaped link between a non-singleton cluster and its children. The height of the top of&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_139520251" LINK="https://www.researchgate.net/publication/244104182_Clustering_with_dendograms_on_interpretation_variables" MODIFIED="1557225479739" TEXT="Clustering with dendograms on interpretation variables | Request PDF">
<node CREATED="1557224068611" ID="ID_789601810" MODIFIED="1557224068611" TEXT="Mar 15 2019  Request PDF on ResearchGate | Clustering with dendograms on interpretation variables | Clustering techniques are used frequently in&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_553014922" LINK="https://people.revoledu.com/kardi/tutorial/Clustering/dendogram.htm" MODIFIED="1557225479739" TEXT="Hierarchical Clustering Tutorial: What is dendogram">
<node CREATED="1557224068611" ID="ID_22058049" MODIFIED="1557224068611" TEXT="The standard output of hierarchical clustering is a dendogram. A dendogram is a cluster tree diagram where the distance of split or merge is recorded." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_394393913" LINK="https://stackabuse.com/hierarchical-clustering-with-python-and-scikit-learn/" MODIFIED="1557225479739" TEXT="Hierarchical Clustering with Python and Scikit-Learn">
<node CREATED="1557224068611" ID="ID_271251322" MODIFIED="1557224068611" TEXT="Jul 12 2018  In the last section we said that once one large cluster is formed by the combination of small clusters dendrograms of the cluster are used to&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_483280401" MODIFIED="1557225483445" TEXT="Agglomerative Clustering in Scikit-learn#$D$#">
<node CREATED="1557224068611" FOLDED="true" ID="ID_403968870" LINK="http://scikit-learn.org/stable/modules/generated/sklearn.cluster.AgglomerativeClustering.html" MODIFIED="1557225479739" TEXT="sklearn.cluster.AgglomerativeClustering &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068611" ID="ID_1276589697" MODIFIED="1557224068611" TEXT="class sklearn.cluster. AgglomerativeClustering (n_clusters=2 affinity=euclidean memory=None connectivity=None compute_full_tree=auto linkage=ward&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1968657471" LINK="https://stackabuse.com/hierarchical-clustering-with-python-and-scikit-learn/" MODIFIED="1557225479739" TEXT="Hierarchical Clustering with Python and Scikit-Learn">
<node CREATED="1557224068611" ID="ID_153861619" MODIFIED="1557224068611" TEXT="Jul 12 2018  In some cases the result of hierarchical and K-Means clustering can be similar. Before implementing hierarchical clustering using Scikit-Learn&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_742917976" LINK="http://scikit-learn.org/stable/modules/clustering.html" MODIFIED="1557225479739" TEXT="2.3. Clustering &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068611" ID="ID_1338464728" MODIFIED="1557224068611" TEXT="Agglomerative clustering number of clusters linkage type distance Large n_samples and n_clusters Many clusters possibly connectivity constraints non&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1434761721" LINK="https://chrisalbon.com/machine_learning/clustering/agglomerative_clustering/" MODIFIED="1557225479739" TEXT="Agglomerative Clustering">
<node CREATED="1557224068611" ID="ID_368172728" MODIFIED="1557224068611" TEXT="Dec 20 2017  Conduct Agglomerative Clustering. In scikit-learn AgglomerativeClustering uses the linkage parameter to determine the merging strategy to&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_413202654" LINK="http://scikit-learn.org/stable/auto_examples/cluster/plot_ward_structured_vs_unstructured.html" MODIFIED="1557225479739" TEXT="Hierarchical clustering: structured vs unstructured ward &#8212; scikit ">
<node CREATED="1557224068611" ID="ID_486179302" MODIFIED="1557224068611" TEXT="In a first step the hierarchical clustering is performed without connectivity constraints on the structure and is solely based on distance whereas in a second step&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1128144806" LINK="https://www.youtube.com/watch?v=EQZaSuK-PHs" MODIFIED="1557225479739" TEXT="Unsupervised Machine Learning - Hierarchical Clustering with ">
<node CREATED="1557224068611" ID="ID_1434721829" MODIFIED="1557224068611" TEXT="Feb 2 2015  This machine learning tutorial covers unsupervised learning with  Learning - Hierarchical Clustering with Mean Shift Scikit-learn and Python." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1456529357" LINK="http://scikit-learn.org/stable/auto_examples/cluster/plot_agglomerative_clustering_metrics.html" MODIFIED="1557225479739" TEXT="Agglomerative clustering with different metrics &#8212; scikit-learn 0.20.3 ">
<node CREATED="1557224068611" ID="ID_78810685" MODIFIED="1557224068611" TEXT="Demonstrates the effect of different metrics on the hierarchical clustering.  np from sklearn.cluster import AgglomerativeClustering from sklearn.metrics import&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_835126546" LINK="https://towardsdatascience.com/an-introduction-to-clustering-algorithms-in-python-123438574097" MODIFIED="1557225479739" TEXT="An Introduction to Clustering Algorithms in Python &#8211; Towards Data ">
<node CREATED="1557224068611" ID="ID_528160860" MODIFIED="1557224068611" TEXT="May 29 2018  This would be an example of &#8220;unsupervised learning&#8221; since were not  friend blobby; i.e. the make_blobs function in Pythons sci-kit learn library.  Agglomerative hierarchical clustering differs from k-means in a key way." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1147777961" LINK="https://pythonprogramming.net/hierarchical-clustering-machine-learning-python-scikit-learn/" MODIFIED="1557225479739" TEXT="Hierarchical Clustering">
<node CREATED="1557224068611" ID="ID_98720908" MODIFIED="1557224068611" TEXT="Unsupervised Machine Learning: Hierarchical Clustering. Mean Shift cluster analysis example with Python and Scikit-learn&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_504242807" LINK="https://stackoverflow.com/questions/29127013/plot-dendrogram-using-sklearn-agglomerativeclustering" MODIFIED="1557225479739" TEXT="Plot dendrogram using sklearn.AgglomerativeClustering - Stack ">
<node CREATED="1557224068611" ID="ID_310211061" MODIFIED="1557224068611" TEXT="Here is a simple function for taking a hierarchical clustering model from sklearn and plotting it using the scipy dendrogram function. Seems like graphing&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1304364571" MODIFIED="1557225483445" TEXT="Clustering Connectivity Constraints#$D$#">
<node CREATED="1557224068611" FOLDED="true" ID="ID_713507825" LINK="http://scikit-learn.org/stable/modules/clustering.html" MODIFIED="1557225479739" TEXT="2.3. Clustering &#8212; scikit-learn 0.20.3 documentation">
<node CREATED="1557224068611" ID="ID_1022436656" MODIFIED="1557224068611" TEXT="Ward hierarchical clustering number of clusters Large n_samples and n_clusters Many clusters possibly connectivity constraints Distances between points." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1612342524" LINK="https://en.wikipedia.org/wiki/Constrained_clustering" MODIFIED="1557225479739" TEXT="Constrained clustering - Wikipedia">
<node CREATED="1557224068611" ID="ID_1568407486" MODIFIED="1557224068611" TEXT="In computer science constrained clustering is a class of semi-supervised learning algorithms. Typically constrained clustering incorporates either a set of&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_48652573" LINK="http://scikit-learn.org/stable/auto_examples/cluster/plot_ward_structured_vs_unstructured.html" MODIFIED="1557225479739" TEXT="Hierarchical clustering: structured vs unstructured ward &#8212; scikit ">
<node CREATED="1557224068611" ID="ID_839322762" MODIFIED="1557224068611" TEXT="In a first step the hierarchical clustering is performed without connectivity constraints on the structure and is solely based on distance whereas in a second step&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1583734784" LINK="https://stackoverflow.com/questions/42821622/scikit-learn-agglomerative-clustering-connectivity-matrix" MODIFIED="1557225479739" TEXT="Scikit-learn Agglomerative Clustering Connectivity Matrix - Stack ">
<node CREATED="1557224068611" ID="ID_1297956023" MODIFIED="1557224068611" TEXT="Mar 21 2017  When passing a connectivity matrix to sklearn.cluster.  You can try reassigning centers after clustering to respect your constraints or youll&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1245628582" LINK="https://link.springer.com/article/10.1007/s00357-003-0011-7" MODIFIED="1557225479739" TEXT="Maximum Split Clustering Under Connectivity Constraints ">
<node CREATED="1557224068611" ID="ID_72021398" MODIFIED="1557224068611" TEXT="Maximum Split Clustering Under Connectivity Constraints. Authors; Authors and affiliations. Pierre Hansen; Brigitte Jaumard; Christophe Meyer; Bruno Simeone&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_930483591" LINK="https://www.quora.com/How-can-I-modify-the-hclust-Hierarchical-cluster-analaysis-in-R-with-connectivity-constraints-matrix-so-that-it-only-cluster-adjacent-nodes-as-described-in-the-constraints-matrix" MODIFIED="1557225479739" TEXT="(Hierarchical cluster analaysis) in R with connectivity constraints ">
<node CREATED="1557224068611" ID="ID_1359422209" MODIFIED="1557224068611" TEXT="How can I modify the hclust (Hierarchical cluster analaysis) in R with connectivity constraints matrix so that it only cluster adjacent nodes as described in the&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_926742924" LINK="https://onlinelibrary.wiley.com/doi/pdf/10.1002/sam.10109" MODIFIED="1557225479739" TEXT="Agglomerative connectivity constrained clustering for image ">
<node CREATED="1557224068611" ID="ID_1236375169" MODIFIED="1557224068611" TEXT="Jan 18 2011  Keywords: connectivity constrained clustering; agglomerative clustering; image . maximum split clustering with connectivity constraints." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1710343323" LINK="https://subscription.packtpub.com/video/big_data_and_business_intelligence/9781789134377/55308/55311/connectivity-constraints" MODIFIED="1557225479739" TEXT="Connectivity Constraints - Fundamentals of Machine Learning with ">
<node CREATED="1557224068611" ID="ID_467613673" MODIFIED="1557224068611" TEXT="Mar 28 2018  scikit-learn also allows specifying a connectivity matrix which can be used as a constraint when finding the clusters to merge. - Start with&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_683042665" LINK="https://www.semanticscholar.org/paper/Maximum-Split-Clustering-Under-Connectivity/8ea04b083ca44b1e7af4c400ccb8384e7ec00945" MODIFIED="1557225479739" TEXT="Maximum Split Clustering Under Connectivity Constraints ">
<node CREATED="1557224068611" ID="ID_893408959" MODIFIED="1557224068611" TEXT="The split of a cluster is the smallest dissimilarity between an entity of this cluster and an entity outside of it. The single-linkage algorithm (ignoring contiguity&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_133845806" LINK="https://dl.acm.org/citation.cfm?id=1062349" MODIFIED="1557225479739" TEXT="Maximum Split Clustering Under Connectivity Constraints">
<node CREATED="1557224068611" ID="ID_255081541" MODIFIED="1557224068611" TEXT="Maximum Split Clustering Under Connectivity Constraints 2003 Article. Bibliometrics Data Bibliometrics. &#183; Citation Count: 3 &#183; Downloads (cumulative): n/a" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1155880132" MODIFIED="1563517391360" TEXT="Connectivity Constraints">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1042819677" MODIFIED="1563517391360" TEXT="Introduction to Recommendation Systems">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_849009274" MODIFIED="1563517391360" TEXT="Naive User based systems">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068611" FOLDED="true" ID="ID_491844402" MODIFIED="1557225483445" TEXT="Introduction to Recommendation Systems#$D$#">
<node CREATED="1557224068611" FOLDED="true" ID="ID_1612210236" LINK="https://www.coursera.org/specializations/recommender-systems" MODIFIED="1557225479739" TEXT="Recommender Systems | Coursera">
<node CREATED="1557224068611" ID="ID_1352161732" MODIFIED="1557224068611" TEXT="Learn Recommender Systems from University of Minnesota.  Introduction to Recommender Systems: Non-Personalized and Content-Based. 4.5. 388 ratings." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_15281996" LINK="https://tryolabs.com/blog/introduction-to-recommender-systems/" MODIFIED="1557225479739" TEXT="Introduction to Recommender Systems in 2019 | Tryolabs Blog">
<node CREATED="1557224068611" ID="ID_992594683" MODIFIED="1557224068611" TEXT="Many e-commerce and retail companies are leveraging the power of data and boosting sales by implementing recommender systems on their websites. In short&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_548220121" LINK="https://www.coursera.org/learn/recommender-systems-introduction" MODIFIED="1557225479739" TEXT="Introduction to Recommender Systems: Non-Personalized and ">
<node CREATED="1557224068611" ID="ID_1597561684" MODIFIED="1557224068611" TEXT="Learn Introduction to Recommender Systems: Non-Personalized and Content-Based from University of Minnesota. This course which is designed to serve as&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1476628932" LINK="https://hackernoon.com/introduction-to-recommender-system-part-1-collaborative-filtering-singular-value-decomposition-44c9659c5e75" MODIFIED="1557225479739" TEXT="Introduction to Recommender System. Part 1 (Collaborative Filtering ">
<node CREATED="1557224068611" ID="ID_811029239" MODIFIED="1557224068611" TEXT="Jan 28 2018  Introduction. A recommender system refers to a system that is capable of predicting the future preference of a set of items for a user and&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1243738603" LINK="http://www.inf.unibz.it/~ricci/papers/intro-rec-sys-handbook.pdf" MODIFIED="1557225479739" TEXT="Introduction to Recommender Systems Handbook">
<node CREATED="1557224068611" ID="ID_1855554154" MODIFIED="1557224068611" TEXT="Introduction to Recommender Systems. Handbook. Francesco Ricci Lior Rokach and Bracha Shapira. Abstract Recommender Systems (RSs) are software tools&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_710085574" LINK="https://towardsdatascience.com/introduction-to-recommender-system-part-2-adoption-of-neural-network-831972c4cbf7" MODIFIED="1557225479739" TEXT="Introduction to Recommender System. Part 2 (Neural Network ">
<node CREATED="1557224068611" ID="ID_262416117" MODIFIED="1557224068611" TEXT="Feb 16 2018  In my last blog post of this series: Introduction to Recommender System. Part 1 (Collaborative Filtering Singular Value Decomposition) I talked&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_97534463" LINK="https://www.datascience.com/resources/white-papers/introduction-to-recommendation-engines-for-business" MODIFIED="1557225479739" TEXT="Introduction to Recommender Systems">
<node CREATED="1557224068611" ID="ID_1709643407" MODIFIED="1557224068611" TEXT="Netflix values the recommendation engine powering its content suggestions at $1 billion per year and Amazon says its system drives a 20-35% lift in sales&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_439876697" LINK="https://en.wikipedia.org/wiki/Recommender_system" MODIFIED="1557225479739" TEXT="Recommender system - Wikipedia">
<node CREATED="1557224068611" ID="ID_1929140712" MODIFIED="1557224068611" TEXT="A recommender system or a recommendation system is a subclass of information filtering  Gerhard Friedrich (2010). Recommender Systems:An Introduction." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1166700573" LINK="https://jessesw.com/Rec-System/" MODIFIED="1557225479739" TEXT="A Gentle Introduction to Recommender Systems with Implicit Feedback">
<node CREATED="1557224068611" ID="ID_1877698693" MODIFIED="1557224068611" TEXT="May 30 2016  Recommender systems have become a very important part of the retail social networking and entertainment industries. From providing advice&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1037956297" LINK="https://pdfs.semanticscholar.org/5d1d/d378962c7601526f65f69e408f8800a0d3c4.pdf" MODIFIED="1557225479739" TEXT="Recommender Systems An introduction">
<node CREATED="1557224068611" ID="ID_1321541974" MODIFIED="1557224068611" TEXT="Recommender Systems. An introduction. Dietmar Jannach TU Dortmund Germany. Slides presented at PhD School 2014 University Szeged Hungary." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1132706626" MODIFIED="1563517391360" TEXT="Content based Systems">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068611" FOLDED="true" ID="ID_1520603051" MODIFIED="1557225483445" TEXT="Content based Systems#$D$#">
<node CREATED="1557224068611" FOLDED="true" ID="ID_1926473760" LINK="https://en.wikipedia.org/wiki/Recommender_system" MODIFIED="1557225479739" TEXT="Recommender system - Wikipedia">
<node CREATED="1557224068611" ID="ID_1026837490" MODIFIED="1557224068611" TEXT="A recommender system or a recommendation system is a subclass of information filtering system that seeks to&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_406317233" LINK="https://towardsdatascience.com/how-to-build-from-scratch-a-content-based-movie-recommender-with-natural-language-processing-25ad400eb243" MODIFIED="1557225479739" TEXT="How to build a content-based movie recommender system with ">
<node CREATED="1557224068611" ID="ID_1519183697" MODIFIED="1557224068611" TEXT="Oct 1 2018  The two main types of recommender systems are either collaborative or content-based filters: these two names are pretty self-explanatory but&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_498330135" LINK="https://www.analyticsvidhya.com/blog/2015/08/beginners-guide-learn-content-based-recommender-systems/" MODIFIED="1557225479739" TEXT="Beginners Guide to learn about Content Based Recommender Engine">
<node CREATED="1557224068611" ID="ID_739638894" MODIFIED="1557224068611" TEXT="Aug 11 2015  Broadly there are two types of recommendation systems &#8211; Content Based  Collaborative filtering based. In this article well learn about&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1062750843" LINK="https://medium.com/@cfpinela/content-based-recommender-systems-a68c2aee2235" MODIFIED="1557225479739" TEXT="Content-Based Recommender Systems &#8211; Carlos Pinela &#8211; Medium">
<node CREATED="1557224068611" ID="ID_628884504" MODIFIED="1557224068611" TEXT="Nov 28 2017  Content-Based Recommender Systems are born from the idea of using the content of each item for recommending purposes and trying to&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_95805943" LINK="https://www.offerzen.com/blog/how-to-build-a-content-based-recommender-system-for-your-product" MODIFIED="1557225479739" TEXT="How to Build a Content-Based Recommender System For Your ">
<node CREATED="1557224068611" ID="ID_1099859113" MODIFIED="1557224068611" TEXT="Based on this Im going to introduce you to content-based filtering for a movie recommender system. Ill use Python as the programming language for the&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1295740813" LINK="http://www.fxpal.com/publications/FXPAL-PR-06-383.pdf" MODIFIED="1557225479739" TEXT="Content-based Recommendation Systems">
<node CREATED="1557224068611" ID="ID_1235589144" MODIFIED="1557224068611" TEXT="Abstract. This chapter discusses content-based recommendation systems i.e. systems that recommend an item to a user based upon a description of the item." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1964585949" LINK="http://recommender-systems.org/content-based-filtering/" MODIFIED="1557225479739" TEXT="Content-based Filtering">
<node CREATED="1557224068611" ID="ID_1093349843" MODIFIED="1557224068611" TEXT="Several issues have to be considered when implementing a content-based filtering system. First terms can either be assigned automatically or manually." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1426484309" LINK="https://www.upwork.com/hiring/data/what-is-content-based-filtering/" MODIFIED="1557225479739" TEXT="What Is Content-Based Filtering? - Hiring | Upwork">
<node CREATED="1557224068611" ID="ID_1075966134" MODIFIED="1557224068611" TEXT="Content-based filtering is used in a number of applications including information retrieval (as in search engines) as well as recommender systems. In this article&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1336656964" LINK="https://link.springer.com/chapter/10.1007/978-3-540-72079-9_10" MODIFIED="1557225479739" TEXT="Content-Based Recommendation Systems | SpringerLink">
<node CREATED="1557224068611" ID="ID_1217671885" MODIFIED="1557224068611" TEXT="This chapter discusses content-based recommendation systems i.e. systems that recommend an item to a user based upon a description of the item and a&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1017400805" LINK="https://www.youtube.com/watch?v=9siFuMMHNIA" MODIFIED="1557225479739" TEXT="Lecture 16.2 &#8212; Recommender Systems | Content Based ">
<node CREATED="1557224068611" ID="ID_1750589284" MODIFIED="1557224068611" TEXT="Feb 9 2017  Lecture 16.2 &#8212; Recommender Systems | Content Based Recommendations &#8212; [ Andrew Ng ]. Artificial Intelligence - All in One. Loading." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1870707605" MODIFIED="1563517391360" TEXT="Blog">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_943665214" MODIFIED="1563517391360" TEXT="Analytics Vidya ">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_912750094" MODIFIED="1563517391360" TEXT="Model free collaborative filtering">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_455663786" MODIFIED="1563517391360" TEXT="Singular Value Decomposition">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068611" FOLDED="true" ID="ID_1562043055" MODIFIED="1557225483445" TEXT="Model free collaborative filtering#$D$#">
<node CREATED="1557224068611" FOLDED="true" ID="ID_827230115" LINK="https://www.oreilly.com/library/view/machine-learning-algorithms/9781789347999/b0fe1c1c-b442-4c42-9795-90e1cae036bc.xhtml" MODIFIED="1557225479739" TEXT="Model-free (or memory-based) collaborative filtering - Machine ">
<node CREATED="1557224068611" ID="ID_1153790766" MODIFIED="1557224068611" TEXT="Model-free (or memory-based) collaborative filtering As with the user-based approach lets consider two sets of elements: users and items. However in this case&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1596601168" LINK="https://en.wikipedia.org/wiki/Collaborative_filtering" MODIFIED="1557225479739" TEXT="Collaborative filtering - Wikipedia">
<node CREATED="1557224068611" ID="ID_51681988" MODIFIED="1557224068611" TEXT="Collaborative filtering (CF) is a technique used by recommender systems. Collaborative filtering  From Wikipedia the free encyclopedia. Jump to .. A number of applications combine the memory-based and the model-based CF algorithms." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_229962135" LINK="https://www.bonaccorso.eu/2017/09/13/a-model-free-collaborative-recommendation-system-in-20-lines-of-python/" MODIFIED="1557225479739" TEXT="A model-free collaborative recommendation system in 20 lines of ">
<node CREATED="1557224068611" ID="ID_968047178" MODIFIED="1557224068611" TEXT="Sep 13 2017  A brief discussion about model-free or in-memory collaborative filtering recommendation systems with a fast Python implementation." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_776166903" LINK="https://medium.freecodecamp.org/how-companies-use-collaborative-filtering-to-learn-exactly-what-you-want-a3fc58e22ad9" MODIFIED="1557225479739" TEXT="How companies use collaborative filtering to learn exactly what you ">
<node CREATED="1557224068611" ID="ID_865275257" MODIFIED="1557224068611" TEXT="Feb 14 2019  Well consider our collaborative filtering model a success if its able to fill in the zeros. This would mean that its able to predict how each user&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_566265998" LINK="https://www.quora.com/Where-will-I-get-sample-data-for-collaborative-filtering" MODIFIED="1557225479739" TEXT="Where will I get sample data for collaborative filtering? - Quora">
<node CREATED="1557224068611" ID="ID_1981090685" MODIFIED="1557224068611" TEXT="Where can I get data set for collaborative filtering system? 577 Views  Free guide to machine learning basics and advanced techniques. Download the ebook&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_410026639" LINK="http://ieeexplore.ieee.org/document/6913637/" MODIFIED="1557225479739" TEXT="Collaborative filtering enhanced by user free-text reviews topic ">
<node CREATED="1557224068611" ID="ID_1825394152" MODIFIED="1557224068611" TEXT="Collaborative filtering enhanced by user free-text reviews topic modelling. Abstract: User based collaborative filtering (UCF) and item based collaborative&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_540822901" LINK="https://towardsdatascience.com/various-implementations-of-collaborative-filtering-100385c6dfe0" MODIFIED="1557225479739" TEXT="Various Implementations of Collaborative Filtering &#8211; Towards Data ">
<node CREATED="1557224068611" ID="ID_1959920472" MODIFIED="1557224068611" TEXT="Dec 28 2017  The most basic models for recommendations systems are collaborative filtering models which are based on assumption that people like things&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_866529532" LINK="https://www.cs.huji.ac.il/~shais/papers/ShamirShalevCOLT11.pdf" MODIFIED="1557225479739" TEXT="Collaborative Filtering with the Trace Norm: Learning Bounding ">
<node CREATED="1557224068611" ID="ID_1957779269" MODIFIED="1557224068611" TEXT="and despite previous attempts there are no distribution-free non-trivial .. model which we argue to more closely resemble collaborative filtering as done in&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1338967629" LINK="https://towardsdatascience.com/how-to-build-a-collaborative-filtering-model-for-personalized-recommendations-using-tensorflow-and-b9a77dc1320" MODIFIED="1557225479739" TEXT="How to build a collaborative filtering model for personalized ">
<node CREATED="1557224068611" ID="ID_692743166" MODIFIED="1557224068611" TEXT="Apr 10 2018  In this article I will step you through how to use TensorFlows Estimator API to build a WALS collaborative filtering model for product&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_840529629" MODIFIED="1557225483445" TEXT="Singular Value Decomposition#$D$#">
<node CREATED="1557224068611" FOLDED="true" ID="ID_113487939" LINK="https://en.wikipedia.org/wiki/Singular_value_decomposition" MODIFIED="1557225479739" TEXT="Singular value decomposition - Wikipedia">
<node CREATED="1557224068611" ID="ID_875397454" MODIFIED="1557224068611" TEXT="In linear algebra the singular-value decomposition (SVD) is a factorization of a real or complex matrix. It is the generalization of the eigendecomposition of a&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1129967650" LINK="http://mathworld.wolfram.com/SingularValueDecomposition.html" MODIFIED="1557225479739" TEXT="Singular Value Decomposition -- from Wolfram MathWorld">
<node CREATED="1557224068611" ID="ID_531110927" MODIFIED="1557224068611" TEXT="then A can be written using a so-called singular value decomposition of the form  Singular value decomposition is implemented in the Wolfram Language as&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1798588033" LINK="https://www.cs.cmu.edu/~venkatg/teaching/CStheory-infoage/book-chapter-4.pdf" MODIFIED="1557225479739" TEXT="Singular Value Decomposition">
<node CREATED="1557224068611" ID="ID_568076742" MODIFIED="1557224068611" TEXT="The singular value decomposition of a matrix A is the factorization of A into the  Also singular value decomposition is defined for all matrices (rectangular or&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_742905470" LINK="http://web.mit.edu/be.400/www/SVD/Singular_Value_Decomposition.htm" MODIFIED="1557225479739" TEXT="Singular Value Decomposition (SVD) tutorial">
<node CREATED="1557224068611" ID="ID_614031061" MODIFIED="1557224068611" TEXT="Singular Value Decomposition (SVD) tutorial. BE.400 / 7.548. Singular value decomposition takes a rectangular matrix of gene expression data (defined as A&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_453432349" LINK="https://www.youtube.com/watch?v=mBcLRGuAFUk" MODIFIED="1557225479739" TEXT="Singular Value Decomposition (the SVD) - YouTube">
<node CREATED="1557224068611" ID="ID_467212824" MODIFIED="1557224068611" TEXT="May 6 2016  MIT RES.18-009 Learn Differential Equations: Up Close with Gilbert Strang and Cleve Moler Fall 2015 View the complete course:&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_454764799" LINK="https://machinelearningmastery.com/singular-value-decomposition-for-machine-learning/" MODIFIED="1557225479739" TEXT="A Gentle Introduction to Singular-Value Decomposition (SVD) for ">
<node CREATED="1557224068611" ID="ID_1563338206" MODIFIED="1557224068611" TEXT="Feb 26 2018  The Singular-Value Decomposition or SVD for short is a matrix decomposition method for reducing a matrix to its constituent parts in order to&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_373138098" LINK="https://hadrienj.github.io/posts/Deep-Learning-Book-Series-2.8-Singular-Value-Decomposition/" MODIFIED="1557225479739" TEXT="Introduction to Singular Value Decomposition - Deep Learning Book ">
<node CREATED="1557224068611" ID="ID_237433991" MODIFIED="1557224068611" TEXT="Mar 26 2018  Introduction to the Singular Value Decomposition (SVD). We will use Python to get a practical and visual intuition of the Singular Value&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1582038591" LINK="https://www.youtube.com/watch?v=P5mlg91as1c" MODIFIED="1557225479739" TEXT="Lecture 47 &#8212; Singular Value Decomposition | Stanford University ">
<node CREATED="1557224068611" ID="ID_268126860" MODIFIED="1557224068611" TEXT="Apr 13 2016  Copyright Disclaimer Under Section 107 of the Copyright Act 1976 allowance is made for FAIR USE for purposes such as criticism comment&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_169445744" LINK="https://reference.wolfram.com/language/ref/SingularValueDecomposition.html" MODIFIED="1557225479739" TEXT="SingularValueDecomposition&#8212;Wolfram Language Documentation">
<node CREATED="1557224068611" ID="ID_1904826473" MODIFIED="1557224068611" TEXT="SingularValueDecomposition[m] gives the singular value decomposition for a numerical matrix m as a list of matrices {u w v} where w is a diagonal matrix and&#160;" />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_1314892495" LINK="http://www.ams.org/publicoutreach/feature-column/fcarc-svd" MODIFIED="1557225479739" TEXT="We Recommend a Singular Value Decomposition">
<node CREATED="1557224068611" ID="ID_208019188" MODIFIED="1557224068611" TEXT="The topic of this article the singular value decomposition is one that should be a part of the standard mathematics undergraduate curriculum but all too often&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1240672911" MODIFIED="1563517391360" TEXT="Alternating least squares">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068611" FOLDED="true" ID="ID_319394984" MODIFIED="1557225483446" TEXT="Alternating least squares#$D$#">
<node CREATED="1557224068611" FOLDED="true" ID="ID_217686790" LINK="https://towardsdatascience.com/prototyping-a-recommender-system-step-by-step-part-2-alternating-least-square-als-matrix-4a76c58714a1" MODIFIED="1557225479739" TEXT="Alternating Least Square (ALS)">
<node CREATED="1557224068611" ID="ID_483417804" MODIFIED="1557224068611" TEXT="Nov 17 2018  Prototyping a Recommender System Step by Step Part 2: Alternating Least Square (ALS) Matrix Factorization in Collaborative Filtering." />
</node>
<node CREATED="1557224068611" FOLDED="true" ID="ID_418540093" LINK="https://www.quora.com/What-is-the-Alternating-Least-Squares-method-in-recommendation-systems-And-why-does-this-algorithm-work-intuition-behind-this" MODIFIED="1557225479739" TEXT="What is the Alternating Least Squares method in recommendation ">
<node CREATED="1557224068612" ID="ID_1041003745" MODIFIED="1557224068612" TEXT="Alternating Least Squares (ALS) represents a different approach to optimizing the loss function. The key insight is that you can turn the non-convex optimization&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1567479814" LINK="http://stanford.edu/~rezab/classes/cme323/S15/notes/lec14.pdf" MODIFIED="1557225479739" TEXT="14 Matrix Completion via Alternating Least Square(ALS)">
<node CREATED="1557224068612" ID="ID_1567496460" MODIFIED="1557224068612" TEXT="May 13 2015  14 Matrix Completion via Alternating Least Square(ALS)  This approach is known as ALS(Alternating Least Squares). For our objective&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1379712931" LINK="https://ci.apache.org/projects/flink/flink-docs-release-1.2/dev/libs/ml/als.html" MODIFIED="1557225479739" TEXT="Apache Flink 1.2 Documentation: Alternating Least Squares">
<node CREATED="1557224068612" ID="ID_557248037" MODIFIED="1557224068612" TEXT="The alternating least squares (ALS) algorithm factorizes a given matrix R into two factors U and V such that R&#8776;UTV. The unknown row dimension is given as a&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1463040229" LINK="https://datasciencemadesimpler.wordpress.com/tag/alternating-least-squares/" MODIFIED="1557225479739" TEXT="Alternating Least Squares &#8211; Data Science Made Simpler">
<node CREATED="1557224068612" ID="ID_383596492" MODIFIED="1557224068612" TEXT="Posts about Alternating Least Squares written by roireshef." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1488915118" LINK="https://bugra.github.io/work/notes/2014-04-19/alternating-least-squares-method-for-collaborative-filtering/" MODIFIED="1557225479739" TEXT="Alternating Least Squares Method for Collaborative Filtering | Bugra ">
<node CREATED="1557224068612" ID="ID_314197071" MODIFIED="1557224068612" TEXT="Apr 19 2014  Therefore we will adopt an alternating least squares approach with regularization. By doing so we first estimate Y using X and estimate X by&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_796603935" LINK="https://spark.apache.org/docs/latest/mllib-collaborative-filtering.html" MODIFIED="1557225479739" TEXT="Collaborative Filtering - RDD-based API - Spark 2.4.2 Documentation">
<node CREATED="1557224068612" ID="ID_436693679" MODIFIED="1557224068612" TEXT="alternating least squares (ALS)  be used to predict missing entries. spark.mllib uses the alternating least squares (ALS) algorithm to learn these latent factors." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_834556531" LINK="https://medium.com/radon-dev/als-implicit-collaborative-filtering-5ed653ba39fe" MODIFIED="1557225479739" TEXT="ALS Implicit Collaborative Filtering &#8211; Rn Engineering &#8211; Medium">
<node CREATED="1557224068612" ID="ID_725851801" MODIFIED="1557224068612" TEXT="Aug 23 2017  Alternating Least Squares (ALS) is a the model well use to fit our data and find similarities. But before we dive into how it works we should look&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1740301308" LINK="https://www.elenacuoco.com/2016/12/22/alternating-least-squares-als-spark-ml/" MODIFIED="1557225479739" TEXT="Alternating Least Squares (ALS) Spark ML - Elena Cuoco">
<node CREATED="1557224068612" ID="ID_209323873" MODIFIED="1557224068612" TEXT="Dec 22 2016  Using Alternating Least Squares (ALS) algorithm to solve the Santander Kaggle competition 2016. How to recommend the top seven products&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_187863090" LINK="https://en.wikiversity.org/wiki/Least-Squares_Method" MODIFIED="1557225479739" TEXT="Least-Squares Method - Wikiversity">
<node CREATED="1557224068612" ID="ID_229157631" MODIFIED="1557224068612" TEXT="Jan 21 2018  We can also classify these methods further: ordinary least squares (OLS) weighted least squares (WLS) and alternating least squares (ALS)&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_542220959" MODIFIED="1563517391360" TEXT="Fundamentals of Deep Networks">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1563517391360" Folded="true" ID="ID_1640416969" MODIFIED="1563517391360" TEXT="Defining Deep learning">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068596" FOLDED="true" ID="ID_1117623201" MODIFIED="1557225483421" TEXT="Deep Learning#$D$#">
<node CREATED="1557224068596" FOLDED="true" ID="ID_1606748303" LINK="https://en.wikipedia.org/wiki/Deep_learning" MODIFIED="1557225479614" TEXT="Deep learning - Wikipedia">
<node CREATED="1557224068596" ID="ID_1720805530" MODIFIED="1557224068596" TEXT="Deep learning is part of a broader family of machine learning methods based on the layers used in artificial neural networks. Learning can be supervised&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1810764886" LINK="http://deeplearning.net/" MODIFIED="1557225479614" TEXT="Deep Learning">
<node CREATED="1557224068596" ID="ID_1310358674" MODIFIED="1557224068596" TEXT="Deep Learning is a new area of Machine Learning research which has been introduced with the objective of moving Machine Learning closer to one of its&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_932672000" LINK="https://www.mathworks.com/discovery/deep-learning.html" MODIFIED="1557225479614" TEXT="What Is Deep Learning? | How It Works Techniques  Applications ">
<node CREATED="1557224068596" ID="ID_1188425439" MODIFIED="1557224068596" TEXT="Deep learning is a machine learning technique that teaches computers to learn by example. Learn more about deep learning with MATLAB examples and tools." />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1624643423" LINK="https://www.deeplearningbook.org/" MODIFIED="1557225479614" TEXT="Deep Learning">
<node CREATED="1557224068596" ID="ID_1175362372" MODIFIED="1557224068596" TEXT="The Deep Learning textbook is a resource intended to help students and practitioners enter the field of machine learning in general and deep learning in&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_992049899" LINK="https://www.udacity.com/course/intro-to-tensorflow-for-deep-learning--ud187" MODIFIED="1557225479614" TEXT="Intro to TensorFlow for Deep Learning | Udacity">
<node CREATED="1557224068596" ID="ID_881481981" MODIFIED="1557224068596" TEXT="Learn how to build deep learning applications with TensorFlow. This course was developed by the TensorFlow team and Udacity as a practical approach to&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1438912833" LINK="https://developer.nvidia.com/deep-learning" MODIFIED="1557225479614" TEXT="Deep Learning | NVIDIA Developer">
<node CREATED="1557224068596" ID="ID_758129190" MODIFIED="1557224068596" TEXT="Deep learning is a subset of AI and machine learning that uses multi-layered artificial neural networks to deliver state-of-the-art accuracy in tasks such as object&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1509416775" LINK="https://www.technologyreview.com/s/513696/deep-learning/" MODIFIED="1557225479614" TEXT="Deep Learning - MIT Technology Review">
<node CREATED="1557224068596" ID="ID_1983676999" MODIFIED="1557224068596" TEXT="Apr 23 2013  Intelligent Machines. Deep Learning. With massive amounts of computational power machines can now recognize objects and translate&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_951706154" LINK="https://www.forbes.com/sites/bernardmarr/2018/10/01/what-is-deep-learning-ai-a-simple-guide-with-8-practical-examples/" MODIFIED="1557225479614" TEXT="What Is Deep Learning AI? A Simple Guide With 8 Practical Examples">
<node CREATED="1557224068596" ID="ID_360996103" MODIFIED="1557224068596" TEXT="Oct 1 2018  Artificial intelligence machine learning and deep learning are some of the biggest buzzwords around today. This guide provides a simple&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_390667558" LINK="http://neuralnetworksanddeeplearning.com/chap6.html" MODIFIED="1557225479614" TEXT="Neural networks and deep learning">
<node CREATED="1557224068596" ID="ID_1076059465" MODIFIED="1557224068596" TEXT="In the last chapter we learned that deep neural networks are often much harder to train than shallow neural networks. Thats unfortunate since we have good&#160;" />
</node>
<node CREATED="1557224068596" FOLDED="true" ID="ID_1618201244" LINK="https://skymind.ai/wiki/neural-network" MODIFIED="1557225479614" TEXT="A Beginners Guide to Neural Networks and Deep Learning | Skymind">
<node CREATED="1557224068597" ID="ID_1048334232" MODIFIED="1557224068597" TEXT="Deep learning maps inputs to outputs. It finds correlations. It is known as a &#8220;universal approximator&#8221; because it can learn to approximate an unknown function&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_982644902" MODIFIED="1557225483446" TEXT="Defining Deep learning#$D$#">
<node CREATED="1557224068612" FOLDED="true" ID="ID_1795386431" LINK="https://en.wikipedia.org/wiki/Deep_learning" MODIFIED="1557225479739" TEXT="Deep learning - Wikipedia">
<node CREATED="1557224068612" ID="ID_1653663857" MODIFIED="1557224068612" TEXT="Deep learning is part of a broader family of machine learning methods based on the layers .. Deep reinforcement learning has been used to approximate the value of possible direct marketing actions defined in terms of RFM variables." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1452524486" LINK="https://searchenterpriseai.techtarget.com/definition/deep-learning-deep-neural-network" MODIFIED="1557225479739" TEXT="What is deep learning (deep neural network)? - Definition from ">
<node CREATED="1557224068612" ID="ID_1146695438" MODIFIED="1557224068612" TEXT="This definition explains the meaning of deep learning and explains how this  rate depends entirely upon the programmers ability to accurately define a feature&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_69533094" LINK="https://en.wikipedia.org/wiki/Machine_learning" MODIFIED="1557225479739" TEXT="Machine learning - Wikipedia">
<node CREATED="1557224068612" ID="ID_1533817919" MODIFIED="1557224068612" TEXT="Machine learning (ML) is the scientific study of algorithms and statistical models that computer .. The defining characteristic of a rule-based machine learning algorithm is the identification and utilization of a set of relational rules that collectively&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1062628341" LINK="https://www.investopedia.com/terms/d/deep-learning.asp" MODIFIED="1557225479739" TEXT="Deep Learning Definition">
<node CREATED="1557224068612" ID="ID_1372948839" MODIFIED="1557224068612" TEXT="Apr 18 2019  Deep learning is an artificial intelligence function that imitates the workings of the human brain in processing data and creating patterns for use&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1796838913" LINK="https://machinelearningmastery.com/what-is-deep-learning/" MODIFIED="1557225479739" TEXT="What is Deep Learning?">
<node CREATED="1557224068612" ID="ID_1658993292" MODIFIED="1557224068612" TEXT="Aug 16 2016  In the soon to be published book titled &#8220;Deep Learning&#8221; co-authored with Ian Goodfellow and Aaron Courville they define deep learning in&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1403928437" LINK="https://skymind.ai/wiki/neural-network" MODIFIED="1557225479739" TEXT="A Beginners Guide to Neural Networks and Deep Learning | Skymind">
<node CREATED="1557224068612" ID="ID_1607139659" MODIFIED="1557224068612" TEXT="It is a strictly defined term that means more than one hidden layer. In deep-learning networks each layer of nodes trains on a distinct set of features based on the&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_965971853" LINK="https://emerj.com/ai-glossary-terms/what-is-machine-learning/" MODIFIED="1557225479739" TEXT="What is Machine Learning? | Emerj">
<node CREATED="1557224068612" ID="ID_1494301715" MODIFIED="1557224068612" TEXT="Feb 19 2019  We asked 6 machine learning experts (including machine learning godfather Dr. Yoshua Bengio) to define Machine Learning as simply as&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_104127407" LINK="https://medium.com/@anthony_sarkis/how-do-you-define-deep-learning-in-4-steps-9b8308aacafa" MODIFIED="1557225479739" TEXT="How do you define deep learning in 4 steps? &#8211; Anthony Sarkis ">
<node CREATED="1557224068612" ID="ID_1115728989" MODIFIED="1557224068612" TEXT="Jun 11 2018  Given the way the author defined step 4 and the rest of the article I think the author is actually trying to reference deep learning. If thats the&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1785747862" LINK="https://www.techopedia.com/definition/30325/deep-learning" MODIFIED="1557225479739" TEXT="What is Deep Learning? - Definition from Techopedia">
<node CREATED="1557224068612" ID="ID_1890843987" MODIFIED="1557224068612" TEXT="Deep learning is a collection of algorithms used in machine learning used to model high-level abstractions in data through the use of model architectures which&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1364721718" LINK="https://www.sas.com/en_us/insights/analytics/machine-learning.html" MODIFIED="1557225479739" TEXT="Machine Learning: What it is and why it matters | SAS">
<node CREATED="1557224068612" ID="ID_1354294960" MODIFIED="1557224068612" TEXT="Machine learning is a method of data analysis that automates analytical model building. It is a branch of artificial intelligence based on the idea that systems can&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1651589908" MODIFIED="1563517391360" TEXT="Common Architectural Principles of deep networks">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068612" FOLDED="true" ID="ID_616633896" MODIFIED="1557225483446" TEXT="Fundamentals of Deep Networks#$D$#">
<node CREATED="1557224068612" FOLDED="true" ID="ID_1630002499" LINK="https://www.analyticsvidhya.com/blog/2016/03/introduction-deep-learning-fundamentals-neural-networks/" MODIFIED="1557225479739" TEXT="Fundamentals of Deep Learning - Starting with Artificial Neural ">
<node CREATED="1557224068612" ID="ID_581319891" MODIFIED="1557224068612" TEXT="Mar 16 2016  This article explains artificial neural network fundamental of deep learning for beginners. it also explains forward  backward propogation." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_15671333" LINK="https://www.amazon.com/Fundamentals-Deep-Learning-Next-Generation-Intelligence/dp/1491925612" MODIFIED="1557225479739" TEXT="Fundamentals of Deep Learning: Designing Next-Generation ">
<node CREATED="1557224068612" ID="ID_1042539415" MODIFIED="1557224068612" TEXT="With the reinvigoration of neural networks in the 2000s deep learning has become an extremely active area of research one thats paving the way for modern&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_612476351" LINK="http://shop.oreilly.com/product/0636920039709.do" MODIFIED="1557225479739" TEXT="Fundamentals of Deep Learning - OReilly Media">
<node CREATED="1557224068612" ID="ID_460181411" MODIFIED="1557224068612" TEXT="With the reinvigoration of neural networks in the 2000s deep learning has become an extremely active area of research one thats paving the way for modern&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_728561076" LINK="https://www.oreilly.com/library/view/fundamentals-of-deep/9781491925607/" MODIFIED="1557225479739" TEXT="Fundamentals of Deep Learning [Book]">
<node CREATED="1557224068612" ID="ID_64924343" MODIFIED="1557224068612" TEXT="With the reinvigoration of neural networks in the 2000s deep learning has become an extremely active area of research one thats paving the way for modern&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_897466578" LINK="https://www.amazon.com/Fundamentals-Deep-Learning-Next-Generation-Intelligence-ebook/dp/B0728KKXWB" MODIFIED="1557225479739" TEXT="Amazon.com: Fundamentals of Deep Learning: Designing Next ">
<node CREATED="1557224068612" ID="ID_246695091" MODIFIED="1557224068612" TEXT="Editorial Reviews. Book Description. How to Simulate the Mind. About the Author. Nikhil Buduma is a computer science student at MIT with deep interests in&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_37707244" LINK="https://cognitiveclass.ai/courses/introduction-deep-learning/" MODIFIED="1557225479739" TEXT="Deep Learning Fundamentals - Cognitive Class">
<node CREATED="1557224068612" ID="ID_987143996" MODIFIED="1557224068612" TEXT="DeepLearning.TV. Deep Learning Fundamentals. The further one dives into the ocean the more unfamiliar the territory can become. Deep learning at the&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_954986510" LINK="https://simons.berkeley.edu/programs/dl2019" MODIFIED="1557225479739" TEXT="Foundations of Deep Learning | Simons Institute for the Theory of ">
<node CREATED="1557224068612" ID="ID_287877960" MODIFIED="1557224068612" TEXT="Deep learning is the engine powering many of the recent successes of artificial intelligence. These advances stem from a research effort spanning academia&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1563220889" LINK="https://www.researchgate.net/profile/Malini_Chaudhri2/publication/317638461_DEEP_LEARNING_ALGORITHM-zaloni/data/59451d2e0f7e9b6910ee3db1/DEEP-LEARNING-ALGORITHM-zaloni.pdf" MODIFIED="1557225479739" TEXT="Fundamentals of Deep Learning">
<node CREATED="1557224068612" ID="ID_982724995" MODIFIED="1557224068612" TEXT="The OReilly logo is a registered trademark of OReilly Media Inc. Fundamentals of Deep Learning the cover image and related trade dress are trademarks of&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1055158526" LINK="https://www.nvidia.com/en-us/deep-learning-ai/education/" MODIFIED="1557225479739" TEXT="Classes Workshops Training | NVIDIA Deep Learning Institute">
<node CREATED="1557224068612" ID="ID_1958115897" MODIFIED="1557224068612" TEXT="The NVIDIA Deep Learning Institute (DLI) offers hands-on training in AI and  If youre new to deep learning start with Fundamentals to learn how to train and&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1267663445" LINK="http://perso.ens-lyon.fr/jacques.jayez/Cours/Implicite/Fundamentals_of_Deep_Learning.pdf" MODIFIED="1557225479739" TEXT="Fundamentals of Deep Learning">
<node CREATED="1557224068612" ID="ID_1830924629" MODIFIED="1557224068612" TEXT="Fundamentals of Deep Learning. Designing Next-Generation Machine. Intelligence Algorithms with contributions by Nicholas Locascio. Boston Farnham&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1258099791" MODIFIED="1557225483446" TEXT="Common Architectural Principles of deep networks#$D$#">
<node CREATED="1557224068612" FOLDED="true" ID="ID_50127555" LINK="https://www.oreilly.com/library/view/deep-learning/9781491924570/ch04.html" MODIFIED="1557225479739" TEXT="4. Major Architectures of Deep Networks - Deep Learning [Book]">
<node CREATED="1557224068612" ID="ID_1842634473" MODIFIED="1557224068612" TEXT="Major Architectures of Deep Networks The mother art is architecture.  We commonly refer to the sets of weights in a convolutional layer as a filter (or kernel). .. and in principle can compute anything a traditional computer can compute." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1236947863" LINK="https://www.jeremyjordan.me/convnet-architectures/" MODIFIED="1557225479739" TEXT="Common architectures in convolutional neural networks.">
<node CREATED="1557224068612" ID="ID_1348991549" MODIFIED="1557224068612" TEXT="Apr 19 2018  Common architectures in convolutional neural networks.  principles of successively applying convolutional layers to the input  The general architecture is quite similar to LeNet-5 although this model is considerably larger." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1212463191" LINK="https://www.oreilly.com/library/view/getting-started-with/9781492037330/ch02.html" MODIFIED="1557225479739" TEXT="2. Fundamentals of Deep Networks - Getting started with deep ">
<node CREATED="1557224068612" ID="ID_1104856813" MODIFIED="1557224068612" TEXT="Chapter 2. Fundamentals of Deep Networks Now here you see it takes all the running you can do to keep in the same place. If you want to get somewhere ." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1624775867" LINK="https://hub.packtpub.com/top-5-deep-learning-architectures/" MODIFIED="1557225479739" TEXT="Top 5 Deep Learning Architectures | Packt Hub">
<node CREATED="1557224068612" ID="ID_652713024" MODIFIED="1557224068612" TEXT="Jul 24 2018  Convolutional Neural Networks or CNNs in short are the popular  Here is an in-depth look at the CNN Architecture and its working  Autoencoders apply the principle of backpropagation in an unsupervised environment." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1919331806" LINK="https://en.wikipedia.org/wiki/Deep_learning" MODIFIED="1557225479739" TEXT="Deep learning - Wikipedia">
<node CREATED="1557224068612" ID="ID_1554836547" MODIFIED="1557224068612" TEXT="Deep learning is part of a broader family of machine learning methods based on the layers . The principle of elevating raw features over hand-crafted optimization was first explored successfully in the architecture of deep autoencoder on the raw .. Learning in the most common deep architectures is implemented using&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_76017281" LINK="https://cnec.columbia.edu/deep-networks-and-architecture-complexity" MODIFIED="1557225479739" TEXT="Deep Networks and the Architecture of Complexity | Center for ">
<node CREATED="1557224068612" ID="ID_731098160" MODIFIED="1557224068612" TEXT="Fifty years ago Herbert Simon argued that common hierarchical principles govern the organization of many complex interacting systems in physics biology&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_138963940" LINK="https://en.wikipedia.org/wiki/Artificial_neural_network" MODIFIED="1557225479739" TEXT="Artificial neural network - Wikipedia">
<node CREATED="1557224068612" ID="ID_598424822" MODIFIED="1557224068612" TEXT="Artificial neural networks (ANN) or connectionist systems are computing systems vaguely . Once sufficiently many layers have been learned the deep architecture may be used .. Such networks are commonly depicted in the manner shown at the top of the figure  Unfortunately these general principles are ill-defined." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_271575784" LINK="http://neuralnetworksanddeeplearning.com/chap6.html" MODIFIED="1557225479739" TEXT="Neural networks and deep learning">
<node CREATED="1557224068612" ID="ID_110139135" MODIFIED="1557224068612" TEXT="But what if instead of starting with a network architecture which is tabula rasa we used an .. Those programs worked from first principles and got right down into the details of . This is a common pattern in convolutional neural networks." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_613132937" LINK="https://arxiv.org/pdf/1611.00847" MODIFIED="1557225479739" TEXT="Deep Convolutional Neural Network Design Patterns">
<node CREATED="1557224068612" ID="ID_836030591" MODIFIED="1557224068612" TEXT="Nov 14 2016  ray of architecture choices and therefore opt to use an older architecture (i.e.  We ask: Do universal principles of deep network design exist? . A common thread throughout many of the more successful architectures is to&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1425473963" LINK="https://pdfs.semanticscholar.org/5bd4/177440c17dad736f1e0d2227694d612f5a59.pdf" MODIFIED="1557225479739" TEXT="Three Classes of Deep Learning Architectures and Their Applications">
<node CREATED="1557224068612" ID="ID_852216271" MODIFIED="1557224068612" TEXT="Since 2006 deep structured learning or more commonly called deep learning . common to these shallow learning models is the relatively simple architecture . principle SESM may also be used to effectively initialize the. DNN training." />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_941000811" MODIFIED="1563517391360" TEXT="Building blocks of deep networks">
<attribute NAME="Type" VALUE="syllabus_point" />
<node CREATED="1557224068612" FOLDED="true" ID="ID_223537781" MODIFIED="1557225483446" TEXT="Building blocks of deep networks#$D$#">
<node CREATED="1557224068612" FOLDED="true" ID="ID_963369963" LINK="https://www.coursera.org/lecture/neural-networks-deep-learning/building-blocks-of-deep-neural-networks-uGCun" MODIFIED="1557225479739" TEXT="Building blocks of deep neural networks">
<node CREATED="1557224068612" ID="ID_1952159170" MODIFIED="1557224068612" TEXT="Aug 8 2017  Video created by deeplearning.ai for the course Neural Networks and Deep Learning. Understand the key computations underlying deep&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_576640018" LINK="https://www.cs.cmu.edu/~epxing/Class/10708-17/notes-17/10708-scribe-lecture18.pdf" MODIFIED="1557225479739" TEXT="18 : An Overview of Deep Learning building blocks 1 An overview of ">
<node CREATED="1557224068612" ID="ID_1248879832" MODIFIED="1557224068612" TEXT="18 : An Overview of Deep Learning building blocks. Lecturer: Maruan Al-Shedivat. Scribes: Lisa Lee Chaoyang Wang. 1 An overview of the DL components." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1345157346" LINK="http://deepdish.io/2015/11/21/building-blocks-of-deep-learning/" MODIFIED="1557225479739" TEXT="The building blocks of Deep Learning &#183; Deep learning at the ">
<node CREATED="1557224068612" ID="ID_695746718" MODIFIED="1557224068612" TEXT="The building blocks of Deep Learning. 21 Nov 2015 Gustav Larsson. A feed-forward network is built up of nodes that make a directed acyclic graph (DAG)." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_524896492" LINK="https://medium.com/@culurciello/neural-networks-building-blocks-a5c47bcd7c8d" MODIFIED="1557225479739" TEXT="Neural Networks Building Blocks &#8211; Eugenio Culurciello &#8211; Medium">
<node CREATED="1557224068612" ID="ID_770880104" MODIFIED="1557224068612" TEXT="Nov 1 2017  Neural networks are made of smaller modules or building blocks similarly to atoms in matter and logic gates in digital circuits. Once you know&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_345866663" LINK="https://www.tutorialspoint.com/artificial_neural_network/artificial_neural_network_building_blocks.htm" MODIFIED="1557225479739" TEXT="Artificial Neural Network Building Blocks">
<node CREATED="1557224068612" ID="ID_32344052" MODIFIED="1557224068612" TEXT="Artificial Neural Network Building Blocks - Learn Artificial Neural Network in simple and easy steps starting from basic to advanced concepts with examples&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1472109599" LINK="https://hackernoon.com/mcculloch-pitts-neuron-deep-learning-building-blocks-7928f4e0504d" MODIFIED="1557225479739" TEXT="McCulloch Pitts Neuron &#8212; Deep Learning Building Blocks">
<node CREATED="1557224068612" ID="ID_320189696" MODIFIED="1557224068612" TEXT="Feb 15 2019  The fundamental block of deep learning is artificial neuron i.e. it takes a weighted aggregate of inputs applies a function and gives an output." />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1651574752" LINK="https://towardsdatascience.com/residual-blocks-building-blocks-of-resnet-fd90ca15d6ec" MODIFIED="1557225479739" TEXT="Residual blocks &#8212; Building blocks of ResNet &#8211; Towards Data Science">
<node CREATED="1557224068612" ID="ID_859771347" MODIFIED="1557224068612" TEXT="Nov 27 2018  Understanding a residual block is quite easy. In traditional neural networks each layer feeds into the next layer. In a network with residual&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1219658496" LINK="https://www.oreilly.com/library/view/deep-learning-with/9781788624336/5a68470a-8fdb-4dc8-9613-e38a9b4354d5.xhtml" MODIFIED="1557225479739" TEXT="Building Blocks of Neural Networks - Deep Learning with PyTorch ">
<node CREATED="1557224068612" ID="ID_1775741587" MODIFIED="1557224068612" TEXT="Building Blocks of Neural Networks Understanding the basic building blocks of a neural network such as tensors tensor operations and gradient descents&#160;" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_387125617" LINK="https://www.youtube.com/watch?v=lICRfM2UeOo" MODIFIED="1557225479739" TEXT="The Building Blocks of Deep Learning - YouTube">
<node CREATED="1557224068612" ID="ID_1997310253" MODIFIED="1557224068612" TEXT="Sep 2 2018  Neural networks at their most basic.  The Building Blocks of Deep Learning. Mike Bernico. Loading Unsubscribe from Mike Bernico? Cancel" />
</node>
<node CREATED="1557224068612" FOLDED="true" ID="ID_1792290389" LINK="https://distill.pub/2018/building-blocks" MODIFIED="1557225479739" TEXT="The Building Blocks of Interpretability">
<node CREATED="1557224068612" ID="ID_388288820" MODIFIED="1557224068612" TEXT="Mar 6 2018  With the growing success of neural networks there is a corresponding need to be able to explain their decisions &#8212; including building&#160;" />
</node>
<icon BUILTIN="stop-sign" /></node>
</node>
<node CREATED="1563517391360" Folded="true" ID="ID_1500239675" MODIFIED="1563517391360" TEXT="Cheatsheet">
<attribute NAME="Type" VALUE="syllabus_point" />
</node>
</node>
</node>
</node>
</map>